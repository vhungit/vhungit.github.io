System.register("chunks:///_virtual/PopupQuitFindGame.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Popup.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, _decorator, Popup, GameMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "06b6bKyWBNEBJBBJVZWywU6", "PopupQuitFindGame", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PopupQuitFindGame = exports('PopupQuitFindGame', (_dec = ccclass('PopupQuitFindGame'), _dec2 = property(Button), _dec3 = property(Button), _dec(_class = (_class2 = (_temp = class PopupQuitFindGame extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnContinue", _descriptor, this);

          _initializerDefineProperty(this, "btnCancel", _descriptor2, this);
        }

        start() {
          super.start();
          this.btnContinue.node.on("click", this.onContinueClick, this);
          this.btnCancel.node.on("click", this.onCancelClick, this);
        }

        onContinueClick() {
          this.OnCloseClick();
        }

        onCancelClick() {
          this.OnCloseClick();
          GameMgr.Instance.initRoom();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnContinue", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnCancel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/EndGame.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './AppBridge.ts', './Define.ts', './EventListener.ts', './Profile.ts', './AudioMgr.ts', './MaxApiUtils.ts', './LeaderBoardItem.ts', './TextDefine.ts', './Screen.ts', './MapMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, Label, Node, ScrollView, _decorator, director, view, AppBridge, EventName, SoundName, Features, EventListener, Profile, AudioMgr, MaxApiUtils, LeaderBoardItem, Text, Screen, MapMgr, GameMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      Node = module.Node;
      ScrollView = module.ScrollView;
      _decorator = module._decorator;
      director = module.director;
      view = module.view;
    }, function (module) {
      AppBridge = module.AppBridge;
    }, function (module) {
      EventName = module.EventName;
      SoundName = module.SoundName;
      Features = module.Features;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      LeaderBoardItem = module.LeaderBoardItem;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      MapMgr = module.MapMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _class3, _temp;

      cclegacy._RF.push({}, "075dfMbaQZMf7vO5SZlTpGh", "EndGame", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let EndGame = exports('EndGame', (_dec = ccclass('EndGame'), _dec2 = property(Button), _dec3 = property(Button), _dec4 = property(Button), _dec5 = property(Button), _dec6 = property(Label), _dec7 = property(Label), _dec8 = property(Label), _dec9 = property(Label), _dec10 = property(Label), _dec11 = property(Node), _dec12 = property(Node), _dec13 = property(Node), _dec14 = property(ScrollView), _dec(_class = (_class2 = (_temp = _class3 = class EndGame extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnClose", _descriptor, this);

          _initializerDefineProperty(this, "btnContinue", _descriptor2, this);

          _initializerDefineProperty(this, "btnShare", _descriptor3, this);

          _initializerDefineProperty(this, "btnHoiCho", _descriptor4, this);

          _initializerDefineProperty(this, "rewardText", _descriptor5, this);

          _initializerDefineProperty(this, "rankText", _descriptor6, this);

          _initializerDefineProperty(this, "lableTurn", _descriptor7, this);

          _initializerDefineProperty(this, "tooltipText", _descriptor8, this);

          _initializerDefineProperty(this, "btnHoiChoText", _descriptor9, this);

          _initializerDefineProperty(this, "btnContinueLoadingIcon", _descriptor10, this);

          _initializerDefineProperty(this, "btnContinueContent", _descriptor11, this);

          _initializerDefineProperty(this, "leaderBoardContent", _descriptor12, this);

          _initializerDefineProperty(this, "scrollView", _descriptor13, this);

          _defineProperty(this, "isCapture", false);

          _defineProperty(this, "captureCallback", null);
        }

        onLoad() {
          EndGame.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onBlanceTurn, this.onBlanceTurn, this);
          this.btnContinue.node.on("click", this.onContinueClick, this);
          this.btnShare.node.on("click", this.onShareFBClick, this);
          this.btnClose.node.on("click", this.onCloseClick, this);
          this.btnHoiCho.node.on("click", this.onHoiChoClick, this);
          director.on("director_after_draw", this.canvasAfterDraw.bind(this));
        }

        update(dt) {}

        show() {
          super.show();
          this.updateInfo();
          this.showLoadingBtnContinue(true);
          GameMgr.Instance.refreshBalance();
          this.lableTurn.string = `Tốn ${MapMgr.Intance.mapConfig.matchingPrice} lượt chơi`;
          this.tooltipText.string = Profile.Instance.IsOnboarding ? Text.tooltipTextOB : Text.tooltipTextNormal;
          this.btnHoiChoText.string = Profile.Instance.IsOnboarding ? "Khám phá Lắc Xì" : "Đến hội chợ";
          MaxApiUtils.trackEvent({
            stage: 'pu_reward',
            is_new_user: Profile.Instance.IsOnboarding
          });
        }

        static get Instance() {
          return EndGame.instance;
        }

        onBlanceTurn(value) {
          this.showLoadingBtnContinue(false);
        }

        onContinueClick() {
          if (!this.btnContinueLoadingIcon.active) {
            MaxApiUtils.trackEvent({
              action: 'click_play_pu_reward',
              is_new_user: Profile.Instance.IsOnboarding
            });
            GameMgr.Instance.findRoom();
          }
        }

        onCloseClick() {
          GameMgr.Instance.initRoom();
        }

        showLoadingBtnContinue(value) {
          this.btnContinueLoadingIcon.active = value;
          this.btnContinueContent.active = !value;
        }

        updateInfo() {
          let playerIndex = EndGame.result.players.findIndex(p => p == Profile.Instance.Uid);

          if (playerIndex != -1 && EndGame.result.rewards[playerIndex]) {
            this.rewardText.string = EndGame.result.rewards[playerIndex].toString();

            if (EndGame.result.ranking[playerIndex] >= 0) {
              this.rankText.string = "Hạng " + (EndGame.result.ranking[playerIndex] + 1).toString();
              AudioMgr.Instance.PlaySfx(SoundName.EndGameWin);
            } else {
              this.rankText.string = "Bạn chưa hoàn thành màn chơi";
              AudioMgr.Instance.PlaySfx(SoundName.EndGameLost);
            }
          }

          EndGame.result.ranking.forEach((rank, index) => {
            this.leaderBoardContent.children[index].getComponent(LeaderBoardItem).setInfo(EndGame.result.players[index], rank, MapMgr.Intance.getPlayerName(EndGame.result.players[index]), EndGame.result.rewards[index]);
            this.leaderBoardContent.children[index].active = MapMgr.Intance.getPlayer(EndGame.result.players[index]).node.active;
          });
          this.scrollView.scrollToTop();
        }

        onShareFBClick() {
          MaxApiUtils.trackEvent({
            action: 'click_share_pu_reward',
            is_new_user: Profile.Instance.IsOnboarding
          }); //  this.captureScreen((imageCap: string) => {
          //      AppBridge.Instance.onShare({image: imageCap});
          //      MaxApiUtils.trackEvent({stage: 'scr_share_squid_game'});
          //  });

          let playerIndex = EndGame.result.players.findIndex(p => p == Profile.Instance.Uid);

          if (playerIndex != -1 && EndGame.result.rewards[playerIndex]) {
            AppBridge.Instance.onShare({
              candy: EndGame.result.rewards[playerIndex],
              rank: EndGame.result.ranking[playerIndex]
            });
          }
        }

        canvasAfterDraw() {
          if (this.isCapture) {
            this.isCapture = false;
            let canvas = document.getElementById("GameCanvas");
            var resizedCanvas = document.createElement("canvas");
            var resizedContext = resizedCanvas.getContext("2d");
            let w = view.getVisibleSize().width;
            let h = view.getVisibleSize().height;
            resizedCanvas.width = w;
            resizedCanvas.height = h;
            resizedContext.drawImage(canvas, 0, 0, w, h, 0, 0, w, h); // let c = TrimBase64.trimCanvas(resizedCanvas);

            let image = canvas.toDataURL('image/png');
            this.captureCallback(image);
            document.removeChild(resizedCanvas);
          }
        }

        captureScreen(callback) {
          this.captureCallback = callback;
          this.isCapture = true;
        }

        onHoiChoClick() {
          if (Profile.Instance.IsOnboarding) {
            MaxApiUtils.startFeatureCode(Features.HomePage.refId, Features.HomePage.params, () => {});
          } else {
            MaxApiUtils.startFeatureCode(Features.HoiCho.refId, Features.HoiCho.params, () => {});
          }
        }

      }, _defineProperty(_class3, "instance", null), _defineProperty(_class3, "result", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnClose", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnContinue", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnShare", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btnHoiCho", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "rewardText", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "rankText", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "lableTurn", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "tooltipText", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "btnHoiChoText", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "btnContinueLoadingIcon", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "btnContinueContent", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "leaderBoardContent", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "scrollView", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Popup.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Button, Node, _decorator, Component, Vec3, tween;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      tween = module.tween;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "113e5qtNpZJR4qFFlM73Kmf", "Popup", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Popup = exports('Popup', (_dec = ccclass('Popup'), _dec2 = property(Button), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class Popup extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnClose", _descriptor, this);

          _initializerDefineProperty(this, "container", _descriptor2, this);

          _defineProperty(this, "onClose", null);
        }

        start() {
          this.btnClose.node.on("click", this.OnCloseClick.bind(this));
        }

        OnCloseClick() {
          if (this.onClose) {
            this.onClose();
          }

          this.Hide();
        }

        Show(autoHide = false) {
          this.node.active = true;
          this.container.setScale(Vec3.ZERO);
          tween(this.container).to(0.5, {
            scale: new Vec3(1, 1, 1)
          }, {
            easing: "bounceInOut"
          }).start();

          if (autoHide) {
            setTimeout(() => {
              this.Hide();
            }, 3000);
          }
        }

        Hide(shouldRemove = true) {
          this.node.active = false;

          if (shouldRemove) {
            this.node.removeFromParent();
            this.node.destroy();
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnClose", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AudioMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Utils.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, AudioSource, SoundName, Utils;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      AudioSource = module.AudioSource;
    }, function (module) {
      SoundName = module.SoundName;
    }, function (module) {
      Utils = module.Utils;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "1268aruiMJMSbuwaNTXSCd4", "AudioMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AudioMgr = exports('AudioMgr', (_dec = ccclass('AudioMgr'), _dec(_class = (_temp = _class2 = class AudioMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "audioClips", []);

          _defineProperty(this, "bgVolume", 0.4);

          _defineProperty(this, "sfxVolume", 0.7);

          _defineProperty(this, "audioSourceSFX", null);

          _defineProperty(this, "audioSourceMusic", null);

          _defineProperty(this, "IsEnable", true);
        }

        static get Instance() {
          return this.instance;
        }

        onLoad() {
          AudioMgr.instance = this;
          this.audioSourceSFX = this.addComponent(AudioSource);
          this.audioSourceSFX.loop = false;
          this.audioSourceSFX.volume = this.sfxVolume;
          this.audioSourceMusic = this.addComponent(AudioSource);
          this.audioSourceMusic.play(); // this.Load();
        }

        PlayOneShot(clip, isOneShot = false) {
          if (this.audioSourceSFX.playing) {
            this.audioSourceSFX.stop();
          }

          if (clip && this.IsEnable) {
            if (!isOneShot) {
              this.audioSourceSFX.clip = clip;
              this.audioSourceSFX.play();
            } else {
              this.audioSourceSFX.playOneShot(clip);
            }
          }
        }

        PlayMusic(clip, loop) {
          if (clip && this.IsEnable) {
            if (this.audioSourceMusic.clip != clip || !this.audioSourceMusic.playing) {
              this.Stop();
              this.audioSourceMusic.clip = clip;
              this.audioSourceMusic.loop = loop;
              this.On();
              this.audioSourceMusic.volume = this.bgVolume;
              this.audioSourceMusic.play();
            }
          }
        }

        Stop() {
          this.audioSourceMusic.stop();
        }

        Start() {
          this.audioSourceMusic.play();
        }

        Load(boundle) {
          //load sound
          let array = Object.keys(SoundName);
          array.forEach(element => {
            let name = SoundName[element];
            Utils.getAudioBoundle(boundle, "sounds/" + name, audioClip => {
              if (audioClip) {
                audioClip.name = name;
                this.audioClips.push(audioClip);
                console.log("Sound load: " + name); // if(name == SoundName.Bg)
                // {
                //     this.PlayMusicWithName(SoundName.Bg, true);
                // }
              } else {
                console.error("Sound notfound: " + name);
              }
            });
          });
        }

        PlaySfx(name, isOneShot = false) {
          let clip = this.audioClips.find(clip => clip.name == name);

          if (clip) {
            this.PlayOneShot(clip, isOneShot);
          }
        }

        StopSfx(name) {
          this.audioClips.forEach(clip => {
            if (clip.name == name && this.audioSourceSFX.clip == clip) {
              if (this.audioSourceSFX.playing) {
                this.audioSourceSFX.stop();
              }
            }

            return;
          });
        }

        PlayMusicWithName(name, loop) {
          this.audioClips.forEach(clip => {
            if (clip.name == name) {
              this.PlayMusic(clip, loop);
            }

            return;
          });
        }

        On() {
          this.IsEnable = true;
          this.Start();
        }

        Off() {
          this.IsEnable = false;
          this.Stop();
        }

        NextStatus() {
          this.IsEnable = !this.IsEnable;

          if (this.IsEnable) {
            this.On();
          } else {
            this.Off();
          }
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Init.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './Profile.ts', './MaxApiUtils.ts', './Screen.ts', './ScreenMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, Label, Node, _decorator, EventName, ScreenName, EventListener, Profile, MaxApiUtils, Screen, ScreenMgr, GameMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
    }, function (module) {
      EventName = module.EventName;
      ScreenName = module.ScreenName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _class3, _temp;

      cclegacy._RF.push({}, "15bf0IFcE1MgLjql0H6SAEo", "Init", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Init = exports('Init', (_dec = ccclass('Init'), _dec2 = property(Button), _dec3 = property(Label), _dec4 = property(Node), _dec5 = property(Node), _dec6 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class Init extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnStart", _descriptor, this);

          _initializerDefineProperty(this, "lableTurn", _descriptor2, this);

          _initializerDefineProperty(this, "loadingIcon", _descriptor3, this);

          _initializerDefineProperty(this, "buttonContent", _descriptor4, this);

          _initializerDefineProperty(this, "tooltip", _descriptor5, this);
        }

        onLoad() {
          Init.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onGameDefine, this.onGameDefineUpdate, this);
          EventListener.Instance.on(EventName.onOnboaringStatus, this.onOnboaringStatus, this);
          this.btnStart.node.on("click", this.onContinueClick, this);
          this.setEnableButton(false);
          this.tooltip.active = false;
        }

        show() {
          super.show();
          this.setEnableButton(false);
        }

        update(dt) {}

        static get Instance() {
          return Init.instance;
        }

        onDone() {
          ScreenMgr.Instance.hideAll();
          ScreenMgr.Instance.Show(ScreenName.InGame);
        }

        onContinueClick() {
          MaxApiUtils.trackEvent({
            action: 'click_start_game',
            is_new_user: Profile.Instance.IsOnboarding,
            is_home_momo: Profile.Instance.IsHomeMomo,
            is_no_turn: Profile.Instance.turn == 0
          });
          window.realtimeSinceClickStart = Date.now();
          GameMgr.Instance.joinGame();
        }

        onGameDefineUpdate(define) {
          this.lableTurn.string = `Tốn ${define.matchingPrice} lượt chơi`;
          this.setEnableButton(true);
        }

        setEnableButton(value) {
          this.btnStart.interactable = value; // this.btnStart.getComponent(Sprite).grayscale = !value;
          // this.btnStart.getComponentsInChildren(Sprite).forEach(sprite => {
          //     sprite.grayscale = !value;
          // });

          this.loadingIcon.active = !value;
          this.buttonContent.active = value;
        }

        onOnboaringStatus(isOnboarding) {
          this.tooltip.active = isOnboarding;
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnStart", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lableTurn", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "loadingIcon", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "buttonContent", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "tooltip", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LostConnection.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Popup.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, _decorator, Popup;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      Popup = module.Popup;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "1852biOOpdM/IWHb7CVSJZe", "LostConnection", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let LostConnection = exports('LostConnection', (_dec = ccclass('LostConnection'), _dec2 = property(Button), _dec(_class = (_class2 = (_temp = class LostConnection extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnMoreTurn", _descriptor, this);
        }

        start() {
          super.start();
          this.btnMoreTurn.node.on("click", this.onMoreTurnClick, this);
        }

        onMoreTurnClick() {
          this.OnCloseClick();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnMoreTurn", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/NotifyMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Notify.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, instantiate, resources, NotifyName, Notify;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      instantiate = module.instantiate;
      resources = module.resources;
    }, function (module) {
      NotifyName = module.NotifyName;
    }, function (module) {
      Notify = module.Notify;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "1956cPsurpDrKKhDGK3FN61", "NotifyMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let NotifyMgr = exports('NotifyMgr', (_dec = ccclass('NotifyMgr'), _dec(_class = (_temp = _class2 = class NotifyMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "prefabs", []);
        }

        onLoad() {
          NotifyMgr.instance = this;
        }

        start() {
          this.Load();
        }

        static get Instance() {
          return NotifyMgr.instance;
        }

        showAt(name, pos, str) {
          let prefab = this.prefabs.find(prefab => prefab.data.name == name);

          if (prefab) {
            let notify = instantiate(prefab).getComponent(Notify);
            notify.node.setParent(this.node);
            notify.node.name = name;
            notify.showAt(pos, str);
            return notify;
          }
        }

        show(name, str) {
          let prefab = this.prefabs.find(prefab => prefab.data.name == name);

          if (prefab) {
            let notify = instantiate(prefab).getComponent(Notify);
            notify.node.setParent(this.node);
            notify.node.name = name;
            notify.show(str);
            return notify;
          }
        }

        Load() {
          let array = Object.keys(NotifyName);
          array.forEach(element => {
            resources.load("prefabs/notify/" + element, (err, prefab) => {
              if (prefab) {
                this.prefabs.push(prefab);
                console.log("Notify loaded: " + element);
              } else {
                console.error("Notify loade fail: " + element);
              }
            });
          });
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/EventListener.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, EventTarget;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      EventTarget = module.EventTarget;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "1ca1cfU43pFM64dVb9njsy1", "EventListener", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let EventListener = exports('EventListener', (_dec = ccclass("EventListener"), _dec(_class = (_temp = _class2 = class EventListener extends EventTarget {
        static get Instance() {
          if (this.instance == null) {
            this.instance = new EventListener();
          }

          return this.instance;
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './AppBridge.ts', './Define.ts', './EventListener.ts', './Profile.ts', './Utils.ts', './AudioMgr.ts', './MaxApiUtils.ts', './NetworkDefine.ts', './PopupMgr.ts', './TimeMgr.ts', './NetworkBrigde.ts', './Boss.ts', './Input.ts', './InGame.ts', './EffectMgr.ts', './MapMgr.ts', './EndGame.ts', './ScreenMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, _decorator, Component, AppBridge, EventName, PopupName, Features, ScreenName, EventListener, Profile, Utils, AudioMgr, MaxApiUtils, NetworkDefine, WSCmd, PopupMgr, TimeMgr, NetworkBrigde, Boss, Input, InGame, EffectMgr, MapMgr, EndGame, ScreenMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      AppBridge = module.AppBridge;
    }, function (module) {
      EventName = module.EventName;
      PopupName = module.PopupName;
      Features = module.Features;
      ScreenName = module.ScreenName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      NetworkDefine = module.NetworkDefine;
      WSCmd = module.WSCmd;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      NetworkBrigde = module.NetworkBrigde;
    }, function (module) {
      Boss = module.Boss;
    }, function (module) {
      Input = module.Input;
    }, function (module) {
      InGame = module.InGame;
    }, function (module) {
      EffectMgr = module.EffectMgr;
    }, function (module) {
      MapMgr = module.MapMgr;
    }, function (module) {
      EndGame = module.EndGame;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "23526LZJ8FFNLKcD+3Pr7aj", "GameMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Init"] = 1] = "Init";
        State[State["GetConfig"] = 2] = "GetConfig";
        State[State["CheckToken"] = 3] = "CheckToken";
        State[State["CheckOnboarding"] = 4] = "CheckOnboarding";
        State[State["Connecting"] = 5] = "Connecting";
        State[State["Authentication"] = 6] = "Authentication";
        State[State["FindRoom"] = 7] = "FindRoom";
        State[State["GetRoomConfig"] = 8] = "GetRoomConfig";
        State[State["LoadGame"] = 9] = "LoadGame";
        State[State["Lobby"] = 10] = "Lobby";
        State[State["Wating"] = 11] = "Wating";
        State[State["Start"] = 12] = "Start";
        State[State["Playing"] = 13] = "Playing";
        State[State["EndGame"] = 14] = "EndGame";
        State[State["NetworkError"] = 15] = "NetworkError";
      })(State || (State = {}));

      let GameMgr = exports('GameMgr', (_dec = ccclass('GameMgr'), _dec2 = property(Boss), _dec(_class = (_class2 = (_temp = _class3 = class GameMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "boss", _descriptor, this);

          _defineProperty(this, "state", State.None);

          _defineProperty(this, "networkBrigde", new NetworkBrigde());

          _defineProperty(this, "time", 0);

          _defineProperty(this, "matchTime", 0);

          _defineProperty(this, "startTime", Date.now());

          _defineProperty(this, "autoJoinGame", false);

          _defineProperty(this, "getCongifDone", false);

          _defineProperty(this, "trackingFindMatchStartTime", 0);

          _defineProperty(this, "currentGameID", "");
        }

        static get Instance() {
          return GameMgr.instance;
        }

        onLoad() {
          GameMgr.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onLostConnection, this.onLostConnection, this);

          if (window.OnHideLoading) {
            window.OnHideLoading();
            this.startTime = Date.now();
          }

          this.SetState(State.Init);
        }

        onDestroy() {
          this.networkBrigde.disconnect();
        }

        update(dt) {
          var _InGame$Instance;

          switch (this.state) {
            case State.GetConfig:
              this.time += dt;

              if (this.time > 3) {
                if (NetworkDefine.IsDev) {
                  this.SetState(State.CheckToken);
                } else {
                  this.SetState(State.NetworkError);
                }
              }

              break;

            case State.CheckToken:
              this.time += dt;

              if (Profile.Instance.iSOk) {
                this.SetState(State.CheckOnboarding);
              } else if (this.time > 3) {
                if (NetworkDefine.IsDev) {
                  Profile.Instance.OnUpdateUserInfo(null);
                } else {
                  this.SetState(State.NetworkError);
                }
              }

              break;

            case State.Connecting:
              this.time += dt;

              if (this.time > 10) {
                this.SetState(State.NetworkError);
              } else if (this.networkBrigde.isReady) {
                this.SetState(State.Authentication);
              }

              break;

            case State.LoadGame:
              if (MapMgr.Intance.isReady()) {
                this.SetState(State.Lobby);
              }

              break;

            case State.Lobby:
              break;

            case State.Wating:
              let waitingTime = MapMgr.Intance.mapInfo.startTime - TimeMgr.instance.serverTime;
              EventListener.Instance.emit(EventName.onWaiting, waitingTime);

              if (waitingTime <= 0) {
                this.SetState(State.Playing);
              }

              break;

            case State.Playing:
              MapMgr.Intance.gameUpdate(dt);
              (_InGame$Instance = InGame.Instance) === null || _InGame$Instance === void 0 ? void 0 : _InGame$Instance.updateMatchTime(this.matchTime - TimeMgr.instance.serverTime);
              break;

            case State.EndGame:
              break;
          }
        }

        SetState(state) {
          console.log(`[GameMgr] state: ${State[this.state]} => ${State[state]}`);
          this.state = state;

          switch (state) {
            case State.Init:
              ScreenMgr.Instance.Load();
              AppBridge.Instance.getSoundSetting(response => {
                if (response != null) {
                  response.isSfxOn ? AudioMgr.Instance.On() : AudioMgr.Instance.Off();
                }
              });
              MaxApiUtils.GetDeviceInfo().then(res => {
                if (res) {
                  Profile.Instance.devicePerformance = res.devicePerformance;
                  Profile.Instance.SetNormalFps();
                }
              }).catch(e => {});
              this.SetState(State.GetConfig);
              break;

            case State.GetConfig:
              this.time = 0;
              AppBridge.Instance.getConfig(response => {
                NetworkDefine.UpdateEnvironment(response.env);
                this.networkBrigde.servers = response.servers;
                Profile.Instance.IsHomeMomo = response.callFrom != "lixi_2022";
                this.SetState(State.CheckToken);
                MaxApiUtils.trackEvent({
                  stage: 'scr_squid_game',
                  is_home_momo: Profile.Instance.IsHomeMomo
                });
              });
              AppBridge.Instance.getCoinBalance(res => {
                if (res) {
                  let {
                    balanceMoney,
                    currentChallenge,
                    totalChanllenge
                  } = res;
                  EventListener.Instance.emit(EventName.onBlanceCoin, balanceMoney, currentChallenge, totalChanllenge);
                }
              });
              break;

            case State.CheckToken:
              this.initNetwork();
              this.time = 0;
              MaxApiUtils.GetProfile().then(res => {
                Profile.Instance.OnUpdateUserInfo(res);
              });
              console.log("[GameMgr] CheckToken: ", NetworkDefine.IsDev);
              break;

            case State.CheckOnboarding:
              this.checkOnboarding(isOnboarding => {
                this.SetState(State.Connecting);
              });
              break;

            case State.Connecting:
              this.time = 0;
              break;

            case State.Authentication:
              this.networkBrigde.authentication(Profile.Instance.UserToken);
              break;

            case State.FindRoom:
              this.trackingFindMatchStartTime = TimeMgr.instance.serverTime;
              AudioMgr.Instance.Stop();
              MapMgr.Intance.reset();
              this.networkBrigde.findRoom();

              if (this.autoJoinGame) {
                ScreenMgr.Instance.hideAll();
                ScreenMgr.Instance.Show(ScreenName.Lobby);
              } else {
                ScreenMgr.Instance.hideAll();
                ScreenMgr.Instance.Show(ScreenName.Init);
              }

              break;

            case State.GetRoomConfig:
              this.refreshBalance();
              this.networkBrigde.reqDefines();
              break;

            case State.LoadGame:
              ScreenMgr.Instance.hideAll();
              ScreenMgr.Instance.Show(ScreenName.Lobby);
              break;

            case State.Lobby:
              this.networkBrigde.joinGame(this.currentGameID);
              ScreenMgr.Instance.hideAll();
              ScreenMgr.Instance.Show(ScreenName.Lobby);
              break;

            case State.Wating:
              MaxApiUtils.trackEvent({
                stage: 'scr_find_match',
                loading_time: TimeMgr.instance.serverTime - this.trackingFindMatchStartTime
              });
              PopupMgr.Instance.hideAll();
              ScreenMgr.Instance.hideAll();
              ScreenMgr.Instance.Show(ScreenName.Waiting);
              break;

            case State.Playing:
              MapMgr.Intance.init();
              MapMgr.Intance.show(true);
              Input.Instance.reset();
              EffectMgr.instance.hideAll();
              this.matchTime = MapMgr.Intance.getEndGameTime(); // InGame.Instance.updateMapConfig();

              ScreenMgr.Instance.hideAll();
              ScreenMgr.Instance.Show(ScreenName.InGame); // this.resume();

              break;
            // case State.Pause:
            //     this.pause();
            //     break;

            case State.EndGame:
              // this.pause();
              AudioMgr.Instance.Stop();
              PopupMgr.Instance.hideAll();
              ScreenMgr.Instance.hideAll();
              ScreenMgr.Instance.Show(ScreenName.EndGame);
              break;

            case State.NetworkError:
              PopupMgr.Instance.Show(PopupName.NetworkError, () => {
                MaxApiUtils.startFeatureCode(Features.HomePage.refId, Features.HomePage.params, () => {});
              });
              break;
          }
        }

        initNetwork() {
          this.networkBrigde.connect();
          this.networkBrigde.onMessage = this.onMessage.bind(this);
        }

        onMessage(msg) {
          if (msg.msgClass != WSCmd.KrunMsg && msg.msgClass != WSCmd.MsgPing) {
            console.log("[GameMgr] onMessage", msg);
          }

          switch (msg.msgClass) {
            case WSCmd.ResVerify:
              let verify = tigers.krun.internal.ResVerify.decode(msg.msg);
              Profile.Instance.Uid = verify.uid;
              Profile.Instance.UserName = verify.displayName;
              this.SetState(State.FindRoom);
              console.log("[GameMgr] ResVerify: ", verify);
              break;

            case WSCmd.MsgPing:
              let ping = tigers.krun.internal.MsgPing.decode(msg.msg);
              let value = Date.now() - ping.createAt;
              EventListener.Instance.emit(EventName.onPing, ping.workerAt + value / 2, value);
              console.log("[GameMgr] ping: ", value);
              break;

            case WSCmd.ResWorker:
              this.SetState(State.GetRoomConfig);
              break;

            case WSCmd.KrunMsg:
              this.onGameMsg(msg.msg);
              break;
          }
        }

        onGameMsg(data) {
          let msg = tigers.krun.KrunMsg.decode(data);

          if (msg.error != tigers.krun.KRUN_ERROR.KRUN_ERROR_NONE) {
            console.log("[GameMgr] ongameMsg Error: ", msg);

            switch (msg.error) {
              case tigers.krun.KRUN_ERROR.KRUN_ERROR_MATCHING_FAIL:
              case tigers.krun.KRUN_ERROR.KRUN_ERROR_MATCHING_TIMEOUT:
                EventListener.Instance.emit(EventName.onMatchingFailed);
                break;

              case tigers.krun.KRUN_ERROR.KRUN_ERROR_MATCHING_NOT_ENOUGH_PRICE:
                EventListener.Instance.emit(EventName.onOutOfTurn);
                break;
            }

            return;
          } else {
            switch (msg.cmd) {
              case tigers.krun.KRUN_CMD.KRUN_CMD_GAME_MATCHING:
                let matchingInfo = tigers.krun.KrunGameMatching.decode(msg.body);
                console.log("[GameMgr] matchingInfo: ", matchingInfo);
                EventListener.Instance.emit(EventName.onMatchingInfo, matchingInfo);
                this.currentGameID = matchingInfo.gameId;
                this.SetState(State.Wating);
                break;

              case tigers.krun.KRUN_CMD.KRUN_CMD_DEFINES:
                let gamedefine = tigers.krun.KrunGameDefines.decode(msg.body);
                EventListener.Instance.emit(EventName.onGameDefine, gamedefine);

                if (this.autoJoinGame) {
                  this.SetState(State.Lobby);
                }

                console.log("[GameMgr] room define: ", gamedefine);
                break;

              case tigers.krun.KRUN_CMD.KRUN_CMD_GAME_UPDATE:
                let info = tigers.krun.KrunGameUpdate.decode(msg.body);
                MapMgr.Intance.netUpdate(info);
                break;

              case tigers.krun.KRUN_CMD.KRUN_CMD_GAME_END:
                let endinfo = tigers.krun.KrunGameEnd.decode(msg.body);
                console.log("[GameMgr] endgame: ", endinfo);
                EndGame.result = endinfo;
                setTimeout(() => {
                  this.SetState(State.EndGame);
                }, 1000);
                break;

              case tigers.krun.KRUN_CMD.KRUN_CMD_GET_TURN:
                let turn = tigers.krun.KrunResTurn.decode(msg.body);
                console.log("[GameMgr] turn: ", turn.value);
                EventListener.Instance.emit(EventName.onBlanceTurn, turn.value);
                break;

              case tigers.krun.KRUN_CMD.KRUN_CMD_GET_CANDY:
                let candy = tigers.krun.KrunResCandy.decode(msg.body);
                console.log("[GameMgr] candy: ", candy.value);
                EventListener.Instance.emit(EventName.onBlanceCandy, candy.value);
                break;
            }
          }
        } // private resume() {
        //     MapMgr.Intance.players.forEach(player => {
        //         player.resume();
        //     });
        // }
        // private pause() {
        //     MapMgr.Intance.players.forEach(player => {
        //         player.pause();
        //     });
        // }


        initRoom() {
          this.autoJoinGame = false;
          this.networkBrigde.quitGame();
          this.currentGameID = "";
          this.SetState(State.FindRoom);
        }

        findRoom() {
          this.autoJoinGame = true;
          this.currentGameID = "";
          this.SetState(State.FindRoom);
        }

        onLostConnection() {}

        reconnect() {
          MapMgr.Intance.show(false);
          this.networkBrigde.reconnect();
          this.SetState(State.Connecting);
          AudioMgr.Instance.Stop();
          ScreenMgr.Instance.hideAll();
          ScreenMgr.Instance.Show(ScreenName.Init);
        }

        joinGame() {
          if (Profile.Instance.turn < MapMgr.Intance.getMapConfig().matchingPrice) {
            this.outOfTurn();
          } else {
            // if (this.networkBrigde.isReady) {
            this.SetState(State.LoadGame); // }
            // else {
            //     this.initNetwork();
            //     this.SetState(State.Connecting);
            // }
          }
        }

        victory() {
          ScreenMgr.Instance.Show(ScreenName.EndGame);
        }

        fireBullet() {
          if (this.state == State.Playing) {
            this.networkBrigde.fireBullet(Profile.Instance.UserID);
          }
        }

        get isPlaying() {
          return this.state == State.Playing;
        }

        onBack() {
          if (this.state == State.EndGame) {
            GameMgr.Instance.initRoom();
          } else if (this.state == State.FindRoom || this.state == State.GetRoomConfig) {
            GameMgr.Instance.closeGame();
          } else if (this.state == State.Playing) {
            MaxApiUtils.trackEvent({
              action: 'click_btn_back_after_game'
            });
            MaxApiUtils.trackEvent({
              stage: 'pu_quit'
            });
            PopupMgr.Instance.Show(PopupName.QuitGame, () => {});
          } else if (this.state == State.Lobby) {
            MaxApiUtils.trackEvent({
              action: 'click_btn_back_before_game'
            });
            PopupMgr.Instance.Show(PopupName.QuitFindMatch, () => {});
          }
        }

        closeGame() {
          MaxApiUtils.goBack(); // MaxApiUtils.startFeatureCode(Features.MyHome.refId, Features.MyHome.params, () => {});
        }

        playerMove(cmd) {
          this.networkBrigde.playerMove(cmd);
        }

        outOfTurn() {
          MaxApiUtils.trackEvent({
            stage: 'pu_no_turn',
            is_new_user: Profile.Instance.IsOnboarding
          });
          let popup = PopupMgr.Instance.Show(PopupName.OutOfTurn, () => {});
        }

        refreshBalance() {
          this.networkBrigde.reqCandy();
          this.networkBrigde.reqTurn();
        } // public ping() {
        //     this.networkBrigde.ping();
        // }


        requestServerTime() {
          this.networkBrigde.ping();
        }

        get isPingReady() {
          return this.networkBrigde.isPingReady;
        }

        checkOnboarding(callback) {
          Utils.getRequest(NetworkDefine.API_PROFILE, (resp, status) => {
            if (resp && resp.result) {
              Profile.Instance.IsOnboarding = !resp.result.onboarding;
            }

            EventListener.Instance.emit(EventName.onOnboaringStatus, Profile.Instance.IsOnboarding);

            if (Profile.Instance.IsOnboarding) {
              this.firstLogin(() => {
                callback(Profile.Instance.IsOnboarding);
              });
            } else {
              callback(Profile.Instance.IsOnboarding);
            }

            console.log("[GameMgr] checkOnboarding: ", resp);
          });
        }

        firstLogin(callback) {
          let data = {
            game_id: "tigers",
            mission_id: "first_login_squid",
            partner_ids: []
          };
          Utils.postRequest(NetworkDefine.API_FIRST_LOGIN, data, result => {
            callback();
            console.log("[GameMgr] firstLogin: ", result);
          });
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "boss", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Lobby.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './PopupMgr.ts', './TimeMgr.ts', './Screen.ts', './MapMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, ProgressBar, Label, _decorator, EventName, PopupName, EventListener, PopupMgr, TimeMgr, Screen, MapMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      ProgressBar = module.ProgressBar;
      Label = module.Label;
      _decorator = module._decorator;
    }, function (module) {
      EventName = module.EventName;
      PopupName = module.PopupName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      MapMgr = module.MapMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _class3, _temp;

      cclegacy._RF.push({}, "2405fX3EmhOqLxXcFJAVU2Z", "Lobby", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Lobby = exports('Lobby', (_dec = ccclass('Lobby'), _dec2 = property(ProgressBar), _dec3 = property(Label), _dec(_class = (_class2 = (_temp = _class3 = class Lobby extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "progressBar", _descriptor, this);

          _initializerDefineProperty(this, "labelTime", _descriptor2, this);

          _defineProperty(this, "time", 0);
        }

        onLoad() {
          Lobby.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onOutOfTurn, this.onOutOfTurn, this);
          EventListener.Instance.on(EventName.onMatchingFailed, this.onMatchingFailed, this);
        }

        show() {
          super.show();
          this.time = TimeMgr.instance.serverTime;
          this.progressBar.progress = 0;
        }

        update(dt) {
          if (MapMgr.Intance.mapConfig) {
            let value = MapMgr.Intance.mapConfig.matchingMaxTime - (TimeMgr.instance.serverTime - this.time);
            value = Math.max(1, Math.round(value / 1000));
            this.labelTime.string = value.toString() + "s"; // this.progressBar.progress = (MapMgr.Intance.mapConfig.matchingMaxTime - value) / MapMgr.Intance.mapConfig.matchingMaxTime;
          } else {
            this.labelTime.string = "5" + "s";
            this.progressBar.progress = 0;
          }
        }

        static get Instance() {
          return Lobby.instance;
        }

        onOutOfTurn() {
          let popup = PopupMgr.Instance.Show(PopupName.OutOfTurn, () => {});
        }

        onMatchingFailed() {
          let popup = PopupMgr.Instance.Show(PopupName.FindMatchFail, () => {});
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "progressBar", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "labelTime", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/NetworkDefine.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      exports({
        WSCmd: void 0,
        WSGameCmd: void 0
      });

      cclegacy._RF.push({}, "2af94HN97RHnL27I4ClZS71", "NetworkDefine", undefined);

      class NetworkDefine {
        //(window._IS_DEV == undefined || window._IS_DEV)? true : false;
        //new - get onboarding on profile LacXi
        static UpdateEnvironment(env) {
          // switch(env)
          // {
          //     case "staging":
          //     case "production":
          //         NetworkDefine.IsDev = false;
          //         break;
          //     case "dev":
          //     default:
          //         NetworkDefine.IsDev = true;
          //         break;
          // }
          // NetworkDefine.URL = NetworkDefine.IsDev ? NetworkDefine.URL_DEV : NetworkDefine.URL_PROD;
          console.log("[NetworkDefine] UpdateEnvironment: ", NetworkDefine.URL);
        }

      }

      exports('NetworkDefine', NetworkDefine);

      _defineProperty(NetworkDefine, "IsDev", !false);

      _defineProperty(NetworkDefine, "lostConnectionTime", 15000);

      _defineProperty(NetworkDefine, "HOST", NetworkDefine.IsDev ? "https://m.dev.mservice.io" : "https://m.mservice.io");

      _defineProperty(NetworkDefine, "URL_DEV", "wss://realtime.dev.mservice.io/tigers-krun-connector/connector");

      _defineProperty(NetworkDefine, "URL_PROD", "wss://realtime.mservice.io/tigers-krun-connector/connector");

      _defineProperty(NetworkDefine, "URL", NetworkDefine.IsDev ? NetworkDefine.URL_DEV : NetworkDefine.URL_PROD);

      _defineProperty(NetworkDefine, "BOUNDLE_HOST", "https://hub.mservice.com.vn/webgame/sound/lacxi2022_squid/v4");

      _defineProperty(NetworkDefine, "API_FIRST_LOGIN", NetworkDefine.HOST + "/gnosis-mission-service/v1/send-succeeded-event");

      _defineProperty(NetworkDefine, "API_PROFILE", NetworkDefine.HOST + '/tigers-defendaward-profile/v1/profile');

      let WSCmd;

      (function (WSCmd) {
        WSCmd["MsgPing"] = "MsgPing";
        WSCmd["ReqWorker"] = "ReqWorker";
        WSCmd["ResWorker"] = "ResWorker";
        WSCmd["ResVerify"] = "ResVerify";
        WSCmd["ReqVerify"] = "ReqVerify";
        WSCmd["KrunMsg"] = "KrunMsg";
      })(WSCmd || (WSCmd = exports('WSCmd', {})));

      let WSGameCmd;

      (function (WSGameCmd) {
        WSGameCmd["KrunMsg"] = "KrunMsg";
      })(WSGameCmd || (WSGameCmd = exports('WSGameCmd', {})));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/InGame.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './Profile.ts', './AudioMgr.ts', './MaxApiUtils.ts', './PopupMgr.ts', './TimeMgr.ts', './NotifyMgr.ts', './Input.ts', './Joystick.ts', './Screen.ts', './MapMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, Label, Node, Sprite, _decorator, Vec3, UIOpacity, Color, tween, EventName, SoundName, NotifyName, PopupName, EventListener, Profile, AudioMgr, MaxApiUtils, PopupMgr, TimeMgr, NotifyMgr, Input, Joystick, Screen, MapMgr, GameMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      Node = module.Node;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Vec3 = module.Vec3;
      UIOpacity = module.UIOpacity;
      Color = module.Color;
      tween = module.tween;
    }, function (module) {
      EventName = module.EventName;
      SoundName = module.SoundName;
      NotifyName = module.NotifyName;
      PopupName = module.PopupName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      NotifyMgr = module.NotifyMgr;
    }, function (module) {
      Input = module.Input;
    }, function (module) {
      Joystick = module.Joystick;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      MapMgr = module.MapMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _dec16, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _class3, _temp;

      cclegacy._RF.push({}, "2e1ed5VCJRC1JlfdK2TKybs", "InGame", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let InGame = exports('InGame', (_dec = ccclass('InGame'), _dec2 = property(Button), _dec3 = property(Button), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Node), _dec7 = property(Sprite), _dec8 = property(Sprite), _dec9 = property(Node), _dec10 = property(Label), _dec11 = property(Label), _dec12 = property(Label), _dec13 = property(Label), _dec14 = property(Label), _dec15 = property(Label), _dec16 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class InGame extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBack", _descriptor, this);

          _initializerDefineProperty(this, "btnAttack", _descriptor2, this);

          _initializerDefineProperty(this, "matchTimeMin", _descriptor3, this);

          _initializerDefineProperty(this, "matchTimeSec", _descriptor4, this);

          _initializerDefineProperty(this, "joystick", _descriptor5, this);

          _initializerDefineProperty(this, "redLight", _descriptor6, this);

          _initializerDefineProperty(this, "greenLight", _descriptor7, this);

          _initializerDefineProperty(this, "freezeEffect", _descriptor8, this);

          _initializerDefineProperty(this, "labelEffect", _descriptor9, this);

          _initializerDefineProperty(this, "labelCandy", _descriptor10, this);

          _initializerDefineProperty(this, "labelBulletPrice", _descriptor11, this);

          _initializerDefineProperty(this, "labelBulletName", _descriptor12, this);

          _initializerDefineProperty(this, "labelPlayerRank", _descriptor13, this);

          _initializerDefineProperty(this, "labelTutorial", _descriptor14, this);

          _initializerDefineProperty(this, "viewMode", _descriptor15, this);

          _defineProperty(this, "reloadTime", 0);

          _defineProperty(this, "shouldCheckAttackBtn", false);

          _defineProperty(this, "freezeUiOpacity", null);

          _defineProperty(this, "freezeEffectIsClosing", false);

          _defineProperty(this, "joystickOriginalPos", new Vec3());

          _defineProperty(this, "lastTtime", 0);
        }

        onLoad() {
          InGame.instance = this;
          this.freezeUiOpacity = this.freezeEffect.getComponent(UIOpacity);
          this.freezeEffect.active = false;
        }

        start() {
          this.btnBack.node.on("click", this.onBackClick, this);
          this.btnAttack.node.on("click", this.onAttackClick, this);
          EventListener.Instance.on(EventName.onBossActive, this.onBossActive, this);
          EventListener.Instance.on(EventName.onBossIdle, this.onBossIdle, this);
          EventListener.Instance.on(EventName.onFreeze, this.onFreeze, this);
          EventListener.Instance.on(EventName.onPenalty, this.onPenalty, this);
          EventListener.Instance.on(EventName.onBlanceCandy, this.onBlanceCandy, this);
          EventListener.Instance.on(EventName.onPlayerFinish, this.onPlayerFinish, this);
          EventListener.Instance.on(EventName.onUpdateRank, this.onUpdateRank, this);
          this.joystickOriginalPos = this.joystick.worldPosition;
        }

        update(dt) {
          if (GameMgr.Instance.isPlaying) {
            if (this.shouldCheckAttackBtn) {
              if (TimeMgr.instance.serverTime >= this.reloadTime) {
                this.shouldCheckAttackBtn = false;
                this.updateAttackBtn();
              }
            }

            if (this.labelTutorial.node.active && Input.Instance.isTouchDown) {
              this.labelTutorial.node.active = false;
            }
          }
        }

        show() {
          super.show();
          this.init();
          this.labelTutorial.node.active = true;
          this.viewMode.active = false;
          this.updateAttackBtn();
          this.ShowJoystick(true); // this.joystick.worldPosition = this.joystickOriginalPos;

          MaxApiUtils.trackEvent({
            stage: 'scr_main_game_squid_game'
          });
        }

        hide() {
          super.hide();
          this.freezeEffect.active = false;
          this.freezeEffectIsClosing = false;
        }

        static get Instance() {
          return InGame.instance;
        }

        ShowJoystick(value, pos = null) {
          this.joystick.active = value; // if (pos) {
          //     this.joystick.worldPosition = pos;
          // }

          this.joystick.getComponent(Joystick).reset();
        }

        get isJoystickShow() {
          return this.joystick.active;
        }

        SetLight(isGreen) {
          this.redLight.color = isGreen ? Color.GRAY : Color.RED;
          this.greenLight.color = isGreen ? Color.GREEN : Color.GRAY;
        }

        onBossActive() {
          this.SetLight(false);
        }

        onBossIdle() {
          this.SetLight(true);
        }

        updateMatchTime(time) {
          let value = Math.max(0, Math.round(time / 1000));

          if (this.lastTtime != value) {
            this.lastTtime = value;
            let min = Math.floor(value / 60);
            let sec = value - min * 60;
            this.matchTimeMin.string = min < 10 ? `0${min}` : `${min}`;
            this.matchTimeSec.string = sec < 10 ? `0${sec}` : `${sec}`;

            if (value <= 3) {
              AudioMgr.Instance.PlaySfx(SoundName.Timer, true);
            }
          }
        }

        onAttackClick() {
          MaxApiUtils.trackEvent({
            action: 'click_skill'
          });
          let bulletInfo = MapMgr.Intance.mapConfig.bullets[tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE - 1];
          GameMgr.Instance.fireBullet();
          Profile.Instance.attackCount++;
          Profile.Instance.candy -= bulletInfo.price;
          GameMgr.Instance.refreshBalance();
          this.reloadTime = TimeMgr.instance.serverTime + bulletInfo.reload * MapMgr.Intance.mapConfig.timePerFrame;
          this.shouldCheckAttackBtn = true;
          this.setActiveAttackButton(false);
          let pos = new Vec3(this.btnAttack.node.worldPosition);
          pos.add3f(-80, 60, 0);
          NotifyMgr.Instance.showAt(NotifyName.TextMsg, pos, "-" + MapMgr.Intance.mapConfig.bullets[tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE - 1].price + " kẹo");
        }

        onBackClick() {
          let popup = PopupMgr.Instance.Show(PopupName.QuitGame, () => {});
        }

        onFreeze(value, time, name) {
          if (value) {
            if (!this.freezeEffect.active) {
              this.activeFreezeEffect();
            }
          } else {
            if (!this.freezeEffectIsClosing && time <= 2) {
              this.freezeEffectIsClosing = true;
              this.disableFreezeEffect();
            }
          }

          this.labelEffect.string = `Bất động ${time} giây vì bị dính kỹ năng của ${name}`;
        }

        onPenalty(value, time) {
          if (value) {
            if (!this.freezeEffect.active) {
              this.activeFreezeEffect();
            }
          } else {
            if (!this.freezeEffectIsClosing && time <= 2) {
              this.freezeEffectIsClosing = true;
              this.disableFreezeEffect();
            }
          }

          this.labelEffect.string = `Bất động ${time} giây vì bạn di chuyển khi đèn đỏ`;
        }

        activeFreezeEffect() {
          this.freezeEffect.active = true;
          this.freezeUiOpacity.opacity = 0;
          tween(this.freezeUiOpacity).to(2, {
            opacity: 256
          }).start();
          this.labelTutorial.node.active = false;
        }

        disableFreezeEffect() {
          this.freezeUiOpacity.opacity = 256;
          tween(this.freezeUiOpacity).to(2, {
            opacity: 0
          }).call(() => {
            this.freezeEffect.active = false;
            this.freezeEffectIsClosing = false;
          }).start();
        }

        onBlanceCandy(candy) {
          if (this.labelCandy) {
            this.labelCandy.string = candy.toString();
            this.updateAttackBtn();
          }
        }

        setActiveAttackButton(enable) {
          this.btnAttack.interactable = enable; // this.btnAttack.getComponent(Sprite).grayscale = !enable;

          this.btnAttack.getComponentsInChildren(Sprite).forEach(sprite => {
            sprite.grayscale = !enable;
          });
        }

        updateAttackBtn() {
          let bulletInfo = MapMgr.Intance.mapConfig.bullets[tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE - 1];
          let enable = bulletInfo.limitPerGame > Profile.Instance.attackCount && Profile.Instance.candy >= bulletInfo.price;
          this.setActiveAttackButton(enable);
        }

        init() {
          let bullet = MapMgr.Intance.mapConfig.bullets[tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE - 1];
          this.labelBulletPrice.string = `-${bullet.price}`;
          this.labelBulletName.string = `${bullet.displayName}`;
          this.onBlanceCandy(Profile.Instance.candy);
        }

        onPlayerFinish(isMine) {
          if (isMine) {
            this.viewMode.active = true;
            this.ShowJoystick(false);
            this.setActiveAttackButton(false);
          }
        }

        onUpdateRank(rank) {
          if (MapMgr.Intance.mapInfo) {
            this.labelPlayerRank.string = rank + "/" + MapMgr.Intance.playerCount;
          }
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBack", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnAttack", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "matchTimeMin", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "matchTimeSec", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "joystick", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "redLight", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "greenLight", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "freezeEffect", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "labelEffect", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "labelCandy", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "labelBulletPrice", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "labelBulletName", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "labelPlayerRank", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "labelTutorial", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor15 = _applyDecoratedDescriptor(_class2.prototype, "viewMode", [_dec16], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/NetPlayer.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Vec3;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Vec3 = module.Vec3;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "3bddb1EOpJCo7xgFo+xPRIP", "NetPlayer", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let NetPlayer = exports('NetPlayer', (_dec = ccclass('NetPlayer'), _dec(_class = (_temp = class NetPlayer {
        constructor() {
          _defineProperty(this, "position", new Vec3());

          _defineProperty(this, "isMine", false);

          _defineProperty(this, "data", null);
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Bot.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Input.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Animation, _decorator, Component, Vec3, math, Input;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Animation = module.Animation;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      math = module.math;
    }, function (module) {
      Input = module.Input;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "45c89h+ZwdFx4V+okoiELMU", "Bot", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Init"] = 1] = "Init";
        State[State["Idle"] = 2] = "Idle";
        State[State["Walk"] = 3] = "Walk";
        State[State["Run"] = 4] = "Run";
        State[State["Win"] = 5] = "Win";
        State[State["Lose"] = 6] = "Lose";
      })(State || (State = {}));

      let Bot = exports('Bot', (_dec = ccclass('Bot'), _dec2 = property(Animation), _dec(_class = (_class2 = (_temp = class Bot extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "animation", _descriptor, this);

          _defineProperty(this, "speed", 5);

          _defineProperty(this, "direction", new Vec3(0, 0, -1));

          _defineProperty(this, "state", State.None);

          _defineProperty(this, "position", new Vec3());
        }

        start() {
          this.SetState(State.Init);
        }

        update(dt) {
          switch (this.state) {
            case State.Init:
              break;

            case State.Idle:
              if (Input.IsTouchDown) {
                this.SetState(State.Run);
              }

              break;

            case State.Run:
              this.node.getPosition(this.position);
              this.position.add(this.direction.normalize().multiplyScalar(this.speed * dt));
              this.node.position = this.position;

              if (Input.IsTouchUp) {
                this.SetState(State.Idle);
              }

              break;
          }
        }

        SetState(state) {
          if (this.state != state) {
            console.log(`[Bot] state: ${State[this.state]} => ${State[state]}`);
            this.state = state;

            switch (state) {
              case State.Init:
                this.SetState(State.Idle);
                break;

              case State.Idle:
                this.PlayAnimIdle();
                break;

              case State.Run:
                this.animation.play("Run" + math.randomRangeInt(1, 3));
                break;

              case State.Walk:
                break;
            }
          }
        }

        PlayAnimIdle() {
          this.animation.play("Idle" + math.randomRangeInt(1, 3));
        }

        Run() {
          this.SetState(State.Run);
        }

        Stop() {
          this.SetState(State.Idle);
        }

        Freeze() {}

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "animation", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Input.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, Vec2, Node, TouchState;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Vec2 = module.Vec2;
      Node = module.Node;
    }, function (module) {
      TouchState = module.TouchState;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "47b09oXRZdCr7sUwkusXwAq", "Input", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Input = exports('Input', (_dec = ccclass('Input'), _dec(_class = (_temp = _class2 = class Input extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "state", TouchState.None);

          _defineProperty(this, "isTouchDown", false);

          _defineProperty(this, "downPosition", new Vec2());

          _defineProperty(this, "position", new Vec2());

          _defineProperty(this, "delta", new Vec2());
        }

        static get Instance() {
          return Input.instance;
        }

        onLoad() {
          Input.instance = this;
          this.node.on(Node.EventType.TOUCH_START, this.onTouchBegan, this);
          this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
          this.node.on(Node.EventType.TOUCH_END, this.onTouchEnded, this);
          this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancelled, this);
        }

        lateUpdate() {
          if (this.state == TouchState.Down) {
            this.state = TouchState.Press;
          } else if (this.state == TouchState.Up) {
            this.state = TouchState.None;
            this.delta.set(0, 0);
          }
        }

        onTouchBegan(event) {
          let touches = event.getTouches();
          this.position = touches[0].getUILocation();
          this.downPosition = touches[0].getUILocation();
          Vec2.subtract(this.delta, this.position, this.downPosition);
          this.isTouchDown = true;
          this.state = TouchState.Down;
          this.StopPropagation(event);
        }

        onTouchEnded(event) {
          let touches = event.getTouches();
          this.position = touches[0].getUILocation();
          this.isTouchDown = false;
          this.state = TouchState.Up;
          this.StopPropagation(event);
        }

        onTouchCancelled(event) {
          this.isTouchDown = false;
          this.state = TouchState.Up;
          this.StopPropagation(event);
        }

        onTouchMove(event) {
          let touches = event.getTouches();
          this.position = touches[0].getUILocation();
          Vec2.subtract(this.delta, this.position, this.downPosition);
          this.isTouchDown = true;
          this.state = TouchState.Press;
          this.StopPropagation(event);
        }

        reset() {
          this.state = TouchState.None;
          this.delta.set(0, 0);
        }

        StopPropagation(event) {//event.propagationImmediateStopped = true;
        }

        static get State() {
          return Input.instance.state;
        }

        static get IsTouchDown() {
          return Input.instance.state == TouchState.Down;
        }

        static get IsTouchUp() {
          return Input.instance.state == TouchState.Up;
        }

        static get IsTouchMove() {
          return Input.instance.state == TouchState.Press;
        }

        static Reset() {
          Input.instance.reset();
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/NetworkError.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Popup.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, _decorator, Popup;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      Popup = module.Popup;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "4a6d1S4pdFBcqoXUgbprVDm", "NetworkError", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let NetworkError = exports('NetworkError', (_dec = ccclass('NetworkError'), _dec2 = property(Button), _dec(_class = (_class2 = (_temp = class NetworkError extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnRetry", _descriptor, this);
        }

        start() {
          super.start();
          this.btnRetry.node.on("click", this.onbtnRetryClick, this);
        }

        onbtnRetryClick() {
          this.OnCloseClick();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnRetry", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TopBar.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './Utils.ts', './MaxApiUtils.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, Label, Sprite, Color, _decorator, Component, EventName, Features, EventListener, Utils, MaxApiUtils, GameMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      Sprite = module.Sprite;
      Color = module.Color;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      EventName = module.EventName;
      Features = module.Features;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _temp;

      cclegacy._RF.push({}, "4cad6JbLw1L7o3yx1RrYacX", "TopBar", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let TopBar = exports('TopBar', (_dec = ccclass('TopBar'), _dec2 = property(Button), _dec3 = property(Button), _dec4 = property(Button), _dec5 = property(Button), _dec6 = property(Label), _dec7 = property(Label), _dec8 = property(Label), _dec9 = property(Sprite), _dec10 = property(Color), _dec(_class = (_class2 = (_temp = class TopBar extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBack", _descriptor, this);

          _initializerDefineProperty(this, "btnCoin", _descriptor2, this);

          _initializerDefineProperty(this, "btnTurn", _descriptor3, this);

          _initializerDefineProperty(this, "btnCandy", _descriptor4, this);

          _initializerDefineProperty(this, "labelCandy", _descriptor5, this);

          _initializerDefineProperty(this, "labelTurn", _descriptor6, this);

          _initializerDefineProperty(this, "labelCoin", _descriptor7, this);

          _initializerDefineProperty(this, "spriteStep", _descriptor8, this);

          _initializerDefineProperty(this, "spriteStepColor", _descriptor9, this);
        }

        start() {
          var _this$btnCoin, _this$btnTurn, _this$btnCandy;

          EventListener.Instance.on(EventName.onBlanceCandy, this.onBlanceCandy, this);
          EventListener.Instance.on(EventName.onBlanceTurn, this.onBlanceTurn, this);
          EventListener.Instance.on(EventName.onBlanceCoin, this.onBlanceCoin, this);
          this.btnBack.node.on("click", this.onBackClick, this);
          (_this$btnCoin = this.btnCoin) === null || _this$btnCoin === void 0 ? void 0 : _this$btnCoin.node.on("click", this.onCoinClick, this);
          (_this$btnTurn = this.btnTurn) === null || _this$btnTurn === void 0 ? void 0 : _this$btnTurn.node.on("click", this.onTurnClick, this);
          (_this$btnCandy = this.btnCandy) === null || _this$btnCandy === void 0 ? void 0 : _this$btnCandy.node.on("click", this.onCandyClick, this);
        }

        onBackClick() {
          GameMgr.Instance.onBack();
        }

        onTurnClick() {
          MaxApiUtils.startFeatureCode(Features.Mission.refId, Features.Mission.params, () => {});
        }

        onCandyClick() {
          MaxApiUtils.startFeatureCode(Features.Mission.refId, Features.Candy.params, () => {});
        }

        onCoinClick() {
          MaxApiUtils.startFeatureCode(Features.Mission.refId, Features.Coin.params, () => {});
        }

        onBlanceTurn(turn) {
          if (this.labelTurn) {
            this.labelTurn.string = Utils.toLocalString(turn) + " lượt";
          }
        }

        onBlanceCandy(candy) {
          if (this.labelCandy) {
            this.labelCandy.string = Utils.toLocalString(candy) + " kẹo";
          }
        }

        onBlanceCoin(coin, currentChallenge, totalChanllenge) {
          if (this.labelCoin) {
            this.labelCoin.string = Utils.toLocalString(coin) + " Xu";
            this.spriteStep.forEach((step, index) => {
              step.color = index > currentChallenge - 1 ? Color.GRAY : this.spriteStepColor;
            });
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBack", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnCoin", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnTurn", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btnCandy", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "labelCandy", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "labelTurn", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "labelCoin", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "spriteStep", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "spriteStepColor", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Color();
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/EffectMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, resources, instantiate, EffectName;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      resources = module.resources;
      instantiate = module.instantiate;
    }, function (module) {
      EffectName = module.EffectName;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "517d29u/1ZABqb0/EP1ATFA", "EffectMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let EffectMgr = exports('EffectMgr', (_dec = ccclass('EffectMgr'), _dec(_class = (_temp = _class2 = class EffectMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "prefabs", []);
        }

        onLoad() {
          EffectMgr.instance = this;
        }

        start() {
          this.load();
        }

        load() {
          let array = Object.keys(EffectName);
          array.forEach(element => {
            resources.load("prefabs/effects/" + element, (err, prefab) => {
              if (prefab) {
                this.prefabs.push(prefab);
                console.log("[EffectMgr] load effect: " + element);
              } else {
                console.error("[EffectMgr] load fail: " + element);
              }
            });
          });
        }

        getEffect(name) {
          let result = this.node.children.find(node => {
            return node.name == name && !node.active;
          });

          if (!result) {
            let prefab = this.prefabs.find(p => p.data.name == name);

            if (prefab) {
              result = instantiate(prefab);
              result.name = name;
              result.setParent(this.node);
            }
          }

          return result;
        }

        show(name, wpos) {
          let effect = this.getEffect(name);
          effect.setWorldPosition(wpos);
          effect.active = true;
          return effect;
        }

        hideAll() {
          this.node.children.forEach(child => {
            child.active = false;
          });
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Utils.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Profile.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, ParticleSystem, Vec3, resources, Prefab, AudioClip, Profile;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      ParticleSystem = module.ParticleSystem;
      Vec3 = module.Vec3;
      resources = module.resources;
      Prefab = module.Prefab;
      AudioClip = module.AudioClip;
    }, function (module) {
      Profile = module.Profile;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "524f1gsDoNErLJFctS0Tj+M", "Utils", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Utils = exports('Utils', (_dec = ccclass('Utils'), _dec(_class = (_temp = _class2 = class Utils {
        static PlayParticle(paricle) {
          paricle.play();
          let a = paricle.getComponentsInChildren(ParticleSystem);
          a.forEach(element => {
            element.play();
          });
        }

        static StopParticle(paricle) {
          paricle.stop();
          let a = paricle.getComponentsInChildren(ParticleSystem);
          a.forEach(element => {
            element.stop();
          });
        }

        static toLocalString(num) {
          num = Math.round(num);
          return num.toLocaleString().replace(/","/g, ".");
        }

        static formatScore(score) {
          return score.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }

        static cloneObject(data) {
          const keys = Object.keys(data);
          let t = Object.create(null);

          for (let i = 0, size = keys.length; i < size; i++) {
            t[keys[i]] = data[keys[i]];
          }

          return t;
        }

        static getScale(targetSprite, size) {
          const rect = targetSprite.rect;
          let rateX = size.width / rect.width;
          let rateY = size.height / rect.height;
          let target = rateY;
          if (rateX > rateY) target = rateX;
          return target;
        }

        static CorrectSpriteFrameSize(sprite, size) {
          let scale = Utils.getScale(sprite.spriteFrame, size);
          sprite.node.setScale(new Vec3(scale, scale, scale));
        }

        static getUrlVer(url) {
          // return url + "?v=" + Api.VERSION;
          return url;
        }

        static getTime(d) {
          const pad = s => {
            return s < 10 ? '0' + s : s;
          };

          return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
        }

        static getDateTimeVN(d) {
          const pad = s => {
            return s < 10 ? '0' + s : s;
          };

          return `${[pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/')}`;
        }

        static get uuid() {
          var dt = new Date().getTime();
          var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (dt + Math.random() * 16) % 16 | 0;
            dt = Math.floor(dt / 16);
            return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
          });
          return uuid;
        }

        static destroyAllChild(parent) {
          parent.children.forEach(child => {
            child.destroy();
          });
          parent.removeAllChildren();
        }

        static getPrefabRes(path, callback) {
          resources.load(path, Prefab, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        }

        static getAudioRes(path, callback) {
          resources.load(path, AudioClip, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        }

        static getPrefabBoundle(boundle, path, callback) {
          boundle.load(path, Prefab, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        }

        static getAudioBoundle(boundle, path, callback) {
          boundle.load(path, AudioClip, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        } //cheat to bypass circular dependencies


        static setInfoMySprite(mySpriteNode, link) {
          let mySprite = mySpriteNode.getComponent('MySprite');

          if (mySprite) {
            mySprite.Fetch(link);
          }
        }

        static truncate(text, limitWord) {
          let words = text.split(" ");
          if (words.length > limitWord) return words.splice(0, limitWord).join(" ") + "...";
          return text;
        }

        static fetch(url, method, body) {
          return fetch(url, {
            method,
            headers: new Headers({
              'Authorization': 'Bearer ' + Profile.Instance.UserToken,
              'Content-Type': 'application/json'
            }),
            body
          }).then(res => {
            return res.json();
          });
        }

        static getRequest(url, callback) {
          let XMLHttp = new XMLHttpRequest();
          XMLHttp.open("GET", url, true);
          XMLHttp.timeout = 3000; // time in milliseconds

          XMLHttp.responseType = "json";
          XMLHttp.setRequestHeader('Authorization', `Bearer ${Profile.Instance.UserToken}`);
          XMLHttp.setRequestHeader("Content-Type", "application/json");
          console.log("[NetworkMgr] GET: " + " " + url);

          XMLHttp.onreadystatechange = () => {
            console.log(`state = ${XMLHttp.readyState} status =${XMLHttp.status}`);

            if (XMLHttp.readyState == 4) {
              if (XMLHttp.status == 200) {
                switch (XMLHttp.responseType) {
                  case 'text':
                    // console.log(XMLHttp.responseText);
                    callback(XMLHttp.responseText, XMLHttp.status);
                    break;

                  default:
                    // console.log(XMLHttp.response);
                    callback(XMLHttp.response, XMLHttp.status);
                    break;
                }
              } else if (XMLHttp.status >= 400 || XMLHttp.status === 0) {
                callback(null, XMLHttp.status);
              }
            }
          };

          XMLHttp.send();
        }

        static postRequest(url, params, callback) {
          return new Promise((resolve, reject) => {
            let XMLHttp = new XMLHttpRequest();
            XMLHttp.open("POST", url, true);
            XMLHttp.timeout = 3000; // time in milliseconds

            XMLHttp.responseType = "json";
            XMLHttp.setRequestHeader('Authorization', `Bearer ${Profile.Instance.UserToken}`);
            XMLHttp.setRequestHeader("Content-Type", "application/json");
            console.log("[NetworkMgr] POST: " + " " + url);

            XMLHttp.onreadystatechange = () => {
              console.log(`state = ${XMLHttp.readyState} status =${XMLHttp.status}`);

              if (XMLHttp.readyState == 4) {
                if (XMLHttp.status == 200) {
                  switch (XMLHttp.responseType) {
                    case 'text':
                      // console.log(XMLHttp.responseText);
                      callback(XMLHttp.responseText, XMLHttp.status);
                      break;

                    default:
                      // console.log(XMLHttp.response);
                      callback(XMLHttp.response, XMLHttp.status);
                      break;
                  }
                } else if (XMLHttp.status >= 400 || XMLHttp.status === 0) {
                  callback(null, XMLHttp.status);
                }
              }
            };

            XMLHttp.send(JSON.stringify(params));
          });
        }

      }, _defineProperty(_class2, "getAngleFrom2Vec", (v1, v2) => {
        let rad = Math.atan2(v2.y - v1.y, v2.x - v1.x);
        /** range from 0 to 2PI */

        if (rad < 0) {
          rad = 2 * Math.PI + rad;
        } // if (angle > Math.PI) {
        //   angle -= 2 * Math.PI;
        // }


        return rad * 180 / Math.PI;
      }), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Define.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      exports({
        AnimationEventName: void 0,
        DevicePerformance: void 0,
        EffectName: void 0,
        EventName: void 0,
        NotifyName: void 0,
        PopupName: void 0,
        ScreenName: void 0,
        SoundName: void 0,
        TouchState: void 0
      });

      cclegacy._RF.push({}, "59cdciLEKNF6JfhKVhOZ2pu", "Define", undefined);

      let ScreenName;

      (function (ScreenName) {
        ScreenName["Init"] = "Init";
        ScreenName["Lobby"] = "Lobby";
        ScreenName["Loading"] = "Loading";
        ScreenName["Waiting"] = "Waiting";
        ScreenName["InGame"] = "InGame";
        ScreenName["EndGame"] = "EndGame";
      })(ScreenName || (ScreenName = exports('ScreenName', {})));

      let PopupName;

      (function (PopupName) {
        PopupName["QuitFindMatch"] = "QuitFindMatch";
        PopupName["NetworkError"] = "NetworkError";
        PopupName["OutOfTurn"] = "OutOfTurn";
        PopupName["FindMatchFail"] = "FindMatchFail";
        PopupName["QuitGame"] = "QuitGame";
        PopupName["LostConnection"] = "LostConnection";
      })(PopupName || (PopupName = exports('PopupName', {})));

      let NotifyName;

      (function (NotifyName) {
        NotifyName["BattleMsg"] = "BattleMsg";
        NotifyName["TextMsg"] = "TextMsg";
      })(NotifyName || (NotifyName = exports('NotifyName', {})));

      let SoundName;

      (function (SoundName) {
        SoundName["BossActive"] = "boss-active";
        SoundName["BossShoot"] = "boss-shoot";
        SoundName["EndGameLost"] = "endgame-lose";
        SoundName["EndGameWin"] = "endgame-win";
        SoundName["Freeze"] = "freeze";
        SoundName["FreezeEnd"] = "freeze-end";
        SoundName["FreezeStart"] = "freeze-start";
        SoundName["Step"] = "step";
        SoundName["Timer"] = "timer";
      })(SoundName || (SoundName = exports('SoundName', {})));

      let EffectName;

      (function (EffectName) {
        EffectName["Bullet"] = "Bullet";
        EffectName["Freeze"] = "Freeze";
      })(EffectName || (EffectName = exports('EffectName', {})));

      let TouchState;

      (function (TouchState) {
        TouchState[TouchState["None"] = 0] = "None";
        TouchState[TouchState["Down"] = 1] = "Down";
        TouchState[TouchState["Press"] = 2] = "Press";
        TouchState[TouchState["Up"] = 3] = "Up";
      })(TouchState || (TouchState = exports('TouchState', {})));

      let EventName;

      (function (EventName) {
        EventName["onBossActive"] = "onBossActive";
        EventName["onBossIdle"] = "onBossIdle";
        EventName["onGameDefine"] = "onGameDefine";
        EventName["onMatchingInfo"] = "onMatchingInfo";
        EventName["onOutOfTurn"] = "onOutOfTurn";
        EventName["onMatchingFailed"] = "onMatchingFailed";
        EventName["onBlanceTurn"] = "onBlanceTurn";
        EventName["onBlanceCandy"] = "onBlanceCandy";
        EventName["onBlanceCoin"] = "onBlanceCoin";
        EventName["onFreeze"] = "onFreeze";
        EventName["onPenalty"] = "onPenalty";
        EventName["onFreezeBegin"] = "onFreezeBegin";
        EventName["onFreezeEnd"] = "onFreezeEnd";
        EventName["onPlayerFinish"] = "onPlayerFinish";
        EventName["onUpdateRank"] = "onUpdateRank";
        EventName["onPing"] = "onPing";
        EventName["onWaiting"] = "onWaiting";
        EventName["onLostConnection"] = "onLostConnection";
        EventName["onOnboaringStatus"] = "onOnboaringStatus";
      })(EventName || (EventName = exports('EventName', {})));

      let AnimationEventName;

      (function (AnimationEventName) {
        AnimationEventName["onAnimationBegin"] = "onAnimationBegin";
        AnimationEventName["onAnimationFinished"] = "onAnimationFinished";
      })(AnimationEventName || (AnimationEventName = exports('AnimationEventName', {})));

      class Layer {}

      exports('Layer', Layer);

      _defineProperty(Layer, "Ground", 1 << 0);

      _defineProperty(Layer, "Player", 1 << 1);

      _defineProperty(Layer, "Bullet", 1 << 2);

      _defineProperty(Layer, "Item", 1 << 3);

      _defineProperty(Layer, "FinishLine", 1 << 4);

      class GameDefine {}

      exports('GameDefine', GameDefine);

      _defineProperty(GameDefine, "maxPlayer", 10);

      _defineProperty(GameDefine, "yardHeightInit", 55);

      _defineProperty(GameDefine, "yardWidthInit", 18);

      let REF_ID = exports('REF_ID', {
        LIXI_2022: "lixi_2022",
        SLOT_MACHINE_2022: "SlotMachine_2022"
      });
      let Features = exports('Features', {
        HomePage: {
          refId: REF_ID.LIXI_2022,
          params: {
            callFrom: "lx2022_squid_game",
            inventory: null
          }
        },
        MyHome: {
          refId: REF_ID.LIXI_2022,
          params: {
            typeScreen: 'LiXiMyHouse',
            inventory: null
          }
        },
        Mission: {
          refId: REF_ID.LIXI_2022,
          params: {
            typeScreen: 'LiXiMission',
            callFrom: "lx2022_squid_game",
            inventory: null
          }
        },
        Candy: {
          refId: REF_ID.LIXI_2022,
          params: {
            typeScreen: 'LixiCandyManager',
            callFrom: "lx2022_squid_game",
            inventory: null
          }
        },
        Coin: {
          refId: REF_ID.LIXI_2022,
          params: {
            typeScreen: 'LixiEventChallenge',
            callFrom: "lx2022_squid_game",
            inventory: null
          }
        },
        HoiCho: {
          refId: REF_ID.LIXI_2022,
          params: {
            typeScreen: 'LiXiFair',
            callFrom: "lx2022_squid_game",
            inventory: null
          }
        }
      });
      let DevicePerformance;

      (function (DevicePerformance) {
        DevicePerformance["LowEnd"] = "low-end";
        DevicePerformance["MideEnd"] = "mid-end";
        DevicePerformance["HighEnd"] = "high-end";
      })(DevicePerformance || (DevicePerformance = exports('DevicePerformance', {})));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/CameraFollow.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Node, _decorator, Component, Vec3, Camera, math;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      Camera = module.Camera;
      math = module.math;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _class3, _temp;

      cclegacy._RF.push({}, "5a02dY0DwhDo4SDHqcWY/Ha", "CameraFollow", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Normal"] = 1] = "Normal";
        State[State["Wait"] = 2] = "Wait";
      })(State || (State = {}));

      let CameraFollow = exports('CameraFollow', (_dec = ccclass('CameraFollow'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class CameraFollow extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "target", _descriptor, this);

          _defineProperty(this, "offset", new Vec3());

          _defineProperty(this, "targetPosition", new Vec3());

          _initializerDefineProperty(this, "waitPosition", _descriptor2, this);

          _defineProperty(this, "tempV3", new Vec3());

          _defineProperty(this, "stage", State.None);
        }

        onLoad() {
          CameraFollow.instance = this;
          CameraFollow.camera = this.getComponent(Camera);
        }

        static get Instance() {
          return CameraFollow.instance;
        }

        static get Camera() {
          return CameraFollow.camera;
        }

        start() {
          this.offset = this.node.worldPosition.clone();
        }

        update(dt) {
          switch (this.stage) {
            case State.Normal:
              Vec3.add(this.targetPosition, this.target.position, this.offset);
              Vec3.lerp(this.targetPosition, this.node.position, this.targetPosition, dt * 10);
              this.targetPosition.x = math.clamp(this.targetPosition.x, 4, 16);
              this.node.position = this.targetPosition;
              break;

            case State.Wait:
              Vec3.lerp(this.targetPosition, this.node.position, this.waitPosition.position, dt * 5);
              this.node.position = this.targetPosition;
              break;
          }
        }

        setTarget(node) {
          this.target = node;
        }

        setState(state) {
          if (state != this.stage) {
            this.stage = state;

            switch (this.stage) {
              case State.Normal:
                Vec3.add(this.targetPosition, this.target.position, this.offset);
                this.node.position = this.targetPosition;
                break;

              case State.Wait:
                break;
            }
          }
        }

        waitMode() {
          this.setState(State.Wait);
        }

        reset() {
          this.setState(State.Normal);
        }

      }, _defineProperty(_class3, "camera", null), _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "target", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "waitPosition", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ScreenMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Screen.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Node, _decorator, Component, resources, instantiate, ScreenName, Screen;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      resources = module.resources;
      instantiate = module.instantiate;
    }, function (module) {
      ScreenName = module.ScreenName;
    }, function (module) {
      Screen = module.Screen;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _class3, _temp;

      cclegacy._RF.push({}, "613e4KXbZpIVYqI2TneTBBG", "ScreenMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ScreenMgr = exports('ScreenMgr', (_dec = ccclass('ScreenMgr'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class ScreenMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "Container", _descriptor, this);

          _initializerDefineProperty(this, "scenes", _descriptor2, this);
        }

        static get Instance() {
          return this.instance;
        }

        onLoad() {
          ScreenMgr.instance = this;
        }

        start() {}

        IsShow(name) {
          let scene = this.scenes.find(scene => scene.name == name);
          return scene && scene.active;
        }

        IsLoaded(name) {
          let scene = this.scenes.find(scene => scene.name == name);
          return scene;
        }

        Show(name) {
          let scene = this.scenes.find(scene => scene.name == name);

          if (scene && !scene.active) {
            scene.getComponent(Screen).show();
          }

          return scene;
        }

        Hide(name) {
          let scene = this.scenes.find(scene => scene.name == name);

          if (scene) {
            scene.getComponent(Screen).hide();
          }
        }

        hideAll() {
          this.scenes.forEach(scene => {
            if (scene.active) {
              scene.getComponent(Screen).hide();
            }
          });
        }

        SetRefID(refId) {
          console.log("ScreenMgr CallRefID :" + refId);
        }

        IsContain(name) {
          let result = false;
          this.scenes.forEach(scene => {
            if (scene.name == name) {
              result = true;
              return;
            }
          });
          return result;
        }

        Load() {
          let array = Object.keys(ScreenName);
          array.forEach(element => {
            if (!this.IsContain(element)) {
              resources.load("prefabs/screens/" + element, (err, prefab) => {
                if (prefab) {
                  let screen = instantiate(prefab);
                  screen.active = false;
                  screen.name = element;
                  screen.setParent(this.Container);
                  this.scenes.push(screen);
                  console.log("Screen loaded: " + element);
                } else {
                  console.error("Screen prefab notfound: " + element);
                }
              });
            }
          });
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "Container", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scenes", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Player.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './Profile.ts', './Utils.ts', './AudioMgr.ts', './MaxApiUtils.ts', './TimeMgr.ts', './CameraFollow.ts', './Input.ts', './InGame.ts', './AnimationEvent.ts', './EffectMgr.ts', './MapMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Animation, Node, _decorator, Component, Vec3, Vec2, math, AnimationEventName, SoundName, EventName, EffectName, EventListener, Profile, Utils, AudioMgr, MaxApiUtils, TimeMgr, CameraFollow, Input, InGame, AnimationEvent, EffectMgr, MapMgr, GameMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Animation = module.Animation;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      Vec2 = module.Vec2;
      math = module.math;
    }, function (module) {
      AnimationEventName = module.AnimationEventName;
      SoundName = module.SoundName;
      EventName = module.EventName;
      EffectName = module.EffectName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      CameraFollow = module.CameraFollow;
    }, function (module) {
      Input = module.Input;
    }, function (module) {
      InGame = module.InGame;
    }, function (module) {
      AnimationEvent = module.AnimationEvent;
    }, function (module) {
      EffectMgr = module.EffectMgr;
    }, function (module) {
      MapMgr = module.MapMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "66444v1AmdGj7lSyQFegk+m", "Player", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Init"] = 1] = "Init";
        State[State["Waiting"] = 2] = "Waiting";
        State[State["Idle"] = 3] = "Idle";
        State[State["Walk"] = 4] = "Walk";
        State[State["Run"] = 5] = "Run";
        State[State["Freeze"] = 6] = "Freeze";
        State[State["StandUp"] = 7] = "StandUp";
        State[State["Finish"] = 8] = "Finish";
      })(State || (State = {}));

      let Player = exports('Player', (_dec = ccclass('Player'), _dec2 = property(Animation), _dec3 = property(AnimationEvent), _dec4 = property(Node), _dec5 = property(Node), _dec(_class = (_class2 = (_temp = class Player extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "animation", _descriptor, this);

          _initializerDefineProperty(this, "animationEvent", _descriptor2, this);

          _initializerDefineProperty(this, "aim", _descriptor3, this);

          _initializerDefineProperty(this, "indicator", _descriptor4, this);

          _defineProperty(this, "speed", 0);

          _defineProperty(this, "direction", new Vec3(0, 0, -1));

          _defineProperty(this, "distance", 0);

          _defineProperty(this, "state", State.None);

          _defineProperty(this, "netState", void 0);

          _defineProperty(this, "position", new Vec3());

          _defineProperty(this, "netPosition", new Vec3());

          _defineProperty(this, "temp", new Vec3());

          _defineProperty(this, "isLoaded", false);

          _defineProperty(this, "time", 5);

          _defineProperty(this, "freezeEndTime", 0);

          _defineProperty(this, "freezeType", void 0);

          _defineProperty(this, "vec2Up", new Vec2(0, 1));

          _defineProperty(this, "currentEffect", null);

          _defineProperty(this, "freezeByName", "Player");

          _defineProperty(this, "footstepSoundPlayTime", 0);

          _defineProperty(this, "isMine", false);

          _defineProperty(this, "uid", "");

          _defineProperty(this, "userName", "");

          _defineProperty(this, "rank", 10);

          _defineProperty(this, "convertRadToMoveCmd", angle => {
            if (angle <= 270) {
              angle = Math.min(180, angle);
            } else angle = 0;

            const fixedRad = Math.round(angle / 10) * 10;
            const value = fixedRad === 0 ? '000' : fixedRad < 100 ? `0${fixedRad}` : fixedRad;
            const objKey = `KRUN_CMD_PLAYER_MOVE_${value}`;
            return tigers.krun.KRUN_CMD[objKey] || tigers.krun.KRUN_CMD.KRUN_CMD_PLAYER_MOVE_000;
          });
        }

        start() {
          this.animationEvent.event.on(AnimationEventName.onAnimationBegin, this.onAnimationBegin, this);
          this.animationEvent.event.on(AnimationEventName.onAnimationFinished, this.onAnimationFinished, this);
          this.SetState(State.Init);
          this.isLoaded = true;
        }

        gameUpdate(dt) {
          this.time += dt;

          switch (this.netState) {
            case tigers.krun.KRUN_PLAYER_STATUS.KRUN_PLAYER_STATUS_ALIVE:
              if (this.isMine && this.state != State.Finish && (this.state == State.Idle || this.state == State.Run)) {
                // if (Input.IsTouchDown) {
                //     InGame.Instance.ShowJoystick(true, new Vec3(Input.Instance.position.x, Input.Instance.position.y, 0));
                // }
                // else if (Input.IsTouchMove) {
                //     if (!InGame.Instance.isJoystickShow) {
                //         InGame.Instance.ShowJoystick(true, new Vec3(Input.Instance.position.x, Input.Instance.position.y, 0));
                //     }
                // }
                // else if (Input.IsTouchUp) {
                //     InGame.Instance.ShowJoystick(false);
                // }
                if (Input.IsTouchDown) ;else if (Input.IsTouchMove) {
                  this.SetState(State.Run);
                } else if (Input.IsTouchUp) {
                  this.SetState(State.Idle);
                }

                if (this.time * 1000 >= MapMgr.Intance.mapConfig.timePerFrame) {
                  this.time = 0;

                  if (Input.IsTouchMove) {
                    let angle = Utils.getAngleFrom2Vec(this.vec2Up, Input.Instance.delta);
                    GameMgr.Instance.playerMove(this.convertRadToMoveCmd(angle));
                  }
                }
              }

              if (this.state != State.Freeze) {
                let shouldUpdatePos = this.distance > 0;

                if (this.isMine && this.state != State.Run) {
                  shouldUpdatePos = false;
                }

                if (shouldUpdatePos) {
                  this.speed = 1000 * dt * MapMgr.Intance.mapConfig.playerMoveSpeed / MapMgr.Intance.mapConfig.timePerFrame;
                  this.distance -= this.speed;
                  this.node.getWorldPosition(this.position);
                  this.temp.set(this.direction);
                  this.temp.multiplyScalar(this.speed);
                  this.position.add(this.temp);
                  this.node.setWorldPosition(this.position);

                  if (!this.isMine) {
                    this.SetState(State.Run);
                  }
                } else {
                  // this.node.setWorldPosition(this.netPosition)
                  if (!this.isMine) {
                    this.SetState(State.Idle);
                  }
                }
              }

              break;
          }

          switch (this.state) {
            case State.Freeze:
              switch (this.freezeType) {
                case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE:
                  if (this.isMine) {
                    let duration = this.freezeEndTime - TimeMgr.instance.serverTime;
                    duration = Math.round(duration / 1000);
                    EventListener.Instance.emit(EventName.onFreeze, true, duration, this.freezeByName);
                  }

                  break;

                case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_PENALTY:
                  if (this.isMine) {
                    let duration = this.freezeEndTime - TimeMgr.instance.serverTime;
                    duration = Math.round(duration / 1000);
                    EventListener.Instance.emit(EventName.onPenalty, true, duration);
                  }

                  break;
              }

              if (TimeMgr.instance.serverTime >= this.freezeEndTime) {
                this.stopFreezeEffect();
                this.SetState(State.Idle);
              }

              break;

            case State.Run:
              if (this.isMine) {
                this.footstepSoundPlayTime -= dt;

                if (this.footstepSoundPlayTime <= 0) {
                  this.footstepSoundPlayTime = 0.7;
                  AudioMgr.Instance.PlaySfx(SoundName.Step, true);
                }
              }

              break;
          }
        }

        SetState(state) {
          if (this.state != state) {
            // if(this.isMine)
            // console.log(`[Player] state: ${State[this.state]} => ${State[state]}`);
            this.state = state;

            switch (state) {
              case State.Init:
                this.playAnimIdle();
                break;

              case State.Waiting:
                break;

              case State.Idle:
                this.playAnimIdle();
                break;

              case State.Run:
                this.animation.play("Running");
                break;

              case State.Walk:
                break;

              case State.Freeze:
                this.animation.play("Freeze");
                break;

              case State.StandUp:
                this.animation.play("Stand Up");
                break;

              case State.Finish:
                this.stopFreezeEffect();
                this.playAnimVictory();
                break;
            }
          }
        }

        canAttack() {
          return Profile.Instance.candy >= MapMgr.Intance.getMapConfig().bullets[0].price;
        }

        onAnimationBegin(name) {}

        onAnimationFinished(name) {}

        playAnimIdle() {
          let animName = "Idle" + math.randomRangeInt(2, 4); // console.log(`anim Idle name: ${animName}`);

          this.animation.play(animName);
        }

        playAnimVictory() {
          let animName = "Victory" + math.randomRangeInt(1, 3); // console.log(`anim Victory name: ${animName}`);

          this.animation.play(animName);
        }

        init(nplayer) {
          this.node.active = !nplayer.uid.startsWith("BOT");
          this.uid = nplayer.uid;
          this.isMine = nplayer.uid == Profile.Instance.Uid;
          this.indicator.active = this.isMine;
          this.netPosition.set(nplayer.x, 0, nplayer.y);
          this.node.forward.set(0, 0, -1);
          this.node.setWorldPosition(this.netPosition);
          this.netUpdate(nplayer);
        } // private findLastEffect(effects: tigers.krun.IKrunEffect[], effectID: tigers.krun.KRUN_BULLET_EFFECTS): tigers.krun.IKrunEffect {
        //     let result: tigers.krun.IKrunEffect = null;
        //     effects.forEach(effect => {
        //         if (effect.effect == effectID) {
        //             if (!result) {
        //                 result = effect;
        //             }
        //             else if (result.end < effect.end) {
        //                 result = effect;
        //             }
        //         }
        //     });
        //     return result;
        // }


        updateNetPos(netX, netY) {
          if (this.netPosition.x != netX || this.netPosition.z != netY) {
            this.netPosition.set(netX, 0, netY); // this.node.lookAt(this.netPosition);

            Vec3.subtract(this.direction, this.netPosition, this.node.worldPosition);
            this.direction.normalize();
            this.node.forward = this.direction;
            this.node.getWorldPosition(this.temp);
            this.distance = Vec3.distance(this.temp, this.netPosition);
          }
        }

        netUpdate(nplayer) {
          this.updateNetPos(nplayer.x, nplayer.y);

          if (this.netState != nplayer.status) {
            if (this.isMine) console.log(`[Player] netState: ${tigers.krun.KRUN_PLAYER_STATUS[this.netState]} => ${tigers.krun.KRUN_PLAYER_STATUS[nplayer.status]}`);
            this.netState = nplayer.status;
            console.log(nplayer.status);

            switch (nplayer.status) {
              case tigers.krun.KRUN_PLAYER_STATUS.KRUN_PLAYER_STATUS_ALIVE:
                this.SetState(State.Idle);
                EventListener.Instance.emit(EventName.onFreeze, false, 0, this.freezeByName);
                break;

              case tigers.krun.KRUN_PLAYER_STATUS.KRUN_PLAYER_STATUS_FINISH:
                console.log("[Player] Finish: ", nplayer.uid, `(${nplayer.x}, ${nplayer.x})`);
                this.node.setWorldPosition(this.netPosition);

                if (this.isMine) {
                  CameraFollow.Instance.waitMode();
                }

                this.SetState(State.Finish);
                EventListener.Instance.emit(EventName.onPlayerFinish, this.isMine);
                break;

              case tigers.krun.KRUN_PLAYER_STATUS.KRUN_PLAYER_STATUS_DEAD:
                this.SetState(State.Idle);
                break;

              case tigers.krun.KRUN_PLAYER_STATUS.KRUN_PLAYER_STATUS_MATCHING:
                this.SetState(State.Idle);
                break;
            }
          }
        }

        stopFreezeEffect() {
          if (this.currentEffect) {
            this.currentEffect.active = false;
            this.currentEffect = null;
          }

          if (this.isMine) {
            Input.Reset();
            InGame.Instance.ShowJoystick(true);
            EventListener.Instance.emit(this.freezeType == tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE ? EventName.onFreeze : EventName.onPenalty, false, 0);
            AudioMgr.Instance.PlaySfx(SoundName.FreezeEnd, true);
          }
        }

        freeze(type, targetBy, endTime) {
          if (this.state != State.Freeze) {
            this.freezeByName = targetBy;
            this.freezeType = type;
            this.freezeEndTime = endTime;
            this.currentEffect = EffectMgr.instance.show(EffectName.Freeze, this.node.worldPosition);
            this.SetState(State.Freeze);

            if (this.isMine) {
              InGame.Instance.ShowJoystick(false);
              Input.Reset();

              switch (this.freezeType) {
                case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE:
                  MaxApiUtils.trackEvent({
                    skill_hit: true
                  });
                  break;

                case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_PENALTY:
                  MaxApiUtils.trackEvent({
                    red_move: true
                  });
                  break;
              }
            }

            AudioMgr.Instance.PlaySfx(SoundName.Freeze, true);

            if (this.isMine) {
              AudioMgr.Instance.PlaySfx(SoundName.FreezeStart, true);
            }
          }
        }

        victory() {
          this.SetState(State.Finish);

          if (this.isMine) {
            GameMgr.Instance.victory();
          }
        }

        isMove() {
          return this.state == State.Run;
        }

        get isFinish() {
          return this.state == State.Finish;
        }

        getAim() {
          return this.aim.worldPosition;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "animation", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "animationEvent", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "aim", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "indicator", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/protobuf.ts", ['cc', './index.js', './index.mjs_cjs=&original=.js'], function () {
  'use strict';

  var cclegacy, _cjsExports;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      _cjsExports = module.default;
    }, null],
    execute: function () {
      cclegacy._RF.push({}, "674e5Oo4G5HSJiGxYBnjiGY", "protobuf", undefined);

      window.protobuf = _cjsExports;

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AssetMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './AudioMgr.ts', './NetworkDefine.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, assetManager, AudioMgr, NetworkDefine;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      assetManager = module.assetManager;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      NetworkDefine = module.NetworkDefine;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "67aa1RXrxpDSpvvCVnAeht+", "AssetMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AssetMgr = exports('AssetMgr', (_dec = ccclass('AssetMgr'), _dec(_class = (_temp = _class2 = class AssetMgr extends Component {
        onLoad() {
          AssetMgr.instance = this;
        }

        start() {}

        static get Instance() {
          return AssetMgr.instance;
        }

        Load() {
          try {
            assetManager.loadBundle(`${NetworkDefine.BOUNDLE_HOST}/remote/boundle`, (err, bundle) => {
              if (bundle) {
                AudioMgr.Instance.Load(bundle);
              }
            });
          } catch (e) {}
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Waiting.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './AudioMgr.ts', './TimeMgr.ts', './Screen.ts', './MapMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Label, _decorator, math, EventName, SoundName, EventListener, AudioMgr, TimeMgr, Screen, MapMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      _decorator = module._decorator;
      math = module.math;
    }, function (module) {
      EventName = module.EventName;
      SoundName = module.SoundName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      MapMgr = module.MapMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "68bbfFZUDlHVqtAxkcpKuld", "Waiting", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Waiting = exports('Waiting', (_dec = ccclass('Waiting'), _dec2 = property(Label), _dec(_class = (_class2 = (_temp = _class3 = class Waiting extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "text", _descriptor, this);

          _defineProperty(this, "lastTtime", 0);
        }

        onLoad() {
          Waiting.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onWaiting, this.onWaiting, this);
        }

        show() {
          super.show();
          this.lastTtime = Math.round((MapMgr.Intance.mapInfo.startTime - TimeMgr.instance.serverTime) / 1000) + 1;
        }

        static get Instance() {
          return Waiting.instance;
        }

        onWaiting(time) {
          let value = Math.max(0, Math.round(time / 1000)) + 1;
          this.text.string = `${math.clamp(value, 3, 1)}`;

          if (this.lastTtime != value && value > 0) {
            this.lastTtime = value;
            AudioMgr.Instance.PlaySfx(SoundName.Timer);
          }
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "text", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TrimBase64.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, _decorator;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "72665xtGxlEKKfFfEehF+RP", "TrimBase64", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let TrimBase64 = exports('TrimBase64', (_dec = ccclass('TrimBase64'), _dec(_class = class TrimBase64 {
        static trimCanvas(c) {
          var ctx = c.getContext('2d'),
              copy = document.createElement('canvas').getContext('2d'),
              pixels = ctx.getImageData(0, 0, c.width, c.height),
              l = pixels.data.length,
              i,
              bound = {
            top: null,
            left: null,
            right: null,
            bottom: null
          },
              x,
              y;

          for (i = 0; i < l; i += 4) {
            if (pixels.data[i + 3] !== 0) {
              x = i / 4 % c.width;
              y = ~~(i / 4 / c.width);

              if (bound.top === null) {
                bound.top = y;
              }

              if (bound.left === null) {
                bound.left = x;
              } else if (x < bound.left) {
                bound.left = x;
              }

              if (bound.right === null) {
                bound.right = x;
              } else if (bound.right < x) {
                bound.right = x;
              }

              if (bound.bottom === null) {
                bound.bottom = y;
              } else if (bound.bottom < y) {
                bound.bottom = y;
              }
            }
          }

          var trimHeight = bound.bottom - bound.top + 1,
              trimWidth = bound.right - bound.left + 1,
              trimmed = ctx.getImageData(bound.left, bound.top, trimWidth, trimHeight);
          copy.canvas.width = trimWidth;
          copy.canvas.height = trimHeight;
          copy.putImageData(trimmed, 0, 0); // open new window with trimmed image:

          return copy.canvas;
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/NetworkBrigde.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Profile.ts', './NetworkDefine.ts', './TimeMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, math, Profile, NetworkDefine, WSCmd, WSGameCmd, TimeMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      math = module.math;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      NetworkDefine = module.NetworkDefine;
      WSCmd = module.WSCmd;
      WSGameCmd = module.WSGameCmd;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "7977cTNaeRKkqxQx8E3V1id", "NetworkBrigde", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let NetworkBrigde = exports('NetworkBrigde', (_dec = ccclass('NetworkBrigde'), _dec(_class = (_temp = class NetworkBrigde {
        constructor() {
          _defineProperty(this, "ws", null);

          _defineProperty(this, "payloadCounter", 0);

          _defineProperty(this, "worker", "");

          _defineProperty(this, "servers", []);

          _defineProperty(this, "onOpen", null);

          _defineProperty(this, "onMessage", null);

          _defineProperty(this, "onError", null);

          _defineProperty(this, "onClose", null);
        }

        connect() {
          this.ws = new WebSocket(NetworkDefine.URL);
          this.ws.onopen = this.onopen.bind(this);
          this.ws.onmessage = this.onmessage.bind(this);
          this.ws.onerror = this.onerror.bind(this);
          this.ws.onclose = this.onclose.bind(this);
        }

        disconnect() {
          if (this.ws.readyState == WebSocket.OPEN) {
            this.ws.close();
            this.ws = null;
          }
        }

        get isReady() {
          return this.ws && this.ws.readyState === WebSocket.OPEN;
        }

        get isPingReady() {
          return this.ws && this.ws.readyState === WebSocket.OPEN && this.worker != "";
        }

        get isHttps() {
          return window.location.href.indexOf("https://") != -1;
        }

        onopen(event) {
          if (this.onOpen) {
            this.onOpen();
          }

          console.log("[NetworkBrigde] ws is connected!");
        }

        onmessage(event) {
          this.decodeMsgData(event.data);
        }

        onerror(event) {
          if (this.onError) {
            this.onError();
          }
        }

        onclose(event) {
          if (this.onClose) {
            console.log("[NetworkBrigde] ws is closed!");
            this.onClose();
          } // setTimeout(this.connect.bind(this), 1000);

        }

        send(data) {
          if (this.ws.readyState == WebSocket.OPEN) {
            this.ws.send(data);
          }
        }

        reconnect() {
          if (this.ws != null) {
            this.ws.close();
          }

          this.connect();
        }

        async decodeMsgData(blob) {
          // return new Promise((resolve, reject) => {
          blob.arrayBuffer().then(data => {
            try {
              let wrapper = tigers.krun.internal.MessageWrapper.decode(new Uint8Array(data));

              switch (wrapper.msgClass) {
                case WSCmd.ResVerify:
                  if (this.worker != "") {
                    this.quitGame();
                  }

                  break;

                case WSCmd.MsgPing:
                  break;

                case WSCmd.ResWorker:
                  let worker = tigers.krun.internal.ResWorker.decode(wrapper.msg);
                  this.worker = worker.worker;
                  console.log(`[NetworkBrigde] ResWorker: ${this.worker}`);
                  break;
              }

              if (this.onMessage) {
                this.onMessage(wrapper);
              }
            } catch (e) {
              console.log(`[NetworkBrigde] decodeMsgData error: ${e}`);
            }
          }); // });
        }

        sendProto(cmd, data) {
          let wrapper = new tigers.krun.internal.MessageWrapper();
          wrapper.msg = data;
          wrapper.msgClass = cmd;
          wrapper.worker = this.worker;
          let bytebuf = tigers.krun.internal.MessageWrapper.encode(wrapper).finish();
          this.send(bytebuf); // console.log(`[NetworkBrigde] sendProto => ${cmd}`);
        }

        sendAction(cmd, data) {
          let unixTime = TimeMgr.instance.serverTime;
          let action = new tigers.krun.KrunMsg();
          action.timestamp = unixTime;
          action.cmd = cmd;

          if (data) {
            action.body = data;
          }

          let bytebuf = tigers.krun.KrunMsg.encode(action).finish();
          this.sendProto(WSGameCmd.KrunMsg, bytebuf);
          console.log(`[NetworkBrigde] sendAction => ${cmd}`);
        }

        getRoomName() {
          let name = "krun";

          if (this.servers && this.servers.length > 0) {
            name = this.servers[math.randomRangeInt(0, this.servers.length)];
          } else if (!NetworkDefine.IsDev) {
            let index = math.randomRangeInt(0, 3);

            if (index > 0) {
              name = "krun" + index;
            }
          }

          return name;
        } /////////////////////Client-server////////////////////////////////


        authentication(token) {
          let data = new tigers.krun.internal.ReqVerify();
          data.jwt = token;
          let bytebuf = tigers.krun.internal.ReqVerify.encode(data).finish();
          this.sendProto("ReqVerify", bytebuf);
        }

        findRoom() {
          let worker = new tigers.krun.internal.ReqWorker();
          worker.game = this.getRoomName();
          let bytebuf = tigers.krun.internal.ReqWorker.encode(worker).finish();
          this.sendProto(WSCmd.ReqWorker, bytebuf);
          console.log("[NetworkBrigde] worker: ", worker.game);
        }

        reqDefines() {
          let request = new tigers.krun.KrunMsg();
          request.timestamp = TimeMgr.instance.serverTime;
          request.cmd = tigers.krun.KRUN_CMD.KRUN_CMD_DEFINES;
          this.sendProto(WSCmd.KrunMsg, tigers.krun.KrunMsg.encode(request).finish());
        }

        playerMove(moveCmd) {
          let request = new tigers.krun.KrunMsg();
          request.timestamp = TimeMgr.instance.serverTime;
          request.cmd = moveCmd;
          this.sendProto(WSCmd.KrunMsg, tigers.krun.KrunMsg.encode(request).finish()); // console.log("[NetworkBrigde] playerMove: ", moveCmd);
        }

        reqTurn() {
          let request = new tigers.krun.KrunMsg();
          request.timestamp = TimeMgr.instance.serverTime;
          request.cmd = tigers.krun.KRUN_CMD.KRUN_CMD_GET_TURN;
          this.sendProto(WSCmd.KrunMsg, tigers.krun.KrunMsg.encode(request).finish());
        }

        reqCandy() {
          let request = new tigers.krun.KrunMsg();
          request.timestamp = TimeMgr.instance.serverTime;
          request.cmd = tigers.krun.KRUN_CMD.KRUN_CMD_GET_CANDY;
          this.sendProto(WSCmd.KrunMsg, tigers.krun.KrunMsg.encode(request).finish());
        }

        quitGame() {
          let request = new tigers.krun.KrunMsg();
          request.timestamp = TimeMgr.instance.serverTime;
          request.cmd = tigers.krun.KRUN_CMD.KRUN_CMD_PLAYER_QUIT_GAME;
          this.sendProto(WSCmd.KrunMsg, tigers.krun.KrunMsg.encode(request).finish());
        } //  send action


        joinGame(gameId) {
          let reqPlayerJoin = new tigers.krun.KrunReqPlayerJoin();
          reqPlayerJoin.displayName = Profile.Instance.UserName;
          reqPlayerJoin.gameId = "";
          this.sendAction(tigers.krun.KRUN_CMD.KRUN_CMD_PLAYER_JOIN_GAME, tigers.krun.KrunReqPlayerJoin.encode(reqPlayerJoin).finish());
        }

        ping() {
          let request = new tigers.krun.internal.MsgPing();
          request.id = this.payloadCounter++;
          request.createAt = Date.now();
          let bytebuf = tigers.krun.internal.MsgPing.encode(request).finish();
          this.sendProto(WSCmd.MsgPing, bytebuf);
        }

        fireBullet(shooterId, targetId) {
          let bullet = new tigers.krun.KrunBullet();
          bullet.shooter = shooterId;
          bullet.target = targetId;
          bullet.effect = tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE;
          let body = tigers.krun.KrunBullet.encode(bullet).finish();
          this.sendAction(tigers.krun.KRUN_CMD.KRUN_CMD_PLAYER_FIRE_FREEZE_BULLET, body);
        } /////////////////////Game////////////////////////////////


      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LeaderBoardItem.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Utils.ts', './MaxApiUtils.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Label, Button, _decorator, Component, Features, Utils, MaxApiUtils;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Button = module.Button;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      Features = module.Features;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MaxApiUtils = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "7eba4myYwBG4JquhpQV1gUy", "LeaderBoardItem", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let LeaderBoardItem = exports('LeaderBoardItem', (_dec = ccclass('LeaderBoardItem'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Button), _dec(_class = (_class2 = (_temp = class LeaderBoardItem extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "rank", _descriptor, this);

          _initializerDefineProperty(this, "userName", _descriptor2, this);

          _initializerDefineProperty(this, "reward", _descriptor3, this);

          _initializerDefineProperty(this, "btnVisit", _descriptor4, this);

          _defineProperty(this, "uid", "");
        }

        start() {
          this.btnVisit.node.on("click", this.onVisitClick, this);
        }

        setInfo(uid, rank, userName, reward) {
          this.uid = uid;
          this.rank.string = rank < 0 ? "--" : (rank + 1).toString();
          this.userName.string = userName;
          this.reward.string = Utils.toLocalString(reward).toString();
        }

        onVisitClick() {
          MaxApiUtils.startFeatureCode(Features.MyHome.refId, {
            typeScreen: 'LiXiMyHouse',
            friendId: this.uid,
            callFrom: "lx2022_squid_game"
          }, () => {});
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rank", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "userName", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "reward", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btnVisit", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Joystick.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Input.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Node, _decorator, Component, Vec3, UITransform, Input;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      UITransform = module.UITransform;
    }, function (module) {
      Input = module.Input;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "83414a2p7NAYK9gPibYgbM6", "Joystick", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Joystick = exports('Joystick', (_dec = ccclass('Joystick'), _dec2 = property(Node), _dec(_class = (_class2 = (_temp = class Joystick extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "middle", _descriptor, this);

          _defineProperty(this, "radius", 200);

          _defineProperty(this, "direction", new Vec3());

          _defineProperty(this, "tempV3", new Vec3());
        }

        start() {
          this.radius = this.getComponent(UITransform).contentSize.width / 2;
        }

        update() {
          if (Input.IsTouchUp) {
            this.tempV3.set(Vec3.ZERO);
            this.middle.position = this.tempV3;
            Input.Reset();
          } else if (Input.IsTouchMove) {
            let length = Math.min(Input.Instance.delta.length(), this.radius);
            this.tempV3.set(Input.Instance.delta.x, Input.Instance.delta.y, 0);
            this.tempV3.normalize();
            this.tempV3.multiplyScalar(length);
            this.middle.position = this.tempV3;
          }
        }

        reset() {
          this.tempV3.set(Vec3.ZERO);
          this.middle.position = this.tempV3;
          Input.Reset();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "middle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Boss.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './AudioMgr.ts', './MaxApiUtils.ts', './TimeMgr.ts', './MapMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, SkeletalAnimationComponent, Node, _decorator, Component, EventName, SoundName, EventListener, AudioMgr, MaxApiUtils, TimeMgr, MapMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      SkeletalAnimationComponent = module.SkeletalAnimationComponent;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      EventName = module.EventName;
      SoundName = module.SoundName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      MapMgr = module.MapMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "87242R+tiRNcZQx86FdxMPg", "Boss", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Init"] = 1] = "Init";
        State[State["Idle"] = 2] = "Idle";
        State[State["InActive"] = 3] = "InActive";
        State[State["Active"] = 4] = "Active";
      })(State || (State = {}));

      let Boss = exports('Boss', (_dec = ccclass('Boss'), _dec2 = property(SkeletalAnimationComponent), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class Boss extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "animation", _descriptor, this);

          _initializerDefineProperty(this, "firePos", _descriptor2, this);

          _defineProperty(this, "state", State.None);

          _defineProperty(this, "isLoaded", false);

          _defineProperty(this, "netPhase", null);

          _defineProperty(this, "nextPhaseTime", 0);
        }

        start() {
          this.setState(State.Init);
          this.isLoaded = true;
        }

        gameUpdate(dt) {
          if (TimeMgr.instance.serverTime >= this.nextPhaseTime) {
            let info = MapMgr.Intance.getGamePhase();
            this.setPhase(info.phase);
            this.nextPhaseTime = info.time;
          }

          switch (this.state) {
            case State.Init:
              break;

            case State.InActive:
              break;

            case State.Active:
              break;
          }
        }

        setPhase(phase) {
          if (this.netPhase != phase) {
            // console.log(`[Boss] state: ${tigers.krun.KRUN_GAME_PHASE[this.netPhase]} => ${tigers.krun.KRUN_GAME_PHASE[phase]}`);
            this.netPhase = phase;

            switch (phase) {
              case tigers.krun.KRUN_GAME_PHASE.KRUN_GAME_PHASE_END:
                this.setState(State.Idle);
                break;

              case tigers.krun.KRUN_GAME_PHASE.KRUN_GAME_PHASE_RED:
                if (this.state != State.Active) {
                  this.setState(State.Active);
                }

              case tigers.krun.KRUN_GAME_PHASE.KRUN_GAME_PHASE_GREEN_TO_RED:
                this.setState(State.Active);
                MaxApiUtils.trackEvent({
                  rank_id: MapMgr.Intance.mine.rank
                });
                break;

              case tigers.krun.KRUN_GAME_PHASE.KRUN_GAME_PHASE_RED_TO_GREEN:
                this.setState(State.InActive);
                break;
            }
          }
        }

        setState(state) {
          if (this.state != state) {
            this.state = state;

            switch (state) {
              case State.Init:
                this.setState(State.Idle);
                break;

              case State.Idle:
                this.animation.play("Idle");
                AudioMgr.Instance.Stop();
                break;

              case State.InActive:
                EventListener.Instance.emit(EventName.onBossIdle);
                this.animation.play("Idle");
                AudioMgr.Instance.PlayMusicWithName(SoundName.BossActive, false);
                break;

              case State.Active:
                EventListener.Instance.emit(EventName.onBossActive);
                this.animation.play("Active");
                AudioMgr.Instance.Stop();
                break;
            }
          }
        }

        onAnimationBegin(name) {}

        onAnimationFinished() {
          this.setState(State.InActive);
        }

        getFirePos() {
          return this.firePos.worldPosition;
        }

        reset() {
          this.netPhase = null;
          this.nextPhaseTime = 0;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "animation", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "firePos", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PopupOutOfTurn.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Profile.ts', './MaxApiUtils.ts', './Popup.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, Label, _decorator, Features, Profile, MaxApiUtils, Popup;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      _decorator = module._decorator;
    }, function (module) {
      Features = module.Features;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Popup = module.Popup;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "95db9UTS+xEQr53Ma5Hr7Ce", "PopupOutOfTurn", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PopupOutOfTurn = exports('PopupOutOfTurn', (_dec = ccclass('PopupOutOfTurn'), _dec2 = property(Button), _dec3 = property(Label), _dec4 = property(Label), _dec(_class = (_class2 = (_temp = class PopupOutOfTurn extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnMoreTurn", _descriptor, this);

          _initializerDefineProperty(this, "btnMoreTurnText", _descriptor2, this);

          _initializerDefineProperty(this, "description", _descriptor3, this);
        }

        start() {
          super.start();
          this.btnMoreTurn.node.on("click", this.onMoreTurnClick, this);
        }

        Show() {
          super.Show();
          this.btnMoreTurnText.string = Profile.Instance.IsOnboarding ? "Đến Lắc Xì 2022" : "Tìm thêm lượt";
        }

        onMoreTurnClick() {
          MaxApiUtils.trackEvent({
            action: 'click_find_pu_no_turn',
            is_new_user: Profile.Instance.IsOnboarding
          });
          this.OnCloseClick();

          if (Profile.Instance.IsOnboarding) {
            MaxApiUtils.startFeatureCode(Features.HomePage.refId, Features.HomePage.params, () => {});
          } else {
            MaxApiUtils.startFeatureCode(Features.Mission.refId, Features.Mission.params, () => {});
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnMoreTurn", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnMoreTurnText", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "description", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Profile.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, game, DevicePerformance, EventName, EventListener;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      game = module.game;
    }, function (module) {
      DevicePerformance = module.DevicePerformance;
      EventName = module.EventName;
    }, function (module) {
      EventListener = module.EventListener;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "a294f7m3ZhJL5sqSxj8VgN4", "Profile", undefined);

      const {
        ccclass,
        property
      } = _decorator;

      class ProfileData {
        constructor() {
          _defineProperty(this, "id", "0938314557");

          _defineProperty(this, "token", "0938314557");

          _defineProperty(this, "uid", "");

          _defineProperty(this, "name", "Player");

          _defineProperty(this, "turn", 0);

          _defineProperty(this, "candy", 0);

          _defineProperty(this, "coin", 0);

          _defineProperty(this, "attackCount", 0);
        }

      }

      let Profile = exports('Profile', (_dec = ccclass('Profile'), _dec(_class = (_temp = _class2 = class Profile extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "data", new ProfileData());

          _defineProperty(this, "devicePerformance", DevicePerformance.LowEnd);

          _defineProperty(this, "isHighPerformanceDevice", void 0);

          _defineProperty(this, "iSOk", false);

          _defineProperty(this, "IsOnboarding", false);

          _defineProperty(this, "IsHomeMomo", true);
        }

        get UserID() {
          return this.data.id;
        }

        set UserID(value) {
          this.data.id = value;
        }

        get Uid() {
          return this.data.uid;
        }

        set Uid(value) {
          this.data.uid = value;
        }

        get UserToken() {
          return this.data.token;
        }

        set UserToken(value) {
          this.data.token = value;
        }

        get UserName() {
          return this.data.name;
        }

        set UserName(value) {
          this.data.name = value;
        }

        get turn() {
          return this.data.turn;
        }

        set turn(value) {
          this.data.turn = value;
        }

        get candy() {
          return this.data.candy;
        }

        set candy(value) {
          this.data.turn = value;
        }

        get coin() {
          return this.data.coin;
        }

        set coin(value) {
          this.data.coin = value;
        }

        get attackCount() {
          return this.data.attackCount;
        }

        set attackCount(value) {
          this.data.attackCount = value;
        }

        onLoad() {
          Profile.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onBlanceCandy, this.onBlanceCandy, this);
          EventListener.Instance.on(EventName.onBlanceTurn, this.onBlanceTurn, this);
          EventListener.Instance.on(EventName.onMatchingInfo, this.onMatchingInfo, this);
        }

        static get Instance() {
          return Profile.instance;
        }

        OnUpdateUserInfo(data) {
          if (data) {
            this.UserID = data.userId;
            this.UserToken = data.token;
          }

          console.log("[Profile] OnUpdateUserInfo:", data);
          this.iSOk = true;
        }

        onBlanceTurn(turn) {
          this.data.turn = turn;
        }

        onBlanceCandy(candy) {
          this.data.candy = candy;
        }

        onMatchingInfo(info) {
          this.attackCount = 0;
        }

        SetMaxFps() {
          if (this.devicePerformance == DevicePerformance.LowEnd) {
            game.frameRate = 30;
          } else if (this.devicePerformance == DevicePerformance.MideEnd) {
            game.frameRate = 45;
          } else {
            game.frameRate = 60;
          }
        }

        SetNormalFps() {
          if (this.devicePerformance == DevicePerformance.LowEnd) {
            game.frameRate = 30;
          } else if (this.devicePerformance == DevicePerformance.MideEnd) {
            game.frameRate = 30;
          } else {
            game.frameRate = 45;
          }
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PopupQuitGame.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './MaxApiUtils.ts', './Popup.ts', './MapMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, Label, _decorator, MaxApiUtils, Popup, MapMgr, GameMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      _decorator = module._decorator;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      MapMgr = module.MapMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "a37b0kW97hE57WWeCXWoN37", "PopupQuitGame", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PopupQuitGame = exports('PopupQuitGame', (_dec = ccclass('PopupQuitGame'), _dec2 = property(Button), _dec3 = property(Button), _dec4 = property(Label), _dec(_class = (_class2 = (_temp = class PopupQuitGame extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnContinue", _descriptor, this);

          _initializerDefineProperty(this, "btnQuit", _descriptor2, this);

          _initializerDefineProperty(this, "lableText", _descriptor3, this);
        }

        start() {
          super.start();
          this.btnContinue.node.on("click", this.onContinueClick, this);
          this.btnQuit.node.on("click", this.onQuitClick, this);
        }

        Show() {
          super.Show();
          let candy = MapMgr.Intance.getCandy();
          let rank = MapMgr.Intance.getRank();
          let y2 = "bạn chưa hoàn thành màn chơi.";

          if (rank > 0) {
            y2 = `bạn đạt hạng ${rank}/${MapMgr.Intance.playerCount}.`;
          }

          this.lableText.string = `Trận đấu đang diễn ra. Nếu bạn thoát lúc này sẽ nhận được ${candy} kẹo vì ${y2}`;
        }

        onContinueClick() {
          MaxApiUtils.trackEvent({
            action: 'click_play_pu_quit'
          });
          this.OnCloseClick();
        }

        onQuitClick() {
          MaxApiUtils.trackEvent({
            action: 'click_quit_pu_quit'
          });
          this.OnCloseClick();
          GameMgr.Instance.initRoom();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnContinue", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnQuit", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lableText", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Rotation.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, CCFloat, Vec3, _decorator, Component;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      CCFloat = module.CCFloat;
      Vec3 = module.Vec3;
      _decorator = module._decorator;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "a7d3a3PqslFMrquqCOy6rhZ", "Rotation", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      /**
       * Author = vhung.it
       *
       */

      let Rotation = exports('Rotation', (_dec = ccclass('Rotation'), _dec2 = property(CCFloat), _dec3 = property(Vec3), _dec(_class = (_class2 = (_temp = class Rotation extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "speed", _descriptor, this);

          _initializerDefineProperty(this, "direction", _descriptor2, this);

          _defineProperty(this, "eulerAngle", new Vec3());
        }

        start() {}

        update(dt) {
          this.eulerAngle.add(this.direction.normalize().multiplyScalar(this.speed * dt));
          this.node.eulerAngles = this.eulerAngle;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 100;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "direction", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3(0, 0, 1);
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MessageBox.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Popup.ts', './PopupMgr.ts', './TextDefine.ts', './NetworkMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Label, Sprite, Button, _decorator, PopupName, Popup, PopupMgr, Text, NetworkMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Sprite = module.Sprite;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      PopupName = module.PopupName;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _temp;

      cclegacy._RF.push({}, "aa4dbR79mdBM4DbTw+iqAVC", "MessageBox", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var MsgBoxType;

      (function (MsgBoxType) {
        MsgBoxType[MsgBoxType["OK"] = 0] = "OK";
        MsgBoxType[MsgBoxType["YesNo"] = 1] = "YesNo";
      })(MsgBoxType || (MsgBoxType = {}));

      let MessageBox = exports('MessageBox', (_dec = ccclass('MessageBox'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Label), _dec7 = property(Sprite), _dec8 = property(Button), _dec9 = property(Button), _dec10 = property(Button), _dec(_class = (_class2 = (_temp = class MessageBox extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lbTitle", _descriptor, this);

          _initializerDefineProperty(this, "lbDescription", _descriptor2, this);

          _initializerDefineProperty(this, "lbBtnOk", _descriptor3, this);

          _initializerDefineProperty(this, "lbBtnYes", _descriptor4, this);

          _initializerDefineProperty(this, "lbBtnNo", _descriptor5, this);

          _initializerDefineProperty(this, "icon", _descriptor6, this);

          _initializerDefineProperty(this, "btOk", _descriptor7, this);

          _initializerDefineProperty(this, "btYes", _descriptor8, this);

          _initializerDefineProperty(this, "btno", _descriptor9, this);

          _defineProperty(this, "okCallback", null);

          _defineProperty(this, "yesCallback", null);

          _defineProperty(this, "noCallback", null);

          _defineProperty(this, "type", MsgBoxType.OK);
        }

        start() {
          super.start();
          this.btOk.node.on("click", this.OnOkClick.bind(this));
          this.btYes.node.on("click", this.OnYesClick.bind(this));
          this.btno.node.on("click", this.OnNoClick.bind(this));
        }

        OnOkClick() {
          if (this.okCallback) {
            this.okCallback();
          }

          this.Hide();
        }

        OnYesClick() {
          if (this.yesCallback) {
            this.yesCallback();
          }

          this.Hide();
        }

        OnNoClick() {
          if (this.noCallback) {
            this.noCallback();
          }

          this.Hide();
        }

        SetInfo(title, description, image) {
          this.lbTitle.string = title;
          this.lbDescription.string = description;

          if (this.icon && image && image != "") {
            NetworkMgr.geSpriteFrameAsync(image).then(result => {
              if (result) {
                this.icon.spriteFrame = result;
              }
            }).catch(e => {
              console.warn(e);
            });
          }
        }

        SetTypeOk(textOk, callback) {
          this.lbBtnOk.string = textOk;
          this.okCallback = callback;
          this.SetType(MsgBoxType.OK);
        }

        SetTypeYesNo(textYes, textNo, yesCallback, noCallback) {
          this.lbBtnNo.string = textNo;
          this.lbBtnYes.string = textYes;
          this.yesCallback = yesCallback;
          this.noCallback = noCallback;
          this.SetType(MsgBoxType.YesNo);
        }

        SetType(type) {
          this.lbBtnNo.node.parent.active = false;
          this.lbBtnYes.node.parent.active = false;
          this.lbBtnOk.node.parent.active = false;

          switch (type) {
            case MsgBoxType.OK:
              this.lbBtnOk.node.parent.active = true;
              break;

            case MsgBoxType.YesNo:
              this.lbBtnNo.node.parent.active = true;
              this.lbBtnYes.node.parent.active = true;
              break;
          }
        }

        static Show(title, description, image = "") {
          if (PopupMgr.Instance) {
            let msgBox = PopupMgr.Instance.Show(PopupName.MessageBox);
            msgBox.SetInfo(title, description, image);
            msgBox.SetTypeOk(Text.Close, () => {});
            return msgBox;
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lbTitle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lbDescription", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnOk", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnYes", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnNo", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "icon", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "btOk", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "btYes", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "btno", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AppBridge.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "ad7b20sc3pJsK2A0J0YRNmf", "AppBridge", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AppBridge = exports('AppBridge', (_dec = ccclass('AppBridge'), _dec(_class = (_temp = _class2 = class AppBridge {
        constructor() {
          _defineProperty(this, "callbacks", []);

          this.Init();
        }

        static get Instance() {
          if (this.instance == null) {
            this.instance = new AppBridge();
          }

          return this.instance;
        }

        Init() {
          window.onmessage = event => {
            // console.log("onmessage: ", event);
            this.processMsg(event.data);
          };

          document.addEventListener("message", event => {
            // console.log("on document message: ", event);
            this.processMsg(event.data);
          });
        }

        processMsg(data) {
          if (typeof data == "string") {
            data = JSON.parse(data);
          }

          switch (data.type) {
            case "MaxAPI":
            case "WebGame":
              {
                switch (data.name) {
                  case "getProfile":
                  case "getNewProfile":
                  case "startFeatureCode":
                  case "getInventory":
                  case "getConfig":
                  case "getCoinBalance":
                    {
                      let callback = this.callbacks[data.name];

                      if (callback) {
                        callback(data.response);
                      }

                      this.callbacks[data.name] = null;
                    }
                    break;

                  case "onClickTopBarButton":
                  case "sound":
                    {
                      let callback = this.callbacks[data.name];

                      if (callback) {
                        callback(data.response);
                      }
                    }
                    break;
                }
              }
              break;
          }
        }

        sendMessage(type, name, params) {
          let data = {
            type,
            name,
            params
          };
          let myWindow = window;

          if (myWindow.ReactNativeWebView) {
            myWindow.ReactNativeWebView.postMessage(JSON.stringify(data));
          }

          console.log("Send App msg: ", data);
        }

        getUserProfile(callback) {
          this.callbacks["getProfile"] = callback;
          this.sendMessage("MaxAPI", "getProfile", {});
        }

        getNewUserProfile(callback) {
          this.callbacks["getNewProfile"] = callback; // {type: "MaxAPI", name: "getNewProfile", params: {}}

          this.sendMessage("MaxAPI", "getNewProfile", {});
        }

        startFeatureCode(featureCode, params, callback) {
          this.callbacks["startFeatureCode"] = callback;
          this.sendMessage("MaxAPI", "startFeatureCode", {
            featureCode,
            params
          });
        }

        trackEvent(name, params) {
          this.sendMessage("MaxAPI", "trackEvent", {
            name,
            params: params
          });
        }

        closeGame() {
          this.sendMessage("MaxAPI", "closeGame", {});
        }

        getDeviceInfo(callback) {
          this.callbacks["getDeviceInfo"] = callback;
          this.sendMessage("MaxAPI", "getDeviceInfo", {});
        }

        isHighPerformanceDevice(callback) {
          this.callbacks["isHighPerformanceDevice"] = callback;
          this.sendMessage("MaxAPI", "isHighPerformanceDevice", {});
        }

        vibrateDevice(callback) {
          this.callbacks["vibrateDevice"] = callback;
          this.sendMessage("MaxAPI", "vibrateDevice", {});
        }

        getInventory(callback) {
          //{type, name, params}
          this.callbacks["getInventory"] = callback;
          this.sendMessage("WebGame", "getInventory", {});
        }

        updateInventory(inventory) {
          //{type: "WebGame", name: "updateInventory", params: {"qua_1": true, "qua_2": true}}
          this.sendMessage("WebGame", "updateInventory", {
            inventory
          });
        }

        updateBalance(turn = null, candy = null) {
          //{type: "WebGame", name: "updateBalance", params: {turn: 999, candy: 888}}
          let param = {};
          if (turn != null) param.turn = turn;
          if (candy != null) param.candy = candy;
          this.sendMessage("WebGame", "updateBalance", param);
        }

        updateState(isStart) {
          this.sendMessage("WebGame", "updateState", {
            isStart
          });
        }

        updateTopBarState(isActive) {
          this.updateState(!isActive);
        }

        showGameInfo(isShow) {
          this.sendMessage("WebGame", "showGameInfo", {
            isShow
          });
        }

        onClickTopBarButton(callback) {
          // {type: "WebGame", name: "onClickTopBarButton", params: {}}
          this.callbacks["onClickTopBarButton"] = callback;
        }

        onStartShakeMoney(params) {
          // {type: "WebGame", name: "startShakeMoney", params: {shakeId: string, turnBalance: number, callFrom: string}}
          this.sendMessage("WebGame", "startShakeMoney", params);
        }

        getConfig(callback) {
          this.callbacks["getConfig"] = callback;
          this.sendMessage("WebGame", "getConfig", {}); // callback({"serviceCode":"lx2022_squid_game","env":"staging","isShowConsole":false,"webgameVersion":{"squidgame":"1"},"serverPort":4872,"featureCode":"lx2022_squid_game","features":[],"screen":"WebGame"})
        }

        goBack() {
          this.sendMessage("MaxAPI", "goBack", {});
        }

        onShare(params) {
          // {type: "WebGame", name: "share", params:}
          this.sendMessage("WebGame", "share", params);
        }

        getSoundSetting(callback) {
          this.callbacks["sound"] = callback;
          this.sendMessage("WebGame", "sound", {});
        }

        getCoinBalance(callback) {
          this.callbacks["getCoinBalance"] = callback;
          this.sendMessage("WebGame", "getCoinBalance", {});
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/patchproto.js", ['./cjs-loader.mjs'], function (exports, module) {
  'use strict';

  var loader;
  return {
    setters: [function (module) {
      loader = module.default;
    }],
    execute: function () {
      exports('default', void 0);

      let _cjsExports;

      loader.define(module.meta.url, function (exports$1, _require, module, __filename, __dirname) {
        let require = loader.createRequireWithReqMap({}, _require);

        (function () {
          (function () {
            if ('File' in self) {
              File.prototype.arrayBuffer = File.prototype.arrayBuffer || myArrayBuffer;
            }

            Blob.prototype.arrayBuffer = Blob.prototype.arrayBuffer || myArrayBuffer;

            function myArrayBuffer() {
              // this: File or Blob
              return new Promise(resolve => {
                let fr = new FileReader();

                fr.onload = () => {
                  resolve(fr.result);
                };

                fr.readAsArrayBuffer(this);
              });
            }
          })();
        })();

        _cjsExports = exports('default', module.exports);
      });

      const __cjsMetaURL = exports('__cjsMetaURL', module.meta.url);
    }
  };
});

System.register("chunks:///_virtual/NetworkMgr.ts", ['cc', './Profile.ts'], function (exports) {
  'use strict';

  var cclegacy, Component, assetManager, SpriteFrame, Texture2D, _decorator, Profile;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Component = module.Component;
      assetManager = module.assetManager;
      SpriteFrame = module.SpriteFrame;
      Texture2D = module.Texture2D;
      _decorator = module._decorator;
    }, function (module) {
      Profile = module.Profile;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "b72b0V4dQJJTLMgBo4CZ95K", "NetworkMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let NetworkMgr = exports('NetworkMgr', (_dec = ccclass('NetworkMgr'), _dec(_class = class NetworkMgr extends Component {
        start() {}

        static getRequest(url, callback) {
          let XMLHttp = new XMLHttpRequest();
          XMLHttp.open("GET", url, true);
          XMLHttp.timeout = 3000; // time in milliseconds

          XMLHttp.responseType = "json";
          XMLHttp.setRequestHeader('Authorization', `Bearer ${Profile.Instance.UserToken}`);
          XMLHttp.setRequestHeader("Content-Type", "application/json");
          console.log("[NetworkMgr] GET: " + " " + url);

          XMLHttp.onreadystatechange = () => {
            console.log(`state = ${XMLHttp.readyState} status =${XMLHttp.status}`);

            if (XMLHttp.readyState == 4) {
              if (XMLHttp.status == 200) {
                switch (XMLHttp.responseType) {
                  case 'text':
                    // console.log(XMLHttp.responseText);
                    callback(XMLHttp.responseText);
                    break;

                  default:
                    // console.log(XMLHttp.response);
                    callback(XMLHttp.response);
                    break;
                }
              } else if (XMLHttp.status >= 400 || XMLHttp.status === 0) {
                callback(null);
              }
            }
          };

          XMLHttp.send();
        }

        static postRequest(url, params, callback) {
          return new Promise((resolve, reject) => {
            let XMLHttp = new XMLHttpRequest();
            XMLHttp.open("POST", url, true);
            XMLHttp.timeout = 3000; // time in milliseconds

            XMLHttp.responseType = "json";
            XMLHttp.setRequestHeader('Authorization', `Bearer ${Profile.Instance.UserToken}`);
            XMLHttp.setRequestHeader("Content-Type", "application/json");
            console.log("[NetworkMgr] POST: " + " " + url);

            XMLHttp.onreadystatechange = () => {
              console.log(`state = ${XMLHttp.readyState} status =${XMLHttp.status}`);

              if (XMLHttp.readyState == 4) {
                if (XMLHttp.status == 200) {
                  switch (XMLHttp.responseType) {
                    case 'text':
                      // console.log(XMLHttp.responseText);
                      callback(XMLHttp.responseText);
                      break;

                    default:
                      // console.log(XMLHttp.response);
                      callback(XMLHttp.response);
                      break;
                  }
                } else if (XMLHttp.status >= 400 || XMLHttp.status === 0) {
                  callback(null);
                }
              }
            };

            XMLHttp.send(JSON.stringify(params));
          });
        }

        static geSpriteFrameAsync(imgUrl) {
          imgUrl = imgUrl.replace("img.mservice.io", "atc-edge03.mservice.com.vn");
          return new Promise((resolve, reject) => {
            assetManager.loadRemote(imgUrl, {
              cacheEnabled: true,
              maxRetryCount: 0
            }, (err, imageAsset) => {
              if (err) {
                resolve(null);
                console.warn(err);
              } else {
                if (imageAsset) {
                  const spriteFrame = new SpriteFrame();
                  const texture = new Texture2D();
                  texture.image = imageAsset;
                  spriteFrame.texture = texture;
                  resolve(spriteFrame);
                } else {
                  resolve(null);
                }
              }
            });
          });
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Notify.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, Label, UIOpacity, Vec3, tween;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Label = module.Label;
      UIOpacity = module.UIOpacity;
      Vec3 = module.Vec3;
      tween = module.tween;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "bc29aRMrJBMT6UaznXwO5j9", "Notify", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Notify = exports('Notify', (_dec = ccclass('Notify'), _dec(_class = (_temp = class Notify extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "uiOpacity", null);

          _defineProperty(this, "labelContent", null);

          _defineProperty(this, "startPos", void 0);
        }

        onLoad() {
          this.labelContent = this.getComponent(Label);
          this.uiOpacity = this.getComponent(UIOpacity);
          this.startPos = this.node.worldPosition;
        }

        start() {}

        showAt(pos, str) {
          this.startPos = pos;
          this.show(str);
        }

        show(str) {
          this.labelContent.string = str;
          this.node.worldPosition = this.startPos;
          this.node.scale.set(Vec3.ZERO);
          tween(this.node).parallel(tween().to(3, {
            worldPosition: new Vec3(this.startPos.x, this.startPos.y + 150, this.startPos.z)
          }, {
            easing: "cubicIn",
            onUpdate: this.onUpdateOpacity.bind(this)
          }), tween().to(0.2, {
            scale: Vec3.ONE
          }, {
            easing: "elasticOut"
          })).call(() => {
            this.hide();
          }).start();
        }

        hide() {
          this.node.destroy();
        }

        onUpdateOpacity(target, ratio) {
          this.uiOpacity.opacity = (1 - ratio) * 256;
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameInfo.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Popup.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, _decorator, Popup, GameMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "c10e01i8MxOrZXD7oubpaw4", "GameInfo", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let GameInfo = exports('GameInfo', (_dec = ccclass('GameInfo'), _dec2 = property(Button), _dec(_class = (_class2 = (_temp = class GameInfo extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnStart", _descriptor, this);
        }

        start() {
          this.btnStart.node.on("click", this.onStartClick, this);
        }

        onStartClick() {
          GameMgr.Instance.findRoom();
          this.OnCloseClick();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnStart", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PopupMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Popup.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Prefab, _decorator, Component, instantiate, resources, PopupName, Popup;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      _decorator = module._decorator;
      Component = module.Component;
      instantiate = module.instantiate;
      resources = module.resources;
    }, function (module) {
      PopupName = module.PopupName;
    }, function (module) {
      Popup = module.Popup;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "c11c1DECexCEJoTf4nhLRP9", "PopupMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PopupMgr = exports('PopupMgr', (_dec = ccclass('PopupMgr'), _dec2 = property(Prefab), _dec(_class = (_class2 = (_temp = _class3 = class PopupMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "prefabs", _descriptor, this);
        }

        onLoad() {
          PopupMgr.instance = this;
        }

        start() {
          this.Load();
        }

        static get Instance() {
          return PopupMgr.instance;
        }

        Show(name, onClose = null) {
          if (!this.node.getChildByName(name)) {
            let prefab = this.prefabs.find(prefab => prefab.data.name == name);

            if (prefab) {
              let popup = instantiate(prefab).getComponent(Popup);

              if (onClose) {
                popup.onClose = onClose;
              }

              popup.node.setParent(this.node);
              popup.node.name = name;
              popup.Show();
              return popup;
            }
          }
        }

        Hide(name) {
          this.node.children.forEach(child => {
            if (child.name == name) {
              child.getComponent(Popup).Hide();
            }
          });
        }

        hideAll() {
          this.node.children.forEach(child => {
            if (child.active) {
              child.getComponent(Popup).Hide();
            }
          });
        }

        IsContain(name) {
          let result = false;
          this.prefabs.forEach(child => {
            if (child.data.name == name) {
              result = true;
              return;
            }
          });
          return result;
        }

        Load() {
          let array = Object.keys(PopupName);
          array.forEach(element => {
            if (!this.IsContain(element)) {
              resources.load("prefabs/popups/" + element, (err, prefab) => {
                if (prefab) {
                  this.prefabs.push(prefab);
                  console.log("Popup loaded: " + element);
                } else {
                  console.error("Popup loade fail: " + element);
                }
              });
            }
          });
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "prefabs", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Loading.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './TextDefine.ts', './Screen.ts', './ScreenMgr.ts', './GameMgr.ts', './MessageBox.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, ScreenName, Text, Screen, ScreenMgr, GameMgr, MessageBox;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      ScreenName = module.ScreenName;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }, function (module) {
      MessageBox = module.MessageBox;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "c18c541V+VCF5IglsA2JHul", "Loading", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Loading = exports('Loading', (_dec = ccclass('Loading'), _dec(_class = (_temp = _class2 = class Loading extends Screen {
        onLoad() {
          Loading.instance = this;
        }

        start() {}

        update(dt) {}

        onClickCloseGame() {
          let msgBox = MessageBox.Show(Text.ExitGameTitle, Text.ExitGameContent);
          msgBox.SetTypeYesNo(Text.Continues, Text.Exit, () => {}, () => {
            GameMgr.Instance.closeGame();
          });
        }

        static get Instance() {
          return Loading.instance;
        }

        onDone() {
          ScreenMgr.Instance.HideAll();
          ScreenMgr.Instance.Show(ScreenName.InGame);
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AnimationEvent.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Event.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, AnimationEventName, Event;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      AnimationEventName = module.AnimationEventName;
    }, function (module) {
      Event = module.Event;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "c280d1x/dNPQo9t0nB/Icj6", "AnimationEvent", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AnimationEvent = exports('AnimationEvent', (_dec = ccclass('AnimationEvent'), _dec(_class = (_temp = class AnimationEvent extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "event", new Event());
        }

        start() {}

        onAnimationBegin(name) {
          this.event.emit(AnimationEventName.onAnimationBegin, name);
        }

        onAnimationFinished(name) {
          this.event.emit(AnimationEventName.onAnimationFinished, name);
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Screen.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, Component, _decorator;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Component = module.Component;
      _decorator = module._decorator;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "c58fb0UaBdPmZ0HsdHZQMxC", "Screen", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Screen = exports('Screen', (_dec = ccclass('Screen'), _dec(_class = class Screen extends Component {
        show() {
          this.node.active = true;
        }

        hide() {
          this.node.active = false;
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BulletMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './AudioMgr.ts', './TimeMgr.ts', './Bullet.ts', './MapMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Prefab, _decorator, Component, instantiate, SoundName, AudioMgr, TimeMgr, Bullet, MapMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      _decorator = module._decorator;
      Component = module.Component;
      instantiate = module.instantiate;
    }, function (module) {
      SoundName = module.SoundName;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      Bullet = module.Bullet;
    }, function (module) {
      MapMgr = module.MapMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "c640cscx+xHAZhrAEBfBY7P", "BulletMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;

      class BulletStatus {
        constructor() {
          _defineProperty(this, "active", void 0);

          _defineProperty(this, "data", void 0);
        }

      }

      let BulletMgr = exports('BulletMgr', (_dec = ccclass('BulletMgr'), _dec2 = property(Prefab), _dec(_class = (_class2 = (_temp = _class3 = class BulletMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "bulletPrefab", _descriptor, this);

          _defineProperty(this, "bullets", []);

          _defineProperty(this, "buletInstance", []);
        }

        static get Instance() {
          return BulletMgr.instance;
        }

        onLoad() {
          BulletMgr.instance = this;
        }

        gameUpdate(dt) {
          this.bullets.forEach((bullet, index) => {
            if (bullet.active && TimeMgr.instance.serverTime >= bullet.data.shootAt) {
              bullet.active = false;
              let effect = bullet.data.effect;

              switch (bullet.data.effect) {
                case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE:
                  console.log(`[BulletMgr] player ${bullet.data.shooter} shoot ${bullet.data.target} with effect ${effect}`); // this.missile(bullet.data, MapMgr.Intance.getPlayer(bullet.data.target));

                  this.fire(bullet.data, MapMgr.Intance.getPlayer(bullet.data.shooter).getAim(), MapMgr.Intance.getPlayer(bullet.data.target));
                  break;

                case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_PENALTY:
                  console.log(`[BulletMgr] Boss shoot ${bullet.data.target} with effect ${effect}`);
                  this.fire(bullet.data, MapMgr.Intance.boss.getFirePos(), MapMgr.Intance.getPlayer(bullet.data.target));
                  break;
              }
            } //     bullet.active = false;
            //     let effect: tigers.krun.KRUN_BULLET_EFFECTS = bullet.data.effect;
            //     switch (bullet.data.effect) {
            //         case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE:
            //             console.log(`[BulletMgr] player ${bullet.data.shooter} hit ${bullet.data.target} with effect ${effect}`);
            //             if (bullet.data.target != Profile.Instance.UserID) {
            //                 NotifyMgr.Instance.show(NotifyName.BattleMsg, `${bullet.data.target} bất động 2 giây vì bị dính kỹ năng của ${bullet.data.shooter}`);
            //             }
            //             this.missile(bullet.data, MapMgr.Intance.getPlayer(bullet.data.target));
            //             break;
            //         case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_PENALTY:
            //             this.fire(bullet.data, MapMgr.Intance.boss.getFirePos(), MapMgr.Intance.getPlayer(bullet.data.target));
            //             break;
            //     }
            // }

          });
          this.buletInstance.forEach(bullet => {
            if (bullet.node.active) {
              bullet.gameUpdate(dt);
            }
          });
        }

        netUpdate(bullets) {
          bullets.forEach(bullet => {
            if (!this.isContainNetBullet(bullet)) {
              let b = new BulletStatus();
              b.active = true;
              b.data = bullet;
              b.data.hitAt = TimeMgr.instance.serverTime + (b.data.hitAt - b.data.shootAt) * MapMgr.Intance.mapConfig.timePerFrame;
              b.data.shootAt = TimeMgr.instance.serverTime;
              this.bullets.push(b); // console.log("[BulletMgr] add bullet: ", b.data.effect);
            }
          });
        }

        isContainNetBullet(bullet) {
          let result = false;
          this.bullets.forEach(b => {
            if (b.data.uid == bullet.uid) {
              result = true;
              return;
            }
          });
          return result;
        }

        reset() {
          this.bullets = [];
        }

        getAvailableBullet(type) {
          let bullet = this.buletInstance.find(b => {
            return !b.node.active;
          });

          if (!bullet) {
            bullet = instantiate(this.bulletPrefab).getComponent(Bullet);
            bullet.node.setParent(this.node);
            bullet.node.active = true;
            this.buletInstance.push(bullet);
          }

          return bullet;
        }

        fire(netBullet, wpos, target) {
          let bullet = this.getAvailableBullet(netBullet.effect);
          bullet.node.active = true;
          bullet.node.setWorldPosition(wpos);
          bullet.node.name = target.name;
          bullet.fire(wpos, target, netBullet);
          AudioMgr.Instance.PlaySfx(SoundName.BossShoot, true);
        }

        missile(netBullet, target) {
          let wpos = target.node.worldPosition.clone();
          wpos.add3f(0, 15, 0);
          let bullet = this.getAvailableBullet(netBullet.effect);
          bullet.node.setWorldPosition(wpos);
          bullet.node.name = target.name;
          bullet.fire(wpos, target, netBullet);
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "bulletPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TimeMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './NetworkDefine.ts', './PopupMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, EventName, PopupName, EventListener, NetworkDefine, PopupMgr, GameMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      EventName = module.EventName;
      PopupName = module.PopupName;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      NetworkDefine = module.NetworkDefine;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "ca6dbPXO9hMhoisIAPnFaOx", "TimeMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let TimeMgr = exports('TimeMgr', (_dec = ccclass('TimeMgr'), _dec(_class = (_temp = _class2 = class TimeMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "syncTimeDuration", 1.0);

          _defineProperty(this, "syncPeriod", 5.0);

          _defineProperty(this, "syncTimeBound", 0);

          _defineProperty(this, "localTimeSyncDuration", 0);

          _defineProperty(this, "serverTimeSyncDuration", 0);

          _defineProperty(this, "lastSyncTime", 0);

          _defineProperty(this, "lastServerTime", 0);

          _defineProperty(this, "timeBeforeSync", 0);

          _defineProperty(this, "elapsedTimeFromLastRequest", Number.MAX_VALUE);

          _defineProperty(this, "startupTime", Date.now());

          _defineProperty(this, "popupLostConnection", null);
        }

        onLoad() {
          TimeMgr.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onPing, this.synchronize, this); // this.lastSyncTime = this.realtimeSinceStartup();
        }

        reset() {
          this.syncTimeBound = 0;
          this.localTimeSyncDuration = 0;
          this.serverTimeSyncDuration = 0;
          this.lastSyncTime = 0;
          this.realtimeSinceStartup();
          this.lastServerTime = 0;
          this.timeBeforeSync = 0;
          this.elapsedTimeFromLastRequest = Number.MAX_VALUE;
        }

        get serverTime() {
          let localTime = this.localTime;
          if (localTime >= this.syncTimeBound) return localTime;else return this.syncTimeBound - this.localTimeSyncDuration * ((this.syncTimeBound - localTime) / this.serverTimeSyncDuration);
        }

        get localTime() {
          return this.lastServerTime + this.realtimeSinceStartup() - this.lastSyncTime;
        }

        update(dt) {
          if (GameMgr.Instance.isPingReady) {
            if (this.elapsedTimeFromLastRequest > this.syncPeriod) {
              this.elapsedTimeFromLastRequest = 0;
              this.timeBeforeSync = this.realtimeSinceStartup();
              GameMgr.Instance.requestServerTime();
            } else {
              this.elapsedTimeFromLastRequest += dt;
            }

            if (this.popupLostConnection == null && this.lastSyncTime != 0 && this.realtimeSinceStartup() - this.lastSyncTime > NetworkDefine.lostConnectionTime) {
              EventListener.Instance.emit(EventName.onLostConnection);
              this.popupLostConnection = PopupMgr.Instance.Show(PopupName.LostConnection, () => {
                this.popupLostConnection = null;
                this.lastSyncTime = this.realtimeSinceStartup();
                GameMgr.Instance.reconnect();
              });
            }
          }
        }

        synchronize(time, ping) {
          let realtimeSinceStartup = this.realtimeSinceStartup();

          if (this.lastServerTime > 0) {
            let ping = realtimeSinceStartup - this.timeBeforeSync;
            let localTime = this.serverTime;
            let serverTime = time + ping / 2;
            if (serverTime > localTime) this.syncTimeBound = serverTime + this.syncTimeDuration;else this.syncTimeBound = localTime + this.syncTimeDuration;
            this.localTimeSyncDuration = this.syncTimeBound - localTime;
            this.serverTimeSyncDuration = this.syncTimeBound - serverTime;
            this.lastServerTime = serverTime;
          } else this.lastServerTime = time;

          this.lastSyncTime = realtimeSinceStartup;
        }

        realtimeSinceStartup() {
          return Date.now() - this.startupTime;
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/FindMatchFail.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Popup.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Button, _decorator, Popup, GameMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "d4409eTQOxDe5FiC42VEWZU", "FindMatchFail", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let FindMatchFail = exports('FindMatchFail', (_dec = ccclass('FindMatchFail'), _dec2 = property(Button), _dec(_class = (_class2 = (_temp = class FindMatchFail extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnContinue", _descriptor, this);
        }

        start() {
          this.btnContinue.node.on("click", this.onContinue, this);
        }

        onContinue() {
          GameMgr.Instance.findRoom();
          this.OnCloseClick();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnContinue", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MySprite.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Utils.ts', './NetworkMgr.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, Sprite, _decorator, Component, UITransform, Size, assetManager, SpriteFrame, Texture2D, Vec3, Utils, NetworkMgr;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Component = module.Component;
      UITransform = module.UITransform;
      Size = module.Size;
      assetManager = module.assetManager;
      SpriteFrame = module.SpriteFrame;
      Texture2D = module.Texture2D;
      Vec3 = module.Vec3;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _temp;

      cclegacy._RF.push({}, "d56eeYe8MFLU4l4wOAycQQz", "MySprite", undefined);

      const {
        ccclass,
        property,
        requireComponent
      } = _decorator;
      let MySprite = exports('MySprite', (_dec = ccclass('MySprite'), _dec2 = requireComponent(Sprite), _dec(_class = _dec2(_class = (_temp = class MySprite extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "sprite", null);

          _defineProperty(this, "url", "");

          _defineProperty(this, "size", void 0);
        }

        onLoad() {
          if (!this.sprite) this.sprite = this.getComponent(Sprite);
          let uit = this.sprite.getComponent(UITransform);
          this.size = new Size(uit.width, uit.height);
          this.sprite.sizeMode = Sprite.SizeMode.RAW;
        }

        setFixedSize(fixedSize) {
          this.size = fixedSize.clone();
          this.sprite.sizeMode = Sprite.SizeMode.RAW;
        }

        correctSpriteFrameSize(fixedSize) {
          this.setFixedSize(fixedSize);
          Utils.CorrectSpriteFrameSize(this.sprite, this.size);
        }

        Fetch(url) {
          if (url && this.url != url) {
            if (assetManager.assets.has(url)) {
              const spriteFrame = new SpriteFrame();
              const texture = new Texture2D();
              texture.image = assetManager.assets.get(url);
              spriteFrame.texture = texture;
              this.sprite.spriteFrame = spriteFrame;
              Utils.CorrectSpriteFrameSize(this.sprite, this.size);
            } else {
              NetworkMgr.geSpriteFrameAsync(url).then(frame => {
                if (frame) {
                  this.sprite.spriteFrame = frame;
                  Utils.CorrectSpriteFrameSize(this.sprite, this.size);
                }
              });
            }
          }
        }

        get Sprite() {
          return this.sprite;
        }

        setSprite(spriteFrame, isResetScal = false) {
          this.sprite.spriteFrame = spriteFrame;

          if (isResetScal) {
            this.node.scale = Vec3.ONE;
          } else {
            Utils.CorrectSpriteFrameSize(this.sprite, this.size);
          }
        }

      }, _temp)) || _class) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/tigers.js", ['./cjs-loader.mjs'], function (exports, module) {
  'use strict';

  var loader;
  return {
    setters: [function (module) {
      loader = module.default;
    }],
    execute: function () {
      exports('default', void 0);

      let _cjsExports;

      loader.define(module.meta.url, function (exports$1, _require, module, __filename, __dirname) {
        let require = loader.createRequireWithReqMap({}, _require);

        (function () {
          /*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
          (window || global).tigers = function ($protobuf) {
            var $Reader = $protobuf.Reader,
                $Writer = $protobuf.Writer,
                $util = $protobuf.util; // Exported root namespace

            var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

            $root.tigers = function () {
              /**
               * Namespace tigers.
               * @exports tigers
               * @namespace
               */
              var tigers = {};

              tigers.krun = function () {
                /**
                 * Namespace krun.
                 * @memberof tigers
                 * @namespace
                 */
                var krun = {};

                krun.internal = function () {
                  /**
                   * Namespace internal.
                   * @memberof tigers.krun
                   * @namespace
                   */
                  var internal = {};

                  internal.MsgUser = function () {
                    /**
                     * Properties of a MsgUser.
                     * @memberof tigers.krun.internal
                     * @interface IMsgUser
                     * @property {string|null} [uid] MsgUser uid
                     * @property {string|null} [channel] MsgUser channel
                     */

                    /**
                     * Constructs a new MsgUser.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a MsgUser.
                     * @implements IMsgUser
                     * @constructor
                     * @param {tigers.krun.internal.IMsgUser=} [properties] Properties to set
                     */
                    function MsgUser(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * MsgUser uid.
                     * @member {string} uid
                     * @memberof tigers.krun.internal.MsgUser
                     * @instance
                     */


                    MsgUser.prototype.uid = "";
                    /**
                     * MsgUser channel.
                     * @member {string} channel
                     * @memberof tigers.krun.internal.MsgUser
                     * @instance
                     */

                    MsgUser.prototype.channel = "";
                    /**
                     * Creates a new MsgUser instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {tigers.krun.internal.IMsgUser=} [properties] Properties to set
                     * @returns {tigers.krun.internal.MsgUser} MsgUser instance
                     */

                    MsgUser.create = function create(properties) {
                      return new MsgUser(properties);
                    };
                    /**
                     * Encodes the specified MsgUser message. Does not implicitly {@link tigers.krun.internal.MsgUser.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {tigers.krun.internal.IMsgUser} message MsgUser message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MsgUser.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.uid != null && message.hasOwnProperty("uid")) writer.uint32(
                      /* id 1, wireType 2 =*/
                      10).string(message.uid);
                      if (message.channel != null && message.hasOwnProperty("channel")) writer.uint32(
                      /* id 2, wireType 2 =*/
                      18).string(message.channel);
                      return writer;
                    };
                    /**
                     * Encodes the specified MsgUser message, length delimited. Does not implicitly {@link tigers.krun.internal.MsgUser.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {tigers.krun.internal.IMsgUser} message MsgUser message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MsgUser.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a MsgUser message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.MsgUser} MsgUser
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MsgUser.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.MsgUser();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            message.uid = reader.string();
                            break;

                          case 2:
                            message.channel = reader.string();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a MsgUser message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.MsgUser} MsgUser
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MsgUser.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a MsgUser message.
                     * @function verify
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    MsgUser.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";
                      if (message.uid != null && message.hasOwnProperty("uid")) if (!$util.isString(message.uid)) return "uid: string expected";
                      if (message.channel != null && message.hasOwnProperty("channel")) if (!$util.isString(message.channel)) return "channel: string expected";
                      return null;
                    };
                    /**
                     * Creates a MsgUser message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.MsgUser} MsgUser
                     */


                    MsgUser.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.MsgUser) return object;
                      var message = new $root.tigers.krun.internal.MsgUser();
                      if (object.uid != null) message.uid = String(object.uid);
                      if (object.channel != null) message.channel = String(object.channel);
                      return message;
                    };
                    /**
                     * Creates a plain object from a MsgUser message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.MsgUser
                     * @static
                     * @param {tigers.krun.internal.MsgUser} message MsgUser
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    MsgUser.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};

                      if (options.defaults) {
                        object.uid = "";
                        object.channel = "";
                      }

                      if (message.uid != null && message.hasOwnProperty("uid")) object.uid = message.uid;
                      if (message.channel != null && message.hasOwnProperty("channel")) object.channel = message.channel;
                      return object;
                    };
                    /**
                     * Converts this MsgUser to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.MsgUser
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    MsgUser.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return MsgUser;
                  }();

                  internal.MessageWrapper = function () {
                    /**
                     * Properties of a MessageWrapper.
                     * @memberof tigers.krun.internal
                     * @interface IMessageWrapper
                     * @property {Array.<tigers.krun.internal.IMsgUser>|null} [users] MessageWrapper users
                     * @property {string|null} [connector] MessageWrapper connector
                     * @property {string|null} [worker] MessageWrapper worker
                     * @property {string|null} [msgClass] MessageWrapper msgClass
                     * @property {Uint8Array|null} [msg] MessageWrapper msg
                     * @property {string|null} [error] MessageWrapper error
                     */

                    /**
                     * Constructs a new MessageWrapper.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a MessageWrapper.
                     * @implements IMessageWrapper
                     * @constructor
                     * @param {tigers.krun.internal.IMessageWrapper=} [properties] Properties to set
                     */
                    function MessageWrapper(properties) {
                      this.users = [];
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * MessageWrapper users.
                     * @member {Array.<tigers.krun.internal.IMsgUser>} users
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     */


                    MessageWrapper.prototype.users = $util.emptyArray;
                    /**
                     * MessageWrapper connector.
                     * @member {string} connector
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     */

                    MessageWrapper.prototype.connector = "";
                    /**
                     * MessageWrapper worker.
                     * @member {string} worker
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     */

                    MessageWrapper.prototype.worker = "";
                    /**
                     * MessageWrapper msgClass.
                     * @member {string} msgClass
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     */

                    MessageWrapper.prototype.msgClass = "";
                    /**
                     * MessageWrapper msg.
                     * @member {Uint8Array} msg
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     */

                    MessageWrapper.prototype.msg = $util.newBuffer([]);
                    /**
                     * MessageWrapper error.
                     * @member {string} error
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     */

                    MessageWrapper.prototype.error = "";
                    /**
                     * Creates a new MessageWrapper instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {tigers.krun.internal.IMessageWrapper=} [properties] Properties to set
                     * @returns {tigers.krun.internal.MessageWrapper} MessageWrapper instance
                     */

                    MessageWrapper.create = function create(properties) {
                      return new MessageWrapper(properties);
                    };
                    /**
                     * Encodes the specified MessageWrapper message. Does not implicitly {@link tigers.krun.internal.MessageWrapper.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {tigers.krun.internal.IMessageWrapper} message MessageWrapper message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MessageWrapper.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.users != null && message.users.length) for (var i = 0; i < message.users.length; ++i) $root.tigers.krun.internal.MsgUser.encode(message.users[i], writer.uint32(
                      /* id 1, wireType 2 =*/
                      10).fork()).ldelim();
                      if (message.connector != null && message.hasOwnProperty("connector")) writer.uint32(
                      /* id 2, wireType 2 =*/
                      18).string(message.connector);
                      if (message.worker != null && message.hasOwnProperty("worker")) writer.uint32(
                      /* id 3, wireType 2 =*/
                      26).string(message.worker);
                      if (message.msgClass != null && message.hasOwnProperty("msgClass")) writer.uint32(
                      /* id 4, wireType 2 =*/
                      34).string(message.msgClass);
                      if (message.msg != null && message.hasOwnProperty("msg")) writer.uint32(
                      /* id 5, wireType 2 =*/
                      42).bytes(message.msg);
                      if (message.error != null && message.hasOwnProperty("error")) writer.uint32(
                      /* id 6, wireType 2 =*/
                      50).string(message.error);
                      return writer;
                    };
                    /**
                     * Encodes the specified MessageWrapper message, length delimited. Does not implicitly {@link tigers.krun.internal.MessageWrapper.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {tigers.krun.internal.IMessageWrapper} message MessageWrapper message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MessageWrapper.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a MessageWrapper message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.MessageWrapper} MessageWrapper
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MessageWrapper.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.MessageWrapper();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            if (!(message.users && message.users.length)) message.users = [];
                            message.users.push($root.tigers.krun.internal.MsgUser.decode(reader, reader.uint32()));
                            break;

                          case 2:
                            message.connector = reader.string();
                            break;

                          case 3:
                            message.worker = reader.string();
                            break;

                          case 4:
                            message.msgClass = reader.string();
                            break;

                          case 5:
                            message.msg = reader.bytes();
                            break;

                          case 6:
                            message.error = reader.string();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a MessageWrapper message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.MessageWrapper} MessageWrapper
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MessageWrapper.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a MessageWrapper message.
                     * @function verify
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    MessageWrapper.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";

                      if (message.users != null && message.hasOwnProperty("users")) {
                        if (!Array.isArray(message.users)) return "users: array expected";

                        for (var i = 0; i < message.users.length; ++i) {
                          var error = $root.tigers.krun.internal.MsgUser.verify(message.users[i]);
                          if (error) return "users." + error;
                        }
                      }

                      if (message.connector != null && message.hasOwnProperty("connector")) if (!$util.isString(message.connector)) return "connector: string expected";
                      if (message.worker != null && message.hasOwnProperty("worker")) if (!$util.isString(message.worker)) return "worker: string expected";
                      if (message.msgClass != null && message.hasOwnProperty("msgClass")) if (!$util.isString(message.msgClass)) return "msgClass: string expected";
                      if (message.msg != null && message.hasOwnProperty("msg")) if (!(message.msg && typeof message.msg.length === "number" || $util.isString(message.msg))) return "msg: buffer expected";
                      if (message.error != null && message.hasOwnProperty("error")) if (!$util.isString(message.error)) return "error: string expected";
                      return null;
                    };
                    /**
                     * Creates a MessageWrapper message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.MessageWrapper} MessageWrapper
                     */


                    MessageWrapper.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.MessageWrapper) return object;
                      var message = new $root.tigers.krun.internal.MessageWrapper();

                      if (object.users) {
                        if (!Array.isArray(object.users)) throw TypeError(".tigers.krun.internal.MessageWrapper.users: array expected");
                        message.users = [];

                        for (var i = 0; i < object.users.length; ++i) {
                          if (typeof object.users[i] !== "object") throw TypeError(".tigers.krun.internal.MessageWrapper.users: object expected");
                          message.users[i] = $root.tigers.krun.internal.MsgUser.fromObject(object.users[i]);
                        }
                      }

                      if (object.connector != null) message.connector = String(object.connector);
                      if (object.worker != null) message.worker = String(object.worker);
                      if (object.msgClass != null) message.msgClass = String(object.msgClass);
                      if (object.msg != null) if (typeof object.msg === "string") $util.base64.decode(object.msg, message.msg = $util.newBuffer($util.base64.length(object.msg)), 0);else if (object.msg.length) message.msg = object.msg;
                      if (object.error != null) message.error = String(object.error);
                      return message;
                    };
                    /**
                     * Creates a plain object from a MessageWrapper message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @static
                     * @param {tigers.krun.internal.MessageWrapper} message MessageWrapper
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    MessageWrapper.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};
                      if (options.arrays || options.defaults) object.users = [];

                      if (options.defaults) {
                        object.connector = "";
                        object.worker = "";
                        object.msgClass = "";
                        if (options.bytes === String) object.msg = "";else {
                          object.msg = [];
                          if (options.bytes !== Array) object.msg = $util.newBuffer(object.msg);
                        }
                        object.error = "";
                      }

                      if (message.users && message.users.length) {
                        object.users = [];

                        for (var j = 0; j < message.users.length; ++j) object.users[j] = $root.tigers.krun.internal.MsgUser.toObject(message.users[j], options);
                      }

                      if (message.connector != null && message.hasOwnProperty("connector")) object.connector = message.connector;
                      if (message.worker != null && message.hasOwnProperty("worker")) object.worker = message.worker;
                      if (message.msgClass != null && message.hasOwnProperty("msgClass")) object.msgClass = message.msgClass;
                      if (message.msg != null && message.hasOwnProperty("msg")) object.msg = options.bytes === String ? $util.base64.encode(message.msg, 0, message.msg.length) : options.bytes === Array ? Array.prototype.slice.call(message.msg) : message.msg;
                      if (message.error != null && message.hasOwnProperty("error")) object.error = message.error;
                      return object;
                    };
                    /**
                     * Converts this MessageWrapper to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.MessageWrapper
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    MessageWrapper.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return MessageWrapper;
                  }();

                  internal.MsgPing = function () {
                    /**
                     * Properties of a MsgPing.
                     * @memberof tigers.krun.internal
                     * @interface IMsgPing
                     * @property {number|null} [id] MsgPing id
                     * @property {number|Long|null} [createAt] MsgPing createAt
                     * @property {number|Long|null} [connector1At] MsgPing connector1At
                     * @property {number|Long|null} [workerAt] MsgPing workerAt
                     * @property {number|Long|null} [connector2At] MsgPing connector2At
                     */

                    /**
                     * Constructs a new MsgPing.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a MsgPing.
                     * @implements IMsgPing
                     * @constructor
                     * @param {tigers.krun.internal.IMsgPing=} [properties] Properties to set
                     */
                    function MsgPing(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * MsgPing id.
                     * @member {number} id
                     * @memberof tigers.krun.internal.MsgPing
                     * @instance
                     */


                    MsgPing.prototype.id = 0;
                    /**
                     * MsgPing createAt.
                     * @member {number|Long} createAt
                     * @memberof tigers.krun.internal.MsgPing
                     * @instance
                     */

                    MsgPing.prototype.createAt = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                    /**
                     * MsgPing connector1At.
                     * @member {number|Long} connector1At
                     * @memberof tigers.krun.internal.MsgPing
                     * @instance
                     */

                    MsgPing.prototype.connector1At = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                    /**
                     * MsgPing workerAt.
                     * @member {number|Long} workerAt
                     * @memberof tigers.krun.internal.MsgPing
                     * @instance
                     */

                    MsgPing.prototype.workerAt = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                    /**
                     * MsgPing connector2At.
                     * @member {number|Long} connector2At
                     * @memberof tigers.krun.internal.MsgPing
                     * @instance
                     */

                    MsgPing.prototype.connector2At = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                    /**
                     * Creates a new MsgPing instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {tigers.krun.internal.IMsgPing=} [properties] Properties to set
                     * @returns {tigers.krun.internal.MsgPing} MsgPing instance
                     */

                    MsgPing.create = function create(properties) {
                      return new MsgPing(properties);
                    };
                    /**
                     * Encodes the specified MsgPing message. Does not implicitly {@link tigers.krun.internal.MsgPing.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {tigers.krun.internal.IMsgPing} message MsgPing message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MsgPing.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.id != null && message.hasOwnProperty("id")) writer.uint32(
                      /* id 1, wireType 0 =*/
                      8).int32(message.id);
                      if (message.createAt != null && message.hasOwnProperty("createAt")) writer.uint32(
                      /* id 2, wireType 0 =*/
                      16).int64(message.createAt);
                      if (message.connector1At != null && message.hasOwnProperty("connector1At")) writer.uint32(
                      /* id 3, wireType 0 =*/
                      24).int64(message.connector1At);
                      if (message.workerAt != null && message.hasOwnProperty("workerAt")) writer.uint32(
                      /* id 4, wireType 0 =*/
                      32).int64(message.workerAt);
                      if (message.connector2At != null && message.hasOwnProperty("connector2At")) writer.uint32(
                      /* id 5, wireType 0 =*/
                      40).int64(message.connector2At);
                      return writer;
                    };
                    /**
                     * Encodes the specified MsgPing message, length delimited. Does not implicitly {@link tigers.krun.internal.MsgPing.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {tigers.krun.internal.IMsgPing} message MsgPing message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MsgPing.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a MsgPing message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.MsgPing} MsgPing
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MsgPing.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.MsgPing();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            message.id = reader.int32();
                            break;

                          case 2:
                            message.createAt = reader.int64();
                            break;

                          case 3:
                            message.connector1At = reader.int64();
                            break;

                          case 4:
                            message.workerAt = reader.int64();
                            break;

                          case 5:
                            message.connector2At = reader.int64();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a MsgPing message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.MsgPing} MsgPing
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MsgPing.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a MsgPing message.
                     * @function verify
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    MsgPing.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";
                      if (message.id != null && message.hasOwnProperty("id")) if (!$util.isInteger(message.id)) return "id: integer expected";
                      if (message.createAt != null && message.hasOwnProperty("createAt")) if (!$util.isInteger(message.createAt) && !(message.createAt && $util.isInteger(message.createAt.low) && $util.isInteger(message.createAt.high))) return "createAt: integer|Long expected";
                      if (message.connector1At != null && message.hasOwnProperty("connector1At")) if (!$util.isInteger(message.connector1At) && !(message.connector1At && $util.isInteger(message.connector1At.low) && $util.isInteger(message.connector1At.high))) return "connector1At: integer|Long expected";
                      if (message.workerAt != null && message.hasOwnProperty("workerAt")) if (!$util.isInteger(message.workerAt) && !(message.workerAt && $util.isInteger(message.workerAt.low) && $util.isInteger(message.workerAt.high))) return "workerAt: integer|Long expected";
                      if (message.connector2At != null && message.hasOwnProperty("connector2At")) if (!$util.isInteger(message.connector2At) && !(message.connector2At && $util.isInteger(message.connector2At.low) && $util.isInteger(message.connector2At.high))) return "connector2At: integer|Long expected";
                      return null;
                    };
                    /**
                     * Creates a MsgPing message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.MsgPing} MsgPing
                     */


                    MsgPing.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.MsgPing) return object;
                      var message = new $root.tigers.krun.internal.MsgPing();
                      if (object.id != null) message.id = object.id | 0;
                      if (object.createAt != null) if ($util.Long) (message.createAt = $util.Long.fromValue(object.createAt)).unsigned = false;else if (typeof object.createAt === "string") message.createAt = parseInt(object.createAt, 10);else if (typeof object.createAt === "number") message.createAt = object.createAt;else if (typeof object.createAt === "object") message.createAt = new $util.LongBits(object.createAt.low >>> 0, object.createAt.high >>> 0).toNumber();
                      if (object.connector1At != null) if ($util.Long) (message.connector1At = $util.Long.fromValue(object.connector1At)).unsigned = false;else if (typeof object.connector1At === "string") message.connector1At = parseInt(object.connector1At, 10);else if (typeof object.connector1At === "number") message.connector1At = object.connector1At;else if (typeof object.connector1At === "object") message.connector1At = new $util.LongBits(object.connector1At.low >>> 0, object.connector1At.high >>> 0).toNumber();
                      if (object.workerAt != null) if ($util.Long) (message.workerAt = $util.Long.fromValue(object.workerAt)).unsigned = false;else if (typeof object.workerAt === "string") message.workerAt = parseInt(object.workerAt, 10);else if (typeof object.workerAt === "number") message.workerAt = object.workerAt;else if (typeof object.workerAt === "object") message.workerAt = new $util.LongBits(object.workerAt.low >>> 0, object.workerAt.high >>> 0).toNumber();
                      if (object.connector2At != null) if ($util.Long) (message.connector2At = $util.Long.fromValue(object.connector2At)).unsigned = false;else if (typeof object.connector2At === "string") message.connector2At = parseInt(object.connector2At, 10);else if (typeof object.connector2At === "number") message.connector2At = object.connector2At;else if (typeof object.connector2At === "object") message.connector2At = new $util.LongBits(object.connector2At.low >>> 0, object.connector2At.high >>> 0).toNumber();
                      return message;
                    };
                    /**
                     * Creates a plain object from a MsgPing message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.MsgPing
                     * @static
                     * @param {tigers.krun.internal.MsgPing} message MsgPing
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    MsgPing.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};

                      if (options.defaults) {
                        object.id = 0;

                        if ($util.Long) {
                          var long = new $util.Long(0, 0, false);
                          object.createAt = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else object.createAt = options.longs === String ? "0" : 0;

                        if ($util.Long) {
                          var long = new $util.Long(0, 0, false);
                          object.connector1At = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else object.connector1At = options.longs === String ? "0" : 0;

                        if ($util.Long) {
                          var long = new $util.Long(0, 0, false);
                          object.workerAt = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else object.workerAt = options.longs === String ? "0" : 0;

                        if ($util.Long) {
                          var long = new $util.Long(0, 0, false);
                          object.connector2At = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else object.connector2At = options.longs === String ? "0" : 0;
                      }

                      if (message.id != null && message.hasOwnProperty("id")) object.id = message.id;
                      if (message.createAt != null && message.hasOwnProperty("createAt")) if (typeof message.createAt === "number") object.createAt = options.longs === String ? String(message.createAt) : message.createAt;else object.createAt = options.longs === String ? $util.Long.prototype.toString.call(message.createAt) : options.longs === Number ? new $util.LongBits(message.createAt.low >>> 0, message.createAt.high >>> 0).toNumber() : message.createAt;
                      if (message.connector1At != null && message.hasOwnProperty("connector1At")) if (typeof message.connector1At === "number") object.connector1At = options.longs === String ? String(message.connector1At) : message.connector1At;else object.connector1At = options.longs === String ? $util.Long.prototype.toString.call(message.connector1At) : options.longs === Number ? new $util.LongBits(message.connector1At.low >>> 0, message.connector1At.high >>> 0).toNumber() : message.connector1At;
                      if (message.workerAt != null && message.hasOwnProperty("workerAt")) if (typeof message.workerAt === "number") object.workerAt = options.longs === String ? String(message.workerAt) : message.workerAt;else object.workerAt = options.longs === String ? $util.Long.prototype.toString.call(message.workerAt) : options.longs === Number ? new $util.LongBits(message.workerAt.low >>> 0, message.workerAt.high >>> 0).toNumber() : message.workerAt;
                      if (message.connector2At != null && message.hasOwnProperty("connector2At")) if (typeof message.connector2At === "number") object.connector2At = options.longs === String ? String(message.connector2At) : message.connector2At;else object.connector2At = options.longs === String ? $util.Long.prototype.toString.call(message.connector2At) : options.longs === Number ? new $util.LongBits(message.connector2At.low >>> 0, message.connector2At.high >>> 0).toNumber() : message.connector2At;
                      return object;
                    };
                    /**
                     * Converts this MsgPing to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.MsgPing
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    MsgPing.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return MsgPing;
                  }();

                  internal.ReqVerify = function () {
                    /**
                     * Properties of a ReqVerify.
                     * @memberof tigers.krun.internal
                     * @interface IReqVerify
                     * @property {string|null} [jwt] ReqVerify jwt
                     */

                    /**
                     * Constructs a new ReqVerify.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a ReqVerify.
                     * @implements IReqVerify
                     * @constructor
                     * @param {tigers.krun.internal.IReqVerify=} [properties] Properties to set
                     */
                    function ReqVerify(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * ReqVerify jwt.
                     * @member {string} jwt
                     * @memberof tigers.krun.internal.ReqVerify
                     * @instance
                     */


                    ReqVerify.prototype.jwt = "";
                    /**
                     * Creates a new ReqVerify instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {tigers.krun.internal.IReqVerify=} [properties] Properties to set
                     * @returns {tigers.krun.internal.ReqVerify} ReqVerify instance
                     */

                    ReqVerify.create = function create(properties) {
                      return new ReqVerify(properties);
                    };
                    /**
                     * Encodes the specified ReqVerify message. Does not implicitly {@link tigers.krun.internal.ReqVerify.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {tigers.krun.internal.IReqVerify} message ReqVerify message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ReqVerify.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.jwt != null && message.hasOwnProperty("jwt")) writer.uint32(
                      /* id 1, wireType 2 =*/
                      10).string(message.jwt);
                      return writer;
                    };
                    /**
                     * Encodes the specified ReqVerify message, length delimited. Does not implicitly {@link tigers.krun.internal.ReqVerify.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {tigers.krun.internal.IReqVerify} message ReqVerify message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ReqVerify.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a ReqVerify message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.ReqVerify} ReqVerify
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ReqVerify.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.ReqVerify();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            message.jwt = reader.string();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a ReqVerify message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.ReqVerify} ReqVerify
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ReqVerify.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a ReqVerify message.
                     * @function verify
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    ReqVerify.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";
                      if (message.jwt != null && message.hasOwnProperty("jwt")) if (!$util.isString(message.jwt)) return "jwt: string expected";
                      return null;
                    };
                    /**
                     * Creates a ReqVerify message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.ReqVerify} ReqVerify
                     */


                    ReqVerify.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.ReqVerify) return object;
                      var message = new $root.tigers.krun.internal.ReqVerify();
                      if (object.jwt != null) message.jwt = String(object.jwt);
                      return message;
                    };
                    /**
                     * Creates a plain object from a ReqVerify message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.ReqVerify
                     * @static
                     * @param {tigers.krun.internal.ReqVerify} message ReqVerify
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    ReqVerify.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};
                      if (options.defaults) object.jwt = "";
                      if (message.jwt != null && message.hasOwnProperty("jwt")) object.jwt = message.jwt;
                      return object;
                    };
                    /**
                     * Converts this ReqVerify to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.ReqVerify
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    ReqVerify.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return ReqVerify;
                  }();

                  internal.ResVerify = function () {
                    /**
                     * Properties of a ResVerify.
                     * @memberof tigers.krun.internal
                     * @interface IResVerify
                     * @property {string|null} [uid] ResVerify uid
                     * @property {string|null} [displayName] ResVerify displayName
                     */

                    /**
                     * Constructs a new ResVerify.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a ResVerify.
                     * @implements IResVerify
                     * @constructor
                     * @param {tigers.krun.internal.IResVerify=} [properties] Properties to set
                     */
                    function ResVerify(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * ResVerify uid.
                     * @member {string} uid
                     * @memberof tigers.krun.internal.ResVerify
                     * @instance
                     */


                    ResVerify.prototype.uid = "";
                    /**
                     * ResVerify displayName.
                     * @member {string} displayName
                     * @memberof tigers.krun.internal.ResVerify
                     * @instance
                     */

                    ResVerify.prototype.displayName = "";
                    /**
                     * Creates a new ResVerify instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {tigers.krun.internal.IResVerify=} [properties] Properties to set
                     * @returns {tigers.krun.internal.ResVerify} ResVerify instance
                     */

                    ResVerify.create = function create(properties) {
                      return new ResVerify(properties);
                    };
                    /**
                     * Encodes the specified ResVerify message. Does not implicitly {@link tigers.krun.internal.ResVerify.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {tigers.krun.internal.IResVerify} message ResVerify message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ResVerify.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.uid != null && message.hasOwnProperty("uid")) writer.uint32(
                      /* id 1, wireType 2 =*/
                      10).string(message.uid);
                      if (message.displayName != null && message.hasOwnProperty("displayName")) writer.uint32(
                      /* id 2, wireType 2 =*/
                      18).string(message.displayName);
                      return writer;
                    };
                    /**
                     * Encodes the specified ResVerify message, length delimited. Does not implicitly {@link tigers.krun.internal.ResVerify.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {tigers.krun.internal.IResVerify} message ResVerify message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ResVerify.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a ResVerify message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.ResVerify} ResVerify
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ResVerify.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.ResVerify();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            message.uid = reader.string();
                            break;

                          case 2:
                            message.displayName = reader.string();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a ResVerify message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.ResVerify} ResVerify
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ResVerify.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a ResVerify message.
                     * @function verify
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    ResVerify.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";
                      if (message.uid != null && message.hasOwnProperty("uid")) if (!$util.isString(message.uid)) return "uid: string expected";
                      if (message.displayName != null && message.hasOwnProperty("displayName")) if (!$util.isString(message.displayName)) return "displayName: string expected";
                      return null;
                    };
                    /**
                     * Creates a ResVerify message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.ResVerify} ResVerify
                     */


                    ResVerify.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.ResVerify) return object;
                      var message = new $root.tigers.krun.internal.ResVerify();
                      if (object.uid != null) message.uid = String(object.uid);
                      if (object.displayName != null) message.displayName = String(object.displayName);
                      return message;
                    };
                    /**
                     * Creates a plain object from a ResVerify message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.ResVerify
                     * @static
                     * @param {tigers.krun.internal.ResVerify} message ResVerify
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    ResVerify.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};

                      if (options.defaults) {
                        object.uid = "";
                        object.displayName = "";
                      }

                      if (message.uid != null && message.hasOwnProperty("uid")) object.uid = message.uid;
                      if (message.displayName != null && message.hasOwnProperty("displayName")) object.displayName = message.displayName;
                      return object;
                    };
                    /**
                     * Converts this ResVerify to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.ResVerify
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    ResVerify.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return ResVerify;
                  }();

                  internal.ReqWorker = function () {
                    /**
                     * Properties of a ReqWorker.
                     * @memberof tigers.krun.internal
                     * @interface IReqWorker
                     * @property {tigers.krun.internal.IMsgUser|null} [user] ReqWorker user
                     * @property {string|null} [connector] ReqWorker connector
                     * @property {string|null} [game] ReqWorker game
                     */

                    /**
                     * Constructs a new ReqWorker.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a ReqWorker.
                     * @implements IReqWorker
                     * @constructor
                     * @param {tigers.krun.internal.IReqWorker=} [properties] Properties to set
                     */
                    function ReqWorker(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * ReqWorker user.
                     * @member {tigers.krun.internal.IMsgUser|null|undefined} user
                     * @memberof tigers.krun.internal.ReqWorker
                     * @instance
                     */


                    ReqWorker.prototype.user = null;
                    /**
                     * ReqWorker connector.
                     * @member {string} connector
                     * @memberof tigers.krun.internal.ReqWorker
                     * @instance
                     */

                    ReqWorker.prototype.connector = "";
                    /**
                     * ReqWorker game.
                     * @member {string} game
                     * @memberof tigers.krun.internal.ReqWorker
                     * @instance
                     */

                    ReqWorker.prototype.game = "";
                    /**
                     * Creates a new ReqWorker instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {tigers.krun.internal.IReqWorker=} [properties] Properties to set
                     * @returns {tigers.krun.internal.ReqWorker} ReqWorker instance
                     */

                    ReqWorker.create = function create(properties) {
                      return new ReqWorker(properties);
                    };
                    /**
                     * Encodes the specified ReqWorker message. Does not implicitly {@link tigers.krun.internal.ReqWorker.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {tigers.krun.internal.IReqWorker} message ReqWorker message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ReqWorker.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.user != null && message.hasOwnProperty("user")) $root.tigers.krun.internal.MsgUser.encode(message.user, writer.uint32(
                      /* id 1, wireType 2 =*/
                      10).fork()).ldelim();
                      if (message.connector != null && message.hasOwnProperty("connector")) writer.uint32(
                      /* id 2, wireType 2 =*/
                      18).string(message.connector);
                      if (message.game != null && message.hasOwnProperty("game")) writer.uint32(
                      /* id 3, wireType 2 =*/
                      26).string(message.game);
                      return writer;
                    };
                    /**
                     * Encodes the specified ReqWorker message, length delimited. Does not implicitly {@link tigers.krun.internal.ReqWorker.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {tigers.krun.internal.IReqWorker} message ReqWorker message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ReqWorker.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a ReqWorker message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.ReqWorker} ReqWorker
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ReqWorker.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.ReqWorker();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            message.user = $root.tigers.krun.internal.MsgUser.decode(reader, reader.uint32());
                            break;

                          case 2:
                            message.connector = reader.string();
                            break;

                          case 3:
                            message.game = reader.string();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a ReqWorker message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.ReqWorker} ReqWorker
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ReqWorker.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a ReqWorker message.
                     * @function verify
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    ReqWorker.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";

                      if (message.user != null && message.hasOwnProperty("user")) {
                        var error = $root.tigers.krun.internal.MsgUser.verify(message.user);
                        if (error) return "user." + error;
                      }

                      if (message.connector != null && message.hasOwnProperty("connector")) if (!$util.isString(message.connector)) return "connector: string expected";
                      if (message.game != null && message.hasOwnProperty("game")) if (!$util.isString(message.game)) return "game: string expected";
                      return null;
                    };
                    /**
                     * Creates a ReqWorker message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.ReqWorker} ReqWorker
                     */


                    ReqWorker.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.ReqWorker) return object;
                      var message = new $root.tigers.krun.internal.ReqWorker();

                      if (object.user != null) {
                        if (typeof object.user !== "object") throw TypeError(".tigers.krun.internal.ReqWorker.user: object expected");
                        message.user = $root.tigers.krun.internal.MsgUser.fromObject(object.user);
                      }

                      if (object.connector != null) message.connector = String(object.connector);
                      if (object.game != null) message.game = String(object.game);
                      return message;
                    };
                    /**
                     * Creates a plain object from a ReqWorker message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.ReqWorker
                     * @static
                     * @param {tigers.krun.internal.ReqWorker} message ReqWorker
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    ReqWorker.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};

                      if (options.defaults) {
                        object.user = null;
                        object.connector = "";
                        object.game = "";
                      }

                      if (message.user != null && message.hasOwnProperty("user")) object.user = $root.tigers.krun.internal.MsgUser.toObject(message.user, options);
                      if (message.connector != null && message.hasOwnProperty("connector")) object.connector = message.connector;
                      if (message.game != null && message.hasOwnProperty("game")) object.game = message.game;
                      return object;
                    };
                    /**
                     * Converts this ReqWorker to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.ReqWorker
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    ReqWorker.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return ReqWorker;
                  }();

                  internal.ResWorker = function () {
                    /**
                     * Properties of a ResWorker.
                     * @memberof tigers.krun.internal
                     * @interface IResWorker
                     * @property {tigers.krun.internal.IMsgUser|null} [user] ResWorker user
                     * @property {string|null} [group] ResWorker group
                     * @property {string|null} [worker] ResWorker worker
                     * @property {string|null} [error] ResWorker error
                     */

                    /**
                     * Constructs a new ResWorker.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a ResWorker.
                     * @implements IResWorker
                     * @constructor
                     * @param {tigers.krun.internal.IResWorker=} [properties] Properties to set
                     */
                    function ResWorker(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * ResWorker user.
                     * @member {tigers.krun.internal.IMsgUser|null|undefined} user
                     * @memberof tigers.krun.internal.ResWorker
                     * @instance
                     */


                    ResWorker.prototype.user = null;
                    /**
                     * ResWorker group.
                     * @member {string} group
                     * @memberof tigers.krun.internal.ResWorker
                     * @instance
                     */

                    ResWorker.prototype.group = "";
                    /**
                     * ResWorker worker.
                     * @member {string} worker
                     * @memberof tigers.krun.internal.ResWorker
                     * @instance
                     */

                    ResWorker.prototype.worker = "";
                    /**
                     * ResWorker error.
                     * @member {string} error
                     * @memberof tigers.krun.internal.ResWorker
                     * @instance
                     */

                    ResWorker.prototype.error = "";
                    /**
                     * Creates a new ResWorker instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {tigers.krun.internal.IResWorker=} [properties] Properties to set
                     * @returns {tigers.krun.internal.ResWorker} ResWorker instance
                     */

                    ResWorker.create = function create(properties) {
                      return new ResWorker(properties);
                    };
                    /**
                     * Encodes the specified ResWorker message. Does not implicitly {@link tigers.krun.internal.ResWorker.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {tigers.krun.internal.IResWorker} message ResWorker message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ResWorker.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      if (message.user != null && message.hasOwnProperty("user")) $root.tigers.krun.internal.MsgUser.encode(message.user, writer.uint32(
                      /* id 1, wireType 2 =*/
                      10).fork()).ldelim();
                      if (message.group != null && message.hasOwnProperty("group")) writer.uint32(
                      /* id 2, wireType 2 =*/
                      18).string(message.group);
                      if (message.worker != null && message.hasOwnProperty("worker")) writer.uint32(
                      /* id 3, wireType 2 =*/
                      26).string(message.worker);
                      if (message.error != null && message.hasOwnProperty("error")) writer.uint32(
                      /* id 4, wireType 2 =*/
                      34).string(message.error);
                      return writer;
                    };
                    /**
                     * Encodes the specified ResWorker message, length delimited. Does not implicitly {@link tigers.krun.internal.ResWorker.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {tigers.krun.internal.IResWorker} message ResWorker message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    ResWorker.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a ResWorker message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.ResWorker} ResWorker
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ResWorker.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.ResWorker();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          case 1:
                            message.user = $root.tigers.krun.internal.MsgUser.decode(reader, reader.uint32());
                            break;

                          case 2:
                            message.group = reader.string();
                            break;

                          case 3:
                            message.worker = reader.string();
                            break;

                          case 4:
                            message.error = reader.string();
                            break;

                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a ResWorker message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.ResWorker} ResWorker
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    ResWorker.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a ResWorker message.
                     * @function verify
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    ResWorker.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";

                      if (message.user != null && message.hasOwnProperty("user")) {
                        var error = $root.tigers.krun.internal.MsgUser.verify(message.user);
                        if (error) return "user." + error;
                      }

                      if (message.group != null && message.hasOwnProperty("group")) if (!$util.isString(message.group)) return "group: string expected";
                      if (message.worker != null && message.hasOwnProperty("worker")) if (!$util.isString(message.worker)) return "worker: string expected";
                      if (message.error != null && message.hasOwnProperty("error")) if (!$util.isString(message.error)) return "error: string expected";
                      return null;
                    };
                    /**
                     * Creates a ResWorker message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.ResWorker} ResWorker
                     */


                    ResWorker.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.ResWorker) return object;
                      var message = new $root.tigers.krun.internal.ResWorker();

                      if (object.user != null) {
                        if (typeof object.user !== "object") throw TypeError(".tigers.krun.internal.ResWorker.user: object expected");
                        message.user = $root.tigers.krun.internal.MsgUser.fromObject(object.user);
                      }

                      if (object.group != null) message.group = String(object.group);
                      if (object.worker != null) message.worker = String(object.worker);
                      if (object.error != null) message.error = String(object.error);
                      return message;
                    };
                    /**
                     * Creates a plain object from a ResWorker message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.ResWorker
                     * @static
                     * @param {tigers.krun.internal.ResWorker} message ResWorker
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    ResWorker.toObject = function toObject(message, options) {
                      if (!options) options = {};
                      var object = {};

                      if (options.defaults) {
                        object.user = null;
                        object.group = "";
                        object.worker = "";
                        object.error = "";
                      }

                      if (message.user != null && message.hasOwnProperty("user")) object.user = $root.tigers.krun.internal.MsgUser.toObject(message.user, options);
                      if (message.group != null && message.hasOwnProperty("group")) object.group = message.group;
                      if (message.worker != null && message.hasOwnProperty("worker")) object.worker = message.worker;
                      if (message.error != null && message.hasOwnProperty("error")) object.error = message.error;
                      return object;
                    };
                    /**
                     * Converts this ResWorker to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.ResWorker
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    ResWorker.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return ResWorker;
                  }();

                  internal.MsgReleaseWorker = function () {
                    /**
                     * Properties of a MsgReleaseWorker.
                     * @memberof tigers.krun.internal
                     * @interface IMsgReleaseWorker
                     */

                    /**
                     * Constructs a new MsgReleaseWorker.
                     * @memberof tigers.krun.internal
                     * @classdesc Represents a MsgReleaseWorker.
                     * @implements IMsgReleaseWorker
                     * @constructor
                     * @param {tigers.krun.internal.IMsgReleaseWorker=} [properties] Properties to set
                     */
                    function MsgReleaseWorker(properties) {
                      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                    }
                    /**
                     * Creates a new MsgReleaseWorker instance using the specified properties.
                     * @function create
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {tigers.krun.internal.IMsgReleaseWorker=} [properties] Properties to set
                     * @returns {tigers.krun.internal.MsgReleaseWorker} MsgReleaseWorker instance
                     */


                    MsgReleaseWorker.create = function create(properties) {
                      return new MsgReleaseWorker(properties);
                    };
                    /**
                     * Encodes the specified MsgReleaseWorker message. Does not implicitly {@link tigers.krun.internal.MsgReleaseWorker.verify|verify} messages.
                     * @function encode
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {tigers.krun.internal.IMsgReleaseWorker} message MsgReleaseWorker message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MsgReleaseWorker.encode = function encode(message, writer) {
                      if (!writer) writer = $Writer.create();
                      return writer;
                    };
                    /**
                     * Encodes the specified MsgReleaseWorker message, length delimited. Does not implicitly {@link tigers.krun.internal.MsgReleaseWorker.verify|verify} messages.
                     * @function encodeDelimited
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {tigers.krun.internal.IMsgReleaseWorker} message MsgReleaseWorker message or plain object to encode
                     * @param {$protobuf.Writer} [writer] Writer to encode to
                     * @returns {$protobuf.Writer} Writer
                     */


                    MsgReleaseWorker.encodeDelimited = function encodeDelimited(message, writer) {
                      return this.encode(message, writer).ldelim();
                    };
                    /**
                     * Decodes a MsgReleaseWorker message from the specified reader or buffer.
                     * @function decode
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @param {number} [length] Message length if known beforehand
                     * @returns {tigers.krun.internal.MsgReleaseWorker} MsgReleaseWorker
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MsgReleaseWorker.decode = function decode(reader, length) {
                      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                      var end = length === undefined ? reader.len : reader.pos + length,
                          message = new $root.tigers.krun.internal.MsgReleaseWorker();

                      while (reader.pos < end) {
                        var tag = reader.uint32();

                        switch (tag >>> 3) {
                          default:
                            reader.skipType(tag & 7);
                            break;
                        }
                      }

                      return message;
                    };
                    /**
                     * Decodes a MsgReleaseWorker message from the specified reader or buffer, length delimited.
                     * @function decodeDelimited
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                     * @returns {tigers.krun.internal.MsgReleaseWorker} MsgReleaseWorker
                     * @throws {Error} If the payload is not a reader or valid buffer
                     * @throws {$protobuf.util.ProtocolError} If required fields are missing
                     */


                    MsgReleaseWorker.decodeDelimited = function decodeDelimited(reader) {
                      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                      return this.decode(reader, reader.uint32());
                    };
                    /**
                     * Verifies a MsgReleaseWorker message.
                     * @function verify
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {Object.<string,*>} message Plain object to verify
                     * @returns {string|null} `null` if valid, otherwise the reason why it is not
                     */


                    MsgReleaseWorker.verify = function verify(message) {
                      if (typeof message !== "object" || message === null) return "object expected";
                      return null;
                    };
                    /**
                     * Creates a MsgReleaseWorker message from a plain object. Also converts values to their respective internal types.
                     * @function fromObject
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {Object.<string,*>} object Plain object
                     * @returns {tigers.krun.internal.MsgReleaseWorker} MsgReleaseWorker
                     */


                    MsgReleaseWorker.fromObject = function fromObject(object) {
                      if (object instanceof $root.tigers.krun.internal.MsgReleaseWorker) return object;
                      return new $root.tigers.krun.internal.MsgReleaseWorker();
                    };
                    /**
                     * Creates a plain object from a MsgReleaseWorker message. Also converts values to other types if specified.
                     * @function toObject
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @static
                     * @param {tigers.krun.internal.MsgReleaseWorker} message MsgReleaseWorker
                     * @param {$protobuf.IConversionOptions} [options] Conversion options
                     * @returns {Object.<string,*>} Plain object
                     */


                    MsgReleaseWorker.toObject = function toObject() {
                      return {};
                    };
                    /**
                     * Converts this MsgReleaseWorker to JSON.
                     * @function toJSON
                     * @memberof tigers.krun.internal.MsgReleaseWorker
                     * @instance
                     * @returns {Object.<string,*>} JSON object
                     */


                    MsgReleaseWorker.prototype.toJSON = function toJSON() {
                      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                    };

                    return MsgReleaseWorker;
                  }();

                  return internal;
                }();

                krun.KrunMsg = function () {
                  /**
                   * Properties of a KrunMsg.
                   * @memberof tigers.krun
                   * @interface IKrunMsg
                   * @property {number|Long|null} [timestamp] KrunMsg timestamp
                   * @property {tigers.krun.KRUN_CMD|null} [cmd] KrunMsg cmd
                   * @property {tigers.krun.KRUN_ERROR|null} [error] KrunMsg error
                   * @property {Uint8Array|null} [body] KrunMsg body
                   */

                  /**
                   * Constructs a new KrunMsg.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunMsg.
                   * @implements IKrunMsg
                   * @constructor
                   * @param {tigers.krun.IKrunMsg=} [properties] Properties to set
                   */
                  function KrunMsg(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunMsg timestamp.
                   * @member {number|Long} timestamp
                   * @memberof tigers.krun.KrunMsg
                   * @instance
                   */


                  KrunMsg.prototype.timestamp = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * KrunMsg cmd.
                   * @member {tigers.krun.KRUN_CMD} cmd
                   * @memberof tigers.krun.KrunMsg
                   * @instance
                   */

                  KrunMsg.prototype.cmd = 0;
                  /**
                   * KrunMsg error.
                   * @member {tigers.krun.KRUN_ERROR} error
                   * @memberof tigers.krun.KrunMsg
                   * @instance
                   */

                  KrunMsg.prototype.error = 0;
                  /**
                   * KrunMsg body.
                   * @member {Uint8Array} body
                   * @memberof tigers.krun.KrunMsg
                   * @instance
                   */

                  KrunMsg.prototype.body = $util.newBuffer([]);
                  /**
                   * Creates a new KrunMsg instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {tigers.krun.IKrunMsg=} [properties] Properties to set
                   * @returns {tigers.krun.KrunMsg} KrunMsg instance
                   */

                  KrunMsg.create = function create(properties) {
                    return new KrunMsg(properties);
                  };
                  /**
                   * Encodes the specified KrunMsg message. Does not implicitly {@link tigers.krun.KrunMsg.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {tigers.krun.IKrunMsg} message KrunMsg message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunMsg.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.timestamp != null && message.hasOwnProperty("timestamp")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int64(message.timestamp);
                    if (message.cmd != null && message.hasOwnProperty("cmd")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.cmd);
                    if (message.error != null && message.hasOwnProperty("error")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.error);
                    if (message.body != null && message.hasOwnProperty("body")) writer.uint32(
                    /* id 4, wireType 2 =*/
                    34).bytes(message.body);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunMsg message, length delimited. Does not implicitly {@link tigers.krun.KrunMsg.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {tigers.krun.IKrunMsg} message KrunMsg message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunMsg.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunMsg message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunMsg} KrunMsg
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunMsg.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunMsg();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.timestamp = reader.int64();
                          break;

                        case 2:
                          message.cmd = reader.int32();
                          break;

                        case 3:
                          message.error = reader.int32();
                          break;

                        case 4:
                          message.body = reader.bytes();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunMsg message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunMsg} KrunMsg
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunMsg.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunMsg message.
                   * @function verify
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunMsg.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.timestamp != null && message.hasOwnProperty("timestamp")) if (!$util.isInteger(message.timestamp) && !(message.timestamp && $util.isInteger(message.timestamp.low) && $util.isInteger(message.timestamp.high))) return "timestamp: integer|Long expected";
                    if (message.cmd != null && message.hasOwnProperty("cmd")) switch (message.cmd) {
                      default:
                        return "cmd: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 4:
                      case 10:
                      case 11:
                      case 12:
                      case 21:
                      case 22:
                      case 23:
                      case 100:
                      case 101:
                      case 102:
                      case 103:
                      case 104:
                      case 105:
                      case 106:
                      case 107:
                      case 108:
                      case 109:
                      case 110:
                      case 111:
                      case 112:
                      case 113:
                      case 114:
                      case 115:
                      case 116:
                      case 117:
                      case 118:
                      case 119:
                      case 120:
                      case 121:
                      case 122:
                      case 123:
                      case 124:
                      case 125:
                      case 126:
                      case 127:
                      case 128:
                      case 129:
                      case 130:
                      case 131:
                      case 132:
                      case 133:
                      case 134:
                      case 135:
                        break;
                    }
                    if (message.error != null && message.hasOwnProperty("error")) switch (message.error) {
                      default:
                        return "error: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 4:
                      case 5:
                      case 6:
                      case 7:
                      case 8:
                      case 9:
                      case 10:
                      case 11:
                      case 12:
                        break;
                    }
                    if (message.body != null && message.hasOwnProperty("body")) if (!(message.body && typeof message.body.length === "number" || $util.isString(message.body))) return "body: buffer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunMsg message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunMsg} KrunMsg
                   */


                  KrunMsg.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunMsg) return object;
                    var message = new $root.tigers.krun.KrunMsg();
                    if (object.timestamp != null) if ($util.Long) (message.timestamp = $util.Long.fromValue(object.timestamp)).unsigned = false;else if (typeof object.timestamp === "string") message.timestamp = parseInt(object.timestamp, 10);else if (typeof object.timestamp === "number") message.timestamp = object.timestamp;else if (typeof object.timestamp === "object") message.timestamp = new $util.LongBits(object.timestamp.low >>> 0, object.timestamp.high >>> 0).toNumber();

                    switch (object.cmd) {
                      case "KRUN_CMD_UNKNOW":
                      case 0:
                        message.cmd = 0;
                        break;

                      case "KRUN_CMD_PING":
                      case 1:
                        message.cmd = 1;
                        break;

                      case "KRUN_CMD_DEFINES":
                      case 2:
                        message.cmd = 2;
                        break;

                      case "KRUN_CMD_GET_TURN":
                      case 3:
                        message.cmd = 3;
                        break;

                      case "KRUN_CMD_GET_CANDY":
                      case 4:
                        message.cmd = 4;
                        break;

                      case "KRUN_CMD_GAME_MATCHING":
                      case 10:
                        message.cmd = 10;
                        break;

                      case "KRUN_CMD_GAME_UPDATE":
                      case 11:
                        message.cmd = 11;
                        break;

                      case "KRUN_CMD_GAME_END":
                      case 12:
                        message.cmd = 12;
                        break;

                      case "KRUN_CMD_PLAYER_JOIN_GAME":
                      case 21:
                        message.cmd = 21;
                        break;

                      case "KRUN_CMD_PLAYER_QUIT_GAME":
                      case 22:
                        message.cmd = 22;
                        break;

                      case "KRUN_CMD_PLAYER_FIRE_FREEZE_BULLET":
                      case 23:
                        message.cmd = 23;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_000":
                      case 100:
                        message.cmd = 100;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_010":
                      case 101:
                        message.cmd = 101;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_020":
                      case 102:
                        message.cmd = 102;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_030":
                      case 103:
                        message.cmd = 103;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_040":
                      case 104:
                        message.cmd = 104;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_050":
                      case 105:
                        message.cmd = 105;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_060":
                      case 106:
                        message.cmd = 106;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_070":
                      case 107:
                        message.cmd = 107;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_080":
                      case 108:
                        message.cmd = 108;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_090":
                      case 109:
                        message.cmd = 109;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_100":
                      case 110:
                        message.cmd = 110;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_110":
                      case 111:
                        message.cmd = 111;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_120":
                      case 112:
                        message.cmd = 112;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_130":
                      case 113:
                        message.cmd = 113;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_140":
                      case 114:
                        message.cmd = 114;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_150":
                      case 115:
                        message.cmd = 115;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_160":
                      case 116:
                        message.cmd = 116;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_170":
                      case 117:
                        message.cmd = 117;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_180":
                      case 118:
                        message.cmd = 118;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_190":
                      case 119:
                        message.cmd = 119;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_200":
                      case 120:
                        message.cmd = 120;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_210":
                      case 121:
                        message.cmd = 121;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_220":
                      case 122:
                        message.cmd = 122;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_230":
                      case 123:
                        message.cmd = 123;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_240":
                      case 124:
                        message.cmd = 124;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_250":
                      case 125:
                        message.cmd = 125;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_260":
                      case 126:
                        message.cmd = 126;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_270":
                      case 127:
                        message.cmd = 127;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_280":
                      case 128:
                        message.cmd = 128;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_290":
                      case 129:
                        message.cmd = 129;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_300":
                      case 130:
                        message.cmd = 130;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_310":
                      case 131:
                        message.cmd = 131;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_320":
                      case 132:
                        message.cmd = 132;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_330":
                      case 133:
                        message.cmd = 133;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_340":
                      case 134:
                        message.cmd = 134;
                        break;

                      case "KRUN_CMD_PLAYER_MOVE_350":
                      case 135:
                        message.cmd = 135;
                        break;
                    }

                    switch (object.error) {
                      case "KRUN_ERROR_NONE":
                      case 0:
                        message.error = 0;
                        break;

                      case "KRUN_ERROR_MATCHING_FAIL":
                      case 1:
                        message.error = 1;
                        break;

                      case "KRUN_ERROR_MATCHING_TIMEOUT":
                      case 2:
                        message.error = 2;
                        break;

                      case "KRUN_ERROR_MATCHING_NOT_ENOUGH_PRICE":
                      case 3:
                        message.error = 3;
                        break;

                      case "KRUN_ERROR_USER_INVALID":
                      case 4:
                        message.error = 4;
                        break;

                      case "KRUN_ERROR_USER_DOUBLE":
                      case 5:
                        message.error = 5;
                        break;

                      case "KRUN_ERROR_MATCHING_DISABLE":
                      case 6:
                        message.error = 6;
                        break;

                      case "KRUN_ERROR_RECONNECT_GAME_NOT_FOUND":
                      case 7:
                        message.error = 7;
                        break;

                      case "KRUN_ERROR_RECONNECT_GAME_END":
                      case 8:
                        message.error = 8;
                        break;

                      case "KRUN_ERROR_RECONNECT_PLAYER_NOT_PLAY_THIS_GAME":
                      case 9:
                        message.error = 9;
                        break;

                      case "KRUN_ERROR_RECONNECT_PLAYER_NOT_PAY":
                      case 10:
                        message.error = 10;
                        break;

                      case "KRUN_ERROR_RECONNECT_PLAYER_STILL_ONLINE":
                      case 11:
                        message.error = 11;
                        break;

                      case "KRUN_ERROR_RECONNECT_PLAYER_IS_BOT":
                      case 12:
                        message.error = 12;
                        break;
                    }

                    if (object.body != null) if (typeof object.body === "string") $util.base64.decode(object.body, message.body = $util.newBuffer($util.base64.length(object.body)), 0);else if (object.body.length) message.body = object.body;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunMsg message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunMsg
                   * @static
                   * @param {tigers.krun.KrunMsg} message KrunMsg
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunMsg.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      if ($util.Long) {
                        var long = new $util.Long(0, 0, false);
                        object.timestamp = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                      } else object.timestamp = options.longs === String ? "0" : 0;

                      object.cmd = options.enums === String ? "KRUN_CMD_UNKNOW" : 0;
                      object.error = options.enums === String ? "KRUN_ERROR_NONE" : 0;
                      if (options.bytes === String) object.body = "";else {
                        object.body = [];
                        if (options.bytes !== Array) object.body = $util.newBuffer(object.body);
                      }
                    }

                    if (message.timestamp != null && message.hasOwnProperty("timestamp")) if (typeof message.timestamp === "number") object.timestamp = options.longs === String ? String(message.timestamp) : message.timestamp;else object.timestamp = options.longs === String ? $util.Long.prototype.toString.call(message.timestamp) : options.longs === Number ? new $util.LongBits(message.timestamp.low >>> 0, message.timestamp.high >>> 0).toNumber() : message.timestamp;
                    if (message.cmd != null && message.hasOwnProperty("cmd")) object.cmd = options.enums === String ? $root.tigers.krun.KRUN_CMD[message.cmd] : message.cmd;
                    if (message.error != null && message.hasOwnProperty("error")) object.error = options.enums === String ? $root.tigers.krun.KRUN_ERROR[message.error] : message.error;
                    if (message.body != null && message.hasOwnProperty("body")) object.body = options.bytes === String ? $util.base64.encode(message.body, 0, message.body.length) : options.bytes === Array ? Array.prototype.slice.call(message.body) : message.body;
                    return object;
                  };
                  /**
                   * Converts this KrunMsg to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunMsg
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunMsg.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunMsg;
                }();

                krun.KrunReqPing = function () {
                  /**
                   * Properties of a KrunReqPing.
                   * @memberof tigers.krun
                   * @interface IKrunReqPing
                   * @property {number|null} [id] KrunReqPing id
                   * @property {number|Long|null} [sendAt] KrunReqPing sendAt
                   */

                  /**
                   * Constructs a new KrunReqPing.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunReqPing.
                   * @implements IKrunReqPing
                   * @constructor
                   * @param {tigers.krun.IKrunReqPing=} [properties] Properties to set
                   */
                  function KrunReqPing(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunReqPing id.
                   * @member {number} id
                   * @memberof tigers.krun.KrunReqPing
                   * @instance
                   */


                  KrunReqPing.prototype.id = 0;
                  /**
                   * KrunReqPing sendAt.
                   * @member {number|Long} sendAt
                   * @memberof tigers.krun.KrunReqPing
                   * @instance
                   */

                  KrunReqPing.prototype.sendAt = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * Creates a new KrunReqPing instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {tigers.krun.IKrunReqPing=} [properties] Properties to set
                   * @returns {tigers.krun.KrunReqPing} KrunReqPing instance
                   */

                  KrunReqPing.create = function create(properties) {
                    return new KrunReqPing(properties);
                  };
                  /**
                   * Encodes the specified KrunReqPing message. Does not implicitly {@link tigers.krun.KrunReqPing.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {tigers.krun.IKrunReqPing} message KrunReqPing message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunReqPing.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.id != null && message.hasOwnProperty("id")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.id);
                    if (message.sendAt != null && message.hasOwnProperty("sendAt")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int64(message.sendAt);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunReqPing message, length delimited. Does not implicitly {@link tigers.krun.KrunReqPing.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {tigers.krun.IKrunReqPing} message KrunReqPing message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunReqPing.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunReqPing message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunReqPing} KrunReqPing
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunReqPing.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunReqPing();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.id = reader.int32();
                          break;

                        case 2:
                          message.sendAt = reader.int64();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunReqPing message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunReqPing} KrunReqPing
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunReqPing.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunReqPing message.
                   * @function verify
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunReqPing.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.id != null && message.hasOwnProperty("id")) if (!$util.isInteger(message.id)) return "id: integer expected";
                    if (message.sendAt != null && message.hasOwnProperty("sendAt")) if (!$util.isInteger(message.sendAt) && !(message.sendAt && $util.isInteger(message.sendAt.low) && $util.isInteger(message.sendAt.high))) return "sendAt: integer|Long expected";
                    return null;
                  };
                  /**
                   * Creates a KrunReqPing message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunReqPing} KrunReqPing
                   */


                  KrunReqPing.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunReqPing) return object;
                    var message = new $root.tigers.krun.KrunReqPing();
                    if (object.id != null) message.id = object.id | 0;
                    if (object.sendAt != null) if ($util.Long) (message.sendAt = $util.Long.fromValue(object.sendAt)).unsigned = false;else if (typeof object.sendAt === "string") message.sendAt = parseInt(object.sendAt, 10);else if (typeof object.sendAt === "number") message.sendAt = object.sendAt;else if (typeof object.sendAt === "object") message.sendAt = new $util.LongBits(object.sendAt.low >>> 0, object.sendAt.high >>> 0).toNumber();
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunReqPing message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunReqPing
                   * @static
                   * @param {tigers.krun.KrunReqPing} message KrunReqPing
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunReqPing.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.id = 0;

                      if ($util.Long) {
                        var long = new $util.Long(0, 0, false);
                        object.sendAt = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                      } else object.sendAt = options.longs === String ? "0" : 0;
                    }

                    if (message.id != null && message.hasOwnProperty("id")) object.id = message.id;
                    if (message.sendAt != null && message.hasOwnProperty("sendAt")) if (typeof message.sendAt === "number") object.sendAt = options.longs === String ? String(message.sendAt) : message.sendAt;else object.sendAt = options.longs === String ? $util.Long.prototype.toString.call(message.sendAt) : options.longs === Number ? new $util.LongBits(message.sendAt.low >>> 0, message.sendAt.high >>> 0).toNumber() : message.sendAt;
                    return object;
                  };
                  /**
                   * Converts this KrunReqPing to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunReqPing
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunReqPing.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunReqPing;
                }();

                krun.KrunResPing = function () {
                  /**
                   * Properties of a KrunResPing.
                   * @memberof tigers.krun
                   * @interface IKrunResPing
                   * @property {number|null} [id] KrunResPing id
                   * @property {number|Long|null} [sendAt] KrunResPing sendAt
                   */

                  /**
                   * Constructs a new KrunResPing.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunResPing.
                   * @implements IKrunResPing
                   * @constructor
                   * @param {tigers.krun.IKrunResPing=} [properties] Properties to set
                   */
                  function KrunResPing(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunResPing id.
                   * @member {number} id
                   * @memberof tigers.krun.KrunResPing
                   * @instance
                   */


                  KrunResPing.prototype.id = 0;
                  /**
                   * KrunResPing sendAt.
                   * @member {number|Long} sendAt
                   * @memberof tigers.krun.KrunResPing
                   * @instance
                   */

                  KrunResPing.prototype.sendAt = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * Creates a new KrunResPing instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {tigers.krun.IKrunResPing=} [properties] Properties to set
                   * @returns {tigers.krun.KrunResPing} KrunResPing instance
                   */

                  KrunResPing.create = function create(properties) {
                    return new KrunResPing(properties);
                  };
                  /**
                   * Encodes the specified KrunResPing message. Does not implicitly {@link tigers.krun.KrunResPing.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {tigers.krun.IKrunResPing} message KrunResPing message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResPing.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.id != null && message.hasOwnProperty("id")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.id);
                    if (message.sendAt != null && message.hasOwnProperty("sendAt")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int64(message.sendAt);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunResPing message, length delimited. Does not implicitly {@link tigers.krun.KrunResPing.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {tigers.krun.IKrunResPing} message KrunResPing message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResPing.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunResPing message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunResPing} KrunResPing
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResPing.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunResPing();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.id = reader.int32();
                          break;

                        case 2:
                          message.sendAt = reader.int64();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunResPing message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunResPing} KrunResPing
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResPing.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunResPing message.
                   * @function verify
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunResPing.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.id != null && message.hasOwnProperty("id")) if (!$util.isInteger(message.id)) return "id: integer expected";
                    if (message.sendAt != null && message.hasOwnProperty("sendAt")) if (!$util.isInteger(message.sendAt) && !(message.sendAt && $util.isInteger(message.sendAt.low) && $util.isInteger(message.sendAt.high))) return "sendAt: integer|Long expected";
                    return null;
                  };
                  /**
                   * Creates a KrunResPing message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunResPing} KrunResPing
                   */


                  KrunResPing.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunResPing) return object;
                    var message = new $root.tigers.krun.KrunResPing();
                    if (object.id != null) message.id = object.id | 0;
                    if (object.sendAt != null) if ($util.Long) (message.sendAt = $util.Long.fromValue(object.sendAt)).unsigned = false;else if (typeof object.sendAt === "string") message.sendAt = parseInt(object.sendAt, 10);else if (typeof object.sendAt === "number") message.sendAt = object.sendAt;else if (typeof object.sendAt === "object") message.sendAt = new $util.LongBits(object.sendAt.low >>> 0, object.sendAt.high >>> 0).toNumber();
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunResPing message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunResPing
                   * @static
                   * @param {tigers.krun.KrunResPing} message KrunResPing
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunResPing.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.id = 0;

                      if ($util.Long) {
                        var long = new $util.Long(0, 0, false);
                        object.sendAt = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                      } else object.sendAt = options.longs === String ? "0" : 0;
                    }

                    if (message.id != null && message.hasOwnProperty("id")) object.id = message.id;
                    if (message.sendAt != null && message.hasOwnProperty("sendAt")) if (typeof message.sendAt === "number") object.sendAt = options.longs === String ? String(message.sendAt) : message.sendAt;else object.sendAt = options.longs === String ? $util.Long.prototype.toString.call(message.sendAt) : options.longs === Number ? new $util.LongBits(message.sendAt.low >>> 0, message.sendAt.high >>> 0).toNumber() : message.sendAt;
                    return object;
                  };
                  /**
                   * Converts this KrunResPing to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunResPing
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunResPing.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunResPing;
                }();

                krun.KrunGameDefines = function () {
                  /**
                   * Properties of a KrunGameDefines.
                   * @memberof tigers.krun
                   * @interface IKrunGameDefines
                   * @property {number|null} [matchingPrice] KrunGameDefines matchingPrice
                   * @property {number|null} [matchingMaxTime] KrunGameDefines matchingMaxTime
                   * @property {number|null} [yardWidth] KrunGameDefines yardWidth
                   * @property {number|null} [yardHeight] KrunGameDefines yardHeight
                   * @property {number|null} [timePerFrame] KrunGameDefines timePerFrame
                   * @property {number|null} [timeCountdown] KrunGameDefines timeCountdown
                   * @property {number|null} [timePlayGame] KrunGameDefines timePlayGame
                   * @property {number|null} [playerUnitSize] KrunGameDefines playerUnitSize
                   * @property {number|null} [playerMoveSpeed] KrunGameDefines playerMoveSpeed
                   * @property {Array.<tigers.krun.IKrunBulletDefine>|null} [bullets] KrunGameDefines bullets
                   * @property {Array.<number>|null} [candyByRank] KrunGameDefines candyByRank
                   * @property {number|null} [candyDnf] KrunGameDefines candyDnf
                   */

                  /**
                   * Constructs a new KrunGameDefines.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunGameDefines.
                   * @implements IKrunGameDefines
                   * @constructor
                   * @param {tigers.krun.IKrunGameDefines=} [properties] Properties to set
                   */
                  function KrunGameDefines(properties) {
                    this.bullets = [];
                    this.candyByRank = [];
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunGameDefines matchingPrice.
                   * @member {number} matchingPrice
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */


                  KrunGameDefines.prototype.matchingPrice = 0;
                  /**
                   * KrunGameDefines matchingMaxTime.
                   * @member {number} matchingMaxTime
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.matchingMaxTime = 0;
                  /**
                   * KrunGameDefines yardWidth.
                   * @member {number} yardWidth
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.yardWidth = 0;
                  /**
                   * KrunGameDefines yardHeight.
                   * @member {number} yardHeight
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.yardHeight = 0;
                  /**
                   * KrunGameDefines timePerFrame.
                   * @member {number} timePerFrame
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.timePerFrame = 0;
                  /**
                   * KrunGameDefines timeCountdown.
                   * @member {number} timeCountdown
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.timeCountdown = 0;
                  /**
                   * KrunGameDefines timePlayGame.
                   * @member {number} timePlayGame
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.timePlayGame = 0;
                  /**
                   * KrunGameDefines playerUnitSize.
                   * @member {number} playerUnitSize
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.playerUnitSize = 0;
                  /**
                   * KrunGameDefines playerMoveSpeed.
                   * @member {number} playerMoveSpeed
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.playerMoveSpeed = 0;
                  /**
                   * KrunGameDefines bullets.
                   * @member {Array.<tigers.krun.IKrunBulletDefine>} bullets
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.bullets = $util.emptyArray;
                  /**
                   * KrunGameDefines candyByRank.
                   * @member {Array.<number>} candyByRank
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.candyByRank = $util.emptyArray;
                  /**
                   * KrunGameDefines candyDnf.
                   * @member {number} candyDnf
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   */

                  KrunGameDefines.prototype.candyDnf = 0;
                  /**
                   * Creates a new KrunGameDefines instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {tigers.krun.IKrunGameDefines=} [properties] Properties to set
                   * @returns {tigers.krun.KrunGameDefines} KrunGameDefines instance
                   */

                  KrunGameDefines.create = function create(properties) {
                    return new KrunGameDefines(properties);
                  };
                  /**
                   * Encodes the specified KrunGameDefines message. Does not implicitly {@link tigers.krun.KrunGameDefines.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {tigers.krun.IKrunGameDefines} message KrunGameDefines message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameDefines.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.matchingPrice != null && message.hasOwnProperty("matchingPrice")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.matchingPrice);
                    if (message.matchingMaxTime != null && message.hasOwnProperty("matchingMaxTime")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.matchingMaxTime);
                    if (message.yardWidth != null && message.hasOwnProperty("yardWidth")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.yardWidth);
                    if (message.yardHeight != null && message.hasOwnProperty("yardHeight")) writer.uint32(
                    /* id 4, wireType 0 =*/
                    32).int32(message.yardHeight);
                    if (message.timePerFrame != null && message.hasOwnProperty("timePerFrame")) writer.uint32(
                    /* id 5, wireType 0 =*/
                    40).int32(message.timePerFrame);
                    if (message.timeCountdown != null && message.hasOwnProperty("timeCountdown")) writer.uint32(
                    /* id 6, wireType 0 =*/
                    48).int32(message.timeCountdown);
                    if (message.timePlayGame != null && message.hasOwnProperty("timePlayGame")) writer.uint32(
                    /* id 7, wireType 0 =*/
                    56).int32(message.timePlayGame);
                    if (message.playerUnitSize != null && message.hasOwnProperty("playerUnitSize")) writer.uint32(
                    /* id 8, wireType 0 =*/
                    64).int32(message.playerUnitSize);
                    if (message.playerMoveSpeed != null && message.hasOwnProperty("playerMoveSpeed")) writer.uint32(
                    /* id 9, wireType 5 =*/
                    77).float(message.playerMoveSpeed);
                    if (message.bullets != null && message.bullets.length) for (var i = 0; i < message.bullets.length; ++i) $root.tigers.krun.KrunBulletDefine.encode(message.bullets[i], writer.uint32(
                    /* id 10, wireType 2 =*/
                    82).fork()).ldelim();

                    if (message.candyByRank != null && message.candyByRank.length) {
                      writer.uint32(
                      /* id 11, wireType 2 =*/
                      90).fork();

                      for (var i = 0; i < message.candyByRank.length; ++i) writer.int32(message.candyByRank[i]);

                      writer.ldelim();
                    }

                    if (message.candyDnf != null && message.hasOwnProperty("candyDnf")) writer.uint32(
                    /* id 12, wireType 0 =*/
                    96).int32(message.candyDnf);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunGameDefines message, length delimited. Does not implicitly {@link tigers.krun.KrunGameDefines.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {tigers.krun.IKrunGameDefines} message KrunGameDefines message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameDefines.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunGameDefines message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunGameDefines} KrunGameDefines
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameDefines.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunGameDefines();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.matchingPrice = reader.int32();
                          break;

                        case 2:
                          message.matchingMaxTime = reader.int32();
                          break;

                        case 3:
                          message.yardWidth = reader.int32();
                          break;

                        case 4:
                          message.yardHeight = reader.int32();
                          break;

                        case 5:
                          message.timePerFrame = reader.int32();
                          break;

                        case 6:
                          message.timeCountdown = reader.int32();
                          break;

                        case 7:
                          message.timePlayGame = reader.int32();
                          break;

                        case 8:
                          message.playerUnitSize = reader.int32();
                          break;

                        case 9:
                          message.playerMoveSpeed = reader.float();
                          break;

                        case 10:
                          if (!(message.bullets && message.bullets.length)) message.bullets = [];
                          message.bullets.push($root.tigers.krun.KrunBulletDefine.decode(reader, reader.uint32()));
                          break;

                        case 11:
                          if (!(message.candyByRank && message.candyByRank.length)) message.candyByRank = [];

                          if ((tag & 7) === 2) {
                            var end2 = reader.uint32() + reader.pos;

                            while (reader.pos < end2) message.candyByRank.push(reader.int32());
                          } else message.candyByRank.push(reader.int32());

                          break;

                        case 12:
                          message.candyDnf = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunGameDefines message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunGameDefines} KrunGameDefines
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameDefines.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunGameDefines message.
                   * @function verify
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunGameDefines.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.matchingPrice != null && message.hasOwnProperty("matchingPrice")) if (!$util.isInteger(message.matchingPrice)) return "matchingPrice: integer expected";
                    if (message.matchingMaxTime != null && message.hasOwnProperty("matchingMaxTime")) if (!$util.isInteger(message.matchingMaxTime)) return "matchingMaxTime: integer expected";
                    if (message.yardWidth != null && message.hasOwnProperty("yardWidth")) if (!$util.isInteger(message.yardWidth)) return "yardWidth: integer expected";
                    if (message.yardHeight != null && message.hasOwnProperty("yardHeight")) if (!$util.isInteger(message.yardHeight)) return "yardHeight: integer expected";
                    if (message.timePerFrame != null && message.hasOwnProperty("timePerFrame")) if (!$util.isInteger(message.timePerFrame)) return "timePerFrame: integer expected";
                    if (message.timeCountdown != null && message.hasOwnProperty("timeCountdown")) if (!$util.isInteger(message.timeCountdown)) return "timeCountdown: integer expected";
                    if (message.timePlayGame != null && message.hasOwnProperty("timePlayGame")) if (!$util.isInteger(message.timePlayGame)) return "timePlayGame: integer expected";
                    if (message.playerUnitSize != null && message.hasOwnProperty("playerUnitSize")) if (!$util.isInteger(message.playerUnitSize)) return "playerUnitSize: integer expected";
                    if (message.playerMoveSpeed != null && message.hasOwnProperty("playerMoveSpeed")) if (typeof message.playerMoveSpeed !== "number") return "playerMoveSpeed: number expected";

                    if (message.bullets != null && message.hasOwnProperty("bullets")) {
                      if (!Array.isArray(message.bullets)) return "bullets: array expected";

                      for (var i = 0; i < message.bullets.length; ++i) {
                        var error = $root.tigers.krun.KrunBulletDefine.verify(message.bullets[i]);
                        if (error) return "bullets." + error;
                      }
                    }

                    if (message.candyByRank != null && message.hasOwnProperty("candyByRank")) {
                      if (!Array.isArray(message.candyByRank)) return "candyByRank: array expected";

                      for (var i = 0; i < message.candyByRank.length; ++i) if (!$util.isInteger(message.candyByRank[i])) return "candyByRank: integer[] expected";
                    }

                    if (message.candyDnf != null && message.hasOwnProperty("candyDnf")) if (!$util.isInteger(message.candyDnf)) return "candyDnf: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunGameDefines message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunGameDefines} KrunGameDefines
                   */


                  KrunGameDefines.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunGameDefines) return object;
                    var message = new $root.tigers.krun.KrunGameDefines();
                    if (object.matchingPrice != null) message.matchingPrice = object.matchingPrice | 0;
                    if (object.matchingMaxTime != null) message.matchingMaxTime = object.matchingMaxTime | 0;
                    if (object.yardWidth != null) message.yardWidth = object.yardWidth | 0;
                    if (object.yardHeight != null) message.yardHeight = object.yardHeight | 0;
                    if (object.timePerFrame != null) message.timePerFrame = object.timePerFrame | 0;
                    if (object.timeCountdown != null) message.timeCountdown = object.timeCountdown | 0;
                    if (object.timePlayGame != null) message.timePlayGame = object.timePlayGame | 0;
                    if (object.playerUnitSize != null) message.playerUnitSize = object.playerUnitSize | 0;
                    if (object.playerMoveSpeed != null) message.playerMoveSpeed = Number(object.playerMoveSpeed);

                    if (object.bullets) {
                      if (!Array.isArray(object.bullets)) throw TypeError(".tigers.krun.KrunGameDefines.bullets: array expected");
                      message.bullets = [];

                      for (var i = 0; i < object.bullets.length; ++i) {
                        if (typeof object.bullets[i] !== "object") throw TypeError(".tigers.krun.KrunGameDefines.bullets: object expected");
                        message.bullets[i] = $root.tigers.krun.KrunBulletDefine.fromObject(object.bullets[i]);
                      }
                    }

                    if (object.candyByRank) {
                      if (!Array.isArray(object.candyByRank)) throw TypeError(".tigers.krun.KrunGameDefines.candyByRank: array expected");
                      message.candyByRank = [];

                      for (var i = 0; i < object.candyByRank.length; ++i) message.candyByRank[i] = object.candyByRank[i] | 0;
                    }

                    if (object.candyDnf != null) message.candyDnf = object.candyDnf | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunGameDefines message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunGameDefines
                   * @static
                   * @param {tigers.krun.KrunGameDefines} message KrunGameDefines
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunGameDefines.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.arrays || options.defaults) {
                      object.bullets = [];
                      object.candyByRank = [];
                    }

                    if (options.defaults) {
                      object.matchingPrice = 0;
                      object.matchingMaxTime = 0;
                      object.yardWidth = 0;
                      object.yardHeight = 0;
                      object.timePerFrame = 0;
                      object.timeCountdown = 0;
                      object.timePlayGame = 0;
                      object.playerUnitSize = 0;
                      object.playerMoveSpeed = 0;
                      object.candyDnf = 0;
                    }

                    if (message.matchingPrice != null && message.hasOwnProperty("matchingPrice")) object.matchingPrice = message.matchingPrice;
                    if (message.matchingMaxTime != null && message.hasOwnProperty("matchingMaxTime")) object.matchingMaxTime = message.matchingMaxTime;
                    if (message.yardWidth != null && message.hasOwnProperty("yardWidth")) object.yardWidth = message.yardWidth;
                    if (message.yardHeight != null && message.hasOwnProperty("yardHeight")) object.yardHeight = message.yardHeight;
                    if (message.timePerFrame != null && message.hasOwnProperty("timePerFrame")) object.timePerFrame = message.timePerFrame;
                    if (message.timeCountdown != null && message.hasOwnProperty("timeCountdown")) object.timeCountdown = message.timeCountdown;
                    if (message.timePlayGame != null && message.hasOwnProperty("timePlayGame")) object.timePlayGame = message.timePlayGame;
                    if (message.playerUnitSize != null && message.hasOwnProperty("playerUnitSize")) object.playerUnitSize = message.playerUnitSize;
                    if (message.playerMoveSpeed != null && message.hasOwnProperty("playerMoveSpeed")) object.playerMoveSpeed = options.json && !isFinite(message.playerMoveSpeed) ? String(message.playerMoveSpeed) : message.playerMoveSpeed;

                    if (message.bullets && message.bullets.length) {
                      object.bullets = [];

                      for (var j = 0; j < message.bullets.length; ++j) object.bullets[j] = $root.tigers.krun.KrunBulletDefine.toObject(message.bullets[j], options);
                    }

                    if (message.candyByRank && message.candyByRank.length) {
                      object.candyByRank = [];

                      for (var j = 0; j < message.candyByRank.length; ++j) object.candyByRank[j] = message.candyByRank[j];
                    }

                    if (message.candyDnf != null && message.hasOwnProperty("candyDnf")) object.candyDnf = message.candyDnf;
                    return object;
                  };
                  /**
                   * Converts this KrunGameDefines to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunGameDefines
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunGameDefines.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunGameDefines;
                }();

                krun.KrunBulletDefine = function () {
                  /**
                   * Properties of a KrunBulletDefine.
                   * @memberof tigers.krun
                   * @interface IKrunBulletDefine
                   * @property {string|null} [name] KrunBulletDefine name
                   * @property {number|null} [price] KrunBulletDefine price
                   * @property {number|null} [speed] KrunBulletDefine speed
                   * @property {tigers.krun.KRUN_BULLET_EFFECTS|null} [effect] KrunBulletDefine effect
                   * @property {number|null} [duration] KrunBulletDefine duration
                   * @property {number|null} [limitPerGame] KrunBulletDefine limitPerGame
                   * @property {string|null} [displayName] KrunBulletDefine displayName
                   * @property {string|null} [desc] KrunBulletDefine desc
                   * @property {number|null} [reload] KrunBulletDefine reload
                   */

                  /**
                   * Constructs a new KrunBulletDefine.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunBulletDefine.
                   * @implements IKrunBulletDefine
                   * @constructor
                   * @param {tigers.krun.IKrunBulletDefine=} [properties] Properties to set
                   */
                  function KrunBulletDefine(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunBulletDefine name.
                   * @member {string} name
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */


                  KrunBulletDefine.prototype.name = "";
                  /**
                   * KrunBulletDefine price.
                   * @member {number} price
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.price = 0;
                  /**
                   * KrunBulletDefine speed.
                   * @member {number} speed
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.speed = 0;
                  /**
                   * KrunBulletDefine effect.
                   * @member {tigers.krun.KRUN_BULLET_EFFECTS} effect
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.effect = 0;
                  /**
                   * KrunBulletDefine duration.
                   * @member {number} duration
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.duration = 0;
                  /**
                   * KrunBulletDefine limitPerGame.
                   * @member {number} limitPerGame
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.limitPerGame = 0;
                  /**
                   * KrunBulletDefine displayName.
                   * @member {string} displayName
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.displayName = "";
                  /**
                   * KrunBulletDefine desc.
                   * @member {string} desc
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.desc = "";
                  /**
                   * KrunBulletDefine reload.
                   * @member {number} reload
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   */

                  KrunBulletDefine.prototype.reload = 0;
                  /**
                   * Creates a new KrunBulletDefine instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {tigers.krun.IKrunBulletDefine=} [properties] Properties to set
                   * @returns {tigers.krun.KrunBulletDefine} KrunBulletDefine instance
                   */

                  KrunBulletDefine.create = function create(properties) {
                    return new KrunBulletDefine(properties);
                  };
                  /**
                   * Encodes the specified KrunBulletDefine message. Does not implicitly {@link tigers.krun.KrunBulletDefine.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {tigers.krun.IKrunBulletDefine} message KrunBulletDefine message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunBulletDefine.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.name != null && message.hasOwnProperty("name")) writer.uint32(
                    /* id 1, wireType 2 =*/
                    10).string(message.name);
                    if (message.price != null && message.hasOwnProperty("price")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.price);
                    if (message.speed != null && message.hasOwnProperty("speed")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.speed);
                    if (message.effect != null && message.hasOwnProperty("effect")) writer.uint32(
                    /* id 4, wireType 0 =*/
                    32).int32(message.effect);
                    if (message.duration != null && message.hasOwnProperty("duration")) writer.uint32(
                    /* id 5, wireType 0 =*/
                    40).int32(message.duration);
                    if (message.limitPerGame != null && message.hasOwnProperty("limitPerGame")) writer.uint32(
                    /* id 6, wireType 0 =*/
                    48).int32(message.limitPerGame);
                    if (message.displayName != null && message.hasOwnProperty("displayName")) writer.uint32(
                    /* id 7, wireType 2 =*/
                    58).string(message.displayName);
                    if (message.desc != null && message.hasOwnProperty("desc")) writer.uint32(
                    /* id 8, wireType 2 =*/
                    66).string(message.desc);
                    if (message.reload != null && message.hasOwnProperty("reload")) writer.uint32(
                    /* id 9, wireType 0 =*/
                    72).int32(message.reload);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunBulletDefine message, length delimited. Does not implicitly {@link tigers.krun.KrunBulletDefine.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {tigers.krun.IKrunBulletDefine} message KrunBulletDefine message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunBulletDefine.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunBulletDefine message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunBulletDefine} KrunBulletDefine
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunBulletDefine.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunBulletDefine();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.name = reader.string();
                          break;

                        case 2:
                          message.price = reader.int32();
                          break;

                        case 3:
                          message.speed = reader.int32();
                          break;

                        case 4:
                          message.effect = reader.int32();
                          break;

                        case 5:
                          message.duration = reader.int32();
                          break;

                        case 6:
                          message.limitPerGame = reader.int32();
                          break;

                        case 7:
                          message.displayName = reader.string();
                          break;

                        case 8:
                          message.desc = reader.string();
                          break;

                        case 9:
                          message.reload = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunBulletDefine message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunBulletDefine} KrunBulletDefine
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunBulletDefine.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunBulletDefine message.
                   * @function verify
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunBulletDefine.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.name != null && message.hasOwnProperty("name")) if (!$util.isString(message.name)) return "name: string expected";
                    if (message.price != null && message.hasOwnProperty("price")) if (!$util.isInteger(message.price)) return "price: integer expected";
                    if (message.speed != null && message.hasOwnProperty("speed")) if (!$util.isInteger(message.speed)) return "speed: integer expected";
                    if (message.effect != null && message.hasOwnProperty("effect")) switch (message.effect) {
                      default:
                        return "effect: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                        break;
                    }
                    if (message.duration != null && message.hasOwnProperty("duration")) if (!$util.isInteger(message.duration)) return "duration: integer expected";
                    if (message.limitPerGame != null && message.hasOwnProperty("limitPerGame")) if (!$util.isInteger(message.limitPerGame)) return "limitPerGame: integer expected";
                    if (message.displayName != null && message.hasOwnProperty("displayName")) if (!$util.isString(message.displayName)) return "displayName: string expected";
                    if (message.desc != null && message.hasOwnProperty("desc")) if (!$util.isString(message.desc)) return "desc: string expected";
                    if (message.reload != null && message.hasOwnProperty("reload")) if (!$util.isInteger(message.reload)) return "reload: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunBulletDefine message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunBulletDefine} KrunBulletDefine
                   */


                  KrunBulletDefine.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunBulletDefine) return object;
                    var message = new $root.tigers.krun.KrunBulletDefine();
                    if (object.name != null) message.name = String(object.name);
                    if (object.price != null) message.price = object.price | 0;
                    if (object.speed != null) message.speed = object.speed | 0;

                    switch (object.effect) {
                      case "KRUN_BULLET_EFFECT_NONE":
                      case 0:
                        message.effect = 0;
                        break;

                      case "KRUN_BULLET_EFFECT_FREEZE":
                      case 1:
                        message.effect = 1;
                        break;

                      case "KRUN_BULLET_EFFECT_PENALTY":
                      case 2:
                        message.effect = 2;
                        break;
                    }

                    if (object.duration != null) message.duration = object.duration | 0;
                    if (object.limitPerGame != null) message.limitPerGame = object.limitPerGame | 0;
                    if (object.displayName != null) message.displayName = String(object.displayName);
                    if (object.desc != null) message.desc = String(object.desc);
                    if (object.reload != null) message.reload = object.reload | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunBulletDefine message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunBulletDefine
                   * @static
                   * @param {tigers.krun.KrunBulletDefine} message KrunBulletDefine
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunBulletDefine.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.name = "";
                      object.price = 0;
                      object.speed = 0;
                      object.effect = options.enums === String ? "KRUN_BULLET_EFFECT_NONE" : 0;
                      object.duration = 0;
                      object.limitPerGame = 0;
                      object.displayName = "";
                      object.desc = "";
                      object.reload = 0;
                    }

                    if (message.name != null && message.hasOwnProperty("name")) object.name = message.name;
                    if (message.price != null && message.hasOwnProperty("price")) object.price = message.price;
                    if (message.speed != null && message.hasOwnProperty("speed")) object.speed = message.speed;
                    if (message.effect != null && message.hasOwnProperty("effect")) object.effect = options.enums === String ? $root.tigers.krun.KRUN_BULLET_EFFECTS[message.effect] : message.effect;
                    if (message.duration != null && message.hasOwnProperty("duration")) object.duration = message.duration;
                    if (message.limitPerGame != null && message.hasOwnProperty("limitPerGame")) object.limitPerGame = message.limitPerGame;
                    if (message.displayName != null && message.hasOwnProperty("displayName")) object.displayName = message.displayName;
                    if (message.desc != null && message.hasOwnProperty("desc")) object.desc = message.desc;
                    if (message.reload != null && message.hasOwnProperty("reload")) object.reload = message.reload;
                    return object;
                  };
                  /**
                   * Converts this KrunBulletDefine to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunBulletDefine
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunBulletDefine.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunBulletDefine;
                }();

                krun.KrunReqPlayerJoin = function () {
                  /**
                   * Properties of a KrunReqPlayerJoin.
                   * @memberof tigers.krun
                   * @interface IKrunReqPlayerJoin
                   * @property {string|null} [displayName] KrunReqPlayerJoin displayName
                   * @property {string|null} [gameId] KrunReqPlayerJoin gameId
                   */

                  /**
                   * Constructs a new KrunReqPlayerJoin.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunReqPlayerJoin.
                   * @implements IKrunReqPlayerJoin
                   * @constructor
                   * @param {tigers.krun.IKrunReqPlayerJoin=} [properties] Properties to set
                   */
                  function KrunReqPlayerJoin(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunReqPlayerJoin displayName.
                   * @member {string} displayName
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @instance
                   */


                  KrunReqPlayerJoin.prototype.displayName = "";
                  /**
                   * KrunReqPlayerJoin gameId.
                   * @member {string} gameId
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @instance
                   */

                  KrunReqPlayerJoin.prototype.gameId = "";
                  /**
                   * Creates a new KrunReqPlayerJoin instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {tigers.krun.IKrunReqPlayerJoin=} [properties] Properties to set
                   * @returns {tigers.krun.KrunReqPlayerJoin} KrunReqPlayerJoin instance
                   */

                  KrunReqPlayerJoin.create = function create(properties) {
                    return new KrunReqPlayerJoin(properties);
                  };
                  /**
                   * Encodes the specified KrunReqPlayerJoin message. Does not implicitly {@link tigers.krun.KrunReqPlayerJoin.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {tigers.krun.IKrunReqPlayerJoin} message KrunReqPlayerJoin message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunReqPlayerJoin.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.displayName != null && message.hasOwnProperty("displayName")) writer.uint32(
                    /* id 2, wireType 2 =*/
                    18).string(message.displayName);
                    if (message.gameId != null && message.hasOwnProperty("gameId")) writer.uint32(
                    /* id 3, wireType 2 =*/
                    26).string(message.gameId);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunReqPlayerJoin message, length delimited. Does not implicitly {@link tigers.krun.KrunReqPlayerJoin.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {tigers.krun.IKrunReqPlayerJoin} message KrunReqPlayerJoin message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunReqPlayerJoin.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunReqPlayerJoin message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunReqPlayerJoin} KrunReqPlayerJoin
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunReqPlayerJoin.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunReqPlayerJoin();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 2:
                          message.displayName = reader.string();
                          break;

                        case 3:
                          message.gameId = reader.string();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunReqPlayerJoin message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunReqPlayerJoin} KrunReqPlayerJoin
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunReqPlayerJoin.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunReqPlayerJoin message.
                   * @function verify
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunReqPlayerJoin.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.displayName != null && message.hasOwnProperty("displayName")) if (!$util.isString(message.displayName)) return "displayName: string expected";
                    if (message.gameId != null && message.hasOwnProperty("gameId")) if (!$util.isString(message.gameId)) return "gameId: string expected";
                    return null;
                  };
                  /**
                   * Creates a KrunReqPlayerJoin message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunReqPlayerJoin} KrunReqPlayerJoin
                   */


                  KrunReqPlayerJoin.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunReqPlayerJoin) return object;
                    var message = new $root.tigers.krun.KrunReqPlayerJoin();
                    if (object.displayName != null) message.displayName = String(object.displayName);
                    if (object.gameId != null) message.gameId = String(object.gameId);
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunReqPlayerJoin message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @static
                   * @param {tigers.krun.KrunReqPlayerJoin} message KrunReqPlayerJoin
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunReqPlayerJoin.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.displayName = "";
                      object.gameId = "";
                    }

                    if (message.displayName != null && message.hasOwnProperty("displayName")) object.displayName = message.displayName;
                    if (message.gameId != null && message.hasOwnProperty("gameId")) object.gameId = message.gameId;
                    return object;
                  };
                  /**
                   * Converts this KrunReqPlayerJoin to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunReqPlayerJoin
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunReqPlayerJoin.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunReqPlayerJoin;
                }();

                krun.KrunResPlayerJoin = function () {
                  /**
                   * Properties of a KrunResPlayerJoin.
                   * @memberof tigers.krun
                   * @interface IKrunResPlayerJoin
                   * @property {tigers.krun.IKrunGameUpdate|null} [game] KrunResPlayerJoin game
                   * @property {string|null} [worker] KrunResPlayerJoin worker
                   * @property {number|null} [waitingPlayers] KrunResPlayerJoin waitingPlayers
                   */

                  /**
                   * Constructs a new KrunResPlayerJoin.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunResPlayerJoin.
                   * @implements IKrunResPlayerJoin
                   * @constructor
                   * @param {tigers.krun.IKrunResPlayerJoin=} [properties] Properties to set
                   */
                  function KrunResPlayerJoin(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunResPlayerJoin game.
                   * @member {tigers.krun.IKrunGameUpdate|null|undefined} game
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @instance
                   */


                  KrunResPlayerJoin.prototype.game = null;
                  /**
                   * KrunResPlayerJoin worker.
                   * @member {string} worker
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @instance
                   */

                  KrunResPlayerJoin.prototype.worker = "";
                  /**
                   * KrunResPlayerJoin waitingPlayers.
                   * @member {number} waitingPlayers
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @instance
                   */

                  KrunResPlayerJoin.prototype.waitingPlayers = 0;
                  /**
                   * Creates a new KrunResPlayerJoin instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {tigers.krun.IKrunResPlayerJoin=} [properties] Properties to set
                   * @returns {tigers.krun.KrunResPlayerJoin} KrunResPlayerJoin instance
                   */

                  KrunResPlayerJoin.create = function create(properties) {
                    return new KrunResPlayerJoin(properties);
                  };
                  /**
                   * Encodes the specified KrunResPlayerJoin message. Does not implicitly {@link tigers.krun.KrunResPlayerJoin.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {tigers.krun.IKrunResPlayerJoin} message KrunResPlayerJoin message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResPlayerJoin.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.game != null && message.hasOwnProperty("game")) $root.tigers.krun.KrunGameUpdate.encode(message.game, writer.uint32(
                    /* id 1, wireType 2 =*/
                    10).fork()).ldelim();
                    if (message.worker != null && message.hasOwnProperty("worker")) writer.uint32(
                    /* id 2, wireType 2 =*/
                    18).string(message.worker);
                    if (message.waitingPlayers != null && message.hasOwnProperty("waitingPlayers")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.waitingPlayers);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunResPlayerJoin message, length delimited. Does not implicitly {@link tigers.krun.KrunResPlayerJoin.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {tigers.krun.IKrunResPlayerJoin} message KrunResPlayerJoin message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResPlayerJoin.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunResPlayerJoin message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunResPlayerJoin} KrunResPlayerJoin
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResPlayerJoin.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunResPlayerJoin();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.game = $root.tigers.krun.KrunGameUpdate.decode(reader, reader.uint32());
                          break;

                        case 2:
                          message.worker = reader.string();
                          break;

                        case 3:
                          message.waitingPlayers = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunResPlayerJoin message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunResPlayerJoin} KrunResPlayerJoin
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResPlayerJoin.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunResPlayerJoin message.
                   * @function verify
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunResPlayerJoin.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";

                    if (message.game != null && message.hasOwnProperty("game")) {
                      var error = $root.tigers.krun.KrunGameUpdate.verify(message.game);
                      if (error) return "game." + error;
                    }

                    if (message.worker != null && message.hasOwnProperty("worker")) if (!$util.isString(message.worker)) return "worker: string expected";
                    if (message.waitingPlayers != null && message.hasOwnProperty("waitingPlayers")) if (!$util.isInteger(message.waitingPlayers)) return "waitingPlayers: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunResPlayerJoin message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunResPlayerJoin} KrunResPlayerJoin
                   */


                  KrunResPlayerJoin.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunResPlayerJoin) return object;
                    var message = new $root.tigers.krun.KrunResPlayerJoin();

                    if (object.game != null) {
                      if (typeof object.game !== "object") throw TypeError(".tigers.krun.KrunResPlayerJoin.game: object expected");
                      message.game = $root.tigers.krun.KrunGameUpdate.fromObject(object.game);
                    }

                    if (object.worker != null) message.worker = String(object.worker);
                    if (object.waitingPlayers != null) message.waitingPlayers = object.waitingPlayers | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunResPlayerJoin message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @static
                   * @param {tigers.krun.KrunResPlayerJoin} message KrunResPlayerJoin
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunResPlayerJoin.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.game = null;
                      object.worker = "";
                      object.waitingPlayers = 0;
                    }

                    if (message.game != null && message.hasOwnProperty("game")) object.game = $root.tigers.krun.KrunGameUpdate.toObject(message.game, options);
                    if (message.worker != null && message.hasOwnProperty("worker")) object.worker = message.worker;
                    if (message.waitingPlayers != null && message.hasOwnProperty("waitingPlayers")) object.waitingPlayers = message.waitingPlayers;
                    return object;
                  };
                  /**
                   * Converts this KrunResPlayerJoin to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunResPlayerJoin
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunResPlayerJoin.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunResPlayerJoin;
                }();

                krun.KrunGameMatching = function () {
                  /**
                   * Properties of a KrunGameMatching.
                   * @memberof tigers.krun
                   * @interface IKrunGameMatching
                   * @property {string|null} [gameId] KrunGameMatching gameId
                   * @property {number|Long|null} [serverTime] KrunGameMatching serverTime
                   * @property {number|Long|null} [startTime] KrunGameMatching startTime
                   * @property {Array.<tigers.krun.IKrunPlayer>|null} [players] KrunGameMatching players
                   * @property {Array.<tigers.krun.IKrunGamePhase>|null} [phases] KrunGameMatching phases
                   * @property {Array.<string>|null} [playerNames] KrunGameMatching playerNames
                   */

                  /**
                   * Constructs a new KrunGameMatching.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunGameMatching.
                   * @implements IKrunGameMatching
                   * @constructor
                   * @param {tigers.krun.IKrunGameMatching=} [properties] Properties to set
                   */
                  function KrunGameMatching(properties) {
                    this.players = [];
                    this.phases = [];
                    this.playerNames = [];
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunGameMatching gameId.
                   * @member {string} gameId
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   */


                  KrunGameMatching.prototype.gameId = "";
                  /**
                   * KrunGameMatching serverTime.
                   * @member {number|Long} serverTime
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   */

                  KrunGameMatching.prototype.serverTime = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * KrunGameMatching startTime.
                   * @member {number|Long} startTime
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   */

                  KrunGameMatching.prototype.startTime = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * KrunGameMatching players.
                   * @member {Array.<tigers.krun.IKrunPlayer>} players
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   */

                  KrunGameMatching.prototype.players = $util.emptyArray;
                  /**
                   * KrunGameMatching phases.
                   * @member {Array.<tigers.krun.IKrunGamePhase>} phases
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   */

                  KrunGameMatching.prototype.phases = $util.emptyArray;
                  /**
                   * KrunGameMatching playerNames.
                   * @member {Array.<string>} playerNames
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   */

                  KrunGameMatching.prototype.playerNames = $util.emptyArray;
                  /**
                   * Creates a new KrunGameMatching instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {tigers.krun.IKrunGameMatching=} [properties] Properties to set
                   * @returns {tigers.krun.KrunGameMatching} KrunGameMatching instance
                   */

                  KrunGameMatching.create = function create(properties) {
                    return new KrunGameMatching(properties);
                  };
                  /**
                   * Encodes the specified KrunGameMatching message. Does not implicitly {@link tigers.krun.KrunGameMatching.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {tigers.krun.IKrunGameMatching} message KrunGameMatching message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameMatching.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.gameId != null && message.hasOwnProperty("gameId")) writer.uint32(
                    /* id 1, wireType 2 =*/
                    10).string(message.gameId);
                    if (message.serverTime != null && message.hasOwnProperty("serverTime")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int64(message.serverTime);
                    if (message.startTime != null && message.hasOwnProperty("startTime")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int64(message.startTime);
                    if (message.players != null && message.players.length) for (var i = 0; i < message.players.length; ++i) $root.tigers.krun.KrunPlayer.encode(message.players[i], writer.uint32(
                    /* id 4, wireType 2 =*/
                    34).fork()).ldelim();
                    if (message.phases != null && message.phases.length) for (var i = 0; i < message.phases.length; ++i) $root.tigers.krun.KrunGamePhase.encode(message.phases[i], writer.uint32(
                    /* id 5, wireType 2 =*/
                    42).fork()).ldelim();
                    if (message.playerNames != null && message.playerNames.length) for (var i = 0; i < message.playerNames.length; ++i) writer.uint32(
                    /* id 6, wireType 2 =*/
                    50).string(message.playerNames[i]);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunGameMatching message, length delimited. Does not implicitly {@link tigers.krun.KrunGameMatching.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {tigers.krun.IKrunGameMatching} message KrunGameMatching message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameMatching.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunGameMatching message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunGameMatching} KrunGameMatching
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameMatching.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunGameMatching();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.gameId = reader.string();
                          break;

                        case 2:
                          message.serverTime = reader.int64();
                          break;

                        case 3:
                          message.startTime = reader.int64();
                          break;

                        case 4:
                          if (!(message.players && message.players.length)) message.players = [];
                          message.players.push($root.tigers.krun.KrunPlayer.decode(reader, reader.uint32()));
                          break;

                        case 5:
                          if (!(message.phases && message.phases.length)) message.phases = [];
                          message.phases.push($root.tigers.krun.KrunGamePhase.decode(reader, reader.uint32()));
                          break;

                        case 6:
                          if (!(message.playerNames && message.playerNames.length)) message.playerNames = [];
                          message.playerNames.push(reader.string());
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunGameMatching message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunGameMatching} KrunGameMatching
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameMatching.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunGameMatching message.
                   * @function verify
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunGameMatching.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.gameId != null && message.hasOwnProperty("gameId")) if (!$util.isString(message.gameId)) return "gameId: string expected";
                    if (message.serverTime != null && message.hasOwnProperty("serverTime")) if (!$util.isInteger(message.serverTime) && !(message.serverTime && $util.isInteger(message.serverTime.low) && $util.isInteger(message.serverTime.high))) return "serverTime: integer|Long expected";
                    if (message.startTime != null && message.hasOwnProperty("startTime")) if (!$util.isInteger(message.startTime) && !(message.startTime && $util.isInteger(message.startTime.low) && $util.isInteger(message.startTime.high))) return "startTime: integer|Long expected";

                    if (message.players != null && message.hasOwnProperty("players")) {
                      if (!Array.isArray(message.players)) return "players: array expected";

                      for (var i = 0; i < message.players.length; ++i) {
                        var error = $root.tigers.krun.KrunPlayer.verify(message.players[i]);
                        if (error) return "players." + error;
                      }
                    }

                    if (message.phases != null && message.hasOwnProperty("phases")) {
                      if (!Array.isArray(message.phases)) return "phases: array expected";

                      for (var i = 0; i < message.phases.length; ++i) {
                        var error = $root.tigers.krun.KrunGamePhase.verify(message.phases[i]);
                        if (error) return "phases." + error;
                      }
                    }

                    if (message.playerNames != null && message.hasOwnProperty("playerNames")) {
                      if (!Array.isArray(message.playerNames)) return "playerNames: array expected";

                      for (var i = 0; i < message.playerNames.length; ++i) if (!$util.isString(message.playerNames[i])) return "playerNames: string[] expected";
                    }

                    return null;
                  };
                  /**
                   * Creates a KrunGameMatching message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunGameMatching} KrunGameMatching
                   */


                  KrunGameMatching.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunGameMatching) return object;
                    var message = new $root.tigers.krun.KrunGameMatching();
                    if (object.gameId != null) message.gameId = String(object.gameId);
                    if (object.serverTime != null) if ($util.Long) (message.serverTime = $util.Long.fromValue(object.serverTime)).unsigned = false;else if (typeof object.serverTime === "string") message.serverTime = parseInt(object.serverTime, 10);else if (typeof object.serverTime === "number") message.serverTime = object.serverTime;else if (typeof object.serverTime === "object") message.serverTime = new $util.LongBits(object.serverTime.low >>> 0, object.serverTime.high >>> 0).toNumber();
                    if (object.startTime != null) if ($util.Long) (message.startTime = $util.Long.fromValue(object.startTime)).unsigned = false;else if (typeof object.startTime === "string") message.startTime = parseInt(object.startTime, 10);else if (typeof object.startTime === "number") message.startTime = object.startTime;else if (typeof object.startTime === "object") message.startTime = new $util.LongBits(object.startTime.low >>> 0, object.startTime.high >>> 0).toNumber();

                    if (object.players) {
                      if (!Array.isArray(object.players)) throw TypeError(".tigers.krun.KrunGameMatching.players: array expected");
                      message.players = [];

                      for (var i = 0; i < object.players.length; ++i) {
                        if (typeof object.players[i] !== "object") throw TypeError(".tigers.krun.KrunGameMatching.players: object expected");
                        message.players[i] = $root.tigers.krun.KrunPlayer.fromObject(object.players[i]);
                      }
                    }

                    if (object.phases) {
                      if (!Array.isArray(object.phases)) throw TypeError(".tigers.krun.KrunGameMatching.phases: array expected");
                      message.phases = [];

                      for (var i = 0; i < object.phases.length; ++i) {
                        if (typeof object.phases[i] !== "object") throw TypeError(".tigers.krun.KrunGameMatching.phases: object expected");
                        message.phases[i] = $root.tigers.krun.KrunGamePhase.fromObject(object.phases[i]);
                      }
                    }

                    if (object.playerNames) {
                      if (!Array.isArray(object.playerNames)) throw TypeError(".tigers.krun.KrunGameMatching.playerNames: array expected");
                      message.playerNames = [];

                      for (var i = 0; i < object.playerNames.length; ++i) message.playerNames[i] = String(object.playerNames[i]);
                    }

                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunGameMatching message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunGameMatching
                   * @static
                   * @param {tigers.krun.KrunGameMatching} message KrunGameMatching
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunGameMatching.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.arrays || options.defaults) {
                      object.players = [];
                      object.phases = [];
                      object.playerNames = [];
                    }

                    if (options.defaults) {
                      object.gameId = "";

                      if ($util.Long) {
                        var long = new $util.Long(0, 0, false);
                        object.serverTime = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                      } else object.serverTime = options.longs === String ? "0" : 0;

                      if ($util.Long) {
                        var long = new $util.Long(0, 0, false);
                        object.startTime = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                      } else object.startTime = options.longs === String ? "0" : 0;
                    }

                    if (message.gameId != null && message.hasOwnProperty("gameId")) object.gameId = message.gameId;
                    if (message.serverTime != null && message.hasOwnProperty("serverTime")) if (typeof message.serverTime === "number") object.serverTime = options.longs === String ? String(message.serverTime) : message.serverTime;else object.serverTime = options.longs === String ? $util.Long.prototype.toString.call(message.serverTime) : options.longs === Number ? new $util.LongBits(message.serverTime.low >>> 0, message.serverTime.high >>> 0).toNumber() : message.serverTime;
                    if (message.startTime != null && message.hasOwnProperty("startTime")) if (typeof message.startTime === "number") object.startTime = options.longs === String ? String(message.startTime) : message.startTime;else object.startTime = options.longs === String ? $util.Long.prototype.toString.call(message.startTime) : options.longs === Number ? new $util.LongBits(message.startTime.low >>> 0, message.startTime.high >>> 0).toNumber() : message.startTime;

                    if (message.players && message.players.length) {
                      object.players = [];

                      for (var j = 0; j < message.players.length; ++j) object.players[j] = $root.tigers.krun.KrunPlayer.toObject(message.players[j], options);
                    }

                    if (message.phases && message.phases.length) {
                      object.phases = [];

                      for (var j = 0; j < message.phases.length; ++j) object.phases[j] = $root.tigers.krun.KrunGamePhase.toObject(message.phases[j], options);
                    }

                    if (message.playerNames && message.playerNames.length) {
                      object.playerNames = [];

                      for (var j = 0; j < message.playerNames.length; ++j) object.playerNames[j] = message.playerNames[j];
                    }

                    return object;
                  };
                  /**
                   * Converts this KrunGameMatching to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunGameMatching
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunGameMatching.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunGameMatching;
                }();

                krun.KrunGameUpdate = function () {
                  /**
                   * Properties of a KrunGameUpdate.
                   * @memberof tigers.krun
                   * @interface IKrunGameUpdate
                   * @property {string|null} [gameId] KrunGameUpdate gameId
                   * @property {number|null} [gameTime] KrunGameUpdate gameTime
                   * @property {tigers.krun.KRUN_GAME_PHASE|null} [phase] KrunGameUpdate phase
                   * @property {Array.<tigers.krun.IKrunPlayer>|null} [players] KrunGameUpdate players
                   * @property {Array.<tigers.krun.IKrunBullet>|null} [bullets] KrunGameUpdate bullets
                   */

                  /**
                   * Constructs a new KrunGameUpdate.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunGameUpdate.
                   * @implements IKrunGameUpdate
                   * @constructor
                   * @param {tigers.krun.IKrunGameUpdate=} [properties] Properties to set
                   */
                  function KrunGameUpdate(properties) {
                    this.players = [];
                    this.bullets = [];
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunGameUpdate gameId.
                   * @member {string} gameId
                   * @memberof tigers.krun.KrunGameUpdate
                   * @instance
                   */


                  KrunGameUpdate.prototype.gameId = "";
                  /**
                   * KrunGameUpdate gameTime.
                   * @member {number} gameTime
                   * @memberof tigers.krun.KrunGameUpdate
                   * @instance
                   */

                  KrunGameUpdate.prototype.gameTime = 0;
                  /**
                   * KrunGameUpdate phase.
                   * @member {tigers.krun.KRUN_GAME_PHASE} phase
                   * @memberof tigers.krun.KrunGameUpdate
                   * @instance
                   */

                  KrunGameUpdate.prototype.phase = 0;
                  /**
                   * KrunGameUpdate players.
                   * @member {Array.<tigers.krun.IKrunPlayer>} players
                   * @memberof tigers.krun.KrunGameUpdate
                   * @instance
                   */

                  KrunGameUpdate.prototype.players = $util.emptyArray;
                  /**
                   * KrunGameUpdate bullets.
                   * @member {Array.<tigers.krun.IKrunBullet>} bullets
                   * @memberof tigers.krun.KrunGameUpdate
                   * @instance
                   */

                  KrunGameUpdate.prototype.bullets = $util.emptyArray;
                  /**
                   * Creates a new KrunGameUpdate instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {tigers.krun.IKrunGameUpdate=} [properties] Properties to set
                   * @returns {tigers.krun.KrunGameUpdate} KrunGameUpdate instance
                   */

                  KrunGameUpdate.create = function create(properties) {
                    return new KrunGameUpdate(properties);
                  };
                  /**
                   * Encodes the specified KrunGameUpdate message. Does not implicitly {@link tigers.krun.KrunGameUpdate.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {tigers.krun.IKrunGameUpdate} message KrunGameUpdate message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameUpdate.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.gameId != null && message.hasOwnProperty("gameId")) writer.uint32(
                    /* id 1, wireType 2 =*/
                    10).string(message.gameId);
                    if (message.gameTime != null && message.hasOwnProperty("gameTime")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.gameTime);
                    if (message.phase != null && message.hasOwnProperty("phase")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.phase);
                    if (message.players != null && message.players.length) for (var i = 0; i < message.players.length; ++i) $root.tigers.krun.KrunPlayer.encode(message.players[i], writer.uint32(
                    /* id 4, wireType 2 =*/
                    34).fork()).ldelim();
                    if (message.bullets != null && message.bullets.length) for (var i = 0; i < message.bullets.length; ++i) $root.tigers.krun.KrunBullet.encode(message.bullets[i], writer.uint32(
                    /* id 5, wireType 2 =*/
                    42).fork()).ldelim();
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunGameUpdate message, length delimited. Does not implicitly {@link tigers.krun.KrunGameUpdate.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {tigers.krun.IKrunGameUpdate} message KrunGameUpdate message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameUpdate.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunGameUpdate message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunGameUpdate} KrunGameUpdate
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameUpdate.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunGameUpdate();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.gameId = reader.string();
                          break;

                        case 2:
                          message.gameTime = reader.int32();
                          break;

                        case 3:
                          message.phase = reader.int32();
                          break;

                        case 4:
                          if (!(message.players && message.players.length)) message.players = [];
                          message.players.push($root.tigers.krun.KrunPlayer.decode(reader, reader.uint32()));
                          break;

                        case 5:
                          if (!(message.bullets && message.bullets.length)) message.bullets = [];
                          message.bullets.push($root.tigers.krun.KrunBullet.decode(reader, reader.uint32()));
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunGameUpdate message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunGameUpdate} KrunGameUpdate
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameUpdate.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunGameUpdate message.
                   * @function verify
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunGameUpdate.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.gameId != null && message.hasOwnProperty("gameId")) if (!$util.isString(message.gameId)) return "gameId: string expected";
                    if (message.gameTime != null && message.hasOwnProperty("gameTime")) if (!$util.isInteger(message.gameTime)) return "gameTime: integer expected";
                    if (message.phase != null && message.hasOwnProperty("phase")) switch (message.phase) {
                      default:
                        return "phase: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 4:
                      case 5:
                        break;
                    }

                    if (message.players != null && message.hasOwnProperty("players")) {
                      if (!Array.isArray(message.players)) return "players: array expected";

                      for (var i = 0; i < message.players.length; ++i) {
                        var error = $root.tigers.krun.KrunPlayer.verify(message.players[i]);
                        if (error) return "players." + error;
                      }
                    }

                    if (message.bullets != null && message.hasOwnProperty("bullets")) {
                      if (!Array.isArray(message.bullets)) return "bullets: array expected";

                      for (var i = 0; i < message.bullets.length; ++i) {
                        var error = $root.tigers.krun.KrunBullet.verify(message.bullets[i]);
                        if (error) return "bullets." + error;
                      }
                    }

                    return null;
                  };
                  /**
                   * Creates a KrunGameUpdate message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunGameUpdate} KrunGameUpdate
                   */


                  KrunGameUpdate.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunGameUpdate) return object;
                    var message = new $root.tigers.krun.KrunGameUpdate();
                    if (object.gameId != null) message.gameId = String(object.gameId);
                    if (object.gameTime != null) message.gameTime = object.gameTime | 0;

                    switch (object.phase) {
                      case "KRUN_GAME_PHASE_MATCHING":
                      case 0:
                        message.phase = 0;
                        break;

                      case "KRUN_GAME_PHASE_RED":
                      case 1:
                        message.phase = 1;
                        break;

                      case "KRUN_GAME_PHASE_RED_TO_GREEN":
                      case 2:
                        message.phase = 2;
                        break;

                      case "KRUN_GAME_PHASE_GREEN":
                      case 3:
                        message.phase = 3;
                        break;

                      case "KRUN_GAME_PHASE_GREEN_TO_RED":
                      case 4:
                        message.phase = 4;
                        break;

                      case "KRUN_GAME_PHASE_END":
                      case 5:
                        message.phase = 5;
                        break;
                    }

                    if (object.players) {
                      if (!Array.isArray(object.players)) throw TypeError(".tigers.krun.KrunGameUpdate.players: array expected");
                      message.players = [];

                      for (var i = 0; i < object.players.length; ++i) {
                        if (typeof object.players[i] !== "object") throw TypeError(".tigers.krun.KrunGameUpdate.players: object expected");
                        message.players[i] = $root.tigers.krun.KrunPlayer.fromObject(object.players[i]);
                      }
                    }

                    if (object.bullets) {
                      if (!Array.isArray(object.bullets)) throw TypeError(".tigers.krun.KrunGameUpdate.bullets: array expected");
                      message.bullets = [];

                      for (var i = 0; i < object.bullets.length; ++i) {
                        if (typeof object.bullets[i] !== "object") throw TypeError(".tigers.krun.KrunGameUpdate.bullets: object expected");
                        message.bullets[i] = $root.tigers.krun.KrunBullet.fromObject(object.bullets[i]);
                      }
                    }

                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunGameUpdate message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunGameUpdate
                   * @static
                   * @param {tigers.krun.KrunGameUpdate} message KrunGameUpdate
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunGameUpdate.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.arrays || options.defaults) {
                      object.players = [];
                      object.bullets = [];
                    }

                    if (options.defaults) {
                      object.gameId = "";
                      object.gameTime = 0;
                      object.phase = options.enums === String ? "KRUN_GAME_PHASE_MATCHING" : 0;
                    }

                    if (message.gameId != null && message.hasOwnProperty("gameId")) object.gameId = message.gameId;
                    if (message.gameTime != null && message.hasOwnProperty("gameTime")) object.gameTime = message.gameTime;
                    if (message.phase != null && message.hasOwnProperty("phase")) object.phase = options.enums === String ? $root.tigers.krun.KRUN_GAME_PHASE[message.phase] : message.phase;

                    if (message.players && message.players.length) {
                      object.players = [];

                      for (var j = 0; j < message.players.length; ++j) object.players[j] = $root.tigers.krun.KrunPlayer.toObject(message.players[j], options);
                    }

                    if (message.bullets && message.bullets.length) {
                      object.bullets = [];

                      for (var j = 0; j < message.bullets.length; ++j) object.bullets[j] = $root.tigers.krun.KrunBullet.toObject(message.bullets[j], options);
                    }

                    return object;
                  };
                  /**
                   * Converts this KrunGameUpdate to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunGameUpdate
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunGameUpdate.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunGameUpdate;
                }();

                krun.KrunGameEnd = function () {
                  /**
                   * Properties of a KrunGameEnd.
                   * @memberof tigers.krun
                   * @interface IKrunGameEnd
                   * @property {string|null} [gameId] KrunGameEnd gameId
                   * @property {Array.<string>|null} [players] KrunGameEnd players
                   * @property {Array.<number>|null} [ranking] KrunGameEnd ranking
                   * @property {Array.<number>|null} [rewards] KrunGameEnd rewards
                   */

                  /**
                   * Constructs a new KrunGameEnd.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunGameEnd.
                   * @implements IKrunGameEnd
                   * @constructor
                   * @param {tigers.krun.IKrunGameEnd=} [properties] Properties to set
                   */
                  function KrunGameEnd(properties) {
                    this.players = [];
                    this.ranking = [];
                    this.rewards = [];
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunGameEnd gameId.
                   * @member {string} gameId
                   * @memberof tigers.krun.KrunGameEnd
                   * @instance
                   */


                  KrunGameEnd.prototype.gameId = "";
                  /**
                   * KrunGameEnd players.
                   * @member {Array.<string>} players
                   * @memberof tigers.krun.KrunGameEnd
                   * @instance
                   */

                  KrunGameEnd.prototype.players = $util.emptyArray;
                  /**
                   * KrunGameEnd ranking.
                   * @member {Array.<number>} ranking
                   * @memberof tigers.krun.KrunGameEnd
                   * @instance
                   */

                  KrunGameEnd.prototype.ranking = $util.emptyArray;
                  /**
                   * KrunGameEnd rewards.
                   * @member {Array.<number>} rewards
                   * @memberof tigers.krun.KrunGameEnd
                   * @instance
                   */

                  KrunGameEnd.prototype.rewards = $util.emptyArray;
                  /**
                   * Creates a new KrunGameEnd instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {tigers.krun.IKrunGameEnd=} [properties] Properties to set
                   * @returns {tigers.krun.KrunGameEnd} KrunGameEnd instance
                   */

                  KrunGameEnd.create = function create(properties) {
                    return new KrunGameEnd(properties);
                  };
                  /**
                   * Encodes the specified KrunGameEnd message. Does not implicitly {@link tigers.krun.KrunGameEnd.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {tigers.krun.IKrunGameEnd} message KrunGameEnd message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameEnd.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.gameId != null && message.hasOwnProperty("gameId")) writer.uint32(
                    /* id 1, wireType 2 =*/
                    10).string(message.gameId);
                    if (message.players != null && message.players.length) for (var i = 0; i < message.players.length; ++i) writer.uint32(
                    /* id 2, wireType 2 =*/
                    18).string(message.players[i]);

                    if (message.ranking != null && message.ranking.length) {
                      writer.uint32(
                      /* id 3, wireType 2 =*/
                      26).fork();

                      for (var i = 0; i < message.ranking.length; ++i) writer.int32(message.ranking[i]);

                      writer.ldelim();
                    }

                    if (message.rewards != null && message.rewards.length) {
                      writer.uint32(
                      /* id 4, wireType 2 =*/
                      34).fork();

                      for (var i = 0; i < message.rewards.length; ++i) writer.int32(message.rewards[i]);

                      writer.ldelim();
                    }

                    return writer;
                  };
                  /**
                   * Encodes the specified KrunGameEnd message, length delimited. Does not implicitly {@link tigers.krun.KrunGameEnd.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {tigers.krun.IKrunGameEnd} message KrunGameEnd message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGameEnd.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunGameEnd message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunGameEnd} KrunGameEnd
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameEnd.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunGameEnd();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.gameId = reader.string();
                          break;

                        case 2:
                          if (!(message.players && message.players.length)) message.players = [];
                          message.players.push(reader.string());
                          break;

                        case 3:
                          if (!(message.ranking && message.ranking.length)) message.ranking = [];

                          if ((tag & 7) === 2) {
                            var end2 = reader.uint32() + reader.pos;

                            while (reader.pos < end2) message.ranking.push(reader.int32());
                          } else message.ranking.push(reader.int32());

                          break;

                        case 4:
                          if (!(message.rewards && message.rewards.length)) message.rewards = [];

                          if ((tag & 7) === 2) {
                            var end2 = reader.uint32() + reader.pos;

                            while (reader.pos < end2) message.rewards.push(reader.int32());
                          } else message.rewards.push(reader.int32());

                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunGameEnd message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunGameEnd} KrunGameEnd
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGameEnd.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunGameEnd message.
                   * @function verify
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunGameEnd.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.gameId != null && message.hasOwnProperty("gameId")) if (!$util.isString(message.gameId)) return "gameId: string expected";

                    if (message.players != null && message.hasOwnProperty("players")) {
                      if (!Array.isArray(message.players)) return "players: array expected";

                      for (var i = 0; i < message.players.length; ++i) if (!$util.isString(message.players[i])) return "players: string[] expected";
                    }

                    if (message.ranking != null && message.hasOwnProperty("ranking")) {
                      if (!Array.isArray(message.ranking)) return "ranking: array expected";

                      for (var i = 0; i < message.ranking.length; ++i) if (!$util.isInteger(message.ranking[i])) return "ranking: integer[] expected";
                    }

                    if (message.rewards != null && message.hasOwnProperty("rewards")) {
                      if (!Array.isArray(message.rewards)) return "rewards: array expected";

                      for (var i = 0; i < message.rewards.length; ++i) if (!$util.isInteger(message.rewards[i])) return "rewards: integer[] expected";
                    }

                    return null;
                  };
                  /**
                   * Creates a KrunGameEnd message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunGameEnd} KrunGameEnd
                   */


                  KrunGameEnd.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunGameEnd) return object;
                    var message = new $root.tigers.krun.KrunGameEnd();
                    if (object.gameId != null) message.gameId = String(object.gameId);

                    if (object.players) {
                      if (!Array.isArray(object.players)) throw TypeError(".tigers.krun.KrunGameEnd.players: array expected");
                      message.players = [];

                      for (var i = 0; i < object.players.length; ++i) message.players[i] = String(object.players[i]);
                    }

                    if (object.ranking) {
                      if (!Array.isArray(object.ranking)) throw TypeError(".tigers.krun.KrunGameEnd.ranking: array expected");
                      message.ranking = [];

                      for (var i = 0; i < object.ranking.length; ++i) message.ranking[i] = object.ranking[i] | 0;
                    }

                    if (object.rewards) {
                      if (!Array.isArray(object.rewards)) throw TypeError(".tigers.krun.KrunGameEnd.rewards: array expected");
                      message.rewards = [];

                      for (var i = 0; i < object.rewards.length; ++i) message.rewards[i] = object.rewards[i] | 0;
                    }

                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunGameEnd message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunGameEnd
                   * @static
                   * @param {tigers.krun.KrunGameEnd} message KrunGameEnd
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunGameEnd.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.arrays || options.defaults) {
                      object.players = [];
                      object.ranking = [];
                      object.rewards = [];
                    }

                    if (options.defaults) object.gameId = "";
                    if (message.gameId != null && message.hasOwnProperty("gameId")) object.gameId = message.gameId;

                    if (message.players && message.players.length) {
                      object.players = [];

                      for (var j = 0; j < message.players.length; ++j) object.players[j] = message.players[j];
                    }

                    if (message.ranking && message.ranking.length) {
                      object.ranking = [];

                      for (var j = 0; j < message.ranking.length; ++j) object.ranking[j] = message.ranking[j];
                    }

                    if (message.rewards && message.rewards.length) {
                      object.rewards = [];

                      for (var j = 0; j < message.rewards.length; ++j) object.rewards[j] = message.rewards[j];
                    }

                    return object;
                  };
                  /**
                   * Converts this KrunGameEnd to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunGameEnd
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunGameEnd.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunGameEnd;
                }();

                krun.KrunPlayer = function () {
                  /**
                   * Properties of a KrunPlayer.
                   * @memberof tigers.krun
                   * @interface IKrunPlayer
                   * @property {string|null} [uid] KrunPlayer uid
                   * @property {tigers.krun.KRUN_PLAYER_STATUS|null} [status] KrunPlayer status
                   * @property {number|null} [x] KrunPlayer x
                   * @property {number|null} [y] KrunPlayer y
                   * @property {Array.<tigers.krun.IKrunEffect>|null} [effects] KrunPlayer effects
                   * @property {Array.<tigers.krun.IKrunNextShoot>|null} [bullets] KrunPlayer bullets
                   * @property {number|Long|null} [finishAt] KrunPlayer finishAt
                   */

                  /**
                   * Constructs a new KrunPlayer.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunPlayer.
                   * @implements IKrunPlayer
                   * @constructor
                   * @param {tigers.krun.IKrunPlayer=} [properties] Properties to set
                   */
                  function KrunPlayer(properties) {
                    this.effects = [];
                    this.bullets = [];
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunPlayer uid.
                   * @member {string} uid
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */


                  KrunPlayer.prototype.uid = "";
                  /**
                   * KrunPlayer status.
                   * @member {tigers.krun.KRUN_PLAYER_STATUS} status
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */

                  KrunPlayer.prototype.status = 0;
                  /**
                   * KrunPlayer x.
                   * @member {number} x
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */

                  KrunPlayer.prototype.x = 0;
                  /**
                   * KrunPlayer y.
                   * @member {number} y
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */

                  KrunPlayer.prototype.y = 0;
                  /**
                   * KrunPlayer effects.
                   * @member {Array.<tigers.krun.IKrunEffect>} effects
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */

                  KrunPlayer.prototype.effects = $util.emptyArray;
                  /**
                   * KrunPlayer bullets.
                   * @member {Array.<tigers.krun.IKrunNextShoot>} bullets
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */

                  KrunPlayer.prototype.bullets = $util.emptyArray;
                  /**
                   * KrunPlayer finishAt.
                   * @member {number|Long} finishAt
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   */

                  KrunPlayer.prototype.finishAt = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * Creates a new KrunPlayer instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {tigers.krun.IKrunPlayer=} [properties] Properties to set
                   * @returns {tigers.krun.KrunPlayer} KrunPlayer instance
                   */

                  KrunPlayer.create = function create(properties) {
                    return new KrunPlayer(properties);
                  };
                  /**
                   * Encodes the specified KrunPlayer message. Does not implicitly {@link tigers.krun.KrunPlayer.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {tigers.krun.IKrunPlayer} message KrunPlayer message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunPlayer.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.uid != null && message.hasOwnProperty("uid")) writer.uint32(
                    /* id 1, wireType 2 =*/
                    10).string(message.uid);
                    if (message.status != null && message.hasOwnProperty("status")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.status);
                    if (message.x != null && message.hasOwnProperty("x")) writer.uint32(
                    /* id 3, wireType 5 =*/
                    29).float(message.x);
                    if (message.y != null && message.hasOwnProperty("y")) writer.uint32(
                    /* id 4, wireType 5 =*/
                    37).float(message.y);
                    if (message.effects != null && message.effects.length) for (var i = 0; i < message.effects.length; ++i) $root.tigers.krun.KrunEffect.encode(message.effects[i], writer.uint32(
                    /* id 5, wireType 2 =*/
                    42).fork()).ldelim();
                    if (message.bullets != null && message.bullets.length) for (var i = 0; i < message.bullets.length; ++i) $root.tigers.krun.KrunNextShoot.encode(message.bullets[i], writer.uint32(
                    /* id 6, wireType 2 =*/
                    50).fork()).ldelim();
                    if (message.finishAt != null && message.hasOwnProperty("finishAt")) writer.uint32(
                    /* id 7, wireType 0 =*/
                    56).int64(message.finishAt);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunPlayer message, length delimited. Does not implicitly {@link tigers.krun.KrunPlayer.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {tigers.krun.IKrunPlayer} message KrunPlayer message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunPlayer.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunPlayer message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunPlayer} KrunPlayer
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunPlayer.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunPlayer();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.uid = reader.string();
                          break;

                        case 2:
                          message.status = reader.int32();
                          break;

                        case 3:
                          message.x = reader.float();
                          break;

                        case 4:
                          message.y = reader.float();
                          break;

                        case 5:
                          if (!(message.effects && message.effects.length)) message.effects = [];
                          message.effects.push($root.tigers.krun.KrunEffect.decode(reader, reader.uint32()));
                          break;

                        case 6:
                          if (!(message.bullets && message.bullets.length)) message.bullets = [];
                          message.bullets.push($root.tigers.krun.KrunNextShoot.decode(reader, reader.uint32()));
                          break;

                        case 7:
                          message.finishAt = reader.int64();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunPlayer message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunPlayer} KrunPlayer
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunPlayer.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunPlayer message.
                   * @function verify
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunPlayer.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.uid != null && message.hasOwnProperty("uid")) if (!$util.isString(message.uid)) return "uid: string expected";
                    if (message.status != null && message.hasOwnProperty("status")) switch (message.status) {
                      default:
                        return "status: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 4:
                        break;
                    }
                    if (message.x != null && message.hasOwnProperty("x")) if (typeof message.x !== "number") return "x: number expected";
                    if (message.y != null && message.hasOwnProperty("y")) if (typeof message.y !== "number") return "y: number expected";

                    if (message.effects != null && message.hasOwnProperty("effects")) {
                      if (!Array.isArray(message.effects)) return "effects: array expected";

                      for (var i = 0; i < message.effects.length; ++i) {
                        var error = $root.tigers.krun.KrunEffect.verify(message.effects[i]);
                        if (error) return "effects." + error;
                      }
                    }

                    if (message.bullets != null && message.hasOwnProperty("bullets")) {
                      if (!Array.isArray(message.bullets)) return "bullets: array expected";

                      for (var i = 0; i < message.bullets.length; ++i) {
                        var error = $root.tigers.krun.KrunNextShoot.verify(message.bullets[i]);
                        if (error) return "bullets." + error;
                      }
                    }

                    if (message.finishAt != null && message.hasOwnProperty("finishAt")) if (!$util.isInteger(message.finishAt) && !(message.finishAt && $util.isInteger(message.finishAt.low) && $util.isInteger(message.finishAt.high))) return "finishAt: integer|Long expected";
                    return null;
                  };
                  /**
                   * Creates a KrunPlayer message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunPlayer} KrunPlayer
                   */


                  KrunPlayer.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunPlayer) return object;
                    var message = new $root.tigers.krun.KrunPlayer();
                    if (object.uid != null) message.uid = String(object.uid);

                    switch (object.status) {
                      case "KRUN_PLAYER_STATUS_MATCHING":
                      case 0:
                        message.status = 0;
                        break;

                      case "KRUN_PLAYER_STATUS_ALIVE":
                      case 1:
                        message.status = 1;
                        break;

                      case "KRUN_PLAYER_STATUS_DEAD":
                      case 2:
                        message.status = 2;
                        break;

                      case "KRUN_PLAYER_STATUS_FINISH":
                      case 3:
                        message.status = 3;
                        break;

                      case "KRUN_PLAYER_STATUS_DNF":
                      case 4:
                        message.status = 4;
                        break;
                    }

                    if (object.x != null) message.x = Number(object.x);
                    if (object.y != null) message.y = Number(object.y);

                    if (object.effects) {
                      if (!Array.isArray(object.effects)) throw TypeError(".tigers.krun.KrunPlayer.effects: array expected");
                      message.effects = [];

                      for (var i = 0; i < object.effects.length; ++i) {
                        if (typeof object.effects[i] !== "object") throw TypeError(".tigers.krun.KrunPlayer.effects: object expected");
                        message.effects[i] = $root.tigers.krun.KrunEffect.fromObject(object.effects[i]);
                      }
                    }

                    if (object.bullets) {
                      if (!Array.isArray(object.bullets)) throw TypeError(".tigers.krun.KrunPlayer.bullets: array expected");
                      message.bullets = [];

                      for (var i = 0; i < object.bullets.length; ++i) {
                        if (typeof object.bullets[i] !== "object") throw TypeError(".tigers.krun.KrunPlayer.bullets: object expected");
                        message.bullets[i] = $root.tigers.krun.KrunNextShoot.fromObject(object.bullets[i]);
                      }
                    }

                    if (object.finishAt != null) if ($util.Long) (message.finishAt = $util.Long.fromValue(object.finishAt)).unsigned = false;else if (typeof object.finishAt === "string") message.finishAt = parseInt(object.finishAt, 10);else if (typeof object.finishAt === "number") message.finishAt = object.finishAt;else if (typeof object.finishAt === "object") message.finishAt = new $util.LongBits(object.finishAt.low >>> 0, object.finishAt.high >>> 0).toNumber();
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunPlayer message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunPlayer
                   * @static
                   * @param {tigers.krun.KrunPlayer} message KrunPlayer
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunPlayer.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.arrays || options.defaults) {
                      object.effects = [];
                      object.bullets = [];
                    }

                    if (options.defaults) {
                      object.uid = "";
                      object.status = options.enums === String ? "KRUN_PLAYER_STATUS_MATCHING" : 0;
                      object.x = 0;
                      object.y = 0;

                      if ($util.Long) {
                        var long = new $util.Long(0, 0, false);
                        object.finishAt = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                      } else object.finishAt = options.longs === String ? "0" : 0;
                    }

                    if (message.uid != null && message.hasOwnProperty("uid")) object.uid = message.uid;
                    if (message.status != null && message.hasOwnProperty("status")) object.status = options.enums === String ? $root.tigers.krun.KRUN_PLAYER_STATUS[message.status] : message.status;
                    if (message.x != null && message.hasOwnProperty("x")) object.x = options.json && !isFinite(message.x) ? String(message.x) : message.x;
                    if (message.y != null && message.hasOwnProperty("y")) object.y = options.json && !isFinite(message.y) ? String(message.y) : message.y;

                    if (message.effects && message.effects.length) {
                      object.effects = [];

                      for (var j = 0; j < message.effects.length; ++j) object.effects[j] = $root.tigers.krun.KrunEffect.toObject(message.effects[j], options);
                    }

                    if (message.bullets && message.bullets.length) {
                      object.bullets = [];

                      for (var j = 0; j < message.bullets.length; ++j) object.bullets[j] = $root.tigers.krun.KrunNextShoot.toObject(message.bullets[j], options);
                    }

                    if (message.finishAt != null && message.hasOwnProperty("finishAt")) if (typeof message.finishAt === "number") object.finishAt = options.longs === String ? String(message.finishAt) : message.finishAt;else object.finishAt = options.longs === String ? $util.Long.prototype.toString.call(message.finishAt) : options.longs === Number ? new $util.LongBits(message.finishAt.low >>> 0, message.finishAt.high >>> 0).toNumber() : message.finishAt;
                    return object;
                  };
                  /**
                   * Converts this KrunPlayer to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunPlayer
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunPlayer.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunPlayer;
                }();

                krun.KrunBullet = function () {
                  /**
                   * Properties of a KrunBullet.
                   * @memberof tigers.krun
                   * @interface IKrunBullet
                   * @property {number|null} [uid] KrunBullet uid
                   * @property {string|null} [shooter] KrunBullet shooter
                   * @property {string|null} [target] KrunBullet target
                   * @property {tigers.krun.KRUN_BULLET_EFFECTS|null} [effect] KrunBullet effect
                   * @property {number|null} [shootAt] KrunBullet shootAt
                   * @property {number|null} [hitAt] KrunBullet hitAt
                   */

                  /**
                   * Constructs a new KrunBullet.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunBullet.
                   * @implements IKrunBullet
                   * @constructor
                   * @param {tigers.krun.IKrunBullet=} [properties] Properties to set
                   */
                  function KrunBullet(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunBullet uid.
                   * @member {number} uid
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   */


                  KrunBullet.prototype.uid = 0;
                  /**
                   * KrunBullet shooter.
                   * @member {string} shooter
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   */

                  KrunBullet.prototype.shooter = "";
                  /**
                   * KrunBullet target.
                   * @member {string} target
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   */

                  KrunBullet.prototype.target = "";
                  /**
                   * KrunBullet effect.
                   * @member {tigers.krun.KRUN_BULLET_EFFECTS} effect
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   */

                  KrunBullet.prototype.effect = 0;
                  /**
                   * KrunBullet shootAt.
                   * @member {number} shootAt
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   */

                  KrunBullet.prototype.shootAt = 0;
                  /**
                   * KrunBullet hitAt.
                   * @member {number} hitAt
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   */

                  KrunBullet.prototype.hitAt = 0;
                  /**
                   * Creates a new KrunBullet instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {tigers.krun.IKrunBullet=} [properties] Properties to set
                   * @returns {tigers.krun.KrunBullet} KrunBullet instance
                   */

                  KrunBullet.create = function create(properties) {
                    return new KrunBullet(properties);
                  };
                  /**
                   * Encodes the specified KrunBullet message. Does not implicitly {@link tigers.krun.KrunBullet.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {tigers.krun.IKrunBullet} message KrunBullet message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunBullet.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.uid != null && message.hasOwnProperty("uid")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.uid);
                    if (message.shooter != null && message.hasOwnProperty("shooter")) writer.uint32(
                    /* id 2, wireType 2 =*/
                    18).string(message.shooter);
                    if (message.target != null && message.hasOwnProperty("target")) writer.uint32(
                    /* id 3, wireType 2 =*/
                    26).string(message.target);
                    if (message.effect != null && message.hasOwnProperty("effect")) writer.uint32(
                    /* id 4, wireType 0 =*/
                    32).int32(message.effect);
                    if (message.shootAt != null && message.hasOwnProperty("shootAt")) writer.uint32(
                    /* id 5, wireType 0 =*/
                    40).int32(message.shootAt);
                    if (message.hitAt != null && message.hasOwnProperty("hitAt")) writer.uint32(
                    /* id 6, wireType 0 =*/
                    48).int32(message.hitAt);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunBullet message, length delimited. Does not implicitly {@link tigers.krun.KrunBullet.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {tigers.krun.IKrunBullet} message KrunBullet message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunBullet.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunBullet message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunBullet} KrunBullet
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunBullet.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunBullet();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.uid = reader.int32();
                          break;

                        case 2:
                          message.shooter = reader.string();
                          break;

                        case 3:
                          message.target = reader.string();
                          break;

                        case 4:
                          message.effect = reader.int32();
                          break;

                        case 5:
                          message.shootAt = reader.int32();
                          break;

                        case 6:
                          message.hitAt = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunBullet message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunBullet} KrunBullet
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunBullet.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunBullet message.
                   * @function verify
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunBullet.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.uid != null && message.hasOwnProperty("uid")) if (!$util.isInteger(message.uid)) return "uid: integer expected";
                    if (message.shooter != null && message.hasOwnProperty("shooter")) if (!$util.isString(message.shooter)) return "shooter: string expected";
                    if (message.target != null && message.hasOwnProperty("target")) if (!$util.isString(message.target)) return "target: string expected";
                    if (message.effect != null && message.hasOwnProperty("effect")) switch (message.effect) {
                      default:
                        return "effect: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                        break;
                    }
                    if (message.shootAt != null && message.hasOwnProperty("shootAt")) if (!$util.isInteger(message.shootAt)) return "shootAt: integer expected";
                    if (message.hitAt != null && message.hasOwnProperty("hitAt")) if (!$util.isInteger(message.hitAt)) return "hitAt: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunBullet message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunBullet} KrunBullet
                   */


                  KrunBullet.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunBullet) return object;
                    var message = new $root.tigers.krun.KrunBullet();
                    if (object.uid != null) message.uid = object.uid | 0;
                    if (object.shooter != null) message.shooter = String(object.shooter);
                    if (object.target != null) message.target = String(object.target);

                    switch (object.effect) {
                      case "KRUN_BULLET_EFFECT_NONE":
                      case 0:
                        message.effect = 0;
                        break;

                      case "KRUN_BULLET_EFFECT_FREEZE":
                      case 1:
                        message.effect = 1;
                        break;

                      case "KRUN_BULLET_EFFECT_PENALTY":
                      case 2:
                        message.effect = 2;
                        break;
                    }

                    if (object.shootAt != null) message.shootAt = object.shootAt | 0;
                    if (object.hitAt != null) message.hitAt = object.hitAt | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunBullet message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunBullet
                   * @static
                   * @param {tigers.krun.KrunBullet} message KrunBullet
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunBullet.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.uid = 0;
                      object.shooter = "";
                      object.target = "";
                      object.effect = options.enums === String ? "KRUN_BULLET_EFFECT_NONE" : 0;
                      object.shootAt = 0;
                      object.hitAt = 0;
                    }

                    if (message.uid != null && message.hasOwnProperty("uid")) object.uid = message.uid;
                    if (message.shooter != null && message.hasOwnProperty("shooter")) object.shooter = message.shooter;
                    if (message.target != null && message.hasOwnProperty("target")) object.target = message.target;
                    if (message.effect != null && message.hasOwnProperty("effect")) object.effect = options.enums === String ? $root.tigers.krun.KRUN_BULLET_EFFECTS[message.effect] : message.effect;
                    if (message.shootAt != null && message.hasOwnProperty("shootAt")) object.shootAt = message.shootAt;
                    if (message.hitAt != null && message.hasOwnProperty("hitAt")) object.hitAt = message.hitAt;
                    return object;
                  };
                  /**
                   * Converts this KrunBullet to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunBullet
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunBullet.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunBullet;
                }();

                krun.KrunNextShoot = function () {
                  /**
                   * Properties of a KrunNextShoot.
                   * @memberof tigers.krun
                   * @interface IKrunNextShoot
                   * @property {tigers.krun.KRUN_BULLET_EFFECTS|null} [effect] KrunNextShoot effect
                   * @property {number|null} [remain] KrunNextShoot remain
                   * @property {number|null} [nextShoot] KrunNextShoot nextShoot
                   */

                  /**
                   * Constructs a new KrunNextShoot.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunNextShoot.
                   * @implements IKrunNextShoot
                   * @constructor
                   * @param {tigers.krun.IKrunNextShoot=} [properties] Properties to set
                   */
                  function KrunNextShoot(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunNextShoot effect.
                   * @member {tigers.krun.KRUN_BULLET_EFFECTS} effect
                   * @memberof tigers.krun.KrunNextShoot
                   * @instance
                   */


                  KrunNextShoot.prototype.effect = 0;
                  /**
                   * KrunNextShoot remain.
                   * @member {number} remain
                   * @memberof tigers.krun.KrunNextShoot
                   * @instance
                   */

                  KrunNextShoot.prototype.remain = 0;
                  /**
                   * KrunNextShoot nextShoot.
                   * @member {number} nextShoot
                   * @memberof tigers.krun.KrunNextShoot
                   * @instance
                   */

                  KrunNextShoot.prototype.nextShoot = 0;
                  /**
                   * Creates a new KrunNextShoot instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {tigers.krun.IKrunNextShoot=} [properties] Properties to set
                   * @returns {tigers.krun.KrunNextShoot} KrunNextShoot instance
                   */

                  KrunNextShoot.create = function create(properties) {
                    return new KrunNextShoot(properties);
                  };
                  /**
                   * Encodes the specified KrunNextShoot message. Does not implicitly {@link tigers.krun.KrunNextShoot.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {tigers.krun.IKrunNextShoot} message KrunNextShoot message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunNextShoot.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.effect != null && message.hasOwnProperty("effect")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.effect);
                    if (message.remain != null && message.hasOwnProperty("remain")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.remain);
                    if (message.nextShoot != null && message.hasOwnProperty("nextShoot")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.nextShoot);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunNextShoot message, length delimited. Does not implicitly {@link tigers.krun.KrunNextShoot.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {tigers.krun.IKrunNextShoot} message KrunNextShoot message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunNextShoot.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunNextShoot message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunNextShoot} KrunNextShoot
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunNextShoot.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunNextShoot();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.effect = reader.int32();
                          break;

                        case 2:
                          message.remain = reader.int32();
                          break;

                        case 3:
                          message.nextShoot = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunNextShoot message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunNextShoot} KrunNextShoot
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunNextShoot.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunNextShoot message.
                   * @function verify
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunNextShoot.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.effect != null && message.hasOwnProperty("effect")) switch (message.effect) {
                      default:
                        return "effect: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                        break;
                    }
                    if (message.remain != null && message.hasOwnProperty("remain")) if (!$util.isInteger(message.remain)) return "remain: integer expected";
                    if (message.nextShoot != null && message.hasOwnProperty("nextShoot")) if (!$util.isInteger(message.nextShoot)) return "nextShoot: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunNextShoot message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunNextShoot} KrunNextShoot
                   */


                  KrunNextShoot.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunNextShoot) return object;
                    var message = new $root.tigers.krun.KrunNextShoot();

                    switch (object.effect) {
                      case "KRUN_BULLET_EFFECT_NONE":
                      case 0:
                        message.effect = 0;
                        break;

                      case "KRUN_BULLET_EFFECT_FREEZE":
                      case 1:
                        message.effect = 1;
                        break;

                      case "KRUN_BULLET_EFFECT_PENALTY":
                      case 2:
                        message.effect = 2;
                        break;
                    }

                    if (object.remain != null) message.remain = object.remain | 0;
                    if (object.nextShoot != null) message.nextShoot = object.nextShoot | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunNextShoot message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunNextShoot
                   * @static
                   * @param {tigers.krun.KrunNextShoot} message KrunNextShoot
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunNextShoot.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.effect = options.enums === String ? "KRUN_BULLET_EFFECT_NONE" : 0;
                      object.remain = 0;
                      object.nextShoot = 0;
                    }

                    if (message.effect != null && message.hasOwnProperty("effect")) object.effect = options.enums === String ? $root.tigers.krun.KRUN_BULLET_EFFECTS[message.effect] : message.effect;
                    if (message.remain != null && message.hasOwnProperty("remain")) object.remain = message.remain;
                    if (message.nextShoot != null && message.hasOwnProperty("nextShoot")) object.nextShoot = message.nextShoot;
                    return object;
                  };
                  /**
                   * Converts this KrunNextShoot to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunNextShoot
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunNextShoot.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunNextShoot;
                }();

                krun.KrunEffect = function () {
                  /**
                   * Properties of a KrunEffect.
                   * @memberof tigers.krun
                   * @interface IKrunEffect
                   * @property {tigers.krun.KRUN_BULLET_EFFECTS|null} [effect] KrunEffect effect
                   * @property {number|null} [end] KrunEffect end
                   */

                  /**
                   * Constructs a new KrunEffect.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunEffect.
                   * @implements IKrunEffect
                   * @constructor
                   * @param {tigers.krun.IKrunEffect=} [properties] Properties to set
                   */
                  function KrunEffect(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunEffect effect.
                   * @member {tigers.krun.KRUN_BULLET_EFFECTS} effect
                   * @memberof tigers.krun.KrunEffect
                   * @instance
                   */


                  KrunEffect.prototype.effect = 0;
                  /**
                   * KrunEffect end.
                   * @member {number} end
                   * @memberof tigers.krun.KrunEffect
                   * @instance
                   */

                  KrunEffect.prototype.end = 0;
                  /**
                   * Creates a new KrunEffect instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {tigers.krun.IKrunEffect=} [properties] Properties to set
                   * @returns {tigers.krun.KrunEffect} KrunEffect instance
                   */

                  KrunEffect.create = function create(properties) {
                    return new KrunEffect(properties);
                  };
                  /**
                   * Encodes the specified KrunEffect message. Does not implicitly {@link tigers.krun.KrunEffect.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {tigers.krun.IKrunEffect} message KrunEffect message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunEffect.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.effect != null && message.hasOwnProperty("effect")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.effect);
                    if (message.end != null && message.hasOwnProperty("end")) writer.uint32(
                    /* id 3, wireType 0 =*/
                    24).int32(message.end);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunEffect message, length delimited. Does not implicitly {@link tigers.krun.KrunEffect.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {tigers.krun.IKrunEffect} message KrunEffect message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunEffect.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunEffect message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunEffect} KrunEffect
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunEffect.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunEffect();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.effect = reader.int32();
                          break;

                        case 3:
                          message.end = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunEffect message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunEffect} KrunEffect
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunEffect.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunEffect message.
                   * @function verify
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunEffect.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.effect != null && message.hasOwnProperty("effect")) switch (message.effect) {
                      default:
                        return "effect: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                        break;
                    }
                    if (message.end != null && message.hasOwnProperty("end")) if (!$util.isInteger(message.end)) return "end: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunEffect message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunEffect} KrunEffect
                   */


                  KrunEffect.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunEffect) return object;
                    var message = new $root.tigers.krun.KrunEffect();

                    switch (object.effect) {
                      case "KRUN_BULLET_EFFECT_NONE":
                      case 0:
                        message.effect = 0;
                        break;

                      case "KRUN_BULLET_EFFECT_FREEZE":
                      case 1:
                        message.effect = 1;
                        break;

                      case "KRUN_BULLET_EFFECT_PENALTY":
                      case 2:
                        message.effect = 2;
                        break;
                    }

                    if (object.end != null) message.end = object.end | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunEffect message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunEffect
                   * @static
                   * @param {tigers.krun.KrunEffect} message KrunEffect
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunEffect.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.effect = options.enums === String ? "KRUN_BULLET_EFFECT_NONE" : 0;
                      object.end = 0;
                    }

                    if (message.effect != null && message.hasOwnProperty("effect")) object.effect = options.enums === String ? $root.tigers.krun.KRUN_BULLET_EFFECTS[message.effect] : message.effect;
                    if (message.end != null && message.hasOwnProperty("end")) object.end = message.end;
                    return object;
                  };
                  /**
                   * Converts this KrunEffect to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunEffect
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunEffect.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunEffect;
                }();

                krun.KrunGamePhase = function () {
                  /**
                   * Properties of a KrunGamePhase.
                   * @memberof tigers.krun
                   * @interface IKrunGamePhase
                   * @property {tigers.krun.KRUN_GAME_PHASE|null} [phase] KrunGamePhase phase
                   * @property {number|null} [duration] KrunGamePhase duration
                   */

                  /**
                   * Constructs a new KrunGamePhase.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunGamePhase.
                   * @implements IKrunGamePhase
                   * @constructor
                   * @param {tigers.krun.IKrunGamePhase=} [properties] Properties to set
                   */
                  function KrunGamePhase(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunGamePhase phase.
                   * @member {tigers.krun.KRUN_GAME_PHASE} phase
                   * @memberof tigers.krun.KrunGamePhase
                   * @instance
                   */


                  KrunGamePhase.prototype.phase = 0;
                  /**
                   * KrunGamePhase duration.
                   * @member {number} duration
                   * @memberof tigers.krun.KrunGamePhase
                   * @instance
                   */

                  KrunGamePhase.prototype.duration = 0;
                  /**
                   * Creates a new KrunGamePhase instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {tigers.krun.IKrunGamePhase=} [properties] Properties to set
                   * @returns {tigers.krun.KrunGamePhase} KrunGamePhase instance
                   */

                  KrunGamePhase.create = function create(properties) {
                    return new KrunGamePhase(properties);
                  };
                  /**
                   * Encodes the specified KrunGamePhase message. Does not implicitly {@link tigers.krun.KrunGamePhase.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {tigers.krun.IKrunGamePhase} message KrunGamePhase message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGamePhase.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.phase != null && message.hasOwnProperty("phase")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int32(message.phase);
                    if (message.duration != null && message.hasOwnProperty("duration")) writer.uint32(
                    /* id 2, wireType 0 =*/
                    16).int32(message.duration);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunGamePhase message, length delimited. Does not implicitly {@link tigers.krun.KrunGamePhase.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {tigers.krun.IKrunGamePhase} message KrunGamePhase message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunGamePhase.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunGamePhase message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunGamePhase} KrunGamePhase
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGamePhase.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunGamePhase();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.phase = reader.int32();
                          break;

                        case 2:
                          message.duration = reader.int32();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunGamePhase message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunGamePhase} KrunGamePhase
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunGamePhase.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunGamePhase message.
                   * @function verify
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunGamePhase.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.phase != null && message.hasOwnProperty("phase")) switch (message.phase) {
                      default:
                        return "phase: enum value expected";

                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 4:
                      case 5:
                        break;
                    }
                    if (message.duration != null && message.hasOwnProperty("duration")) if (!$util.isInteger(message.duration)) return "duration: integer expected";
                    return null;
                  };
                  /**
                   * Creates a KrunGamePhase message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunGamePhase} KrunGamePhase
                   */


                  KrunGamePhase.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunGamePhase) return object;
                    var message = new $root.tigers.krun.KrunGamePhase();

                    switch (object.phase) {
                      case "KRUN_GAME_PHASE_MATCHING":
                      case 0:
                        message.phase = 0;
                        break;

                      case "KRUN_GAME_PHASE_RED":
                      case 1:
                        message.phase = 1;
                        break;

                      case "KRUN_GAME_PHASE_RED_TO_GREEN":
                      case 2:
                        message.phase = 2;
                        break;

                      case "KRUN_GAME_PHASE_GREEN":
                      case 3:
                        message.phase = 3;
                        break;

                      case "KRUN_GAME_PHASE_GREEN_TO_RED":
                      case 4:
                        message.phase = 4;
                        break;

                      case "KRUN_GAME_PHASE_END":
                      case 5:
                        message.phase = 5;
                        break;
                    }

                    if (object.duration != null) message.duration = object.duration | 0;
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunGamePhase message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunGamePhase
                   * @static
                   * @param {tigers.krun.KrunGamePhase} message KrunGamePhase
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunGamePhase.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};

                    if (options.defaults) {
                      object.phase = options.enums === String ? "KRUN_GAME_PHASE_MATCHING" : 0;
                      object.duration = 0;
                    }

                    if (message.phase != null && message.hasOwnProperty("phase")) object.phase = options.enums === String ? $root.tigers.krun.KRUN_GAME_PHASE[message.phase] : message.phase;
                    if (message.duration != null && message.hasOwnProperty("duration")) object.duration = message.duration;
                    return object;
                  };
                  /**
                   * Converts this KrunGamePhase to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunGamePhase
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunGamePhase.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunGamePhase;
                }();

                krun.KrunResTurn = function () {
                  /**
                   * Properties of a KrunResTurn.
                   * @memberof tigers.krun
                   * @interface IKrunResTurn
                   * @property {number|Long|null} [value] KrunResTurn value
                   */

                  /**
                   * Constructs a new KrunResTurn.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunResTurn.
                   * @implements IKrunResTurn
                   * @constructor
                   * @param {tigers.krun.IKrunResTurn=} [properties] Properties to set
                   */
                  function KrunResTurn(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunResTurn value.
                   * @member {number|Long} value
                   * @memberof tigers.krun.KrunResTurn
                   * @instance
                   */


                  KrunResTurn.prototype.value = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * Creates a new KrunResTurn instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {tigers.krun.IKrunResTurn=} [properties] Properties to set
                   * @returns {tigers.krun.KrunResTurn} KrunResTurn instance
                   */

                  KrunResTurn.create = function create(properties) {
                    return new KrunResTurn(properties);
                  };
                  /**
                   * Encodes the specified KrunResTurn message. Does not implicitly {@link tigers.krun.KrunResTurn.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {tigers.krun.IKrunResTurn} message KrunResTurn message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResTurn.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.value != null && message.hasOwnProperty("value")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int64(message.value);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunResTurn message, length delimited. Does not implicitly {@link tigers.krun.KrunResTurn.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {tigers.krun.IKrunResTurn} message KrunResTurn message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResTurn.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunResTurn message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunResTurn} KrunResTurn
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResTurn.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunResTurn();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.value = reader.int64();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunResTurn message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunResTurn} KrunResTurn
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResTurn.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunResTurn message.
                   * @function verify
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunResTurn.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.value != null && message.hasOwnProperty("value")) if (!$util.isInteger(message.value) && !(message.value && $util.isInteger(message.value.low) && $util.isInteger(message.value.high))) return "value: integer|Long expected";
                    return null;
                  };
                  /**
                   * Creates a KrunResTurn message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunResTurn} KrunResTurn
                   */


                  KrunResTurn.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunResTurn) return object;
                    var message = new $root.tigers.krun.KrunResTurn();
                    if (object.value != null) if ($util.Long) (message.value = $util.Long.fromValue(object.value)).unsigned = false;else if (typeof object.value === "string") message.value = parseInt(object.value, 10);else if (typeof object.value === "number") message.value = object.value;else if (typeof object.value === "object") message.value = new $util.LongBits(object.value.low >>> 0, object.value.high >>> 0).toNumber();
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunResTurn message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunResTurn
                   * @static
                   * @param {tigers.krun.KrunResTurn} message KrunResTurn
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunResTurn.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};
                    if (options.defaults) if ($util.Long) {
                      var long = new $util.Long(0, 0, false);
                      object.value = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else object.value = options.longs === String ? "0" : 0;
                    if (message.value != null && message.hasOwnProperty("value")) if (typeof message.value === "number") object.value = options.longs === String ? String(message.value) : message.value;else object.value = options.longs === String ? $util.Long.prototype.toString.call(message.value) : options.longs === Number ? new $util.LongBits(message.value.low >>> 0, message.value.high >>> 0).toNumber() : message.value;
                    return object;
                  };
                  /**
                   * Converts this KrunResTurn to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunResTurn
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunResTurn.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunResTurn;
                }();

                krun.KrunResCandy = function () {
                  /**
                   * Properties of a KrunResCandy.
                   * @memberof tigers.krun
                   * @interface IKrunResCandy
                   * @property {number|Long|null} [value] KrunResCandy value
                   */

                  /**
                   * Constructs a new KrunResCandy.
                   * @memberof tigers.krun
                   * @classdesc Represents a KrunResCandy.
                   * @implements IKrunResCandy
                   * @constructor
                   * @param {tigers.krun.IKrunResCandy=} [properties] Properties to set
                   */
                  function KrunResCandy(properties) {
                    if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
                  }
                  /**
                   * KrunResCandy value.
                   * @member {number|Long} value
                   * @memberof tigers.krun.KrunResCandy
                   * @instance
                   */


                  KrunResCandy.prototype.value = $util.Long ? $util.Long.fromBits(0, 0, false) : 0;
                  /**
                   * Creates a new KrunResCandy instance using the specified properties.
                   * @function create
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {tigers.krun.IKrunResCandy=} [properties] Properties to set
                   * @returns {tigers.krun.KrunResCandy} KrunResCandy instance
                   */

                  KrunResCandy.create = function create(properties) {
                    return new KrunResCandy(properties);
                  };
                  /**
                   * Encodes the specified KrunResCandy message. Does not implicitly {@link tigers.krun.KrunResCandy.verify|verify} messages.
                   * @function encode
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {tigers.krun.IKrunResCandy} message KrunResCandy message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResCandy.encode = function encode(message, writer) {
                    if (!writer) writer = $Writer.create();
                    if (message.value != null && message.hasOwnProperty("value")) writer.uint32(
                    /* id 1, wireType 0 =*/
                    8).int64(message.value);
                    return writer;
                  };
                  /**
                   * Encodes the specified KrunResCandy message, length delimited. Does not implicitly {@link tigers.krun.KrunResCandy.verify|verify} messages.
                   * @function encodeDelimited
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {tigers.krun.IKrunResCandy} message KrunResCandy message or plain object to encode
                   * @param {$protobuf.Writer} [writer] Writer to encode to
                   * @returns {$protobuf.Writer} Writer
                   */


                  KrunResCandy.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                  };
                  /**
                   * Decodes a KrunResCandy message from the specified reader or buffer.
                   * @function decode
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @param {number} [length] Message length if known beforehand
                   * @returns {tigers.krun.KrunResCandy} KrunResCandy
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResCandy.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length,
                        message = new $root.tigers.krun.KrunResCandy();

                    while (reader.pos < end) {
                      var tag = reader.uint32();

                      switch (tag >>> 3) {
                        case 1:
                          message.value = reader.int64();
                          break;

                        default:
                          reader.skipType(tag & 7);
                          break;
                      }
                    }

                    return message;
                  };
                  /**
                   * Decodes a KrunResCandy message from the specified reader or buffer, length delimited.
                   * @function decodeDelimited
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                   * @returns {tigers.krun.KrunResCandy} KrunResCandy
                   * @throws {Error} If the payload is not a reader or valid buffer
                   * @throws {$protobuf.util.ProtocolError} If required fields are missing
                   */


                  KrunResCandy.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader)) reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                  };
                  /**
                   * Verifies a KrunResCandy message.
                   * @function verify
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {Object.<string,*>} message Plain object to verify
                   * @returns {string|null} `null` if valid, otherwise the reason why it is not
                   */


                  KrunResCandy.verify = function verify(message) {
                    if (typeof message !== "object" || message === null) return "object expected";
                    if (message.value != null && message.hasOwnProperty("value")) if (!$util.isInteger(message.value) && !(message.value && $util.isInteger(message.value.low) && $util.isInteger(message.value.high))) return "value: integer|Long expected";
                    return null;
                  };
                  /**
                   * Creates a KrunResCandy message from a plain object. Also converts values to their respective internal types.
                   * @function fromObject
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {Object.<string,*>} object Plain object
                   * @returns {tigers.krun.KrunResCandy} KrunResCandy
                   */


                  KrunResCandy.fromObject = function fromObject(object) {
                    if (object instanceof $root.tigers.krun.KrunResCandy) return object;
                    var message = new $root.tigers.krun.KrunResCandy();
                    if (object.value != null) if ($util.Long) (message.value = $util.Long.fromValue(object.value)).unsigned = false;else if (typeof object.value === "string") message.value = parseInt(object.value, 10);else if (typeof object.value === "number") message.value = object.value;else if (typeof object.value === "object") message.value = new $util.LongBits(object.value.low >>> 0, object.value.high >>> 0).toNumber();
                    return message;
                  };
                  /**
                   * Creates a plain object from a KrunResCandy message. Also converts values to other types if specified.
                   * @function toObject
                   * @memberof tigers.krun.KrunResCandy
                   * @static
                   * @param {tigers.krun.KrunResCandy} message KrunResCandy
                   * @param {$protobuf.IConversionOptions} [options] Conversion options
                   * @returns {Object.<string,*>} Plain object
                   */


                  KrunResCandy.toObject = function toObject(message, options) {
                    if (!options) options = {};
                    var object = {};
                    if (options.defaults) if ($util.Long) {
                      var long = new $util.Long(0, 0, false);
                      object.value = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else object.value = options.longs === String ? "0" : 0;
                    if (message.value != null && message.hasOwnProperty("value")) if (typeof message.value === "number") object.value = options.longs === String ? String(message.value) : message.value;else object.value = options.longs === String ? $util.Long.prototype.toString.call(message.value) : options.longs === Number ? new $util.LongBits(message.value.low >>> 0, message.value.high >>> 0).toNumber() : message.value;
                    return object;
                  };
                  /**
                   * Converts this KrunResCandy to JSON.
                   * @function toJSON
                   * @memberof tigers.krun.KrunResCandy
                   * @instance
                   * @returns {Object.<string,*>} JSON object
                   */


                  KrunResCandy.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                  };

                  return KrunResCandy;
                }();
                /**
                 * KRUN_ERROR enum.
                 * @name tigers.krun.KRUN_ERROR
                 * @enum {string}
                 * @property {number} KRUN_ERROR_NONE=0 KRUN_ERROR_NONE value
                 * @property {number} KRUN_ERROR_MATCHING_FAIL=1 KRUN_ERROR_MATCHING_FAIL value
                 * @property {number} KRUN_ERROR_MATCHING_TIMEOUT=2 KRUN_ERROR_MATCHING_TIMEOUT value
                 * @property {number} KRUN_ERROR_MATCHING_NOT_ENOUGH_PRICE=3 KRUN_ERROR_MATCHING_NOT_ENOUGH_PRICE value
                 * @property {number} KRUN_ERROR_USER_INVALID=4 KRUN_ERROR_USER_INVALID value
                 * @property {number} KRUN_ERROR_USER_DOUBLE=5 KRUN_ERROR_USER_DOUBLE value
                 * @property {number} KRUN_ERROR_MATCHING_DISABLE=6 KRUN_ERROR_MATCHING_DISABLE value
                 * @property {number} KRUN_ERROR_RECONNECT_GAME_NOT_FOUND=7 KRUN_ERROR_RECONNECT_GAME_NOT_FOUND value
                 * @property {number} KRUN_ERROR_RECONNECT_GAME_END=8 KRUN_ERROR_RECONNECT_GAME_END value
                 * @property {number} KRUN_ERROR_RECONNECT_PLAYER_NOT_PLAY_THIS_GAME=9 KRUN_ERROR_RECONNECT_PLAYER_NOT_PLAY_THIS_GAME value
                 * @property {number} KRUN_ERROR_RECONNECT_PLAYER_NOT_PAY=10 KRUN_ERROR_RECONNECT_PLAYER_NOT_PAY value
                 * @property {number} KRUN_ERROR_RECONNECT_PLAYER_STILL_ONLINE=11 KRUN_ERROR_RECONNECT_PLAYER_STILL_ONLINE value
                 * @property {number} KRUN_ERROR_RECONNECT_PLAYER_IS_BOT=12 KRUN_ERROR_RECONNECT_PLAYER_IS_BOT value
                 */


                krun.KRUN_ERROR = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_ERROR_NONE"] = 0;
                  values[valuesById[1] = "KRUN_ERROR_MATCHING_FAIL"] = 1;
                  values[valuesById[2] = "KRUN_ERROR_MATCHING_TIMEOUT"] = 2;
                  values[valuesById[3] = "KRUN_ERROR_MATCHING_NOT_ENOUGH_PRICE"] = 3;
                  values[valuesById[4] = "KRUN_ERROR_USER_INVALID"] = 4;
                  values[valuesById[5] = "KRUN_ERROR_USER_DOUBLE"] = 5;
                  values[valuesById[6] = "KRUN_ERROR_MATCHING_DISABLE"] = 6;
                  values[valuesById[7] = "KRUN_ERROR_RECONNECT_GAME_NOT_FOUND"] = 7;
                  values[valuesById[8] = "KRUN_ERROR_RECONNECT_GAME_END"] = 8;
                  values[valuesById[9] = "KRUN_ERROR_RECONNECT_PLAYER_NOT_PLAY_THIS_GAME"] = 9;
                  values[valuesById[10] = "KRUN_ERROR_RECONNECT_PLAYER_NOT_PAY"] = 10;
                  values[valuesById[11] = "KRUN_ERROR_RECONNECT_PLAYER_STILL_ONLINE"] = 11;
                  values[valuesById[12] = "KRUN_ERROR_RECONNECT_PLAYER_IS_BOT"] = 12;
                  return values;
                }();
                /**
                 * KRUN_CMD enum.
                 * @name tigers.krun.KRUN_CMD
                 * @enum {string}
                 * @property {number} KRUN_CMD_UNKNOW=0 KRUN_CMD_UNKNOW value
                 * @property {number} KRUN_CMD_PING=1 KRUN_CMD_PING value
                 * @property {number} KRUN_CMD_DEFINES=2 KRUN_CMD_DEFINES value
                 * @property {number} KRUN_CMD_GET_TURN=3 KRUN_CMD_GET_TURN value
                 * @property {number} KRUN_CMD_GET_CANDY=4 KRUN_CMD_GET_CANDY value
                 * @property {number} KRUN_CMD_GAME_MATCHING=10 KRUN_CMD_GAME_MATCHING value
                 * @property {number} KRUN_CMD_GAME_UPDATE=11 KRUN_CMD_GAME_UPDATE value
                 * @property {number} KRUN_CMD_GAME_END=12 KRUN_CMD_GAME_END value
                 * @property {number} KRUN_CMD_PLAYER_JOIN_GAME=21 KRUN_CMD_PLAYER_JOIN_GAME value
                 * @property {number} KRUN_CMD_PLAYER_QUIT_GAME=22 KRUN_CMD_PLAYER_QUIT_GAME value
                 * @property {number} KRUN_CMD_PLAYER_FIRE_FREEZE_BULLET=23 KRUN_CMD_PLAYER_FIRE_FREEZE_BULLET value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_000=100 KRUN_CMD_PLAYER_MOVE_000 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_010=101 KRUN_CMD_PLAYER_MOVE_010 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_020=102 KRUN_CMD_PLAYER_MOVE_020 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_030=103 KRUN_CMD_PLAYER_MOVE_030 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_040=104 KRUN_CMD_PLAYER_MOVE_040 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_050=105 KRUN_CMD_PLAYER_MOVE_050 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_060=106 KRUN_CMD_PLAYER_MOVE_060 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_070=107 KRUN_CMD_PLAYER_MOVE_070 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_080=108 KRUN_CMD_PLAYER_MOVE_080 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_090=109 KRUN_CMD_PLAYER_MOVE_090 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_100=110 KRUN_CMD_PLAYER_MOVE_100 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_110=111 KRUN_CMD_PLAYER_MOVE_110 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_120=112 KRUN_CMD_PLAYER_MOVE_120 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_130=113 KRUN_CMD_PLAYER_MOVE_130 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_140=114 KRUN_CMD_PLAYER_MOVE_140 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_150=115 KRUN_CMD_PLAYER_MOVE_150 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_160=116 KRUN_CMD_PLAYER_MOVE_160 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_170=117 KRUN_CMD_PLAYER_MOVE_170 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_180=118 KRUN_CMD_PLAYER_MOVE_180 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_190=119 KRUN_CMD_PLAYER_MOVE_190 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_200=120 KRUN_CMD_PLAYER_MOVE_200 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_210=121 KRUN_CMD_PLAYER_MOVE_210 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_220=122 KRUN_CMD_PLAYER_MOVE_220 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_230=123 KRUN_CMD_PLAYER_MOVE_230 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_240=124 KRUN_CMD_PLAYER_MOVE_240 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_250=125 KRUN_CMD_PLAYER_MOVE_250 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_260=126 KRUN_CMD_PLAYER_MOVE_260 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_270=127 KRUN_CMD_PLAYER_MOVE_270 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_280=128 KRUN_CMD_PLAYER_MOVE_280 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_290=129 KRUN_CMD_PLAYER_MOVE_290 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_300=130 KRUN_CMD_PLAYER_MOVE_300 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_310=131 KRUN_CMD_PLAYER_MOVE_310 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_320=132 KRUN_CMD_PLAYER_MOVE_320 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_330=133 KRUN_CMD_PLAYER_MOVE_330 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_340=134 KRUN_CMD_PLAYER_MOVE_340 value
                 * @property {number} KRUN_CMD_PLAYER_MOVE_350=135 KRUN_CMD_PLAYER_MOVE_350 value
                 */


                krun.KRUN_CMD = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_CMD_UNKNOW"] = 0;
                  values[valuesById[1] = "KRUN_CMD_PING"] = 1;
                  values[valuesById[2] = "KRUN_CMD_DEFINES"] = 2;
                  values[valuesById[3] = "KRUN_CMD_GET_TURN"] = 3;
                  values[valuesById[4] = "KRUN_CMD_GET_CANDY"] = 4;
                  values[valuesById[10] = "KRUN_CMD_GAME_MATCHING"] = 10;
                  values[valuesById[11] = "KRUN_CMD_GAME_UPDATE"] = 11;
                  values[valuesById[12] = "KRUN_CMD_GAME_END"] = 12;
                  values[valuesById[21] = "KRUN_CMD_PLAYER_JOIN_GAME"] = 21;
                  values[valuesById[22] = "KRUN_CMD_PLAYER_QUIT_GAME"] = 22;
                  values[valuesById[23] = "KRUN_CMD_PLAYER_FIRE_FREEZE_BULLET"] = 23;
                  values[valuesById[100] = "KRUN_CMD_PLAYER_MOVE_000"] = 100;
                  values[valuesById[101] = "KRUN_CMD_PLAYER_MOVE_010"] = 101;
                  values[valuesById[102] = "KRUN_CMD_PLAYER_MOVE_020"] = 102;
                  values[valuesById[103] = "KRUN_CMD_PLAYER_MOVE_030"] = 103;
                  values[valuesById[104] = "KRUN_CMD_PLAYER_MOVE_040"] = 104;
                  values[valuesById[105] = "KRUN_CMD_PLAYER_MOVE_050"] = 105;
                  values[valuesById[106] = "KRUN_CMD_PLAYER_MOVE_060"] = 106;
                  values[valuesById[107] = "KRUN_CMD_PLAYER_MOVE_070"] = 107;
                  values[valuesById[108] = "KRUN_CMD_PLAYER_MOVE_080"] = 108;
                  values[valuesById[109] = "KRUN_CMD_PLAYER_MOVE_090"] = 109;
                  values[valuesById[110] = "KRUN_CMD_PLAYER_MOVE_100"] = 110;
                  values[valuesById[111] = "KRUN_CMD_PLAYER_MOVE_110"] = 111;
                  values[valuesById[112] = "KRUN_CMD_PLAYER_MOVE_120"] = 112;
                  values[valuesById[113] = "KRUN_CMD_PLAYER_MOVE_130"] = 113;
                  values[valuesById[114] = "KRUN_CMD_PLAYER_MOVE_140"] = 114;
                  values[valuesById[115] = "KRUN_CMD_PLAYER_MOVE_150"] = 115;
                  values[valuesById[116] = "KRUN_CMD_PLAYER_MOVE_160"] = 116;
                  values[valuesById[117] = "KRUN_CMD_PLAYER_MOVE_170"] = 117;
                  values[valuesById[118] = "KRUN_CMD_PLAYER_MOVE_180"] = 118;
                  values[valuesById[119] = "KRUN_CMD_PLAYER_MOVE_190"] = 119;
                  values[valuesById[120] = "KRUN_CMD_PLAYER_MOVE_200"] = 120;
                  values[valuesById[121] = "KRUN_CMD_PLAYER_MOVE_210"] = 121;
                  values[valuesById[122] = "KRUN_CMD_PLAYER_MOVE_220"] = 122;
                  values[valuesById[123] = "KRUN_CMD_PLAYER_MOVE_230"] = 123;
                  values[valuesById[124] = "KRUN_CMD_PLAYER_MOVE_240"] = 124;
                  values[valuesById[125] = "KRUN_CMD_PLAYER_MOVE_250"] = 125;
                  values[valuesById[126] = "KRUN_CMD_PLAYER_MOVE_260"] = 126;
                  values[valuesById[127] = "KRUN_CMD_PLAYER_MOVE_270"] = 127;
                  values[valuesById[128] = "KRUN_CMD_PLAYER_MOVE_280"] = 128;
                  values[valuesById[129] = "KRUN_CMD_PLAYER_MOVE_290"] = 129;
                  values[valuesById[130] = "KRUN_CMD_PLAYER_MOVE_300"] = 130;
                  values[valuesById[131] = "KRUN_CMD_PLAYER_MOVE_310"] = 131;
                  values[valuesById[132] = "KRUN_CMD_PLAYER_MOVE_320"] = 132;
                  values[valuesById[133] = "KRUN_CMD_PLAYER_MOVE_330"] = 133;
                  values[valuesById[134] = "KRUN_CMD_PLAYER_MOVE_340"] = 134;
                  values[valuesById[135] = "KRUN_CMD_PLAYER_MOVE_350"] = 135;
                  return values;
                }();
                /**
                 * KRUN_CONNECT_STATUS enum.
                 * @name tigers.krun.KRUN_CONNECT_STATUS
                 * @enum {string}
                 * @property {number} KRUN_CONNECT_STATUS_ONLINE=0 KRUN_CONNECT_STATUS_ONLINE value
                 * @property {number} KRUN_CONNECT_STATUS_OFFLINE=1 KRUN_CONNECT_STATUS_OFFLINE value
                 */


                krun.KRUN_CONNECT_STATUS = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_CONNECT_STATUS_ONLINE"] = 0;
                  values[valuesById[1] = "KRUN_CONNECT_STATUS_OFFLINE"] = 1;
                  return values;
                }();
                /**
                 * KRUN_PLAYER_STATUS enum.
                 * @name tigers.krun.KRUN_PLAYER_STATUS
                 * @enum {string}
                 * @property {number} KRUN_PLAYER_STATUS_MATCHING=0 KRUN_PLAYER_STATUS_MATCHING value
                 * @property {number} KRUN_PLAYER_STATUS_ALIVE=1 KRUN_PLAYER_STATUS_ALIVE value
                 * @property {number} KRUN_PLAYER_STATUS_DEAD=2 KRUN_PLAYER_STATUS_DEAD value
                 * @property {number} KRUN_PLAYER_STATUS_FINISH=3 KRUN_PLAYER_STATUS_FINISH value
                 * @property {number} KRUN_PLAYER_STATUS_DNF=4 KRUN_PLAYER_STATUS_DNF value
                 */


                krun.KRUN_PLAYER_STATUS = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_PLAYER_STATUS_MATCHING"] = 0;
                  values[valuesById[1] = "KRUN_PLAYER_STATUS_ALIVE"] = 1;
                  values[valuesById[2] = "KRUN_PLAYER_STATUS_DEAD"] = 2;
                  values[valuesById[3] = "KRUN_PLAYER_STATUS_FINISH"] = 3;
                  values[valuesById[4] = "KRUN_PLAYER_STATUS_DNF"] = 4;
                  return values;
                }();
                /**
                 * KRUN_BULLET_EFFECTS enum.
                 * @name tigers.krun.KRUN_BULLET_EFFECTS
                 * @enum {string}
                 * @property {number} KRUN_BULLET_EFFECT_NONE=0 KRUN_BULLET_EFFECT_NONE value
                 * @property {number} KRUN_BULLET_EFFECT_FREEZE=1 KRUN_BULLET_EFFECT_FREEZE value
                 * @property {number} KRUN_BULLET_EFFECT_PENALTY=2 KRUN_BULLET_EFFECT_PENALTY value
                 */


                krun.KRUN_BULLET_EFFECTS = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_BULLET_EFFECT_NONE"] = 0;
                  values[valuesById[1] = "KRUN_BULLET_EFFECT_FREEZE"] = 1;
                  values[valuesById[2] = "KRUN_BULLET_EFFECT_PENALTY"] = 2;
                  return values;
                }();
                /**
                 * KRUN_ACTION enum.
                 * @name tigers.krun.KRUN_ACTION
                 * @enum {string}
                 * @property {number} KRUN_ACTION_IDLE=0 KRUN_ACTION_IDLE value
                 * @property {number} KRUN_ACTION_FIRE_FREEZE_BULLET=1 KRUN_ACTION_FIRE_FREEZE_BULLET value
                 * @property {number} KRUN_ACTION_MOVE_000=100 KRUN_ACTION_MOVE_000 value
                 * @property {number} KRUN_ACTION_MOVE_010=101 KRUN_ACTION_MOVE_010 value
                 * @property {number} KRUN_ACTION_MOVE_020=102 KRUN_ACTION_MOVE_020 value
                 * @property {number} KRUN_ACTION_MOVE_030=103 KRUN_ACTION_MOVE_030 value
                 * @property {number} KRUN_ACTION_MOVE_040=104 KRUN_ACTION_MOVE_040 value
                 * @property {number} KRUN_ACTION_MOVE_050=105 KRUN_ACTION_MOVE_050 value
                 * @property {number} KRUN_ACTION_MOVE_060=106 KRUN_ACTION_MOVE_060 value
                 * @property {number} KRUN_ACTION_MOVE_070=107 KRUN_ACTION_MOVE_070 value
                 * @property {number} KRUN_ACTION_MOVE_080=108 KRUN_ACTION_MOVE_080 value
                 * @property {number} KRUN_ACTION_MOVE_090=109 KRUN_ACTION_MOVE_090 value
                 * @property {number} KRUN_ACTION_MOVE_100=110 KRUN_ACTION_MOVE_100 value
                 * @property {number} KRUN_ACTION_MOVE_110=111 KRUN_ACTION_MOVE_110 value
                 * @property {number} KRUN_ACTION_MOVE_120=112 KRUN_ACTION_MOVE_120 value
                 * @property {number} KRUN_ACTION_MOVE_130=113 KRUN_ACTION_MOVE_130 value
                 * @property {number} KRUN_ACTION_MOVE_140=114 KRUN_ACTION_MOVE_140 value
                 * @property {number} KRUN_ACTION_MOVE_150=115 KRUN_ACTION_MOVE_150 value
                 * @property {number} KRUN_ACTION_MOVE_160=116 KRUN_ACTION_MOVE_160 value
                 * @property {number} KRUN_ACTION_MOVE_170=117 KRUN_ACTION_MOVE_170 value
                 * @property {number} KRUN_ACTION_MOVE_180=118 KRUN_ACTION_MOVE_180 value
                 * @property {number} KRUN_ACTION_MOVE_190=119 KRUN_ACTION_MOVE_190 value
                 * @property {number} KRUN_ACTION_MOVE_200=120 KRUN_ACTION_MOVE_200 value
                 * @property {number} KRUN_ACTION_MOVE_210=121 KRUN_ACTION_MOVE_210 value
                 * @property {number} KRUN_ACTION_MOVE_220=122 KRUN_ACTION_MOVE_220 value
                 * @property {number} KRUN_ACTION_MOVE_230=123 KRUN_ACTION_MOVE_230 value
                 * @property {number} KRUN_ACTION_MOVE_240=124 KRUN_ACTION_MOVE_240 value
                 * @property {number} KRUN_ACTION_MOVE_250=125 KRUN_ACTION_MOVE_250 value
                 * @property {number} KRUN_ACTION_MOVE_260=126 KRUN_ACTION_MOVE_260 value
                 * @property {number} KRUN_ACTION_MOVE_270=127 KRUN_ACTION_MOVE_270 value
                 * @property {number} KRUN_ACTION_MOVE_280=128 KRUN_ACTION_MOVE_280 value
                 * @property {number} KRUN_ACTION_MOVE_290=129 KRUN_ACTION_MOVE_290 value
                 * @property {number} KRUN_ACTION_MOVE_300=130 KRUN_ACTION_MOVE_300 value
                 * @property {number} KRUN_ACTION_MOVE_310=131 KRUN_ACTION_MOVE_310 value
                 * @property {number} KRUN_ACTION_MOVE_320=132 KRUN_ACTION_MOVE_320 value
                 * @property {number} KRUN_ACTION_MOVE_330=133 KRUN_ACTION_MOVE_330 value
                 * @property {number} KRUN_ACTION_MOVE_340=134 KRUN_ACTION_MOVE_340 value
                 * @property {number} KRUN_ACTION_MOVE_350=135 KRUN_ACTION_MOVE_350 value
                 */


                krun.KRUN_ACTION = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_ACTION_IDLE"] = 0;
                  values[valuesById[1] = "KRUN_ACTION_FIRE_FREEZE_BULLET"] = 1;
                  values[valuesById[100] = "KRUN_ACTION_MOVE_000"] = 100;
                  values[valuesById[101] = "KRUN_ACTION_MOVE_010"] = 101;
                  values[valuesById[102] = "KRUN_ACTION_MOVE_020"] = 102;
                  values[valuesById[103] = "KRUN_ACTION_MOVE_030"] = 103;
                  values[valuesById[104] = "KRUN_ACTION_MOVE_040"] = 104;
                  values[valuesById[105] = "KRUN_ACTION_MOVE_050"] = 105;
                  values[valuesById[106] = "KRUN_ACTION_MOVE_060"] = 106;
                  values[valuesById[107] = "KRUN_ACTION_MOVE_070"] = 107;
                  values[valuesById[108] = "KRUN_ACTION_MOVE_080"] = 108;
                  values[valuesById[109] = "KRUN_ACTION_MOVE_090"] = 109;
                  values[valuesById[110] = "KRUN_ACTION_MOVE_100"] = 110;
                  values[valuesById[111] = "KRUN_ACTION_MOVE_110"] = 111;
                  values[valuesById[112] = "KRUN_ACTION_MOVE_120"] = 112;
                  values[valuesById[113] = "KRUN_ACTION_MOVE_130"] = 113;
                  values[valuesById[114] = "KRUN_ACTION_MOVE_140"] = 114;
                  values[valuesById[115] = "KRUN_ACTION_MOVE_150"] = 115;
                  values[valuesById[116] = "KRUN_ACTION_MOVE_160"] = 116;
                  values[valuesById[117] = "KRUN_ACTION_MOVE_170"] = 117;
                  values[valuesById[118] = "KRUN_ACTION_MOVE_180"] = 118;
                  values[valuesById[119] = "KRUN_ACTION_MOVE_190"] = 119;
                  values[valuesById[120] = "KRUN_ACTION_MOVE_200"] = 120;
                  values[valuesById[121] = "KRUN_ACTION_MOVE_210"] = 121;
                  values[valuesById[122] = "KRUN_ACTION_MOVE_220"] = 122;
                  values[valuesById[123] = "KRUN_ACTION_MOVE_230"] = 123;
                  values[valuesById[124] = "KRUN_ACTION_MOVE_240"] = 124;
                  values[valuesById[125] = "KRUN_ACTION_MOVE_250"] = 125;
                  values[valuesById[126] = "KRUN_ACTION_MOVE_260"] = 126;
                  values[valuesById[127] = "KRUN_ACTION_MOVE_270"] = 127;
                  values[valuesById[128] = "KRUN_ACTION_MOVE_280"] = 128;
                  values[valuesById[129] = "KRUN_ACTION_MOVE_290"] = 129;
                  values[valuesById[130] = "KRUN_ACTION_MOVE_300"] = 130;
                  values[valuesById[131] = "KRUN_ACTION_MOVE_310"] = 131;
                  values[valuesById[132] = "KRUN_ACTION_MOVE_320"] = 132;
                  values[valuesById[133] = "KRUN_ACTION_MOVE_330"] = 133;
                  values[valuesById[134] = "KRUN_ACTION_MOVE_340"] = 134;
                  values[valuesById[135] = "KRUN_ACTION_MOVE_350"] = 135;
                  return values;
                }();
                /**
                 * KRUN_GAME_PHASE enum.
                 * @name tigers.krun.KRUN_GAME_PHASE
                 * @enum {string}
                 * @property {number} KRUN_GAME_PHASE_MATCHING=0 KRUN_GAME_PHASE_MATCHING value
                 * @property {number} KRUN_GAME_PHASE_RED=1 KRUN_GAME_PHASE_RED value
                 * @property {number} KRUN_GAME_PHASE_RED_TO_GREEN=2 KRUN_GAME_PHASE_RED_TO_GREEN value
                 * @property {number} KRUN_GAME_PHASE_GREEN=3 KRUN_GAME_PHASE_GREEN value
                 * @property {number} KRUN_GAME_PHASE_GREEN_TO_RED=4 KRUN_GAME_PHASE_GREEN_TO_RED value
                 * @property {number} KRUN_GAME_PHASE_END=5 KRUN_GAME_PHASE_END value
                 */


                krun.KRUN_GAME_PHASE = function () {
                  var valuesById = {},
                      values = Object.create(valuesById);
                  values[valuesById[0] = "KRUN_GAME_PHASE_MATCHING"] = 0;
                  values[valuesById[1] = "KRUN_GAME_PHASE_RED"] = 1;
                  values[valuesById[2] = "KRUN_GAME_PHASE_RED_TO_GREEN"] = 2;
                  values[valuesById[3] = "KRUN_GAME_PHASE_GREEN"] = 3;
                  values[valuesById[4] = "KRUN_GAME_PHASE_GREEN_TO_RED"] = 4;
                  values[valuesById[5] = "KRUN_GAME_PHASE_END"] = 5;
                  return values;
                }();

                return krun;
              }();

              return tigers;
            }();

            return $root;
          }(protobuf).tigers;
        })();

        _cjsExports = exports('default', module.exports);
      });

      const __cjsMetaURL = exports('__cjsMetaURL', module.meta.url);
    }
  };
});

System.register("chunks:///_virtual/MaxApiUtils.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './AppBridge.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, AppBridge;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      AppBridge = module.AppBridge;
    }],
    execute: function () {
      cclegacy._RF.push({}, "e05e6inMlxKIInWCe0B8rXo", "MaxApiUtils", undefined);

      class MaxApiUtils {
        static RegisterNoti(callback) {
          if (window.MaxApi) {
            window.MaxApi.observer('DIS_RECEIVE_NOTI', res => {
              console.log(`[DIS_RECEIVE_NOTI] ${res}`);
              callback(res);
            });
          } else {
            callback(null);
          }
        }

        static RegisShaking() {
          if (window.MaxApi) {
            window.MaxApi.registerShakeSensitivity();
          }
        } // static SetCallbackShaking(callback: Function){
        //     console.log("SET CALLBACK SHAKING");
        //     if (window.MaxApi) {
        //         if (this.listenedShake == false) {
        //             window.MaxApi.listen("onShaker", (response) => {
        //                 callback();
        //             });
        //             this.listenedShake = true;
        //         }
        //     }
        // }


        static UnRegisShaking() {
          if (window.MaxApi) {
            console.log("UNREGIS_SHAKING");
            window.MaxApi.unregisterShakeSensitivity();
          }
        }

        static GetProfile() {
          return new Promise((resolve, reject) => {
            if (window.MaxApi) {
              window.MaxApi.getProfile(function (res) {
                resolve(res);
              });
            } else {
              AppBridge.Instance.getUserProfile(res => {
                resolve(res);
              });
            }
          });
        }

        static GetNewProfile() {
          return new Promise((resolve, reject) => {
            AppBridge.Instance.getNewUserProfile(res => {
              resolve(res);
            });
          });
        }

        static UploadImage(base64) {
          return new Promise((resolve, reject) => {
            const props = {
              path: 'base64-upload',
              files: base64,
              options: {
                loading: true
              }
            };

            if (window.MaxApi) {
              window.MaxApi.uploadImage(props, ({
                status,
                response
              }) => {
                const {
                  url
                } = response;

                if (url && url.length > 0 && url.indexOf('http') >= 0) {
                  resolve(url);
                } else {
                  resolve(response);
                }
              });
            } else {
              resolve(null);
            }
          });
        }

        static GetDeviceInfo() {
          return new Promise((resolve, reject) => {
            if (window.MaxApi) {
              window.MaxApi.getDeviceInfo(function (res) {
                resolve(res);
              });
            } else {
              AppBridge.Instance.getDeviceInfo(res => {
                resolve(res);
              });
            }
          });
        }

        static CheckHighPerformanceDevice() {
          return new Promise((resolve, reject) => {
            if (window.MaxApi) {
              window.MaxApi.isHighPerformanceDevice(function (res) {
                resolve(res);
              });
            } else {
              AppBridge.Instance.isHighPerformanceDevice(res => {
                resolve(res);
              });
            }
          });
        }

        static closeGame() {
          if (window.MaxApi) {
            window.MaxApi.dismiss();
            console.log("111_CLOSE_CALL_DISMISS");
          } else {
            AppBridge.Instance.closeGame();
          }
        }

        static copyToClipboard(copyText, toastMsg) {
          if (window.MaxApi) {
            window.MaxApi.copyToClipboard(copyText, toastMsg);
          }
        }

        static openWeb(url) {
          if (window.MaxApi) {
            window.MaxApi.openWeb({
              url
            });
          }
        } //start screen by feature code.


        static startFeatureCode(refId, params, callback) {
          if (!window.MaxApi) {
            // callback(true);
            AppBridge.Instance.startFeatureCode(refId, params, callback);
          } else {
            window.MaxApi.startFeatureCode(refId, params, callback);
          }
        }

        static checkPermission(permissionName) {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve('granted');
            } else {
              window.MaxApi.checkPermission(permissionName, result => {
                resolve(result);
              });
            }
          });
        }

        static requestPermission(permissionName) {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve('granted');
            } else {
              window.MaxApi.requestPermission(permissionName, result => {
                resolve(result);
              });
            }
          });
        }

        static getContacts() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve([]);
            } else {
              const paramsContact = {
                allowNonMomo: false,
                autoFocus: true,
                isAllowMerchant: false,
                showPopupNonMomo: false,
                allowAgency: false,
                allowMultipleSelection: true
              };
              window.MaxApi.getContacts({
                paramsContact,
                title: "MegaLuckyWheel"
              }, contacts => {
                resolve(contacts);
              });
            }
          });
        }

        static getAvatarEndPoint() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve("");
            } else {
              if (this.avatarEndpoint.length > 0) {
                resolve(this.avatarEndpoint);
              }

              window.MaxApi.getAvatarEndPoint(response => {
                this.avatarEndpoint = response;
                resolve(response);
              });
            }
          });
        }

        static getContact() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve([]);
            } else {
              window.MaxApi.getContact({}, contacts => {
                resolve(contacts);
              });
            }
          });
        }

        static goBack() {
          return new Promise(resolve => {
            if (window.MaxApi) {
              window.MaxApi.goBack(result => {
                resolve(result);
              });
            } else {
              AppBridge.Instance.goBack();
            }
          });
        }

        static getScreenShot(callback) {
          if (!window.MaxApi) {
            callback("");
          } else {
            window.MaxApi.getScreenShot(callback);
          }
        }

        static saveImage(data) {
          return new Promise(resolve => {
            if (window.MaxApi) {
              window.MaxApi.requestPermission('storage', status => {
                if (status === 'granted') {
                  window.MaxApi.saveImage(data, result => {
                    if (result) {
                      window.MaxApi.showToast({
                        duration: 5000,
                        title: 'Lưu hình ảnh thành công'
                      });
                      resolve(true);
                    } else {
                      window.MaxApi.showToast({
                        duration: 5000,
                        title: 'Lưu hình ảnh không thành công'
                      });
                      resolve(false);
                    }
                  });
                } else {
                  window.MaxApi.showToast({
                    duration: 5000,
                    title: 'Lưu hình ảnh không thành công'
                  });
                  resolve(false);
                }
              });
            } else {
              resolve(false);
            }
          });
        }

        static shareFacebook(params, callback) {
          if (!window.MaxApi) {
            callback("");
          } else {
            window.MaxApi.shareFacebook(params, callback);
          }
        }

        static facebookMsg(link) {
          const _url = "fb-messenger://share/?link=" + link;

          if (window.MaxApi) {
            window.MaxApi.openURL(_url);
          }
        }

        static moreMenu(title, subject, message, url) {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve(false);
            } else {
              let shareOptions = {
                title,
                message,
                url,
                subject
              };
              window.MaxApi.share(shareOptions, result => {
                resolve(result);
              });
            }
          });
        }

        static copyLink(link) {
          if (window.MaxApi) {
            window.MaxApi.copyToClipboard(link, 'Đã sao chép');
          }
        }

        static trackEvent(params) {
          if (window.MaxApi) {
            window.MaxApi.trackEvent('lacxi22_squidgame', params);
          } else {
            AppBridge.Instance.trackEvent('lacxi22_squidgame', params);
          }
        }

        static showToast(title, time = 3000) {
          if (window.MaxApi) {
            window.MaxApi.showToast({
              duration: time,
              title
            });
          }
        }

        static vibrateDevice(callback) {
          if (window.MaxApi) {
            window.MaxApi.triggerEventVibration();
          } else {
            AppBridge.Instance.vibrateDevice(callback);
          }
        }

      }

      exports('default', MaxApiUtils);

      _defineProperty(MaxApiUtils, "listenedShake", false);

      _defineProperty(MaxApiUtils, "observer", null);

      _defineProperty(MaxApiUtils, "avatarEndpoint", "");

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TextDefine.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "e19c0a/LP9JFLwLwIt5pY0V", "TextDefine", undefined);

      const Text = exports('Text', {
        Close: "\u0110\xF3ng",
        Exit: "Tho\xE1t",
        Continues: "Ch\u01A1i ti\u1EBFp",
        Retry: "Th\u1EED l\u1EA1i",
        Error: "L\u1ED7i",
        Back: "Quay l\u1EA1i",
        BackAfter: "Quay l\u1EA1i sau",
        Confirm: "X\xE1c nh\u1EADn",
        RewardError: "Kh\xF4ng th\u1EC3 nh\u1EADn qu\xE0 l\xFAc n\xE0y",
        ErrorGeneral: "Th\xF4ng b\xE1o l\u1ED7i t\u1EEB BE",
        NetworkError: "Vui l\xF2ng ki\u1EC5m tra l\u1EA1i k\u1EBFt n\u1ED1i",
        OutOfTurn: "H\u1EBET L\u01AF\u1EE2T",
        MoreDetail: "T\xECm hi\u1EC3u th\xEAm",
        Copied: "\u0110\xE3 sao ch\xE9p",
        ToastBusy: "Ch\u1EDD ch\xFAt nh\xE9!",
        OutOfFreeTurn: "B\u1EA1n \u0111\xE3 h\u1EBFt l\u01B0\u1EE3t mi\u1EC5n ph\xED",
        ExitGameTitle: "B\u1EA1n c\xF3 mu\u1ED1n tho\xE1t tr\xF2 ch\u01A1i?",
        ExitGameContent: "Tr\xF2 ch\u01A1i s\u1EBD k\u1EBFt th\xFAc v\xE0 ng\u01B0ng t\xEDnh \u0111i\u1EC3m n\u1EBFu b\u1EA1n tho\xE1t b\xE2y gi\u1EDD",
        AddTurnTip: "Sau m\u1ED7i {0} b\u1EA1n s\u1EBD nh\u1EADn \u0111\u01B0\u1EE3c 1 l\u01B0\u1EE3t mi\u1EC5n ph\xED khi s\u1ED1 l\u01B0\u1EE3t \u0111ang c\xF3 nh\u1ECF h\u01A1n {1}",
        ClaimGift: "x\xE1c nh\u1EADn ph\u1EA7n th\u01B0\u1EDFng",
        ClaimGiftContent: "B\u1EA1n \u0111\xE3 ch\u1ECDn ph\u1EA7n th\u01B0\u1EDFng d\u01B0\u1EDBi \u0111\xE2y, h\xE3y x\xE1c nh\u1EADn \u0111\u1EC3 nh\u1EADn ngay nh\xE9.",
        ClaimGiftLate: "B\u1EA1n ch\u1EADm tay r\u1ED3i",
        OutOfGift: "Qu\xE0 \u0111\xE3 h\u1EBFt, h\xE3y quay l\u1EA1i sau nh\xE9.",
        tooltipTextNormal: "Tr\u1EA3i nghi\u1EC7m L\u1EAFc x\xEC 2022 ngay c\xF9ng nhi\u1EC1u c\u01A1 h\u1ED9i tr\xFAng th\u01B0\u1EDFng to. V\u01B0\u1EE3t 5 Th\u1EED th\xE1ch Th\u1EA7n T\xE0i \u0111\u1EC3 t\u0103ng v\xE0 gi\u1EEF xu. Cu\u1ED1i game \u0111\u1ED5i xu nh\u1EADn ti\u1EC1n!",
        tooltipTextOB: "Nh\u1EADn ngay 500k xu khi tham gia L\u1EAFc x\xEC 2022. M\u1ED7i xu t\u01B0\u01A1ng \u1EE9ng 1 VN\u0110. V\u01B0\u1EE3t 5 th\u1EED th\xE1ch \u0111\u1EC3 t\u0103ng v\xE0 gi\u1EEF xu. Cu\u1ED1i game \u0111\u1ED5i xu nh\u1EADn ti\u1EC1n!"
      });

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MapMgr.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './EventListener.ts', './Utils.ts', './TimeMgr.ts', './AssetMgr.ts', './Boss.ts', './BulletMgr.ts', './CameraFollow.ts', './Player.ts'], function (exports) {
  'use strict';

  var _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Node, _decorator, Component, resources, instantiate, Vec3, EventName, GameDefine, EventListener, Utils, TimeMgr, AssetMgr, Boss, BulletMgr, CameraFollow, Player;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      resources = module.resources;
      instantiate = module.instantiate;
      Vec3 = module.Vec3;
    }, function (module) {
      EventName = module.EventName;
      GameDefine = module.GameDefine;
    }, function (module) {
      EventListener = module.EventListener;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      AssetMgr = module.AssetMgr;
    }, function (module) {
      Boss = module.Boss;
    }, function (module) {
      BulletMgr = module.BulletMgr;
    }, function (module) {
      CameraFollow = module.CameraFollow;
    }, function (module) {
      Player = module.Player;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _class3, _temp;

      cclegacy._RF.push({}, "e8c5alaZbpO0pbgyOdhXkpV", "MapMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Init"] = 1] = "Init";
        State[State["LoadMap"] = 2] = "LoadMap";
        State[State["LoadPlayer"] = 3] = "LoadPlayer";
        State[State["Done"] = 4] = "Done";
      })(State || (State = {}));

      let MapMgr = exports('MapMgr', (_dec = ccclass('MapMgr'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class MapMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "playerContainer", _descriptor, this);

          _initializerDefineProperty(this, "bossContainer", _descriptor2, this);

          _defineProperty(this, "state", State.None);

          _defineProperty(this, "playerPrefabs", []);

          _defineProperty(this, "players", []);

          _defineProperty(this, "boss", null);

          _defineProperty(this, "mine", null);

          _defineProperty(this, "map", null);

          _defineProperty(this, "playerCount", 0);

          _defineProperty(this, "mapConfig", null);

          _defineProperty(this, "mapInfo", null);

          _defineProperty(this, "yardScaleWidth", 1);

          _defineProperty(this, "yardScaleHeight", 1);
        }

        static get Intance() {
          return MapMgr.instance;
        }

        onLoad() {
          MapMgr.instance = this;
        }

        start() {
          EventListener.Instance.on(EventName.onGameDefine, this.setMapConfig, this);
          EventListener.Instance.on(EventName.onMatchingInfo, this.setMapInfo, this);
          this.setState(State.Init);
        }

        update() {
          switch (this.state) {
            case State.LoadPlayer:
              if (this.players.length == GameDefine.maxPlayer) {
                this.setState(State.Done);
              }

              break;
          }
        }

        gameUpdate(dt) {
          this.boss.gameUpdate(dt);
          BulletMgr.Instance.gameUpdate(dt);
          this.players.forEach(player => {
            if (player.node.active) {
              player.gameUpdate(dt);
            }
          });
        }

        setState(state) {
          this.state = state;

          switch (state) {
            case State.Init:
              Utils.destroyAllChild(this.playerContainer);
              Utils.destroyAllChild(this.bossContainer);
              this.setState(State.LoadMap);
              break;

            case State.LoadMap:
              let mapName = "MapLowend";
              resources.load("prefabs/games/" + mapName, (err, prefab) => {
                if (prefab) {
                  this.map = instantiate(prefab);
                  this.map.setParent(this.node);
                  this.map.active = false;
                  prefab.destroy();
                  this.setState(State.LoadPlayer);
                } else {
                  console.error("Map prefab notfound");
                }
              });
              resources.load("prefabs/games/Boss", (err, prefab) => {
                if (prefab) {
                  let boss = instantiate(prefab);
                  boss.setParent(this.bossContainer);
                  this.boss = boss.getComponent(Boss);
                  prefab.destroy();
                } else {
                  console.error("Boss prefab notfound");
                }
              });
              break;

            case State.LoadPlayer:
              for (let i = 0; i < GameDefine.maxPlayer; i++) {
                resources.load("prefabs/players/player" + (i + 1), (err, prefab) => {
                  if (prefab) {
                    let player = instantiate(prefab);
                    player.name = i.toString();
                    player.setScale(1.5, 1.5, 1.5);
                    player.active = false;
                    player.setParent(this.playerContainer);
                    this.players[i] = player.getComponent(Player);
                  }
                });
              }

              break;

            case State.Done:
              AssetMgr.Instance.Load();
              break;
          }
        }

        setMapInfo(info) {
          this.mapInfo = info;
          this.boss.reset();
        }

        setMapConfig(config) {
          this.mapConfig = config;
          this.yardScaleWidth = GameDefine.yardWidthInit / config.yardWidth;
          this.yardScaleHeight = GameDefine.yardHeightInit / config.yardHeight;
        }

        getMapInfo() {
          return this.mapInfo;
        }

        getMapConfig() {
          return this.mapConfig;
        }

        getEndGameTime() {
          return this.mapInfo.startTime + this.mapConfig.timePlayGame;
        }

        getFrameTime(frame) {
          return this.mapInfo.startTime + frame * this.mapConfig.timePerFrame;
        }

        getGamePhase() {
          let time = this.mapInfo.startTime;
          let phase;
          let duration;

          for (let i = 0; i < this.mapInfo.phases.length; i++) {
            phase = this.mapInfo.phases[i];
            duration = phase.duration * this.mapConfig.timePerFrame;

            if (TimeMgr.instance.serverTime >= time && TimeMgr.instance.serverTime < time + duration) {
              return {
                index: i,
                phase: phase.phase,
                time: time + duration
              };
            }

            time += duration;
          }

          phase = this.mapInfo.phases[0];
          return {
            index: 0,
            phase: phase.phase,
            time: phase.duration * this.mapConfig.timePerFrame
          };
        }

        isReady() {
          return this.state == State.Done;
        }

        show(value) {
          if (this.map) {
            this.map.active = value;
            this.playerContainer.active = value;
            this.bossContainer.active = value;
          }
        }

        init() {
          this.playerCount = 0;
          this.players.forEach(player => {
            player.node.active = false;
          });
          this.mapInfo.players.forEach((netPlayer, i) => {
            let player = this.players[i];
            player.init(netPlayer);
            player.userName = this.mapInfo.playerNames[i]; // player.speed = this.mapConfig.playerMoveSpeed * 4;

            if (player.node.active) {
              this.playerCount++;
            }

            if (player.isMine) {
              CameraFollow.Instance.setTarget(player.node);
              this.mine = player;
            }
          });
          CameraFollow.Instance.reset();
        }

        findTarget(mine) {
          let result = null;
          let mindis = 0;
          this.players.forEach((p, index) => {
            if (p != mine) {
              let dis = Vec3.distance(mine.node.worldPosition, p.node.worldPosition);

              if (result == null) {
                result = p;
                mindis = dis;
              } else {
                if (mindis > dis) {
                  mindis = dis;
                  result = p;
                }
              }
            }
          });
          return result;
        }

        getPlayer(uid) {
          return this.players.find(p => p.uid == uid);
        }

        getPlayerName(uid) {
          let player = this.getPlayer(uid);

          if (player) {
            let array = player.userName.trim().split(" ");
            let name = player.userName;

            if (array.length > 2) {
              name = array[array.length - 2] + " " + array[array.length - 1];
            }

            return name || "Player";
          } else {
            return "Player";
          }
        }

        getPlayerFullName(uid) {
          let player = this.getPlayer(uid);

          if (player) {
            return player.userName;
          } else {
            return "Player";
          }
        }

        getCandy() {
          if (this.mine.isFinish) {
            return this.mapConfig.candyByRank[this.mine.rank - 1] || this.mapConfig.candyDnf;
          } else {
            return this.mapConfig.candyDnf;
          }
        }

        getRank() {
          if (this.mine.isFinish) {
            this.mine.rank;
          } else {
            return -1;
          }
        }

        netUpdate(info) {
          if (this.mapConfig) {
            //player
            info.players.forEach(nplayer => {
              let player = this.getPlayer(nplayer.uid);
              player.netUpdate(nplayer);
            });
            BulletMgr.Instance.netUpdate(info.bullets);
            let rank = 1;
            let nMine = info.players.find(p => p.uid == this.mine.uid);

            if (nMine) {
              if (nMine.finishAt >= 0) {
                info.players.forEach(nplayer => {
                  if (nplayer.finishAt >= 0 && nplayer.finishAt < nMine.finishAt) {
                    rank++;
                  }
                });
              } else {
                info.players.forEach(nplayer => {
                  if (nplayer.uid != this.mine.uid && nplayer.finishAt >= 0 || nplayer.y < nMine.y) {
                    rank++;
                  }
                });
              }

              this.mine.rank = rank;
            }

            EventListener.Instance.emit(EventName.onUpdateRank, rank);
          }
        }

        reset() {
          this.mapConfig = null;
          this.mapInfo = null;
          BulletMgr.Instance.reset();
          this.players.forEach(player => {
            player.node.active = false;
          });
        } // public correctPos(pos: Vec3) {
        //     pos.x *= this.yardScaleWidth;
        //     pos.x -= (this.mapConfig.yardWidth / 2) * this.yardScaleWidth;
        //     pos.y *= this.yardScaleHeight;
        // }


      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "playerContainer", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "bossContainer", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Bullet.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './Define.ts', './Profile.ts', './TimeMgr.ts', './NotifyMgr.ts', './MapMgr.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, _decorator, Component, Vec3, NotifyName, Profile, TimeMgr, NotifyMgr, MapMgr;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
    }, function (module) {
      NotifyName = module.NotifyName;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      TimeMgr = module.TimeMgr;
    }, function (module) {
      NotifyMgr = module.NotifyMgr;
    }, function (module) {
      MapMgr = module.MapMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "ebadb4aDHZLDab3+bnOdv0i", "Bullet", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Init"] = 1] = "Init";
        State[State["Move"] = 2] = "Move";
        State[State["Destroy"] = 3] = "Destroy";
      })(State || (State = {}));

      let Bullet = exports('Bullet', (_dec = ccclass('Bullet'), _dec2 = property(Number), _dec(_class = (_class2 = (_temp = class Bullet extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "speed", _descriptor, this);

          _defineProperty(this, "target", null);

          _defineProperty(this, "direction", new Vec3());

          _defineProperty(this, "temp", new Vec3());

          _defineProperty(this, "startPos", new Vec3());

          _defineProperty(this, "shootAtTime", 0);

          _defineProperty(this, "distance", 0);

          _defineProperty(this, "netBullet", null);

          _defineProperty(this, "state", State.None);
        }

        start() {
          this.setState(State.Init);
        }

        gameUpdate(dt) {
          switch (this.state) {
            case State.Init:
              if (this.target) {
                this.setState(State.Move);
              }

              break;

            case State.Move:
              Vec3.subtract(this.direction, this.target.getAim(), this.node.worldPosition);
              this.direction.normalize();
              this.speed = 1000 * dt * MapMgr.Intance.mapConfig.bullets[0].speed / MapMgr.Intance.mapConfig.timePerFrame;
              this.distance -= this.speed;
              Vec3.multiplyScalar(this.temp, this.direction, this.speed);
              Vec3.add(this.temp, this.node.worldPosition, this.temp);
              this.node.worldPosition = this.temp;
              this.node.forward = this.direction;
              let shootAtTime = this.netBullet.shootAt;
              let hitAtTime = this.netBullet.hitAt;
              let movePercent = 1 - (hitAtTime - TimeMgr.instance.serverTime) / (hitAtTime - shootAtTime); // Vec3.lerp(this.temp, this.startPos, this.target.getAim(), movePercent);
              // this.node.worldPosition.set(this.temp);
              // console.log("[Bullet] move: ", movePercent, shootAtTime, hitAtTime, TimeMgr.instance.serverTime)
              // if ( TimeMgr.instance.serverTime >= hitAtTime) {

              if (this.distance <= 0) {
                this.explosion();
                let bulletInfo = MapMgr.Intance.mapConfig.bullets[this.netBullet.effect - 1];
                let freezeEndTime = hitAtTime + bulletInfo.duration * MapMgr.Intance.mapConfig.timePerFrame;
                let shooterName = MapMgr.Intance.getPlayerName(this.netBullet.shooter);
                this.target.freeze(this.netBullet.effect, shooterName, freezeEndTime);

                switch (this.netBullet.effect) {
                  case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_FREEZE:
                    if (this.netBullet.target != Profile.Instance.Uid) {
                      NotifyMgr.Instance.show(NotifyName.BattleMsg, `${MapMgr.Intance.getPlayerName(this.netBullet.target)} bất động ${Math.round(bulletInfo.duration * MapMgr.Intance.mapConfig.timePerFrame / 1000)} giây vì bị dính kỹ năng của ${shooterName}`);
                    }

                    break;

                  case tigers.krun.KRUN_BULLET_EFFECTS.KRUN_BULLET_EFFECT_PENALTY:
                    break;
                }
              }

              break;

            case State.Destroy:
              break;
          }
        }

        setState(state) {
          if (this.state != state) {
            // console.log(`[Bullet] state: ${State[this.state]} => ${State[state]}`);
            this.state = state;

            switch (state) {
              case State.Init:
                break;

              case State.Move:
                // if( TimeMgr.instance.serverTime > MapMgr.Intance.getFrameTime(this.netBullet.shootAt))
                // {
                //     this.shootAtTime = TimeMgr.instance.serverTime;
                // }
                // else
                // {
                //     this.shootAtTime = MapMgr.Intance.getFrameTime(this.netBullet.shootAt);
                // }
                this.distance = Vec3.distance(this.node.worldPosition, this.target.getAim());
                break;

              case State.Destroy:
                this.node.active = false;
                break;
            }
          }
        }

        fire(startPos, target, netBullet) {
          this.startPos = startPos;
          this.target = target;
          this.netBullet = netBullet;
          this.setState(State.Init);
        }

        explosion() {
          this.setState(State.Destroy);
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 100;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Event.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, EventTarget;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      EventTarget = module.EventTarget;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "f03fbiKccpPkIK/XUr/SGvF", "Event", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Event = exports('Event', (_dec = ccclass("Event"), _dec(_class = (_temp = class Event extends EventTarget {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "instance", null);
        }

        get Instance() {
          if (this.instance == null) {
            this.instance = new Event();
          }

          return this.instance;
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/main", ['./AppBridge.ts', './Define.ts', './EventListener.ts', './Profile.ts', './Utils.ts', './AudioMgr.ts', './MaxApiUtils.ts', './NetworkDefine.ts', './Popup.ts', './PopupMgr.ts', './TimeMgr.ts', './NetworkBrigde.ts', './LeaderBoardItem.ts', './TextDefine.ts', './AssetMgr.ts', './Boss.ts', './Notify.ts', './NotifyMgr.ts', './Bullet.ts', './BulletMgr.ts', './CameraFollow.ts', './Input.ts', './Joystick.ts', './Screen.ts', './InGame.ts', './Event.ts', './AnimationEvent.ts', './EffectMgr.ts', './Player.ts', './MapMgr.ts', './EndGame.ts', './ScreenMgr.ts', './GameMgr.ts', './PopupQuitFindGame.ts', './Init.ts', './LostConnection.ts', './Lobby.ts', './NetPlayer.ts', './Bot.ts', './NetworkError.ts', './TopBar.ts', './protobuf.ts', './Waiting.ts', './TrimBase64.ts', './PopupOutOfTurn.ts', './PopupQuitGame.ts', './Rotation.ts', './NetworkMgr.ts', './MessageBox.ts', './GameInfo.ts', './Loading.ts', './FindMatchFail.ts', './MySprite.ts', './patchproto.mjs_cjs=&original=.js', './tigers.mjs_cjs=&original=.js'], function () {
  'use strict';

  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});