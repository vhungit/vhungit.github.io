System.register("chunks:///_virtual/GameEvent.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, EventTarget;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      EventTarget = module.EventTarget;
    }],
    execute: function () {
      cclegacy._RF.push({}, "057b7vW4Y5Co5jQ4cdw8kFk", "GameEvent", undefined);

      let gameEvent = exports('default', new EventTarget());

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BoxMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './AudioMgr.ts', './FlyScore.ts', './Profile.ts', './Gameconfig.ts'], function (exports) {
  'use strict';

  var cclegacy, Camera, _decorator, Component, find, math, instantiate, Vec3, tween, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, SoundName, AudioMgr, FlyScore, Profile, Gameconfig;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Camera = module.Camera;
      _decorator = module._decorator;
      Component = module.Component;
      find = module.find;
      math = module.math;
      instantiate = module.instantiate;
      Vec3 = module.Vec3;
      tween = module.tween;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      SoundName = module.SoundName;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      FlyScore = module.FlyScore;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "069d2bYyQ9KT6vcjaRR6O+b", "BoxMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let BoxMgr = exports('BoxMgr', (_dec = ccclass('BoxMgr'), _dec2 = property(Camera), _dec(_class = (_class2 = (_temp = _class3 = class BoxMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "camera", _descriptor, this);

          _defineProperty(this, "popupGift", null);

          _defineProperty(this, "count", 1);

          _defineProperty(this, "giftCount", 0);

          _defineProperty(this, "itemPrefabs", []);

          _defineProperty(this, "flyScorePrefabs", null);

          _defineProperty(this, "gifts", []);

          _defineProperty(this, "dirs", [[0, 0, 0, 1], [0, 0, 1, 1], [0, 0, 1, 1]]);
        }

        onLoad() {
          BoxMgr.instance = this;
          this.camera = find("CameraHolder/MainCamera").getComponent(Camera);
          this.itemPrefabs = this.node.children;
        }

        load(scoreContainer) {
          this.flyScorePrefabs = find('flyscore', scoreContainer);
          this.flyScorePrefabs.active = false;
          this.popupGift = find('FlyPopup', scoreContainer);
          this.popupGift.active = false;
        }

        static get Instance() {
          return BoxMgr.instance;
        }

        GetConfig() {
          let mode = Profile.Instance.Mode;
          let scale = Gameconfig.Instance.GetSize(mode < 3 ? 0 : this.count);
          let distance = Gameconfig.Instance.GetDistance(mode < 3 ? 0 : this.count);
          let size = mode < 3 ? (scale.min + scale.max) * .5 : math.randomRange(scale.min, scale.max);
          let dist = mode < 3 ? (distance.min + distance.max) * .5 : math.randomRange(distance.min, distance.max);
          let dirs = this.dirs[mode];
          let dir = mode < 3 ? dirs[this.count % dirs.length] : math.randomRangeInt(0, 2);
          return {
            dir,
            dist,
            size
          };
        }

        spawnGiftOrTransparent(pos) {
          let gift = null;
          let giftCouter = this.count + this.giftCount;
          let bonus = Gameconfig.Instance.CheckBonus(giftCouter);
          Gameconfig.Instance.CheckGiftForStep(giftCouter);
          let hasGift = Gameconfig.Instance.HasGift(giftCouter);
          let flyScore = null;

          if (hasGift) {
            this.resetItem();
            gift = this.itemPrefabs[math.randomRangeInt(0, this.itemPrefabs.length)];
            flyScore = this.popupGift.getComponent(FlyScore);
          } else if (bonus > 0) {
            this.resetItem();
            gift = instantiate(this.flyScorePrefabs);
            this.flyScorePrefabs.parent.addChild(gift);
            flyScore = gift.getComponent(FlyScore);
            flyScore.Show(bonus);
          }

          this.count++;

          if (!gift) {
            if (Profile.Instance.Mode == 2) {
              return math.randomRange(0, 1) > .5;
            } else if (Profile.Instance.Mode == 3) {
              return math.randomRange(0, 1) > .9;
            } else return false;
          } // return ((Profile.Instance.Mode == 2 || Profile.Instance.Mode == 3) ? math.randomRange(0, 1) : 0) > .5


          pos = pos.clone().add3f(0, 1.2, 0);
          this.node.position = pos;
          flyScore.init(this.camera, hasGift ? pos.clone().add3f(0, 1.3, 0) : pos);
          gift.scale = Vec3.ZERO;
          tween(gift).delay(.5).to(.3, {
            scale: new Vec3(1.2, 1.2, 1.2)
          }, {
            easing: 'sineOut'
          }).to(.2, {
            scale: new Vec3(1, 1, 1)
          }, {
            easing: 'sineIn'
          }).start();
          gift.active = true;
          this.gifts.push(gift);
          return false;
        }

        prepick() {
          if (this.gifts.length > 0) {
            this.gifts[0].active = false;
          }
        }

        pickedUp(detail = '') {
          if (this.gifts.length > 0) {
            AudioMgr.Instance.PlaySfx(SoundName.GetGift, true);
            let flyscore = null;
            let gift = this.gifts.shift();

            if (detail.length > 0) {
              flyscore = this.popupGift.getComponent(FlyScore);
              flyscore.Show(detail);
            } else {
              gift.active = true;
              flyscore = gift.getComponent(FlyScore);
            }

            flyscore.pickup();
          }
        }

        Reset() {
          this.giftCount = 0;
          this.count = 1;

          for (let i of this.gifts) {
            var _i$getComponent;

            (_i$getComponent = i.getComponent(FlyScore)) === null || _i$getComponent === void 0 ? void 0 : _i$getComponent.clear();
          }

          this.gifts.length = 0;
          this.resetItem();
        }

        ResetCount() {
          this.giftCount += this.count - 1;
          this.count = 1;
        }

        resetItem() {
          this.itemPrefabs.forEach(item => {
            item.active = false;
          });
        }

        initFlyScore(score, pos) {
          let flyScore = instantiate(this.flyScorePrefabs);
          this.flyScorePrefabs.parent.addChild(flyScore);
          let flyScoreComp = flyScore.getComponent(FlyScore);
          pos = new Vec3(0, 2.5, 0).add(pos);
          flyScoreComp.init(this.camera, pos);
          flyScoreComp.Show(score.toString());
          flyScoreComp.pickup();
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "camera", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/EndGame.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MaxApiUtils.ts', './Profile.ts', './Screen.ts', './ScreenMgr.ts', './TrackingMgr.ts', './GameApi.ts', './GameMgr.ts', './MyGift.ts', './RankView.ts'], function (exports) {
  'use strict';

  var cclegacy, Button, Label, UITransform, Node, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, ScreenName, MaxApiUtils, Profile, Screen, ScreenMgr, TrackingMgr, GameApi, GameMgr, MyGift, RankView;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      UITransform = module.UITransform;
      Node = module.Node;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      ScreenName = module.ScreenName;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      GameMgr = module.GameMgr;
    }, function (module) {
      MyGift = module.MyGift;
    }, function (module) {
      RankView = module.RankView;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _dec16, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _temp;

      cclegacy._RF.push({}, "07926rHs9NJwZ6k9Rb2Qppc", "EndGame", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let EndGame = exports('EndGame', (_dec = ccclass('EndGame'), _dec2 = property(Button), _dec3 = property(Button), _dec4 = property(Button), _dec5 = property(Button), _dec6 = property(Button), _dec7 = property(Label), _dec8 = property(Label), _dec9 = property(UITransform), _dec10 = property(MyGift), _dec11 = property(Node), _dec12 = property(Node), _dec13 = property(Node), _dec14 = property(Node), _dec15 = property(Node), _dec16 = property(RankView), _dec(_class = (_class2 = (_temp = class EndGame extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnRetry", _descriptor, this);

          _initializerDefineProperty(this, "btnShare", _descriptor2, this);

          _initializerDefineProperty(this, "btnClose", _descriptor3, this);

          _initializerDefineProperty(this, "btnDetail", _descriptor4, this);

          _initializerDefineProperty(this, "btnShowMoreGift", _descriptor5, this);

          _initializerDefineProperty(this, "score", _descriptor6, this);

          _initializerDefineProperty(this, "highScore", _descriptor7, this);

          _initializerDefineProperty(this, "container", _descriptor8, this);

          _initializerDefineProperty(this, "myGift", _descriptor9, this);

          _initializerDefineProperty(this, "LeaderBoardloadingIcon", _descriptor10, this);

          _initializerDefineProperty(this, "GiftloadingIcon", _descriptor11, this);

          _initializerDefineProperty(this, "NoGift", _descriptor12, this);

          _initializerDefineProperty(this, "HasGift", _descriptor13, this);

          _initializerDefineProperty(this, "KYC", _descriptor14, this);

          _initializerDefineProperty(this, "rankView", _descriptor15, this);

          _defineProperty(this, "deeplink", '');
        }

        start() {
          this.btnRetry.node.on('click', () => {
            TrackingMgr.Instance.ClickPlayAgain();
            this.OnCloseClick();
          });
          this.btnClose.node.on('click', () => {
            this.OnCloseClick();
          });
          this.btnShare.node.on('click', () => {
            this.OnShareClick();
          });
          this.btnDetail.node.on('click', this.OnLeaderBoardClick.bind(this));
          this.btnShowMoreGift.node.on('click', this.OnShowMoreGiftClick.bind(this));
        }

        Show() {
          const self = this;
          super.Show();
          self.UpdateUI();
          Profile.Instance.SubmitScore(Profile.Instance.Score, true, (result, reward) => {
            GameApi.getRankGlobalAll(rankResp => self.OnLeaderBoardFetched(rankResp));
          });
          Profile.Instance.GetGameGift(resp => {
            if (Profile.Instance.HasGift) {
              self.OnGiftFetched(resp);
            }
          });
          self.HideAllGift();
          self.GiftloadingIcon.active = false;

          if (Profile.Instance.HasGift) {
            self.GiftloadingIcon.active = true;
          } else {
            self.NoGift.active = false;
            self.KYC.active = true;
          }

          self.LeaderBoardloadingIcon.active = true;
          this.btnRetry.getComponentInChildren(Label).string = GameMgr.Instance.IsEndGame ? 'Chơi lại' : 'Chơi tiếp';
          TrackingMgr.Instance.ShowSuccessGameResult();
        }

        Hide() {
          this.rankView.Reset();
          super.Hide();
        }

        OnCloseClick() {
          this.Hide();
          GameMgr.Instance.Retry();
        }

        OnShareClick() {
          const self = this;
          GameMgr.Instance.captureScreen(image64 => {
            MaxApiUtils.UploadImage(image64).then(uploadedLink => {
              if (!uploadedLink || typeof uploadedLink.status !== 'undefined') {
                //error
                MaxApiUtils.showToast("Đã có lỗi xảy ra!");
              } else {
                self.genDeepLink(uploadedLink);
              }
            });
          });
        }

        genDeepLink(url) {
          const self = this;
          let data = {
            title: 'Chia sẻ',
            description: 'Nào mình cùng chơi MoMoJump nhé!',
            imageLink: url,
            domain: "page.momoapp.vn",
            originalLink: "https://momo.vn/tin-tuc/khuyen-mai/cung-tiger-platinum-mo-momo-jump-san-ngay-tien-mat-2558",
            fallbackLink: "https://momo.vn/tin-tuc/khuyen-mai/cung-tiger-platinum-mo-momo-jump-san-ngay-tien-mat-2558",
            appParams: {
              refId: "vn.momo.web.momojumptiger",
              featureCode: "jump_tiger_game"
            }
          };
          GameApi.genDeepLink(data, res => {
            if (res && res.item && res.item.shortLink) {
              self.deeplink = res.item.shortLink;
              self.shareFB();
            }
          });
        }

        shareFB() {
          MaxApiUtils.shareFacebook({
            link: this.deeplink
          }, () => {
            console.log("Share success!");
          });
        }

        OnLeaderBoardClick() {
          this.Hide();
          ScreenMgr.Instance.Show(ScreenName.Leaderboard);
        }

        OnShowMoreGiftClick() {
          this.Hide();
          ScreenMgr.Instance.Show(ScreenName.History);
        }

        UpdateUI() {
          this.score.string = Profile.Instance.Score.toString();
        }

        OnLeaderBoardFetched(data) {
          var _data$response_info;

          if ((data === null || data === void 0 ? void 0 : (_data$response_info = data.response_info) === null || _data$response_info === void 0 ? void 0 : _data$response_info.error_code) == 0) {
            this.highScore.string = data.meta.point.toString();
            this.rankView.loadModel(data);
          }

          this.LeaderBoardloadingIcon.active = false;
        }

        OnGiftFetched(items) {
          this.GiftloadingIcon.active = false;

          if (items != null && items.length > 0) {
            this.HasGift.active = true;
            this.myGift.loadView(items);
          } else {
            this.NoGift.active = true;
            this.KYC.active = false;
          }
        }

        HideAllGift() {
          this.NoGift.active = false;
          this.HasGift.active = false;
          this.KYC.active = false;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnRetry", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnShare", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnClose", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btnDetail", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "btnShowMoreGift", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "score", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "highScore", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "myGift", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "LeaderBoardloadingIcon", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "GiftloadingIcon", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "NoGift", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "HasGift", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "KYC", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor15 = _applyDecoratedDescriptor(_class2.prototype, "rankView", [_dec16], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Collection.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts', './MaxApiUtils.ts', './Gameconfig.ts', './Screen.ts', './ScreenMgr.ts', './TextDefine.ts', './TrackingMgr.ts', './MessageBox.ts', './GameApi.ts', './GameMgr.ts', './CollectionItem.ts', './Rotation.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, Button, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, ScreenName, IventoryId, MySprite, MaxApiUtils, Gameconfig, Screen, ScreenMgr, Text, TrackingMgr, MessageBox, GameApi, GameMgr, CollectionItem, Rotation;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      ScreenName = module.ScreenName;
      IventoryId = module.IventoryId;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      MessageBox = module.MessageBox;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      GameMgr = module.GameMgr;
    }, function (module) {
      CollectionItem = module.CollectionItem;
    }, function (module) {
      Rotation = module.Rotation;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _temp;

      cclegacy._RF.push({}, "0c6115rv89LQb9ATkIEzD/o", "Collection", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Collection = exports('Collection', (_dec = ccclass('Collection'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(MySprite), _dec5 = property(Rotation), _dec6 = property(CollectionItem), _dec7 = property(Button), _dec8 = property(Button), _dec9 = property(Node), _dec10 = property(Node), _dec11 = property(Node), _dec(_class = (_class2 = (_temp = class Collection extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBack", _descriptor, this);

          _initializerDefineProperty(this, "btnEvent", _descriptor2, this);

          _initializerDefineProperty(this, "iconRewards", _descriptor3, this);

          _initializerDefineProperty(this, "loading", _descriptor4, this);

          _initializerDefineProperty(this, "listCollectionItem", _descriptor5, this);

          _initializerDefineProperty(this, "btnCombine", _descriptor6, this);

          _initializerDefineProperty(this, "btnClaim", _descriptor7, this);

          _initializerDefineProperty(this, "btnCombineDisalbe", _descriptor8, this);

          _initializerDefineProperty(this, "congratulation", _descriptor9, this);

          _initializerDefineProperty(this, "btnGroup", _descriptor10, this);

          _defineProperty(this, "isLoading", false);

          _defineProperty(this, "data", null);
        }

        start() {
          this.btnBack.on("click", this.OnBackClick.bind(this));
          this.btnEvent.on("click", this.OnEventClick.bind(this));
          this.btnCombine.node.on("click", this.OnCombineClick.bind(this));
          this.btnClaim.node.on("click", this.OnClaimClick.bind(this));
          this.setIconRewards();
        }

        Show() {
          super.Show();
          this.LoadInfo();
        }

        LoadInfo() {
          const self = this;

          if (!self.isLoading) {
            if (self.data == null) {
              self.loading.node.active = true;
            }

            self.isLoading = true;
            GameApi.getInventory(resp => {
              var _resp$inventory;

              if (!(resp === null || resp === void 0 ? void 0 : (_resp$inventory = resp.inventory) === null || _resp$inventory === void 0 ? void 0 : _resp$inventory.isSuccess)) {
                let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
                msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
                  self.LoadInfo();
                });
              } else {
                self.getIventoryInfo(resp.inventory.items);
              }

              self.loading.node.active = false;
              self.isLoading = false;
            });
          }
        }

        OnBackClick() {
          ScreenMgr.Instance.Hide(ScreenName.Collection);

          if (GameMgr.Instance.IsEndGame) {
            GameMgr.Instance.Retry();
          }
        }

        OnEventClick() {
          MaxApiUtils.openWeb(Gameconfig.Instance.EventLink);
        }

        setIconRewards() {
          let array = Object.keys(IventoryId);
          array.forEach((element, index) => {
            if (index <= 3) {
              let item = Gameconfig.Instance.GetInventoryById(element);
              this.iconRewards[index].Fetch(item.image); // this.listCollectionItem[index].setImage(item.image);
            }
          });
        }

        getIventoryInfo(iventory) {
          if (!iventory) return;
          let isCanCombine = true;
          let array = Object.keys(IventoryId);
          array.forEach((element, index) => {
            let items = iventory.filter(item => item.itemId == element);
            let amount = items.length;

            if (index <= 3) {
              this.listCollectionItem[index].setAmout(amount);
              if (amount == 0) isCanCombine = false;
            }

            if (index == 4) {
              if (items.length > 0) {
                this.btnGroup.active = false;
                this.congratulation.active = true;
                isCanCombine = false;
                this.setCombined();
              } else {
                this.btnGroup.active = true;
                this.congratulation.active = false;
              }
            }
          });

          if (this.btnGroup.active) {
            this.btnCombine.node.active = isCanCombine;
            this.btnCombineDisalbe.active = !isCanCombine;
            this.btnClaim.node.active = false;
          }
        }

        onReceiveError() {
          let self = this;
          let msgBox = MessageBox.Show(Text.RewardError, Text.BackAfter, "", () => {}, 1);
          msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
            self.LoadInfo();
          });
        }

        OnCombineClick() {
          TrackingMgr.Instance.ClickGiftAssemble();
          this.btnCombine.node.active = false;
          let self = this;
          GameApi.postClaimIventoryReward(response => {
            if (response && response.result && response.response_info.error_code == 0) {
              this.setCombined();
              this.btnClaim.node.active = true;
            } else {
              self.onReceiveError();
              self.btnCombine.node.active = true;
            }
          });
        }

        OnClaimClick() {
          TrackingMgr.Instance.ClickCollectTicket();
          this.btnGroup.active = false;
          this.congratulation.active = true;
        }

        setCombined() {
          this.listCollectionItem.forEach(element => {
            element.setCombined();
          });
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBack", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnEvent", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "iconRewards", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "loading", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "listCollectionItem", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "btnCombine", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "btnClaim", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "btnCombineDisalbe", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "congratulation", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "btnGroup", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Popup.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, Button, Node, _decorator, Component, Vec3, tween, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      tween = module.tween;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "113e5qtNpZJR4qFFlM73Kmf", "Popup", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Popup = exports('Popup', (_dec = ccclass('Popup'), _dec2 = property(Button), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class Popup extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnClose", _descriptor, this);

          _initializerDefineProperty(this, "container", _descriptor2, this);

          _defineProperty(this, "onClose", null);
        }

        start() {
          this.btnClose.node.on("click", this.OnCloseClick.bind(this));
        }

        OnCloseClick() {
          if (this.onClose) {
            this.onClose();
          }

          this.Hide();
        }

        Show(autoHide = false) {
          this.node.active = true;
          this.container.setScale(Vec3.ZERO);
          tween(this.container).to(0.5, {
            scale: new Vec3(1, 1, 1)
          }, {
            easing: "bounceInOut"
          }).start();

          if (autoHide) {
            setTimeout(() => {
              this.Hide();
            }, 3000);
          }
        }

        Hide(shouldRemove = true) {
          this.node.active = false;

          if (shouldRemove) {
            this.node.removeFromParent();
            this.node.destroy();
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnClose", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AudioMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, AudioSource, _defineProperty, SoundName, Utils;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      AudioSource = module.AudioSource;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      SoundName = module.SoundName;
    }, function (module) {
      Utils = module.Utils;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "1268aruiMJMSbuwaNTXSCd4", "AudioMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AudioMgr = exports('AudioMgr', (_dec = ccclass('AudioMgr'), _dec(_class = (_temp = _class2 = class AudioMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "audioClips", []);

          _defineProperty(this, "bgVolume", 0.4);

          _defineProperty(this, "sfxVolume", 0.7);

          _defineProperty(this, "audioSourceSFX", null);

          _defineProperty(this, "audioSourceMusic", null);

          _defineProperty(this, "IsEnable", true);
        }

        static get Instance() {
          return this.instance;
        }

        onLoad() {
          AudioMgr.instance = this;
          this.audioSourceSFX = this.addComponent(AudioSource);
          this.audioSourceSFX.loop = false;
          this.audioSourceSFX.volume = this.sfxVolume;
          this.audioSourceSFX.playOnAwake = false;
          this.audioSourceMusic = this.addComponent(AudioSource);
          this.audioSourceMusic.playOnAwake = false;
          this.audioSourceMusic.play();
        }

        PlayOneShot(clip, isOneShot = false) {
          if (this.audioSourceSFX.playing) {
            this.audioSourceSFX.stop();
          }

          if (clip && this.IsEnable) {
            if (!isOneShot) {
              this.audioSourceSFX.clip = clip;
              this.audioSourceSFX.play();
            } else {
              this.audioSourceSFX.playOneShot(clip);
            }
          }
        }

        PlayMusic(clip, loop) {
          if (clip && this.IsEnable) {
            if (this.audioSourceMusic.clip != clip || !this.audioSourceMusic.playing) {
              this.Stop();
              this.audioSourceMusic.clip = clip;
              this.audioSourceMusic.loop = loop;
              this.On();
              this.audioSourceMusic.volume = this.bgVolume;
              this.audioSourceMusic.play();
            }
          }
        }

        Stop() {
          this.audioSourceMusic.stop();
          this.audioSourceSFX.stop();
        }

        Start() {
          if (this.IsEnable) this.audioSourceMusic.play();
        }

        Load() {
          let array = Object.keys(SoundName);
          array.forEach(element => {
            let name = SoundName[element];
            Utils.getAudioRes("sounds/" + name, audioClip => {
              if (audioClip) {
                audioClip.name = name;
                this.audioClips.push(audioClip);
                console.log("Sound load: " + name);

                if (name == SoundName.BackgroundMusic) {
                  this.PlayMusicWithName(name, true);
                }
              } else {
                console.error("Sound notfound: " + name);
              }
            });
          });
        }

        PlaySfx(name, isOneShot = false) {
          if (!this.IsEnable) return;
          let clip = this.audioClips.find(clip => clip.name == name);

          if (clip) {
            this.PlayOneShot(clip, isOneShot);
          }
        }

        StopSfx(name) {
          this.audioClips.forEach(clip => {
            if (clip.name == name && this.audioSourceSFX.clip == clip) {
              if (this.audioSourceSFX.playing) {
                this.audioSourceSFX.stop();
              }
            }

            return;
          });
        }

        PlayMusicWithName(name, loop) {
          if (!this.IsEnable) return;
          this.audioClips.forEach(clip => {
            if (clip.name == name) {
              this.PlayMusic(clip, loop);
            }

            return;
          });
        }

        On() {
          this.IsEnable = true;
          this.Start();
        }

        Off() {
          this.IsEnable = false;
          this.Stop();
        }

        NextStatus() {
          this.IsEnable = !this.IsEnable;

          if (this.IsEnable) {
            this.On();
          } else {
            this.Off();
          }
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/FlyScore.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './MySprite.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, _decorator, Component, tween, Vec3, UIOpacity, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, GameDefine, Utils, MySprite;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      Vec3 = module.Vec3;
      UIOpacity = module.UIOpacity;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MySprite = module.MySprite;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "12ee4JI4OdHEbwO6flryMO+", "FlyScore", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let FlyScore = exports('FlyScore', (_dec = ccclass('FlyScore'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(MySprite), _dec(_class = (_class2 = (_temp = class FlyScore extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "giftText", _descriptor, this);

          _initializerDefineProperty(this, "scoreText", _descriptor2, this);

          _initializerDefineProperty(this, "icon", _descriptor3, this);

          _defineProperty(this, "target", null);

          _defineProperty(this, "camera", null);
        } // Update is called once per frame


        update(dt) {
          if (this.camera) this.node.position = this.camera.convertToUINode(this.target, this.node.parent);
        }

        init(camera, target) {
          this.target = target;
          this.camera = camera;
          this.update(0);
        }

        Show(detail = null, iconLink = '') {
          if (this.giftText) {
            this.giftText.string = Utils.truncate(detail, 15);

            if (this.icon) {
              this.icon.correctSpriteFrameSize(GameDefine.POPUP_GIFT_SIZE);

              if (iconLink != '') {
                this.icon.Fetch(iconLink);
              }
            }
          }

          if (this.scoreText) this.scoreText.string = "+" + detail;
          this.node.active = true;
        }

        clear() {
          if (this.scoreText) {
            this.node.destroy();
          } else {
            this.node.active = false;
          }
        }

        pickup() {
          let node = this.node;

          if (this.scoreText) {
            tween(node).to(.5, {
              scale: new Vec3(1.5, 1.5, 1.5)
            }, {
              easing: 'elasticOut'
            }).start();
          } else {
            node.scale = Vec3.ZERO;
            tween(node).to(.5, {
              scale: Vec3.ONE
            }, {
              easing: 'elasticOut'
            }).start();
          }

          let time = 1.75;
          if (this.scoreText) time = 1;
          let pos = this.target.clone();
          tween(pos).to(time, new Vec3(pos.x, pos.y + 1, pos.z), {
            'onUpdate': (target, ratio) => {
              this.target = target;
            },
            easing: 'sineIn'
          }).start();
          let opacityComp = this.getComponent(UIOpacity);

          if (opacityComp) {
            opacityComp.opacity = 255;
            tween({
              opacity: 255
            }).delay(time * 0.75).to(time / 5, {
              opacity: 100
            }, {
              'onUpdate': (target, ratio) => {
                opacityComp.opacity = target.opacity;
                ratio >= 1 && this.clear();
              },
              easing: 'sineIn'
            }).start();
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "giftText", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scoreText", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "icon", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Progress.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './MaxApiUtils.ts', './Screen.ts', './ScreenMgr.ts', './TextDefine.ts', './MessageBox.ts', './GameApi.ts', './GameMgr.ts', './Rotation.ts', './ProgressScrollView.ts', './ProgressBarScore.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, Sprite, Label, _decorator, UITransform, Size, tween, gameEvent, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, EventName, ScreenName, Utils, MaxApiUtils, Screen, ScreenMgr, Text, MessageBox, GameApi, GameMgr, Rotation, ProgressScrollView, ProgressBarScore;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      Sprite = module.Sprite;
      Label = module.Label;
      _decorator = module._decorator;
      UITransform = module.UITransform;
      Size = module.Size;
      tween = module.tween;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      EventName = module.EventName;
      ScreenName = module.ScreenName;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      MessageBox = module.MessageBox;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      GameMgr = module.GameMgr;
    }, function (module) {
      Rotation = module.Rotation;
    }, function (module) {
      ProgressScrollView = module.ProgressScrollView;
    }, function (module) {
      ProgressBarScore = module.ProgressBarScore;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _temp;

      cclegacy._RF.push({}, "13fc5UUwY9A5683dS9dCSts", "Progress", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Progress = exports('Progress', (_dec = ccclass('Progress'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(ProgressScrollView), _dec5 = property(Rotation), _dec6 = property(ProgressBarScore), _dec7 = property(Sprite), _dec8 = property(Label), _dec9 = property(Node), _dec10 = property(Node), _dec(_class = (_class2 = (_temp = class Progress extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBack", _descriptor, this);

          _initializerDefineProperty(this, "btnRestart", _descriptor2, this);

          _initializerDefineProperty(this, "scrollView", _descriptor3, this);

          _initializerDefineProperty(this, "loading", _descriptor4, this);

          _initializerDefineProperty(this, "progressBarScore", _descriptor5, this);

          _initializerDefineProperty(this, "progressSprite", _descriptor6, this);

          _initializerDefineProperty(this, "labelScore", _descriptor7, this);

          _initializerDefineProperty(this, "bannerSprite", _descriptor8, this);

          _initializerDefineProperty(this, "banner", _descriptor9, this);

          _defineProperty(this, "isLoading", false);

          _defineProperty(this, "data", null);

          _defineProperty(this, "tweenScore", null);

          _defineProperty(this, "tweenProgressBar", null);

          _defineProperty(this, "currentScore", 0);

          _defineProperty(this, "preScore", 0);

          _defineProperty(this, "time", 0);

          _defineProperty(this, "bannerLink", "https://img.mservice.com.vn/momo_app_v2/img/1029x342_ingame1.jpg");

          _defineProperty(this, "eventLink", "https://momo.vn/tin-tuc/khuyen-mai/cung-tiger-platinum-mo-momo-jump-san-ngay-tien-mat-2558");
        }

        onLoad() {
          gameEvent.on(EventName.OnUpdateProgress, this.LoadInfo.bind(this));
          Utils.setInfoMySprite(this.bannerSprite, this.bannerLink);
        }

        start() {
          this.setEvent();
        }

        setEvent() {
          this.btnBack.on("click", this.OnBackClick.bind(this));
          this.btnRestart.on("click", this.OnRestartClick.bind(this));
          this.banner.on("click", this.OnOpenBanner.bind(this));
        }

        OnBackClick() {
          ScreenMgr.Instance.Hide(ScreenName.Progress);

          if (GameMgr.Instance.IsEndGame) {
            GameMgr.Instance.Retry();
          }
        }

        OnRestartClick() {
          this.Hide();

          if (GameMgr.Instance.IsEndGame) {
            GameMgr.Instance.Retry();
          }
        }

        OnOpenBanner() {
          MaxApiUtils.openWeb(this.eventLink);
        }

        Show() {
          // Profile.Instance.SetNormalFps();
          super.Show();
          this.LoadInfo();
        }

        Hide() {
          super.Hide();

          if (GameMgr.Instance.IsEndGame) {
            GameMgr.Instance.Retry();
          }
        }

        LoadInfo() {
          const self = this;

          if (!self.isLoading) {
            if (self.data == null) {
              self.loading.node.active = true;
            }

            self.isLoading = true;
            GameApi.getProgress(resp => {
              if (!resp || !resp.response_info || resp.response_info.error_code !== 0) {
                let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
                msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
                  self.LoadInfo();
                });
              } else {
                self.SetInfo(resp.data);
                GameMgr.Instance.setInfoMiniProgress(resp.data); //self.SetInfo(ApiMock.getProgress.data) //unrem to cheat test
              }

              self.loading.node.active = false;
              self.isLoading = false;
            });
          }
        }

        SetInfo(data) {
          if (this.data != data) {
            this.data = data;
            this.scrollView.clear();
            this.progressBarScore.node.active = false;
            this.scrollView.loadView(data.milestones, data.currentPoint, this.UpdateProgressBar.bind(this));
          }
        }

        UpdateProgressBar(listLabelScorePosition) {
          let currentPoint = this.data.currentPoint;
          this.currentScore = currentPoint;
          this.preScore = parseInt(this.labelScore.string);
          const progressSpriteUIComp = this.progressSprite.node.getComponent(UITransform);
          const progressBarScoreUIComp = this.progressBarScore.node.getComponent(UITransform);
          const preOffset = progressSpriteUIComp.height;
          const height = Math.abs(listLabelScorePosition[listLabelScorePosition.length - 1]);
          progressBarScoreUIComp.setContentSize(new Size(progressSpriteUIComp.width, height));
          const listTargetPoint = [];
          let indexLastGained = -1;
          this.data.milestones.forEach((element, index) => {
            listTargetPoint.push(element.targetPoint);

            if (currentPoint >= element.targetPoint) {
              indexLastGained = index;
            }
          });
          let offset;

          if (indexLastGained != listTargetPoint.length - 1) {
            let startHeight = 0;
            let respoint = 0;
            let pointToNextTarget = 0;
            let distanceToNextTarget = 0;

            if (indexLastGained >= 0) {
              startHeight = Math.abs(listLabelScorePosition[indexLastGained]) + 20;
              respoint = currentPoint - listTargetPoint[indexLastGained];
              pointToNextTarget = listTargetPoint[indexLastGained + 1] - listTargetPoint[indexLastGained];
              distanceToNextTarget = Math.abs(listLabelScorePosition[indexLastGained + 1] - listLabelScorePosition[indexLastGained]) - 40;
            } else {
              respoint = currentPoint;
              pointToNextTarget = listTargetPoint[indexLastGained + 1];
              distanceToNextTarget = Math.abs(listLabelScorePosition[indexLastGained + 1]) - 20;
            }

            const minAddHeight = 10;
            let addHeight = respoint / pointToNextTarget * distanceToNextTarget;
            if (addHeight > 0 && addHeight < minAddHeight) addHeight = minAddHeight;
            offset = startHeight + addHeight;
          } else {
            offset = height;
          }

          this.progressBarScore.loadView(currentPoint, listTargetPoint, listLabelScorePosition);
          this.progressBarScore.node.active = true;
          const speed = 50;
          this.time = Math.min(3, (this.currentScore - this.preScore) / speed);

          if (this.tweenProgressBar) {
            this.tweenProgressBar.stop();
          }

          this.tweenProgressBar = tween({
            offset: preOffset
          }).to(this.time, {
            offset
          }, {
            onUpdate: (target, ratio) => {
              progressSpriteUIComp.setContentSize(new Size(progressSpriteUIComp.width, target.offset));
              gameEvent.emit(EventName.OnUpdateLabelScoreProgress, target.offset);
            }
          }).call(() => {
            progressSpriteUIComp.setContentSize(new Size(progressSpriteUIComp.width, offset));
          });
          this.updateScore();
        }

        updateScore() {
          if (this.currentScore == this.preScore) return;

          if (this.tweenScore) {
            this.tweenScore.stop();
          }

          this.tweenScore = tween({
            value: this.preScore || 0
          }).to(this.time, {
            value: this.currentScore
          }, {
            onUpdate: (target, ratio) => {
              this.labelScore.string = Math.floor(target.value).toString();
            }
          }).call(() => {
            this.labelScore.string = this.currentScore.toString();
          });
          this.tweenScore.start();
          this.tweenProgressBar.start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBack", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnRestart", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "scrollView", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "loading", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "progressBarScore", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "progressSprite", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "labelScore", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "bannerSprite", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "banner", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GiftHistoryCell.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts'], function (exports) {
  'use strict';

  var cclegacy, Sprite, Label, Node, _decorator, Component, UITransform, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, HistoryCellType, Utils;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Sprite = module.Sprite;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      UITransform = module.UITransform;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      HistoryCellType = module.HistoryCellType;
    }, function (module) {
      Utils = module.Utils;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "14e1fsXcFxMAraWE7/HV4Qy", "GiftHistoryCell", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let GiftHistoryCell = exports('GiftHistoryCell', (_dec = ccclass('GiftHistoryCell'), _dec2 = property(Sprite), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Node), _dec(_class = (_class2 = (_temp = class GiftHistoryCell extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "giftIcon", _descriptor, this);

          _initializerDefineProperty(this, "giftNameLabel", _descriptor2, this);

          _initializerDefineProperty(this, "dateTimeLabel", _descriptor3, this);

          _initializerDefineProperty(this, "labelGroup", _descriptor4, this);

          _defineProperty(this, "type", HistoryCellType.ITEM);

          _defineProperty(this, "uiComp", null);

          _defineProperty(this, "labelHolderUIComp", null);
        }

        onLoad() {
          this.uiComp = this.node.getComponent(UITransform);
          this.labelHolderUIComp = this.labelGroup.getComponent(UITransform);
        }

        loadView(item) {
          //this.giftIcon.Fetch(item.iconUrl);
          this.giftNameLabel.string = item.giftName;
          const date = new Date(parseInt(item.timestamp));
          this.dateTimeLabel.string = Utils.getTime(date);
          this.uiComp.setContentSize(this.uiComp.width, this.labelHolderUIComp.height);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "giftIcon", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "giftNameLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "dateTimeLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "labelGroup", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ThemeController.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts'], function (exports) {
  'use strict';

  var cclegacy, SpriteFrame, Material, _decorator, Component, randomRangeInt, Sprite, tween, resources, Texture2D, _applyDecoratedDescriptor, _initializerDefineProperty, BackgroundName;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      SpriteFrame = module.SpriteFrame;
      Material = module.Material;
      _decorator = module._decorator;
      Component = module.Component;
      randomRangeInt = module.randomRangeInt;
      Sprite = module.Sprite;
      tween = module.tween;
      resources = module.resources;
      Texture2D = module.Texture2D;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      BackgroundName = module.BackgroundName;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "1b646ExIr9IsqaF0ZUBt1tk", "ThemeController", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ThemeController = exports('ThemeController', (_dec = ccclass('ThemeController'), _dec2 = property(SpriteFrame), _dec3 = property(Material), _dec(_class = (_class2 = (_temp = class ThemeController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "listBackground", _descriptor, this);

          _initializerDefineProperty(this, "randomSwitch", _descriptor2, this);
        }

        switchRandom(delay, duration) {
          console.log("SWITCH BACKGROUND RANDOM");

          if (this.listBackground.length == 3 && this.randomSwitch) {
            let id = 2;
            let length = this.listBackground.length;
            id = (id + randomRangeInt(1, length)) % length;
            this.setByIndex(id, duration);
            this.scheduleOnce(() => {
              this.getComponent(Sprite).setMaterial(this.randomSwitch, 0);
              this.randomSwitch = null;
              tween(this).call(() => {
                id = (id + randomRangeInt(1, length)) % length;
                this.setByIndex(id, duration);
              }).delay(delay).union().repeatForever().start();
            }, delay);
          }
        }

        setByIndex(index, time) {
          console.log("CHANGE Background: " + index);
          let sprite = this.getComponent(Sprite);
          let frame = this.listBackground[index];
          if (frame == sprite.spriteFrame) return;

          if (time == 0) {
            sprite.spriteFrame = frame;
            return;
          }

          let material = sprite.sharedMaterial;
          if (!material) return;

          if (sprite.spriteFrame && sprite.spriteFrame.texture) {
            material.setProperty('next', sprite.spriteFrame.texture);
          }

          sprite.spriteFrame = frame;
          tween({
            value: 1
          }).to(time, {
            value: 0
          }, {
            onUpdate: (target, ratio) => {
              material.setProperty('alphaThreshold', target.value);
            },
            easing: "sineOut"
          }).start();
        }

        load() {
          let array = Object.keys(BackgroundName);
          array.forEach((element, index) => {
            resources.load("backgrounds/" + element, (err, imageAsset) => {
              let spriteFrame = new SpriteFrame();
              let texture = new Texture2D();
              texture.image = imageAsset;
              spriteFrame.texture = texture;
              this.listBackground[index] = spriteFrame;
              if (index == 0) this.setByIndex(0, 0);
            });
          });
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "listBackground", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "randomSwitch", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MaxApiUtils.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      cclegacy._RF.push({}, "28774sywudKJaUfJ3kzaJm/", "MaxApiUtils", undefined);

      class MaxApiUtils {
        static registerScreenShot(callback) {
          if (window.MaxApi) {
            window.MaxApi.listen("onScreenShot", () => {
              callback();
            });
          } else {
            callback(null);
          }
        }

        static RegisterNoti(callback) {
          if (window.MaxApi) {
            window.MaxApi.observer('DIS_RECEIVE_NOTI', res => {
              console.log(`[DIS_RECEIVE_NOTI] ${res}`);
              callback(res);
            });
          } else {
            callback(null);
          }
        }

        static GetProfile() {
          return new Promise((resolve, reject) => {
            if (window.MaxApi) {
              window.MaxApi.getProfile(function (res) {
                resolve(res);
              });
            } else {
              resolve();
            }
          });
        }

        static UploadImage(base64) {
          return new Promise((resolve, reject) => {
            const props = {
              path: 'base64-upload',
              files: base64,
              options: {
                loading: true
              }
            };

            if (window.MaxApi) {
              window.MaxApi.uploadImage(props, ({
                status,
                response
              }) => {
                const {
                  url
                } = response;

                if (url && url.length > 0 && url.indexOf('http') >= 0) {
                  resolve(url);
                } else {
                  resolve(response);
                }
              });
            } else {
              resolve(null);
            }
          });
        }

        static GetDeviceInfo() {
          return new Promise((resolve, reject) => {
            if (window.MaxApi) {
              window.MaxApi.getDeviceInfo(function (res) {
                resolve(res);
              });
            } else {
              resolve(null);
            }
          });
        }

        static CheckHighPerformanceDevice() {
          return new Promise((resolve, reject) => {
            if (window.MaxApi) {
              window.MaxApi.isHighPerformanceDevice(function (res) {
                resolve(res);
              });
            } else {
              resolve(true);
            }
          });
        }

        static closeGame() {
          if (window.MaxApi) {
            window.MaxApi.dismiss();
          }
        }

        static copyToClipboard(copyText, toastMsg) {
          if (window.MaxApi) {
            window.MaxApi.copyToClipboard(copyText, toastMsg);
          }
        }

        static openWeb(url) {
          window.MaxApi.openWeb({
            url
          });
        } //start screen by feature code.


        static startFeatureCode(featureCode, params, callback) {
          if (!window.MaxApi) {
            callback(true);
          } else {
            window.MaxApi.startFeatureCode(featureCode, params, callback);
          }
        }

        static checkPermission(permissionName) {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve('granted');
            } else {
              window.MaxApi.checkPermission(permissionName, result => {
                resolve(result);
              });
            }
          });
        }

        static requestPermission(permissionName) {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve('granted');
            } else {
              window.MaxApi.requestPermission(permissionName, result => {
                resolve(result);
              });
            }
          });
        }

        static getContacts() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve([]);
            } else {
              const paramsContact = {
                allowNonMomo: false,
                autoFocus: true,
                isAllowMerchant: false,
                showPopupNonMomo: false,
                allowAgency: false,
                allowMultipleSelection: true
              };
              window.MaxApi.getContacts({
                paramsContact,
                title: "MegaLuckyWheel"
              }, contacts => {
                resolve(contacts);
              });
            }
          });
        }

        static getAvatarEndPoint() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve("");
            } else {
              if (this.avatarEndpoint.length > 0) {
                resolve(this.avatarEndpoint);
              }

              window.MaxApi.getAvatarEndPoint(response => {
                this.avatarEndpoint = response;
                resolve(response);
              });
            }
          });
        }

        static getContact() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve([]);
            } else {
              window.MaxApi.getContact({}, contacts => {
                resolve(contacts);
              });
            }
          });
        }

        static goBack() {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve('denied');
            } else {
              window.MaxApi.goBack(result => {
                resolve(result);
              });
            }
          });
        }

        static getScreenShot(callback) {
          if (!window.MaxApi) {
            callback("");
          } else {
            window.MaxApi.getScreenShot(callback);
          }
        }

        static saveImage(data) {
          return new Promise(resolve => {
            if (window.MaxApi) {
              window.MaxApi.requestPermission('storage', status => {
                if (status === 'granted') {
                  window.MaxApi.saveImage(data, result => {
                    if (result) {
                      window.MaxApi.showToast({
                        duration: 5000,
                        title: 'Lưu hình ảnh thành công'
                      });
                      resolve(true);
                    } else {
                      window.MaxApi.showToast({
                        duration: 5000,
                        title: 'Lưu hình ảnh không thành công'
                      });
                      resolve(false);
                    }
                  });
                } else {
                  window.MaxApi.showToast({
                    duration: 5000,
                    title: 'Lưu hình ảnh không thành công'
                  });
                  resolve(false);
                }
              });
            } else {
              resolve(false);
            }
          });
        }

        static shareFacebook(params, callback) {
          if (!window.MaxApi) {
            callback("");
          } else {
            window.MaxApi.shareFacebook(params, callback);
          }
        }

        static facebookMsg(link) {
          const _url = "fb-messenger://share/?link=" + link;

          if (window.MaxApi) {
            window.MaxApi.openURL(_url);
          }
        }

        static moreMenu(title, subject, message, url) {
          return new Promise(resolve => {
            if (!window.MaxApi) {
              resolve(false);
            } else {
              let shareOptions = {
                title,
                message,
                url,
                subject
              };
              window.MaxApi.share(shareOptions, result => {
                resolve(result);
              });
            }
          });
        }

        static copyLink(link) {
          if (window.MaxApi) {
            window.MaxApi.copyToClipboard(link, 'Đã sao chép');
          }
        }

        static trackEvent(params) {
          if (window.MaxApi) {
            window.MaxApi.trackEvent('gamification_momo_jump', params);
          }
        }

        static showToast(title, time = 3000) {
          if (window.MaxApi) {
            window.MaxApi.showToast({
              duration: time,
              title
            });
          }
        }

        static setItem(key, value) {
          if (window.MaxApi) {
            window.MaxApi.setItem(key, value);
          }
        }

        static getItem(key, callback = null) {
          if (window.MaxApi) {
            window.MaxApi.getItem(key, callback);
          }
        } /////////////////Tracking performent/////////////////////


        static startTraceScreenLoad(screenName, callback) {
          if (window.MaxApi) {
            window.MaxApi.startTraceScreenLoad(screenName, ({
              traceId
            }) => {
              callback(traceId);
            });
          } else {
            callback();
          }
        }

        static startTraceScreenInteraction(screenName, callback) {
          if (window.MaxApi) {
            window.MaxApi.startTraceScreenInteraction(screenName, ({
              traceId
            }) => {
              callback(traceId);
            });
          } else {
            callback();
          }
        }

        static startTraceScreenGoal(screenName, callback) {
          if (window.MaxApi) {
            window.MaxApi.startTraceScreenGoal(screenName, ({
              traceId
            }) => {
              callback(traceId);
            });
          } else {
            callback();
          }
        }

        static startTrace(flow, step, callback) {
          if (window.MaxApi) {
            window.MaxApi.startTrace({
              flow,
              step
            }, ({
              traceId
            }) => {
              callback(traceId);
            });
          } else {
            callback();
          }
        }

        static traceSuccess(traceId) {
          if (window.MaxApi) {
            window.MaxApi.traceSuccess(traceId, {});
          }
        }

        static traceFail(traceId) {
          if (window.MaxApi) {
            window.MaxApi.traceFail(traceId, {});
          }
        }

        static stopTrace(traceId) {
          if (window.MaxApi) {
            window.MaxApi.stopTrace(traceId, {});
          }
        }

        static triggerEventVibration() {
          if (window.MaxApi) {
            window.MaxApi.triggerEventVibration();
          }
        }

      }

      exports('default', MaxApiUtils);

      _defineProperty(MaxApiUtils, "avatarEndpoint", "");

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Gameconfig.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Api.ts', './Profile.ts', './NetworkMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, math, _defineProperty, Default, Api, Profile, NetworkMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      math = module.math;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      Default = module.Default;
    }, function (module) {
      Api = module.Api;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "3067cdUA1dOZIgAYWcOzEaU", "Gameconfig", undefined);

      const {
        ccclass,
        property
      } = _decorator;

      class GameConfigDistance {
        constructor() {
          _defineProperty(this, "step", void 0);

          _defineProperty(this, "min", void 0);

          _defineProperty(this, "max", void 0);
        }

      }

      class GameConfigStepSize {
        constructor() {
          _defineProperty(this, "step", void 0);

          _defineProperty(this, "min", void 0);

          _defineProperty(this, "max", void 0);
        }

      }

      let Gameconfig = exports('Gameconfig', (_dec = ccclass('Gameconfig'), _dec(_class = (_temp = _class2 = class Gameconfig extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "data", null);

          _defineProperty(this, "giftStatus", []);

          _defineProperty(this, "giftSegmentStatus", []);

          _defineProperty(this, "bonus", []);
        }

        static get Instance() {
          if (!Gameconfig.instance) {
            Gameconfig.instance = new Gameconfig();
          }

          return Gameconfig.instance;
        }

        get IsLoaded() {
          return this.data != null;
        }

        get RewardScoreList() {
          if (this.data == null) {
            return Default.RewardScoreList;
          } else {
            return this.data.item.checkpoint;
          }
        }

        get MaxScore() {
          let scores = this.RewardScoreList;
          return scores[scores.length - 1] + scores[0];
        }

        get ComboBonusScores() {
          return Default.ComboBonus;
        }

        GetSize(step) {
          if (this.data != null) {
            let sizes = this.data.item.size;
            let nStep = step % 50;

            if (step >= 50) {
              return sizes[sizes.length - 1];
            } else {
              for (let i = sizes.length - 1; i >= 0; i--) {
                if (nStep >= sizes[i].step) {
                  return sizes[i];
                }
              }
            }
          }

          let size = new GameConfigStepSize();
          size.step = step;
          size.min = 1;
          size.max = 1;
          return size;
        }

        GetDistance(step) {
          if (this.data != null) {
            let distances = this.data.item.distances;
            let nStep = step % 50;

            if (step >= 50) {
              return distances[distances.length - 1];
            } else {
              for (let i = distances.length - 1; i >= 0; i--) {
                if (nStep >= distances[i].step) {
                  return distances[i];
                }
              }
            }
          }

          let distance = new GameConfigDistance();
          distance.step = step;
          distance.min = 1.9;
          distance.max = 2.5;
          return distance;
        }

        get ScoreRange() {
          return this.data.item.point;
        }

        get Distance() {
          return this.data.item.distances;
        }

        get Size() {
          return this.data.item.size;
        }

        get Power() {
          return this.data.item.power;
        }

        get EventLink() {
          return this.data == null ? "" : this.data.item.eventLink;
        }

        get TurnTimerLimit() {
          return this.data.item.turnTimerLimit;
        }

        get inventory() {
          return this.data.inventory;
        }

        GetStageTarget(index) {
          var _this$data, _this$data$item;

          let stage = (_this$data = this.data) === null || _this$data === void 0 ? void 0 : (_this$data$item = _this$data.item) === null || _this$data$item === void 0 ? void 0 : _this$data$item.stages[index];
          return stage ? parseInt(this.data.item.stages[index].target) : -1;
        }

        GetInventoryById(item_id) {
          return this.data.inventory.find(item => item.itemId == item_id);
        }

        Reset() {
          this.giftStatus = [];
          this.giftSegmentStatus = [];
          this.bonus = null;
        }

        HasGift(step) {
          let hasGift = false;

          if (this.data != null && Profile.Instance.HasGift) {
            hasGift = this.giftStatus[step];
          }

          return hasGift;
        }

        SetBonus(value) {
          this.bonus = value;
        }

        CheckBonus(step) {
          if (this.bonus && this.bonus[step]) {
            return this.bonus[step];
          } else {
            return 0;
          }
        }

        CheckComboBonus(perfectStreakCount) {
          if (perfectStreakCount < 1) return 0;
          return this.ComboBonusScores[Math.min(this.ComboBonusScores.length - 1, perfectStreakCount - 1)];
        }

        CheckGiftForStep(step) {
          if (this.data != null && Profile.Instance.HasGift && Profile.Instance.GameID != null) {
            this.data.item.reward.forEach((reward, index) => {
              if (step >= reward.from && step <= reward.to) {
                if (this.giftSegmentStatus.indexOf(index) != -1) {
                  this.giftStatus[step] = false;
                } else {
                  let hasGift = math.randomRangeInt(step, reward.to + 1) * 2 <= step + reward.to;

                  if (hasGift) {
                    this.giftSegmentStatus.push(index);
                  }

                  this.giftStatus[step] = hasGift;
                }

                return;
              }
            });
          }
        }

        Fetch(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.GameConfig, result => {
            console.log("[Game config] is Loaded");

            if (result && result.item) {
              this.data = result;
              this.data.item.turnTimer = result.item.turnTimer ? parseInt(result.item.turnTimer) : 0;
              this.data.inventory = result.inventory;
              callback(true);
            } else {
              callback(false);
            }
          });
        }

        getTurnTime() {
          return this.data.item.turnTimer;
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AgeGatePU.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './Popup.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Button, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, Popup, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "35eaaIHnK9Jjrz1GDY+22df", "AgeGatePU", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AgeGatePU = exports('AgeGatePU', (_dec = ccclass('AgeGatePU'), _dec2 = property(Button), _dec(_class = (_class2 = (_temp = class AgeGatePU extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btOk", _descriptor, this);
        }

        start() {
          super.start();
          this.btOk.node.on("click", this.OnOkClick.bind(this));
        }

        OnOkClick() {
          GameMgr.Instance.closeGame();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "btOk", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AddTurn.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './Profile.ts', './Gameconfig.ts', './ScreenMgr.ts', './Popup.ts', './TextDefine.ts', './TrackingMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Button, Node, Label, _decorator, tween, Vec3, gameEvent, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, EventName, ProfileStorageKey, ScreenName, Utils, Profile, Gameconfig, ScreenMgr, Popup, Text, TrackingMgr, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Node = module.Node;
      Label = module.Label;
      _decorator = module._decorator;
      tween = module.tween;
      Vec3 = module.Vec3;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      EventName = module.EventName;
      ProfileStorageKey = module.ProfileStorageKey;
      ScreenName = module.ScreenName;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _temp;

      cclegacy._RF.push({}, "3e37dpzgTVEopON4SFL1gil", "AddTurn", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["NONE"] = 0] = "NONE";
        State[State["FETCH_DATA"] = 1] = "FETCH_DATA";
        State[State["UPDATE"] = 2] = "UPDATE";
        State[State["REACH_MAX"] = 3] = "REACH_MAX";
      })(State || (State = {}));

      let AddTurn = exports('AddTurn', (_dec = ccclass('AddTurn'), _dec2 = property(Button), _dec3 = property(Button), _dec4 = property(Node), _dec5 = property(Label), _dec6 = property(Label), _dec7 = property(Node), _dec8 = property(Label), _dec9 = property(Node), _dec10 = property(Node), _dec(_class = (_class2 = (_temp = class AddTurn extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnMission", _descriptor, this);

          _initializerDefineProperty(this, "btnTips", _descriptor2, this);

          _initializerDefineProperty(this, "tip", _descriptor3, this);

          _initializerDefineProperty(this, "currentTurnLabel", _descriptor4, this);

          _initializerDefineProperty(this, "countdownTimeLabel", _descriptor5, this);

          _initializerDefineProperty(this, "maxTurnLabel", _descriptor6, this);

          _initializerDefineProperty(this, "tipContentLabel", _descriptor7, this);

          _initializerDefineProperty(this, "loading", _descriptor8, this);

          _initializerDefineProperty(this, "touchInput", _descriptor9, this);

          _defineProperty(this, "targetTimeEarnTurn", 0);

          _defineProperty(this, "_state", State.NONE);
        }

        set State(next) {
          console.log(`${State[this._state]} ->${State[next]}}`);
          this._state = next;

          switch (this._state) {
            case State.FETCH_DATA:
              this.waitingUI();
              GameMgr.Instance.callFetchTurn();
              break;

            case State.UPDATE:
              this.activeUI();
              break;

            case State.REACH_MAX:
              this.deactiveUI();
          }
        }

        start() {
          super.start();
          this.btnMission.node.on("click", this.onMissionClick.bind(this));
          this.btnTips.node.on('click', this.onClickTip.bind(this));
          this.touchInput.on(Node.EventType.TOUCH_START, () => {
            this.tip.active = false;
          });
          let time = Utils.getTimeUnit(Gameconfig.Instance.getTurnTime());
          this.tipContentLabel.string = Text.AddTurnTip.replace('{0}', time).replace('{1}', Gameconfig.Instance.TurnTimerLimit.toString());
        }

        update(dt) {
          switch (this._state) {
            case State.UPDATE:
              let remain = Math.max(0, this.targetTimeEarnTurn - Date.now());
              this.updateRemainTime(remain);

              if (remain <= 0) {
                this.State = State.FETCH_DATA;
              }

              break;
          }
        }

        Show() {
          super.Show();
          this.init();
          gameEvent.on(EventName.OnUpdateTurn, this.onUpdateTurn, this); //first time

          Profile.Instance.getItem(ProfileStorageKey.DisplayedToolTip, value => {
            let displayedToolTip = value;

            if (!displayedToolTip) {
              this.showToolTips();
              Profile.Instance.setItem(ProfileStorageKey.DisplayedToolTip, true);
            }
          });
          this.State = State.FETCH_DATA;
        }

        Hide() {
          super.Hide();
          this.State = State.NONE;
          gameEvent.off(EventName.OnUpdateTurn, this.onUpdateTurn, this);
        }

        onUpdateTurn(resp) {
          if (Profile.Instance.Turn === -1) {
            return;
          }

          this.currentTurnLabel.string = resp.item.balance.toString();

          if (resp.item.timestamp && resp.item.isTiming) {
            this.targetTimeEarnTurn = resp.item.timestamp + Gameconfig.Instance.getTurnTime();
            this.State = State.UPDATE;
          } else {
            this.State = State.REACH_MAX;
          }
        }

        init() {
          this.currentTurnLabel.string = Profile.Instance.Turn.toString();
          this.countdownTimeLabel.node.active = false;
          this.maxTurnLabel.active = false;
          this.tip.active = false;
        }

        activeUI() {
          this.loading.active = false;
          this.countdownTimeLabel.node.active = true;
          this.maxTurnLabel.active = false;
          this.currentTurnLabel.string = Profile.Instance.Turn.toString();
        }

        deactiveUI() {
          this.loading.active = false;
          this.countdownTimeLabel.node.active = false;
          this.maxTurnLabel.active = true;
        }

        waitingUI() {
          this.loading.active = true;
          this.countdownTimeLabel.node.active = false;
          this.maxTurnLabel.active = false;
        }

        updateRemainTime(remain) {
          let seconds = Math.floor(remain / 1000 % 60),
              minutes = Math.floor(remain / (1000 * 60) % 60),
              hours = Math.floor(remain / (1000 * 60 * 60) % 24);
          this.countdownTimeLabel.string = `${hours < 10 ? "0" + hours : hours}:${minutes < 10 ? "0" + minutes : minutes}:${seconds < 10 ? "0" + seconds : seconds}`;
        }

        onMissionClick() {
          this.Hide();
          TrackingMgr.Instance.ClickMissionPopupNoTurn();
          ScreenMgr.Instance.Show(ScreenName.Mission);
        }

        onClickTip() {
          this.tip.active = !this.tip.active;

          if (this.tip.active) {
            this.showToolTips();
          }
        }

        showToolTips() {
          this.tip.active = true;
          tween(this.tip).stop();
          this.tip.setScale(0, 0);
          tween(this.tip).to(0.1, {
            scale: new Vec3(1, 1, 1)
          }, {
            easing: 'bounceOut'
          }).start();
        }

        OnCloseClick() {
          super.OnCloseClick();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnMission", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnTips", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "tip", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "currentTurnLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "countdownTimeLabel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "maxTurnLabel", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "tipContentLabel", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "loading", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "touchInput", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GiftClaim.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts', './Popup.ts', './PopupMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Button, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, GameDefine, PopupName, MySprite, Popup, PopupMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
      PopupName = module.PopupName;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _temp;

      cclegacy._RF.push({}, "45e6fCIcJBEA5x1rBsCCOJ1", "GiftClaim", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var GiftClaimType;

      (function (GiftClaimType) {
        GiftClaimType[GiftClaimType["OK"] = 0] = "OK";
        GiftClaimType[GiftClaimType["YesNo"] = 1] = "YesNo";
      })(GiftClaimType || (GiftClaimType = {}));

      let GiftClaim = exports('GiftClaim', (_dec = ccclass('GiftClaim'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Label), _dec7 = property(MySprite), _dec8 = property(Label), _dec9 = property(Button), _dec10 = property(Button), _dec11 = property(Button), _dec(_class = (_class2 = (_temp = class GiftClaim extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lbTitle", _descriptor, this);

          _initializerDefineProperty(this, "lbDescription", _descriptor2, this);

          _initializerDefineProperty(this, "lbBtnOk", _descriptor3, this);

          _initializerDefineProperty(this, "lbBtnYes", _descriptor4, this);

          _initializerDefineProperty(this, "lbBtnNo", _descriptor5, this);

          _initializerDefineProperty(this, "giftIcon", _descriptor6, this);

          _initializerDefineProperty(this, "giftName", _descriptor7, this);

          _initializerDefineProperty(this, "btOk", _descriptor8, this);

          _initializerDefineProperty(this, "btYes", _descriptor9, this);

          _initializerDefineProperty(this, "btno", _descriptor10, this);

          _defineProperty(this, "okCallback", null);

          _defineProperty(this, "yesCallback", null);

          _defineProperty(this, "noCallback", null);
        }

        start() {
          super.start();
          this.btOk.node.on("click", this.OnOkClick.bind(this));
          this.btYes.node.on("click", this.OnYesClick.bind(this));
          this.btno.node.on("click", this.OnNoClick.bind(this));
        }

        OnOkClick() {
          if (this.okCallback) {
            this.okCallback();
          }

          this.Hide();
        }

        OnYesClick() {
          if (this.yesCallback) {
            this.yesCallback();
          }

          this.Hide();
        }

        OnNoClick() {
          if (this.noCallback) {
            this.noCallback();
          }

          this.Hide();
        }

        SetInfo(title, description, giftIcon, giftName) {
          this.lbTitle.string = title;
          this.lbDescription.string = description;
          this.giftIcon.correctSpriteFrameSize(GameDefine.PROGRESS_GIFT_SIZE);
          this.giftIcon.Fetch(giftIcon);
          this.giftName.string = giftName;
        }

        SetTypeOk(textOk, callback) {
          this.lbBtnOk.string = textOk;
          this.okCallback = callback;
          this.SetType(GiftClaimType.OK);
        }

        SetTypeYesNo(textYes, textNo, yesCallback, noCallback) {
          this.lbBtnNo.string = textNo;
          this.lbBtnYes.string = textYes;
          this.yesCallback = yesCallback;
          this.noCallback = noCallback;
          this.SetType(GiftClaimType.YesNo);
        }

        SetType(type) {
          this.lbBtnNo.node.parent.active = false;
          this.lbBtnYes.node.parent.active = false;
          this.lbBtnOk.node.parent.active = false;

          switch (type) {
            case GiftClaimType.OK:
              this.lbBtnOk.node.parent.active = true;
              break;

            case GiftClaimType.YesNo:
              this.lbBtnNo.node.parent.active = true;
              this.lbBtnYes.node.parent.active = true;
              break;
          }
        }

        static Show(title, description, giftIcon, giftName, onClose = null) {
          if (PopupMgr.Instance) {
            let giftClaim = PopupMgr.Instance.Show(PopupName.GiftClaim, onClose);
            giftClaim.SetInfo(title, description, giftIcon, giftName);
            return giftClaim;
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lbTitle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lbDescription", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnOk", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnYes", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnNo", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "giftIcon", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "giftName", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "btOk", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "btYes", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "btno", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameDefine.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, Color, Size, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Color = module.Color;
      Size = module.Size;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      exports({
        BackgroundName: void 0,
        DevicePerformance: void 0,
        Direction: void 0,
        EventName: void 0,
        EventPlayer: void 0,
        FeatureCode: void 0,
        GiftType: void 0,
        HistoryCellType: void 0,
        IventoryId: void 0,
        KolName: void 0,
        Mission: void 0,
        PopupName: void 0,
        ProfileStorageKey: void 0,
        ProgressGiftStatus: void 0,
        QuestType: void 0,
        RankingType: void 0,
        ScreenName: void 0,
        SoundName: void 0,
        TouchState: void 0
      });

      cclegacy._RF.push({}, "49ae6bXO6tNtK58MjJ4XsZJ", "GameDefine", undefined);

      let ScreenName;

      (function (ScreenName) {
        ScreenName["InGame"] = "InGame";
        ScreenName["EndGame"] = "EndGame";
        ScreenName["Loading"] = "Loading";
        ScreenName["Leaderboard"] = "Leaderboard";
        ScreenName["History"] = "History";
        ScreenName["Mission"] = "Mission";
        ScreenName["AgeGate"] = "AgeGate";
        ScreenName["Progress"] = "Progress";
        ScreenName["Collection"] = "Collection";
      })(ScreenName || (ScreenName = exports('ScreenName', {})));

      let PopupName;

      (function (PopupName) {
        PopupName["MessageBox"] = "MessageBox";
        PopupName["AddTurn"] = "AddTurn";
        PopupName["GiftClaim"] = "GiftClaim";
        PopupName["AgeGatePU"] = "AgeGatePU";
        PopupName["Reward"] = "Reward";
      })(PopupName || (PopupName = exports('PopupName', {})));

      let SoundName;

      (function (SoundName) {
        SoundName["BackgroundMusic"] = "bg";
        SoundName["Jump"] = "landing";
        SoundName["PreJump"] = "prejump";
        SoundName["Dead"] = "die";
        SoundName["Landing"] = "landing";
        SoundName["Spawn"] = "spawn";
        SoundName["Gameover"] = "gameover";
        SoundName["GetGift"] = "gift";
        SoundName["ComboPerfect_1"] = "perfect_x_1";
        SoundName["ComboPerfect_2"] = "perfect_x_2";
        SoundName["ComboPerfect_3"] = "perfect_x_3";
        SoundName["ComboPerfect_4"] = "perfect_x_4";
        SoundName["ComboPerfect_5"] = "perfect_x_5";
        SoundName["Change_Mode"] = "theme_change";
        SoundName["Slap"] = "slap";
      })(SoundName || (SoundName = exports('SoundName', {})));

      let KolName;

      (function (KolName) {
        KolName["kol"] = "kol";
        KolName["kol1"] = "kol1";
        KolName["kol2"] = "kol2";
        KolName["ship"] = "ship";
      })(KolName || (KolName = exports('KolName', {})));

      let BackgroundName;

      (function (BackgroundName) {
        BackgroundName["background"] = "background";
        BackgroundName["background1"] = "background1";
        BackgroundName["background2"] = "background2";
      })(BackgroundName || (BackgroundName = exports('BackgroundName', {})));

      let EventName;

      (function (EventName) {
        EventName["OnUpdateTurn"] = "on-update-turn";
        EventName["OnUpdateUserInfo"] = "on-update-user-info";
        EventName["OnMissionComplete"] = "on-mission-complete";
        EventName["MissionUpdate"] = "mission-update";
        EventName["OnUpdateProgress"] = "on-update-progress";
        EventName["TrackLoadDataLeaderboard"] = "load-leaderboard-success";
        EventName["OnUpdateLabelScoreProgress"] = "on-update-label-score-progress";
      })(EventName || (EventName = exports('EventName', {})));

      let EventPlayer;

      (function (EventPlayer) {
        EventPlayer["OnHold"] = "player-on-hold";
        EventPlayer["OnRelease"] = "player-on-release";
        EventPlayer["OnLanding"] = "player-on-landing";
        EventPlayer["OnLose"] = "player-on-lose";
        EventPlayer["OnWinJumping"] = "on-win-jumping";
        EventPlayer["OnDead"] = "player-on-dead";
      })(EventPlayer || (EventPlayer = exports('EventPlayer', {})));

      let Mission;

      (function (Mission) {
        Mission["ShareFacebook"] = "share_fb";
        Mission["FirstLogin"] = "first_login";
      })(Mission || (Mission = exports('Mission', {})));

      let GiftType;

      (function (GiftType) {
        GiftType["Gift"] = "gift";
        GiftType["Point"] = "point";
      })(GiftType || (GiftType = exports('GiftType', {})));

      let IventoryId;

      (function (IventoryId) {
        IventoryId["tiger_1"] = "tiger_1";
        IventoryId["tiger_2"] = "tiger_2";
        IventoryId["tiger_3"] = "tiger_3";
        IventoryId["tiger_4"] = "tiger_4";
        IventoryId["tiger"] = "tiger";
      })(IventoryId || (IventoryId = exports('IventoryId', {})));

      let DevicePerformance;

      (function (DevicePerformance) {
        DevicePerformance["LowEnd"] = "low-end";
        DevicePerformance["MideEnd"] = "mid-end";
        DevicePerformance["HighEnd"] = "high-end";
      })(DevicePerformance || (DevicePerformance = exports('DevicePerformance', {})));

      let TouchState;

      (function (TouchState) {
        TouchState[TouchState["None"] = 0] = "None";
        TouchState[TouchState["Down"] = 1] = "Down";
        TouchState[TouchState["Press"] = 2] = "Press";
        TouchState[TouchState["Up"] = 3] = "Up";
      })(TouchState || (TouchState = exports('TouchState', {})));

      let Direction;

      (function (Direction) {
        Direction[Direction["Left"] = 0] = "Left";
        Direction[Direction["Right"] = 1] = "Right";
        Direction[Direction["Forward"] = 2] = "Forward";
        Direction[Direction["Backward"] = 3] = "Backward";
      })(Direction || (Direction = exports('Direction', {})));

      let RankingType;

      (function (RankingType) {
        RankingType[RankingType["FriendWeekly"] = 0] = "FriendWeekly";
        RankingType[RankingType["GlobleWeekly"] = 1] = "GlobleWeekly";
        RankingType[RankingType["FriendAll"] = 2] = "FriendAll";
        RankingType[RankingType["GlobleAll"] = 3] = "GlobleAll";
      })(RankingType || (RankingType = exports('RankingType', {})));

      let FeatureCode;

      (function (FeatureCode) {
        FeatureCode["PROFILE_INFO"] = "profile_info";
        FeatureCode["MY_VOUCHERS"] = "my_vouchers";
      })(FeatureCode || (FeatureCode = exports('FeatureCode', {})));

      let HistoryCellType;

      (function (HistoryCellType) {
        HistoryCellType[HistoryCellType["CATEGORY"] = 0] = "CATEGORY";
        HistoryCellType[HistoryCellType["ITEM"] = 1] = "ITEM";
      })(HistoryCellType || (HistoryCellType = exports('HistoryCellType', {})));

      let QuestType;

      (function (QuestType) {
        QuestType["ShareCodeQuest"] = "share_code";
        QuestType["GetCodeQuest"] = "enter_code";
        QuestType["TransferMoney"] = "transfer_p2p";
        QuestType["WatchVideo"] = "watch_video";
        QuestType["ShareFB"] = "share_fb";
        QuestType["Quiz"] = "quiz_test";
        QuestType["EnterActiveCode"] = "enter_code";
        QuestType["QuizFailure"] = "quiz_test_failure";
        QuestType["CashtinTTT"] = "cashin_ttt";
        QuestType["FaceMatching"] = "facematching";
        QuestType["FirstLogin"] = "first_login";
      })(QuestType || (QuestType = exports('QuestType', {})));

      class GameDefine {}

      exports('GameDefine', GameDefine);

      _defineProperty(GameDefine, "HISTORY_LIMIT", 100);

      _defineProperty(GameDefine, "RANKING_LIMIT", 100);

      _defineProperty(GameDefine, "RANK_ITEM_TOP_COLOR", new Color('#FFD6E7'));

      _defineProperty(GameDefine, "RANK_ITEM_ICON_COLOR", new Color('#E22D90'));

      _defineProperty(GameDefine, "RANK_ITEM_NONE_COLOR", new Color('#FFD6E7'));

      _defineProperty(GameDefine, "RANK_AVATAR_SIZE", new Size(80, 80));

      _defineProperty(GameDefine, "INGAME_AVATAR_SIZE", new Size(80, 80));

      _defineProperty(GameDefine, "TOP_RANK_AVATAR_SIZE", new Size(90, 90));

      _defineProperty(GameDefine, "TOP_RANK_AVATAR_SIZE_2", new Size(80, 80));

      _defineProperty(GameDefine, "NORMAL_RANK_AVATAR_SIZE", new Size(60, 60));

      _defineProperty(GameDefine, "PROGRESS_GIFT_SIZE", new Size(54, 54));

      _defineProperty(GameDefine, "POPUP_GIFT_SIZE", new Size(60, 60));

      _defineProperty(GameDefine, "POPUP_REWARD_SIZE", new Size(354, 386));

      _defineProperty(GameDefine, "DROP_BOX_DELAY", 0.5);

      _defineProperty(GameDefine, "MULTIPLY_CHAR", 'x');

      class Default {}

      exports('Default', Default);

      _defineProperty(Default, "ScoreRange", [20, 6, 4, 2, 1]);

      _defineProperty(Default, "RewardScoreList", [100, 200, 300]);

      _defineProperty(Default, "Power", [3.0, 3.0]);

      _defineProperty(Default, "distance", [1.9, 3]);

      _defineProperty(Default, "ComboBonus", [2, 4, 6, 8, 10]);

      class Layer {}

      exports('Layer', Layer);

      _defineProperty(Layer, "Ground", 1 << 0);

      _defineProperty(Layer, "Player", 1 << 1);

      _defineProperty(Layer, "Box", 1 << 2);

      _defineProperty(Layer, "Item", 1 << 3);

      let ProfileStorageKey;

      (function (ProfileStorageKey) {
        ProfileStorageKey["DisplayedToolTip"] = "DisplayedToolTip";
        ProfileStorageKey["IsAgeGateCompete"] = "IsAgeGateCompete";
        ProfileStorageKey["Mode"] = "Mode";
      })(ProfileStorageKey || (ProfileStorageKey = exports('ProfileStorageKey', {})));

      let ProgressGiftStatus;

      (function (ProgressGiftStatus) {
        ProgressGiftStatus["AVAILABLE"] = "AVAILABLE";
        ProgressGiftStatus["OUT_OF_STOCK"] = "OUT_OF_STOCK";
        ProgressGiftStatus["UNAVAILABLE"] = "UNAVAILABLE";
        ProgressGiftStatus["CLAIMED"] = "CLAIMED";
      })(ProgressGiftStatus || (ProgressGiftStatus = exports('ProgressGiftStatus', {})));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/UserHUD.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts', './Api.ts', './Profile.ts', './Gameconfig.ts', './PopupMgr.ts', './TrackingMgr.ts', './PhoneUtils.ts'], function (exports) {
  'use strict';

  var cclegacy, Button, Label, Node, _decorator, Component, gameEvent, _applyDecoratedDescriptor, _initializerDefineProperty, EventName, PopupName, MySprite, Api, Profile, Gameconfig, PopupMgr, TrackingMgr, convertPhoneNumerWithMode;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Button = module.Button;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      EventName = module.EventName;
      PopupName = module.PopupName;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      Api = module.Api;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      convertPhoneNumerWithMode = module.convertPhoneNumerWithMode;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "4ca40A429RMw50kPxvgqoO6", "UserHUD", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let UserHUD = exports('UserHUD', (_dec = ccclass('UserHUD'), _dec2 = property(Button), _dec3 = property(Label), _dec4 = property(Node), _dec5 = property(MySprite), _dec(_class = (_class2 = (_temp = class UserHUD extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "avatarFrameBtn", _descriptor, this);

          _initializerDefineProperty(this, "turn", _descriptor2, this);

          _initializerDefineProperty(this, "avatar", _descriptor3, this);

          _initializerDefineProperty(this, "avatarSprite", _descriptor4, this);
        }

        onLoad() {
          const self = this;
          gameEvent.on(EventName.OnUpdateTurn, resp => {
            const turn = Profile.Instance.Turn;
            if (turn >= 0) self.turn.string = turn.toString() + ' lượt';else self.turn.string = '---';
          });
          gameEvent.on(EventName.OnUpdateUserInfo, data => {
            self.avatarSprite.Fetch(Api.Avatar.replace('{0}', convertPhoneNumerWithMode({
              phone: data.userId
            })));
          });
        }

        start() {
          this.avatarFrameBtn.node.on(Node.EventType.TOUCH_END, this.OnAvatarClick, this);
        }

        OnAvatarClick() {
          TrackingMgr.Instance.ClickTurnHome();

          if (Profile.Instance.iSOk && Gameconfig.Instance.IsLoaded) {
            PopupMgr.Instance.Show(PopupName.AddTurn);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "avatarFrameBtn", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "turn", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "avatar", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "avatarSprite", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/RankView.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Profile.ts', './RankItem.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, ScrollView, UITransform, instantiate, Layout, _defineProperty, GameDefine, Profile, RankItem;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      ScrollView = module.ScrollView;
      UITransform = module.UITransform;
      instantiate = module.instantiate;
      Layout = module.Layout;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      RankItem = module.RankItem;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "4efb8PBJRNMzYNq65gDK2pd", "RankView", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var ScrollViewEvent;

      (function (ScrollViewEvent) {
        ScrollViewEvent[ScrollViewEvent["scrolling"] = 4] = "scrolling";
        ScrollViewEvent[ScrollViewEvent["ScrollEnded"] = 9] = "ScrollEnded";
      })(ScrollViewEvent || (ScrollViewEvent = {}));

      let RankView = exports('RankView', (_dec = ccclass('RankView'), _dec(_class = (_temp = class RankView extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "cellList", []);

          _defineProperty(this, "items", []);

          _defineProperty(this, "model", null);

          _defineProperty(this, "offsetWidth", 190);
        }

        onLoad() {
          let sample = this.getComponent(ScrollView).content.children[0];
          this.offsetWidth = sample.getComponent(UITransform).width;
          this.items.push(sample);

          for (let i = 1; i < GameDefine.RANKING_LIMIT; i++) {
            this.items.push(instantiate(sample));
          }
        }

        loadModel(data) {
          if (this.model != data) {
            let scroll = this.getComponent(ScrollView);
            let content = scroll.content;
            this.model = data;
            this.cellList = [];
            content.removeAllChildren();

            for (let i = 0, size = Math.min(this.items.length, data.items.length); i < size; i++) {
              let nodeItem = this.items[i];
              nodeItem.active = true;
              content.addChild(nodeItem);
              let item = nodeItem.getComponent(RankItem);
              this.cellList.push(item);
              item.loadView(data.items[i], Profile.Instance.isMine(data.items[i].userId));
            }

            content.getComponent(Layout).enabled = true;
            content.getComponent(Layout).updateLayout();
            scroll.scrollToLeft(0);
            content.getComponent(Layout).enabled = false;

            if (this.cellList.length > 0) {
              this.onScroll(scroll, ScrollViewEvent.scrolling);
              this.onScroll(scroll, ScrollViewEvent.ScrollEnded);
            }
          }
        }

        onScroll(scrollView = null, event = null) {
          if (scrollView) {
            switch (event) {
              case ScrollViewEvent.ScrollEnded:
                this.onScrollEnded(scrollView);
                break;

              case ScrollViewEvent.scrolling:
                this.onScrolling(scrollView);
                break;
            }
          }
        }

        onScrolling(scrollView) {
          let scrollViewWidth = scrollView.view.width;
          let itemWidth = this.offsetWidth + scrollView.content.getComponent(Layout).spacingX;
          let maxX = Math.abs(scrollView.getScrollOffset().x);
          let topIndex = Math.max(0, Math.floor(maxX / itemWidth));
          let numberItemShow = Math.ceil(scrollViewWidth / itemWidth);
          scrollView.content.children.forEach((element, index) => {
            if (index < topIndex || index > topIndex + numberItemShow) {
              element.active = false;
            } else {
              element.active = true;
            }
          });
        }

        onScrollEnded(scrollView) {
          for (let i of this.cellList) {
            if (i.node.active && i.canLoadAvatar()) {
              i.LoadAvatar();
            } else {
              i.loadAvatarDefault();
            }
          }
        }

        Reset() {//Utils.destroyAllChild(this.content.node)
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Utils.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, ParticleSystem, Vec3, resources, Prefab, AudioClip, _decorator;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      ParticleSystem = module.ParticleSystem;
      Vec3 = module.Vec3;
      resources = module.resources;
      Prefab = module.Prefab;
      AudioClip = module.AudioClip;
      _decorator = module._decorator;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "524f1gsDoNErLJFctS0Tj+M", "Utils", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Utils = exports('Utils', (_dec = ccclass('Utils'), _dec(_class = class Utils {
        static PlayParticle(paricle) {
          paricle.play();
          let a = paricle.getComponentsInChildren(ParticleSystem);
          a.forEach(element => {
            //if (!element.isPlaying)
            element.play();
          });
        }

        static StopParticle(paricle) {
          paricle.stop();
          let a = paricle.getComponentsInChildren(ParticleSystem);
          a.forEach(element => {
            //if (element.isPlaying)
            element.stop();
          });
        }

        static toLocalString(num) {
          num = Math.round(num);
          return num.toLocaleString().replace(/","/g, ".");
        }

        static formatScore(score) {
          return score.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }

        static cloneObject(data) {
          const keys = Object.keys(data);
          let t = Object.create(null);

          for (let i = 0, size = keys.length; i < size; i++) {
            t[keys[i]] = data[keys[i]];
          }

          return t;
        }

        static getScale(targetSprite, size) {
          const rect = targetSprite.rect;
          let rateX = size.width / rect.width;
          let rateY = size.height / rect.height;
          let target = rateY;
          if (rateX > rateY) target = rateX;
          return target;
        }

        static CorrectSpriteFrameSize(sprite, size) {
          let scale = Utils.getScale(sprite.spriteFrame, size);
          sprite.node.setScale(new Vec3(scale, scale, scale));
        }

        static getUrlVer(url) {
          // return url + "?v=" + Api.VERSION;
          return url;
        }

        static getDate(miliseconds) {
          let d = new Date(miliseconds);

          const pad = s => {
            return s < 10 ? '0' + s : s;
          };

          return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${pad(d.getFullYear())}`;
        }

        static getTime(d) {
          const pad = s => {
            return s < 10 ? '0' + s : s;
          };

          return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
        }

        static getDateTimeVN(d) {
          const pad = s => {
            return s < 10 ? '0' + s : s;
          };

          return `${[pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/')}`;
        }

        static get uuid() {
          var dt = new Date().getTime();
          var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (dt + Math.random() * 16) % 16 | 0;
            dt = Math.floor(dt / 16);
            return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
          });
          return uuid;
        }

        static destroyAllChild(parent) {
          parent.children.forEach(child => {
            child.destroy();
          });
          parent.removeAllChildren();
        }

        static getPrefabRes(path, callback) {
          resources.load(path, Prefab, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        }

        static getAudioRes(path, callback) {
          resources.load(path, AudioClip, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        }

        static getPrefabBoundle(boundle, path, callback) {
          boundle.load(path, Prefab, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        }

        static getAudioBoundle(boundle, path, callback) {
          boundle.load(path, AudioClip, (err, res) => {
            if (err) {
              if (callback) {
                callback(null);
              }

              return;
            }

            if (callback) {
              callback(res);
            }
          });
        } //cheat to bypass circular dependencies


        static setInfoMySprite(mySpriteNode, link) {
          let mySprite = mySpriteNode.getComponent('MySprite');

          if (mySprite) {
            mySprite.Fetch(link);
          }
        }

        static truncate(text, limitWord) {
          let words = text.split(" ");
          if (words.length > limitWord) return words.splice(0, limitWord).join(" ") + "...";
          return text;
        }

        static isUrl(cta) {
          if (cta.startsWith('http') || cta.indexOf('www') === 0) {
            return true;
          }

          return false;
        }

        static milisecondToTime(ms) {
          return {
            seconds: Math.floor(ms / 1000),
            minutes: Math.floor(ms / (1000 * 60)),
            hours: Math.floor(ms / (1000 * 60 * 60))
          };
        }

        static getTimeUnit(ms) {
          const timeOb = Utils.milisecondToTime(ms);

          if (timeOb.hours > 0) {
            return timeOb.hours.toString() + ' Tiếng';
          } else if (timeOb.minutes > 0) {
            return timeOb.minutes.toString() + ' Phút';
          } else {
            return timeOb.seconds.toString() + ' Giây';
          }
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MyButton.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, Vec3, Node, tween, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      Node = module.Node;
      tween = module.tween;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      var _dec, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "55121N6ZJ1F0rv/GR7dwuPA", "MyButton", undefined);

      const {
        ccclass,
        property,
        executeInEditMode
      } = _decorator;
      let MyButton = exports('MyButton', (_dec = ccclass('MyButton'), _dec(_class = (_class2 = (_temp = class MyButton extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "isPlaySound", _descriptor, this);

          _defineProperty(this, "onClick", null);

          _defineProperty(this, "isDone", true);

          _defineProperty(this, "scale", Vec3.ZERO.clone());
        }

        start() {
          this.scale = this.node.scale.clone();
          this.node.on(Node.EventType.TOUCH_START, this._onClick.bind(this));
        }

        _onClick(event) {
          if (this.isDone) {
            this.isDone = false;
            let scale = this.scale;
            let taget = new Vec3();
            Vec3.multiplyScalar(taget, scale, 0.5);
            this.node.setScale(taget);
            tween(this.node).to(0.3, {
              scale
            }, {
              easing: "elasticOut"
            }).call(() => {
              this.isDone = true;

              if (this.onClick) {
                this.onClick();
              }
            }).start();
            if (this.isPlaySound) ;
          } // event.propagationImmediateStopped = true;

        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "isPlaySound", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return true;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ScreenMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './BoxMgr.ts', './Screen.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, _decorator, Component, game, find, resources, instantiate, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, ScreenName, BoxMgr, Screen;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      game = module.game;
      find = module.find;
      resources = module.resources;
      instantiate = module.instantiate;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      ScreenName = module.ScreenName;
    }, function (module) {
      BoxMgr = module.BoxMgr;
    }, function (module) {
      Screen = module.Screen;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _class3, _temp;

      cclegacy._RF.push({}, "613e4KXbZpIVYqI2TneTBBG", "ScreenMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ScreenMgr = exports('ScreenMgr', (_dec = ccclass('ScreenMgr'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class ScreenMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "Container", _descriptor, this);

          _initializerDefineProperty(this, "scenes", _descriptor2, this);
        }

        static get Instance() {
          return this.instance;
        }

        onLoad() {
          ScreenMgr.instance = this;
          game.addPersistRootNode(this.node);
          game.addPersistRootNode(find("Background"));
        }

        start() {
          this.HideAll();
          this.Show(ScreenName.InGame);
        }

        IsShow(name) {
          let scene = this.scenes.find(scene => scene.name == name);
          return scene && scene.active;
        }

        Show(name, button = null) {
          console.log(button);
          this.loadByName(name, scene => {
            if (scene && !scene.active) {
              scene.getComponent(Screen).Show();

              if (button) {
                button.interactable = true;
              }
            }
          });
        }

        public(name) {
          let scene = this.scenes.find(scene => scene.name == name);

          if (scene) {
            scene.getComponent(Screen).Hide();
          }
        }

        Hide(name) {
          let scene = this.scenes.find(scene => scene.name == name);

          if (scene) {
            scene.getComponent(Screen).Hide();
          }
        }

        HideAll() {
          this.scenes.forEach(scene => {
            if (scene.active) {
              scene.getComponent(Screen).Hide();
            }
          });
        }

        LoadCommonUI(callback) {
          let scoreContainer = find('ScoreContainer', this.node);
          resources.loadDir("prefabs/ui/common", (err, prefabs) => {
            for (let prefab of prefabs) {
              let node = instantiate(prefab);
              node.setParent(scoreContainer);
              node.active = true;
            }

            BoxMgr.Instance.load(scoreContainer);
            callback && callback();
          });
        }

        loadByName(screenName, callback) {
          let scene = this.scenes.find(scene => scene.name == screenName);

          if (scene) {
            callback(scene);
            return;
          }

          resources.load("prefabs/screens/" + screenName, (err, prefab) => {
            if (prefab) {
              let scene = instantiate(prefab);
              scene.active = false;
              scene.name = screenName;
              scene.setParent(this.Container);
              this.scenes.push(scene);
              callback(scene);
              console.log("Screen loaded: " + screenName);
            } else {
              console.error("Screen prefab notfound: " + screenName);
            }
          });
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "Container", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scenes", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Api.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      cclegacy._RF.push({}, "6478a4A+/ZPo5+fjQN0Ek1S", "Api", undefined);

      class Api {
        //onboarding
        static LBWeekly(limit) {
          return `${Api.GLOBAL_RANKING}&frequency=NORMAL&limit=${limit}`;
        }

        static LBAll(limit) {
          return `${Api.GLOBAL_RANKING}&frequency=NORMAL&limit=${limit}`; //return `${Api.GLOBAL_RANKING}&frequency=MONTH&limit=${limit}`;
        }

        static LBFriendWeekly(limit) {
          return `${Api.FRIEND_RANKING}&frequency=NORMAL&limit=${limit}`;
        }

        static LBFriendAll(limit) {
          return `${Api.FRIEND_RANKING}&frequency=MONTH&limit=${limit}`;
        }

      }

      exports('Api', Api);

      _defineProperty(Api, "DEBUG_TOKEN", "0362984381"
      /*"0938314514"*/
      );

      _defineProperty(Api, "IS_DEV", !false);

      _defineProperty(Api, "VERSION", "1.0.2");

      _defineProperty(Api, "DEV_HOST", "https://m.dev.mservice.io/");

      _defineProperty(Api, "PROD_HOST", "https://m.mservice.io/");

      _defineProperty(Api, "HOST", Api.IS_DEV ? Api.DEV_HOST : Api.PROD_HOST);

      _defineProperty(Api, "BOUNDLE_HOST", "https://hub.mservice.com.vn/webgame/sound/lacxi2022_momojump/v2");

      _defineProperty(Api, "GAME", "pigjump");

      _defineProperty(Api, "GAME_ID", "vn.momo.web.momojumptiger");

      _defineProperty(Api, "SERVICE_NAME", "pigjump");

      _defineProperty(Api, "APPVARZ_V2", "varz/v2/observe");

      _defineProperty(Api, "Profile", "pigjump-game-logic/v1/get_profile");

      _defineProperty(Api, "GameConfig", "pigjump-config/v1/get_config");

      _defineProperty(Api, "GameTurn", "pigjump-game-logic/v1/turn");

      _defineProperty(Api, "AddTurn", "pigjump-game-logic/v1/add_turn");

      _defineProperty(Api, "SubmitScore", "pigjump-score/v1/submit");

      _defineProperty(Api, "StartGame", "pigjump-game-logic/v1/start");

      _defineProperty(Api, "GameGift", "pigjump-score/v1/get_gift?gameId=");

      _defineProperty(Api, "GiftHistory", "pigjump-score/v1/get_gift_history");

      _defineProperty(Api, "Mission", "gnosis-mission-service/v1/status?game_id=pigjump");

      _defineProperty(Api, "MissionCompleted", "gnosis-mission-service/v1/send-succeeded-event");

      _defineProperty(Api, "Progress", "pigjump-reward-progress/v1/get");

      _defineProperty(Api, "Progress_Claim", "pigjump-reward-progress/v1/claim");

      _defineProperty(Api, "Inventory", "pigjump-game-logic/v1/get_inventory");

      _defineProperty(Api, "Inventory_Claim", "pigjump-game-logic/v1/combine");

      _defineProperty(Api, "Avatar", "https://s3-ap-southeast-1.amazonaws.com/avatars.mservice.io/{0}.png");

      _defineProperty(Api, "DEEP_LINK", `deeplink-universal/v1/content-dynamic`);

      _defineProperty(Api, "OnboardingStatus", 'pigjump-game-logic/v1/onboarding/status');

      _defineProperty(Api, "OnboardingSubmit", 'pigjump-game-logic/v1/onboarding/submit');

      _defineProperty(Api, "FRIEND_RANKING", `${Api.HOST}medalwall/v1/ranking/friends?medal_types=momojump32022_point`);

      _defineProperty(Api, "GLOBAL_RANKING", `${Api.HOST}medalwall/v1/ranking/global?medal_types=momojump32022_point`);

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AssetMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './AudioMgr.ts', './PopupMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, _defineProperty, AudioMgr, PopupMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "67aa1RXrxpDSpvvCVnAeht+", "AssetMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AssetMgr = exports('AssetMgr', (_dec = ccclass('AssetMgr'), _dec(_class = (_temp = _class2 = class AssetMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "isLoaded", false);
        }

        onLoad() {
          AssetMgr.instance = this;
        }

        start() {}

        static get Instance() {
          return AssetMgr.instance;
        }

        Load() {
          // InGame.Instance.loadKol();
          if (this.isLoaded == false) {
            this.isLoaded = true;
            PopupMgr.Instance.Load(() => {
              AudioMgr.Instance.Load();
            }); // ScreenMgr.Instance.Load(()=>{
            //     PopupMgr.Instance.Load(()=>{
            //         AudioMgr.Instance.Load();
            //     });
            // });
          }
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AgeGateMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Profile.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, Node, director, sys, _defineProperty, ProfileStorageKey, Profile;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Node = module.Node;
      director = module.director;
      sys = module.sys;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      ProfileStorageKey = module.ProfileStorageKey;
    }, function (module) {
      Profile = module.Profile;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "6a061OGvg9GyK9n7rjoi2DD", "AgeGateMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AgeGateMgr = exports('AgeGateMgr', (_dec = ccclass('AgeGateMgr'), _dec(_class = (_temp = _class2 = class AgeGateMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "_isComplete", false);
        }

        static get Instance() {
          if (!AgeGateMgr.instance) {
            let node = new Node('OnboardingMgr');
            director.getScene().addChild(node);
            AgeGateMgr.instance = node.addComponent(AgeGateMgr);
          }

          return AgeGateMgr.instance;
        }

        getAgeGateStatus(callback) {
          if (sys.isMobile) {
            Profile.Instance.getItem(ProfileStorageKey.IsAgeGateCompete, value => {
              callback(true, value ? true : false);
            });
          } else {
            callback(true, true);
          }
        }

        isComplete() {
          return this._isComplete;
        }

        setComplete(isComplete) {
          this._isComplete = isComplete;
          Profile.Instance.setItem(ProfileStorageKey.IsAgeGateCompete, isComplete);
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MiniProgress.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Node, _decorator, Component, tween, Quat, random, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, ProgressGiftStatus;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      Quat = module.Quat;
      random = module.random;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      ProgressGiftStatus = module.ProgressGiftStatus;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _temp;

      cclegacy._RF.push({}, "6af89ByZwtGB6myBpb1Jd4a", "MiniProgress", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let MiniProgress = exports('MiniProgress', (_dec = ccclass('MiniProgress'), _dec2 = property(Label), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(Node), _dec6 = property(Node), _dec7 = property(Node), _dec(_class = (_class2 = (_temp = class MiniProgress extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "labelScore", _descriptor, this);

          _initializerDefineProperty(this, "info", _descriptor2, this);

          _initializerDefineProperty(this, "giftClaim", _descriptor3, this);

          _initializerDefineProperty(this, "giftEffect", _descriptor4, this);

          _initializerDefineProperty(this, "gift1", _descriptor5, this);

          _initializerDefineProperty(this, "gift2", _descriptor6, this);

          _defineProperty(this, "tweenEffect", null);

          _defineProperty(this, "tweenShake", null);
        }

        setInfo(data) {
          let currentPoint = data.currentPoint;
          let listMilestone = data.milestones;
          this.labelScore.string = '0';
          let isSetScore = false;
          this.info.active = true;
          this.giftClaim.active = false;
          listMilestone.forEach(element => {
            if (currentPoint < element.targetPoint && isSetScore == false) {
              this.labelScore.string = (element.targetPoint - currentPoint).toString() + " điểm";
              isSetScore = true;
            }

            if (element.status == ProgressGiftStatus.AVAILABLE) {
              this.info.active = false;
              this.giftClaim.active = true;
              this.EffectRotationControl(7);
            }
          });
          this.Shake();
        }

        EffectRotationControl(time) {
          var _this$tweenEffect;

          let angle = this.giftEffect.angle;
          (_this$tweenEffect = this.tweenEffect) === null || _this$tweenEffect === void 0 ? void 0 : _this$tweenEffect.stop();
          this.tweenEffect = tween(this.giftEffect).to(time, {
            angle: angle + 360
          }).set({
            angle: 0
          }).union().repeatForever().start();
        }

        Shake() {
          var _this$tweenShake;

          let rotation1 = this.gift1.rotation.clone();
          let rotation2 = this.gift2.rotation.clone();
          (_this$tweenShake = this.tweenShake) === null || _this$tweenShake === void 0 ? void 0 : _this$tweenShake.stop();
          let quat = new Quat();
          this.tweenShake = tween({
            value: 0
          }).to(0.3, {
            value: 1
          }, {
            onUpdate: (target, ratio) => {
              if (ratio >= 1) {
                if (this.gift1.parent.active) this.gift1.rotation = rotation1;
                if (this.gift2.parent.active) this.gift2.rotation = rotation2;
              } else {
                Quat.fromEuler(quat, 0, 0, (random() - .5) * 10);
                if (this.gift1.parent.active) this.gift1.rotation = quat;
                if (this.gift2.parent.active) this.gift2.rotation = quat;
              }
            }
          }).delay(1.5).union().repeatForever().start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "labelScore", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "info", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "giftClaim", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "giftEffect", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gift1", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "gift2", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameMgr.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './AudioMgr.ts', './Api.ts', './MaxApiUtils.ts', './Profile.ts', './NetworkMgr.ts', './Gameconfig.ts', './BoxMgr.ts', './TrimBase64.ts', './ThemeController.ts', './AgeGateMgr.ts', './Input.ts', './ScoreEffect.ts', './ScreenMgr.ts', './PopupMgr.ts', './TextDefine.ts', './TrackingMgr.ts', './InGame.ts', './OnboardingMgr.ts', './MessageBox.ts', './PlayerController.ts', './GameApi.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, find, dynamicAtlasManager, director, Director, tween, view, resources, Prefab, instantiate, gameEvent, _defineProperty, EventPlayer, ScreenName, SoundName, ProfileStorageKey, PopupName, QuestType, AudioMgr, Api, MaxApiUtils, Profile, NetworkMgr, Gameconfig, BoxMgr, TrimBase64, ThemeController, AgeGateMgr, Input, ScoreEffect, ScreenMgr, PopupMgr, Text, TrackingMgr, InGame, OnboardingMgr, MessageBox, PlayerController, GameApi;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      find = module.find;
      dynamicAtlasManager = module.dynamicAtlasManager;
      director = module.director;
      Director = module.Director;
      tween = module.tween;
      view = module.view;
      resources = module.resources;
      Prefab = module.Prefab;
      instantiate = module.instantiate;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      EventPlayer = module.EventPlayer;
      ScreenName = module.ScreenName;
      SoundName = module.SoundName;
      ProfileStorageKey = module.ProfileStorageKey;
      PopupName = module.PopupName;
      QuestType = module.QuestType;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      Api = module.Api;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      BoxMgr = module.BoxMgr;
    }, function (module) {
      TrimBase64 = module.TrimBase64;
    }, function (module) {
      ThemeController = module.ThemeController;
    }, function (module) {
      AgeGateMgr = module.AgeGateMgr;
    }, function (module) {
      Input = module.Input;
    }, function (module) {
      ScoreEffect = module.ScoreEffect;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      InGame = module.InGame;
    }, function (module) {
      OnboardingMgr = module.OnboardingMgr;
    }, function (module) {
      MessageBox = module.MessageBox;
    }, function (module) {
      PlayerController = module.PlayerController;
    }, function (module) {
      GameApi = module.GameApi;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "6d146Tt/kZC6KzQpSN9ul80", "GameMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var State;

      (function (State) {
        State[State["None"] = 0] = "None";
        State[State["Load"] = 1] = "Load";
        State[State["Init"] = 2] = "Init";
        State[State["CheckToken"] = 3] = "CheckToken";
        State[State["FirstStart"] = 4] = "FirstStart";
        State[State["Onboarding"] = 5] = "Onboarding";
        State[State["GameConfig"] = 6] = "GameConfig";
        State[State["FetchGameTurn"] = 7] = "FetchGameTurn";
        State[State["OutOffTurn"] = 8] = "OutOffTurn";
        State[State["Playing"] = 9] = "Playing";
        State[State["StartGame"] = 10] = "StartGame";
        State[State["EndGame"] = 11] = "EndGame";
        State[State["Complete"] = 12] = "Complete";
        State[State["NetworkError"] = 13] = "NetworkError";
        State[State["AgeGate"] = 14] = "AgeGate";
        State[State["Mode"] = 15] = "Mode";
        State[State["MiniProgressInfo"] = 16] = "MiniProgressInfo";
      })(State || (State = {}));

      let GameMgr = exports('GameMgr', (_dec = ccclass('GameMgr'), _dec(_class = (_temp = _class2 = class GameMgr extends Component {
        constructor() {
          super();

          _defineProperty(this, "state", State.None);

          _defineProperty(this, "prevState", void 0);

          _defineProperty(this, "comboPCounter", 0);

          _defineProperty(this, "comboGCounter", 0);

          _defineProperty(this, "specialBoxCounter", 0);

          _defineProperty(this, "comboMode2Couter", 0);

          _defineProperty(this, "firstStart", true);

          _defineProperty(this, "isPause", false);

          _defineProperty(this, "isCapture", false);

          _defineProperty(this, "captureCallBack", null);

          _defineProperty(this, "time", 0);

          _defineProperty(this, "startTime", Date.now());

          _defineProperty(this, "isFistLoad", true);

          _defineProperty(this, "background", null);

          _defineProperty(this, "isForceOpenAgeGate", false);

          _defineProperty(this, "traceScreenLoadId", "");

          _defineProperty(this, "traceScreenInterractionId", "");

          _defineProperty(this, "traceScreenGoalId", "");

          MaxApiUtils.startTraceScreenLoad("Main", id => {
            this.traceScreenLoadId = id;
          });
          MaxApiUtils.startTraceScreenInteraction("Main", id => {
            this.traceScreenInterractionId = id;
          });
        }

        static get Instance() {
          return GameMgr.instance;
        }

        get ComboGCounter() {
          return this.comboGCounter;
        }

        get CombPCounter() {
          return this.comboPCounter;
        }

        get IsPause() {
          return this.isPause;
        }

        get IsPlaying() {
          return this.state == State.Playing;
        }

        get IsStartGame() {
          return this.state == State.StartGame || this.state == State.OutOffTurn; //cheat for outofturn
        }

        get IsEndGame() {
          return this.state == State.EndGame;
        }

        get IsComplete() {
          return this.state == State.Complete;
        }

        onLoad() {
          this.background = find('Background/background').getComponent(ThemeController);
          dynamicAtlasManager.enabled = false;
        }

        start() {
          console.log("IS_DEV", Api.IS_DEV);

          if (window.OnHideLoading) {
            window.OnHideLoading();
            TrackingMgr.Instance.ShowGameSuccess();
            this.startTime = Date.now();
            MaxApiUtils.stopTrace(this.traceScreenLoadId);
          }

          director.on(Director.EVENT_AFTER_DRAW, this.canvasAfterDraw.bind(this));
          GameMgr.instance = this;
          MaxApiUtils.registerScreenShot(() => {
            console.log('callback screenshot listener');
          });
          this.SetState(State.Load);
          gameEvent.on(EventPlayer.OnLanding, this.onLanding, this);
          gameEvent.on(EventPlayer.OnLose, this.GameOver, this);
        }

        update(dt) {
          switch (this.state) {
            case State.Load:
              break;

            case State.CheckToken:
              this.time += dt;

              if (Profile.Instance.iSOk) {
                if (this.firstStart) {
                  this.SetState(State.AgeGate);
                } else {
                  this.SetState(State.GameConfig);
                }
              } else if (this.time > 3) {
                if (Api.IS_DEV) {
                  Profile.Instance.OnUpdateUserInfo(null);
                } else {
                  this.SetState(State.NetworkError);
                }
              }

              break;

            case State.AgeGate:
              if (this.isForceOpenAgeGate && !ScreenMgr.Instance.IsShow(ScreenName.AgeGate)) {
                ScreenMgr.Instance.Show(ScreenName.AgeGate);
                this.isForceOpenAgeGate = false;
              }

              break;

            case State.OutOffTurn:
              if (Input.Instance.isTouchDown) {
                this.SetState(State.OutOffTurn);
                this.CheckAndShowOutOffTurn();
              }

              break;

            case State.StartGame:
              if (!this.IsPause && Input.Instance.isTouchDown && PlayerController.Instance.isReadyToPlay) {
                this.SetState(State.Playing);
                this.CallStartGame();
                TrackingMgr.Instance.ClickPlayHome();
              }

              break;

            case State.Complete:
              if (!this.IsPause && Input.Instance.isTouchDown) {
                this.SetState(State.Playing);
              }

              break;

            case State.EndGame:
              break;
          }
        }

        get IsOnboarding() {
          return OnboardingMgr.Instance.isComplete() == false;
        }

        OBJumpResult(result, isGreater) {
          if (result) {
            if (BoxMgr.Instance.count >= 4) {
              OnboardingMgr.Instance.postOnBoardingSubmit(resp => {
                if (!resp || resp.response_info.error_code !== 0) ;else {
                  console.log('OB complete');
                }
              });
            }
          }

          InGame.Instance.showTipOnboarding(result, BoxMgr.Instance.count - 1, isGreater);
          console.log(`OB Step ${BoxMgr.Instance.count - 1}: ${result}`);
        }

        onLanding(comboIndex, isSpecialBox) {
          if (comboIndex > -1) {
            let score = Gameconfig.Instance.ScoreRange[comboIndex];
            this.AddScore(score, comboIndex, isSpecialBox);
          } else {
            this.comboPCounter = 0;
            this.comboGCounter = 0;
            this.specialBoxCounter = 0;
            this.comboMode2Couter = 0;
          }
        }

        AddScore(score, level, is_special) {
          let isComplete = false;
          let step = BoxMgr.Instance.count - 1 + BoxMgr.Instance.giftCount;
          let bonus = Gameconfig.Instance.CheckBonus(step);
          let comboBonus = Gameconfig.Instance.CheckComboBonus(level > 0 ? 0 : this.comboPCounter);
          Profile.Instance.Score += score + bonus + comboBonus;

          if (level == 0) {
            this.comboPCounter++;
            this.comboGCounter = 0;
            this.Perfect();
          } else if (level == 1) {
            this.comboGCounter++;
            this.comboPCounter = 0;
            this.comboMode2Couter = 0;
            this.Good();
          } else {
            this.Cool();
            this.comboGCounter = 0;
            this.comboPCounter = 0;
            this.comboMode2Couter = 0;
          }

          let mode = Profile.Instance.Mode;
          let target = Gameconfig.Instance.GetStageTarget(mode);

          if (mode == 0 && Profile.Instance.Score >= target) {
            isComplete = true;
            this.SetState(State.Complete);
          }

          if (mode == 1 && level == 0) {
            this.comboMode2Couter++;

            if (this.comboMode2Couter >= target) {
              isComplete = true;
              this.SetState(State.Complete);
            }
          }

          if (mode == 2 && is_special) {
            this.specialBoxCounter++;

            if (this.specialBoxCounter >= target) {
              isComplete = true;
              this.SetState(State.Complete);
            }
          }

          Profile.Instance.AddScore(step, score, Gameconfig.Instance.HasGift(step), is_special, isComplete);
          InGame.Instance.updateScore(score + bonus + comboBonus);
          BoxMgr.Instance.initFlyScore(score + comboBonus, PlayerController.Instance.platform.position.clone());
        }

        SetState(state) {
          this.prevState = this.state;
          this.state = state;
          console.log("[GameMgr] stage " + State[this.prevState] + " => " + State[this.state]);

          switch (state) {
            case State.Load:
              if (this.isFistLoad) {
                MaxApiUtils.startTraceScreenGoal("Main", id => {
                  this.traceScreenGoalId = id;
                });
                ScreenMgr.Instance.Show(ScreenName.Loading);
                this.load();
                this.isFistLoad = false;
              }

              break;

            case State.Init:
              ScreenMgr.Instance.Show(ScreenName.InGame);
              InGame.Instance.Reset();
              InGame.Instance.setVisible(true);
              BoxMgr.Instance.Reset();
              Profile.Instance.Reset();
              AudioMgr.Instance.PlayMusicWithName(SoundName.BackgroundMusic, true);
              this.Resume();
              this.SetState(State.CheckToken);
              break;

            case State.CheckToken:
              this.time = 0;
              break;

            case State.AgeGate:
              AgeGateMgr.Instance.getAgeGateStatus((result, isComplete) => {
                if (result) {
                  if (isComplete) {
                    GameMgr.Instance.SetState(State.Mode);
                  } else {
                    this.isForceOpenAgeGate = true;
                  }
                } else {
                  this.SetState(State.NetworkError);
                }
              });
              MaxApiUtils.stopTrace(this.traceScreenInterractionId);
              break;

            case State.Mode:
              Profile.Instance.FetchGameMode(mode => {
                if (mode == -1) {
                  this.SetState(State.NetworkError);
                } else {
                  console.log("MODE: " + mode);
                  GameMgr.Instance.SetState(State.Onboarding);
                }
              });
              break;

            case State.Onboarding:
              OnboardingMgr.Instance.getOnbardingStatus(result => {
                if (result) {
                  GameMgr.Instance.SetState(State.GameConfig);
                } else {
                  this.SetState(State.NetworkError);
                }
              });
              break;

            case State.GameConfig:
              if (Gameconfig.Instance.IsLoaded) {
                this.SetState(State.FirstStart);
                this.changeTheme(Profile.Instance.Mode, 3);
                PlayerController.Instance.play();
                this.SetState(State.MiniProgressInfo);
              } else {
                Gameconfig.Instance.Fetch(result => {
                  if (result) {
                    this.SetState(State.FirstStart);
                    this.changeTheme(Profile.Instance.Mode, 3, true);
                    PlayerController.Instance.play();
                    this.SetState(State.MiniProgressInfo);
                  } else {
                    GameMgr.Instance.SetState(State.NetworkError);
                  }
                });
              }

              break;

            case State.MiniProgressInfo:
              this.setInfoMiniProgress();
              break;

            case State.FirstStart:
              if (this.firstStart) {
                GameMgr.Instance.MissionFirstLogin(result => {
                  this.SetState(State.FirstStart);
                });
              } else {
                this.SetState(State.FetchGameTurn);
              }

              this.firstStart = false;
              break;

            case State.FetchGameTurn:
              Profile.Instance.FetchGameTurn(turn => {
                if (turn == -1) {
                  this.SetState(State.NetworkError);
                } else {
                  if (turn < 1) {
                    this.SetState(State.OutOffTurn);
                  } else {
                    this.Resume();
                    this.SetState(State.StartGame);
                  }
                }
              });
              break;

            case State.OutOffTurn:
              this.isPause = true;
              break;

            case State.Playing:
              InGame.Instance.setVisible(false);
              break;

            case State.Complete:
              this.Pause();
              InGame.Instance.setVisibleScore(false);
              Profile.Instance.Mode++;
              Profile.Instance.setItem(ProfileStorageKey.Mode, Profile.Instance.Mode);
              BoxMgr.Instance.ResetCount();
              let delay = 1;
              let timeJump = 3;
              let timePopup = 5;
              let timeChangTheme = 2;
              let timeHideKol = 1.2;
              tween(this.node).delay(delay).call(() => {
                AudioMgr.Instance.PlaySfx(SoundName.Slap);
                PlayerController.Instance.playWinJumping();
              }).delay(timeJump).call(() => {
                PopupMgr.Instance.Show(PopupName.Reward);
                PlayerController.Instance.playIdle();
              }).delay(timePopup).call(() => {
                InGame.Instance.hideKol();
              }).delay(timeHideKol).call(() => {
                AudioMgr.Instance.PlaySfx(SoundName.Change_Mode);
                this.changeTheme(Profile.Instance.Mode, 3);
              }).delay(timeChangTheme).call(() => {
                this.Resume();
              }).start();
              break;

            case State.EndGame:
              MaxApiUtils.stopTrace(this.traceScreenGoalId);
              this.Pause();

              if (!ScreenMgr.Instance.IsShow(ScreenName.EndGame)) {
                ScreenMgr.Instance.HideAll();
                ScreenMgr.Instance.Show(ScreenName.EndGame);
              }

              BoxMgr.Instance.Reset();
              AudioMgr.Instance.Stop();
              AudioMgr.Instance.PlaySfx(SoundName.Gameover);
              TrackingMgr.Instance.PlayerDie();
              break;

            case State.NetworkError:
              this.OnNetworkError();
              break;
          }
        }

        CallStartGame() {
          Profile.Instance.FetchGameID(result => {
            if (!result) {
              this.SetState(State.NetworkError);
            }
          });
        }

        GameOver() {
          this.SetState(State.EndGame);
        }

        Retry() {
          this.node.active = true;
          this.ResetCounter();
          this.SetState(State.Init);
        }

        ResetCounter() {
          this.comboGCounter = 0;
          this.comboPCounter = 0;
          this.specialBoxCounter = 0;
        }

        Pause() {
          this.isPause = true;
        }

        Resume() {
          this.isPause = false;
        }

        RetryNetwork() {
          this.SetState(this.prevState);
        }

        Cool() {
          ScoreEffect.Instance.Cool();
        }

        Good() {
          ScoreEffect.Instance.Good();
        }

        Perfect() {
          ScoreEffect.Instance.Perfect();
        }

        OnNetworkError() {
          let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
          msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
            this.RetryNetwork();
          });
        }

        MissionFirstLogin(callback) {
          let data = {
            game_id: "pigjump",
            mission_id: QuestType.FirstLogin,
            partner_ids: []
          };
          NetworkMgr.postRequest(Api.HOST + Api.MissionCompleted, data, result => {
            callback(result);
          });
        } //just use in AddTurn popup !!!


        callFetchTurn() {
          this.SetState(State.FetchGameTurn);
        } //just use in AgeGate popup !!!


        callOnMode() {
          this.SetState(State.Mode);
        }

        CheckAndShowOutOffTurn() {
          if (Profile.Instance.Turn < 1) {
            TrackingMgr.Instance.ShowPopupNoTurn();

            if (Profile.Instance.iSOk && Gameconfig.Instance.IsLoaded) {
              PopupMgr.Instance.Show(PopupName.AddTurn);
            }
          } else {
            this.Resume();
          }
        }

        canvasAfterDraw() {
          if (this.isCapture) {
            this.isCapture = false;
            let canvas = document.getElementById("GameCanvas");
            var resizedCanvas = document.createElement("canvas");
            var resizedContext = resizedCanvas.getContext("2d");
            let w = view.getVisibleSize().width;
            let h = view.getVisibleSize().height;
            resizedCanvas.width = w;
            resizedCanvas.height = h;
            resizedContext.drawImage(canvas, 0, 0, w, h, 0, 0, w, h);
            let c = TrimBase64.trimCanvas(resizedCanvas);
            let image = c.toDataURL('image/png');
            this.captureCallBack(image);
          }
        }

        captureScreen(callback) {
          this.captureCallBack = callback;
          this.isCapture = true;
        }

        closeGame() {
          MaxApiUtils.goBack();
        }

        showBack() {
          if (GameMgr.Instance.IsPlaying || GameMgr.Instance.IsComplete) {
            let msgBox = MessageBox.Show(Text.ExitGameTitle, Text.ExitGameContent, "", () => {}, 1);
            msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeYesNo(Text.Continues, Text.GiveUp, () => {}, () => {
              Profile.Instance.SubmitScore(Profile.Instance.Score, true, () => {});
              GameMgr.Instance.closeGame();
            });
          } else GameMgr.Instance.closeGame();
        }

        changeTheme(index, time, isFirst = false) {
          this.changeBackground(index, time);
          InGame.Instance.initKol(index, isFirst);
        }

        changeBackground(index, time = 0) {
          if (index == 3) this.background.switchRandom(10, 3);else this.background.setByIndex(index, time);
        }

        setInfoMiniProgress(data = null) {
          if (data) {
            InGame.Instance.setInfoMiniProgress(data);
          } else {
            GameApi.getProgress(value => {
              if (value && value.data) {
                InGame.Instance.setInfoMiniProgress(value.data);
              } else {
                let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
                msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
                  this.setInfoMiniProgress();
                });
              }
            });
          }
        }

        load() {
          resources.loadDir("prefabs/game", Prefab, (err, prefabs) => {
            prefabs.forEach(element => {
              let obj = instantiate(element);
              obj.setParent(this.node);
              console.log("[GameMgr] loaded: " + element.data.name);
            });
            ScreenMgr.instance.LoadCommonUI();
            InGame.Instance.loadKol(() => {
              ScreenMgr.Instance.loadByName(ScreenName.EndGame, () => {});
              ScreenMgr.Instance.loadByName(ScreenName.AgeGate, () => {});
              ScreenMgr.Instance.Hide(ScreenName.Loading);
              this.SetState(State.Init);
            });
          });
          this.background.load();
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PlatformCtrl.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './Profile.ts', './BoxMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Texture2D, _decorator, Component, tween, Vec3, randomRange, randomRangeInt, MeshRenderer, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, Profile, BoxMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Texture2D = module.Texture2D;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      Vec3 = module.Vec3;
      randomRange = module.randomRange;
      randomRangeInt = module.randomRangeInt;
      MeshRenderer = module.MeshRenderer;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      BoxMgr = module.BoxMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "71580NKgklL3r8iOFA5VatK", "PlatformCtrl", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PlatformCtrl = exports('PlatformCtrl', (_dec = ccclass('PlatformCtrl'), _dec2 = property(Texture2D), _dec(_class = (_class2 = (_temp = _class3 = class PlatformCtrl extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "textures", _descriptor, this);

          _defineProperty(this, "effectTween", null);
        }

        onLoad() {
          PlatformCtrl.instance = this;
        }

        init() {
          let node = this.node;
          this.changeColor(Profile.Instance.Mode);
          let {
            dir,
            dist,
            size
          } = BoxMgr.Instance.GetConfig();
          let pos = node.position;
          node.setPosition(pos.x + dir * dist, pos.y, pos.z + (1 - dir) * dist);
          node.setScale(size, 1, size);
          node.children[0].setWorldScale(size + .1, 1, size + .1);
          this.play(size).start();
          let isTransparent = BoxMgr.Instance.spawnGiftOrTransparent(node.position);

          if (isTransparent) {
            // let mat = new Material()
            // mat.copy(this.effect)
            // this.getComponentInChildren(MeshRenderer).setMaterial(mat, 0)
            // this.effect = mat
            // this.effectTween = tween({ value: 1 })
            //     .to(1, { value: 0 }, { 'onUpdate': this.onUpdate.bind(this) })
            //     .to(1, { value: 1 }, { 'onUpdate': this.onUpdate.bind(this) })
            //     .delay(1)
            //     .union().repeatForever().start()
            this.effectTween = tween(node).to(.2, {
              scale: new Vec3(size, 1.2, size)
            }, {
              easing: 'sineIn'
            }).to(.3, {
              scale: new Vec3(size, 0, size)
            }, {
              easing: 'sineOut'
            }).delay(.5).to(.2, {
              scale: new Vec3(size, 1.2, size)
            }, {
              easing: 'sineIn'
            }).to(.3, {
              scale: new Vec3(size, 1, size)
            }, {
              easing: 'sineOut'
            }).delay(1).union().repeatForever().start();
          }
        }

        get isTransparent() {
          return this.node.scale.y < .5;
        }

        stop(alive) {
          if (this.effectTween) {
            this.effectTween.stop();
            let scale = this.node.scale;
            this.node.scale = new Vec3(scale.x, alive ? 1 : 0, scale.z);
          }
        }

        onDestroy() {
          var _this$effectTween;

          (_this$effectTween = this.effectTween) === null || _this$effectTween === void 0 ? void 0 : _this$effectTween.stop();
        } // onUpdate(target: any, ratio: number) {
        //     this.effect.setProperty('alphaThreshold', math.clamp(target.value, 0, 1))
        //     this.node.active = target.value > .1
        // }


        play(size) {
          // new platform appearance
          let node = this.node;
          node.setScale(size, 0, size);
          return tween(node).to(.3, {
            scale: new Vec3(size, 1.2, size)
          }, {
            easing: 'sineIn'
          }).to(.2, {
            scale: new Vec3(size, 1, size)
          }, {
            easing: 'sineOut'
          });
        }

        end(scale, alive) {
          //platform end
          let node = this.node;
          return tween(node).to(.3, {
            scale: new Vec3(scale.x, 1, scale.z)
          }, {
            easing: 'sineOut'
          }).delay(alive ? randomRange(1, 2) : .5).to(.3, {
            scale: new Vec3(scale.x, 1.2, scale.z)
          }, {
            easing: 'sineOut'
          }).to(.2, {
            scale: new Vec3(scale.x, 0, scale.z)
          }, {
            easing: 'sineIn'
          }).call(node.destroy.bind(node));
        }

        changeColor(mode) {
          let index = mode;
          if (mode == 3) index = randomRangeInt(0, 3);
          this.node.children[0].getComponent(MeshRenderer).material.setProperty('mainTexture', this.textures[index]);
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "textures", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/KolController.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './Gameconfig.ts', './AssetMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, UIOpacity, Label, _decorator, Component, Vec3, tween, Quat, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, Gameconfig, AssetMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      UIOpacity = module.UIOpacity;
      Label = module.Label;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      tween = module.tween;
      Quat = module.Quat;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      AssetMgr = module.AssetMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _temp;

      cclegacy._RF.push({}, "785bbdFNEZCcYZrgf9EM/P2", "KolController", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let KolController = exports('KolController', (_dec = ccclass('KolController'), _dec2 = property(UIOpacity), _dec3 = property(UIOpacity), _dec4 = property(UIOpacity), _dec5 = property(UIOpacity), _dec6 = property(UIOpacity), _dec7 = property(UIOpacity), _dec8 = property(UIOpacity), _dec9 = property(UIOpacity), _dec10 = property(UIOpacity), _dec11 = property(UIOpacity), _dec12 = property(Label), _dec(_class = (_class2 = (_temp = class KolController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "kolOpacityComp", _descriptor, this);

          _initializerDefineProperty(this, "speakerEffectOpacityComp", _descriptor2, this);

          _initializerDefineProperty(this, "microEffectOpacityComp", _descriptor3, this);

          _initializerDefineProperty(this, "headphoneEffectOpacityComp", _descriptor4, this);

          _initializerDefineProperty(this, "discEffectOpacityComp", _descriptor5, this);

          _initializerDefineProperty(this, "readerEffectOpacityComp", _descriptor6, this);

          _initializerDefineProperty(this, "glassesEffectOpacityComp", _descriptor7, this);

          _initializerDefineProperty(this, "hangerEffectOpacityComp", _descriptor8, this);

          _initializerDefineProperty(this, "music1EffectOpacityComp", _descriptor9, this);

          _initializerDefineProperty(this, "music2EffectOpacityComp", _descriptor10, this);

          _initializerDefineProperty(this, "title", _descriptor11, this);

          _defineProperty(this, "speakerEffect", null);

          _defineProperty(this, "tweenOpacity", null);

          _defineProperty(this, "tweenScale", null);

          _defineProperty(this, "tweenPosition", null);

          _defineProperty(this, "tweenHorizontal", null);

          _defineProperty(this, "tweenRotation", null);
        }

        onLoad() {
          this.node.active = false;
        }

        setTitle(mode) {
          let target = Gameconfig.Instance.GetStageTarget(mode);

          switch (mode) {
            case 0:
              if (target == -1) target = 100;
              this.title.string = 'Đạt ' + target + ' điểm';
              break;

            case 1:
              if (target == -1) target = 3;
              this.title.string = 'Tuyệt vời ' + target + ' lần liên tiếp';
              break;

            case 2:
              if (target == -1) target = 3;
              this.title.string = 'Vượt ' + target + ' hộp biến hình';
              break;
          }
        }

        startEffect(speakerTime = 0.7) {
          var _this$speakerEffect;

          this.stopEffect();
          this.speakerEffect = this.getEffect(speakerTime);
          (_this$speakerEffect = this.speakerEffect) === null || _this$speakerEffect === void 0 ? void 0 : _this$speakerEffect.start();
        }

        stopEffect() {
          var _this$speakerEffect2;

          (_this$speakerEffect2 = this.speakerEffect) === null || _this$speakerEffect2 === void 0 ? void 0 : _this$speakerEffect2.stop();
        }

        showOut() {
          this.node.active = true;
          const time = 0.1;
          this.stopShow();
          this.startEffect();
          this.node.scale = new Vec3(0.5, 0.5, 0.5);
          this.kolOpacityComp.opacity = 0;
          this.tweenOpacity = tween({
            opacity: 0
          }).to(time * 2, {
            opacity: 150
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "elasticOut"
          }).to(time, {
            opacity: 55
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "quadOut"
          }).to(time * 2, {
            opacity: 200
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "elasticOut"
          }).to(time, {
            opacity: 55
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "quadOut"
          }).to(time * 2, {
            opacity: 255
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "elasticOut"
          });
          this.tweenScale = tween(this.node).to(time * 5, {
            scale: Vec3.ONE
          }, {
            easing: "backOut"
          }).call(() => {
            this.startEffect(0.2);
            this.idle();
            this.tweenOpacity.start();
            AssetMgr.Instance.Load();
          }).start();
        }

        showIn() {
          const time = 0.1;
          this.stopShow();
          this.startEffect();
          this.node.rotation = new Quat(0, 0, 0);
          this.tweenPosition = tween(this.node).by(2, {
            position: new Vec3(0, 85, 0)
          }, {
            easing: "backOut"
          }).call(() => {
            this.startEffect(0.2);
            this.idle();
          });
          this.tweenOpacity = tween({
            opacity: 0
          }).delay(1).to(time * 2, {
            opacity: 150
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "elasticOut"
          }).to(time, {
            opacity: 55
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "quadOut"
          }).to(time * 2, {
            opacity: 200
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "elasticOut"
          }).to(time, {
            opacity: 55
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "quadOut"
          }).to(time, {
            opacity: 255
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "elasticOut"
          }).to(time, {
            opacity: 0
          }, {
            onUpdate: this.updateKolOpacity.bind(this),
            easing: "quadOut"
          }).call(() => {
            this.tweenPosition.start();
          }).start();
        }

        updateKolOpacity(target, ratio) {
          this.kolOpacityComp.opacity = target.opacity;
        }

        idle() {
          let time = 2;
          const y = this.node.position.y;
          let quatRight = new Quat();
          Quat.fromEuler(quatRight, 0, 0, -0.7);
          let quatLeft = new Quat();
          Quat.fromEuler(quatLeft, 0, 0, 0.7);
          this.tweenHorizontal = tween(this.node).to(time, {
            position: new Vec3(0, y + 10, 0)
          }, {
            easing: "quadOut"
          }).to(time, {
            position: new Vec3(-0, y - 10, 0)
          }, {
            easing: "quadOut"
          }).union().repeatForever().start();
          this.tweenRotation = tween(this.node).to(time * 1.5, {
            rotation: quatLeft
          }, {
            easing: "linear"
          }).to(time * 1.5, {
            rotation: quatRight
          }, {
            easing: "linear"
          }).union().repeatForever().start();
        }

        getEffect(time) {
          if (!this.speakerEffectOpacityComp) return null;
          return tween({
            opacity: 50
          }).to(time, {
            opacity: 255
          }, {
            onUpdate: this.updateOpacity.bind(this),
            easing: "sineOut"
          }).to(time, {
            opacity: 50
          }, {
            onUpdate: this.updateOpacity.bind(this),
            easing: "sineIn"
          }).union().repeatForever();
        }

        updateOpacity(target, ratio) {
          if (this.speakerEffectOpacityComp) this.speakerEffectOpacityComp.opacity = target.opacity;
          if (this.microEffectOpacityComp) this.microEffectOpacityComp.opacity = target.opacity;
          if (this.headphoneEffectOpacityComp) this.headphoneEffectOpacityComp.opacity = target.opacity;
          if (this.discEffectOpacityComp) this.discEffectOpacityComp.opacity = target.opacity;
          if (this.readerEffectOpacityComp) this.readerEffectOpacityComp.opacity = target.opacity;
          if (this.glassesEffectOpacityComp) this.glassesEffectOpacityComp.opacity = target.opacity;
          if (this.hangerEffectOpacityComp) this.hangerEffectOpacityComp.opacity = target.opacity;
          if (this.music1EffectOpacityComp) this.music1EffectOpacityComp.opacity = target.opacity;
          if (this.music2EffectOpacityComp) this.music2EffectOpacityComp.opacity = target.opacity;
        }

        stopIdle() {
          var _this$tweenHorizontal, _this$tweenRotation;

          (_this$tweenHorizontal = this.tweenHorizontal) === null || _this$tweenHorizontal === void 0 ? void 0 : _this$tweenHorizontal.stop();
          (_this$tweenRotation = this.tweenRotation) === null || _this$tweenRotation === void 0 ? void 0 : _this$tweenRotation.stop();
        }

        stopShow() {
          var _this$tweenOpacity, _this$tweenScale, _this$tweenPosition;

          (_this$tweenOpacity = this.tweenOpacity) === null || _this$tweenOpacity === void 0 ? void 0 : _this$tweenOpacity.stop();
          (_this$tweenScale = this.tweenScale) === null || _this$tweenScale === void 0 ? void 0 : _this$tweenScale.stop();
          (_this$tweenPosition = this.tweenPosition) === null || _this$tweenPosition === void 0 ? void 0 : _this$tweenPosition.stop();
          this.stopIdle();
        }

        stop() {
          this.stopShow();
          this.stopEffect();
        }

        reset() {
          this.stop();
          this.node.position = Vec3.ZERO;
          this.node.scale = Vec3.ONE;
        }

        hide() {
          var _this$tweenScale2;

          (_this$tweenScale2 = this.tweenScale) === null || _this$tweenScale2 === void 0 ? void 0 : _this$tweenScale2.stop();
          this.tweenScale = tween(this.node).to(1, {
            scale: new Vec3(0, 0, 1)
          }, {
            easing: "elasticIn"
          }).start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "kolOpacityComp", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "speakerEffectOpacityComp", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "microEffectOpacityComp", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "headphoneEffectOpacityComp", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "discEffectOpacityComp", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "readerEffectOpacityComp", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "glassesEffectOpacityComp", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "hangerEffectOpacityComp", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "music1EffectOpacityComp", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "music2EffectOpacityComp", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "title", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LeaderboardTopCell.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './MySprite.ts', './MaxApiUtils.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Mask, _decorator, Component, Node, Vec3, UITransform, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, FeatureCode, GameDefine, Utils, MySprite, MaxApiUtils;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Mask = module.Mask;
      _decorator = module._decorator;
      Component = module.Component;
      Node = module.Node;
      Vec3 = module.Vec3;
      UITransform = module.UITransform;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      FeatureCode = module.FeatureCode;
      GameDefine = module.GameDefine;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      MaxApiUtils = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "790ee9pd81Ar7ZxcDPzWwHP", "LeaderboardTopCell", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let LeaderboardTopCell = exports('LeaderboardTopCell', (_dec = ccclass('LeaderboardTopCell'), _dec2 = property(MySprite), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Mask), _dec(_class = (_class2 = (_temp = class LeaderboardTopCell extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "avatarComponent", _descriptor, this);

          _initializerDefineProperty(this, "userNameLabel", _descriptor2, this);

          _initializerDefineProperty(this, "score", _descriptor3, this);

          _initializerDefineProperty(this, "avatarMask", _descriptor4, this);

          _defineProperty(this, "data", Object.create(null));
        }

        onLoad() {
          this.avatarComponent.node.on(Node.EventType.TOUCH_START, this.onTouchSelf, this);
        }

        loadView(data, rank) {
          this.data = Utils.cloneObject(data);
          this.userNameLabel.string = '';

          if (data.name.length == 0) {
            this.userNameLabel.string = data.userId;
          } else {
            let names = data.name.toUpperCase().split(' ').slice(-2);

            for (let i = 0; i < names.length; i++) {
              this.userNameLabel.string += names[i] + ' ';
            }
          }

          this.score.string = data.point.toString();

          if (rank == 1) {
            this.node.setPosition(new Vec3(0, 40, 0));
          } else if (rank == 2) {
            this.node.setPosition(new Vec3(-235, 0, 0));
          } else if (rank == 3) {
            this.node.setPosition(new Vec3(235, 0, 0));
          }

          this.loadAvatar(rank);
        }

        onTouchSelf(ev) {
          MaxApiUtils.startFeatureCode(FeatureCode.PROFILE_INFO, {
            userId: this.data.userId,
            source: 'webgame_momojump'
          }, () => {});
        }

        setAvatar(spriteFrame) {
          this.avatarComponent.setSprite(spriteFrame);
        }

        loadAvatar(rank) {
          if (rank == 1) {
            this.avatarMask.getComponent(UITransform).setContentSize(GameDefine.TOP_RANK_AVATAR_SIZE);
          } else {
            this.avatarMask.getComponent(UITransform).setContentSize(GameDefine.TOP_RANK_AVATAR_SIZE_2);
          }

          this.avatarComponent.correctSpriteFrameSize(GameDefine.TOP_RANK_AVATAR_SIZE);
          if (this.data.avatarUrl && this.data.avatarUrl.length > 0) this.avatarComponent.Fetch(this.data.avatarUrl);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "avatarComponent", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "userNameLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "score", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "avatarMask", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MissionCell.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './MySprite.ts', './MaxApiUtils.ts', './TextDefine.ts', './TrackingMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Button, Node, _decorator, Component, UITransform, LabelComponent, Widget, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, MySprite, MaxApiUtils, Text, TrackingMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Button = module.Button;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      UITransform = module.UITransform;
      LabelComponent = module.LabelComponent;
      Widget = module.Widget;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _temp;

      cclegacy._RF.push({}, "7e72dLdh7BFHYw/BVS42bwn", "MissionCell", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let MissionCell = exports('MissionCell', (_dec = ccclass('MissionCell'), _dec2 = property(MySprite), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Button), _dec7 = property(Node), _dec8 = property(MySprite), _dec9 = property(Label), _dec10 = property(Node), _dec(_class = (_class2 = (_temp = class MissionCell extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "missionIcon", _descriptor, this);

          _initializerDefineProperty(this, "titleLabel", _descriptor2, this);

          _initializerDefineProperty(this, "descLabel", _descriptor3, this);

          _initializerDefineProperty(this, "counterLabel", _descriptor4, this);

          _initializerDefineProperty(this, "actionButton", _descriptor5, this);

          _initializerDefineProperty(this, "completeNode", _descriptor6, this);

          _initializerDefineProperty(this, "giftIcon", _descriptor7, this);

          _initializerDefineProperty(this, "giftDescription", _descriptor8, this);

          _initializerDefineProperty(this, "containerDesAndTitle", _descriptor9, this);

          _defineProperty(this, "data", null);

          _defineProperty(this, "onCTAClickCallback", null);

          _defineProperty(this, "originalHeight", null);
        }

        start() {
          this.actionButton.node.on('click', this.onCTAClick.bind(this));
          this.originalHeight = this.getComponent(UITransform).height;
        }

        resetCell() {
          this.getComponent(UITransform).height = this.originalHeight;
        }

        setInfo(data, ctaCallback) {
          this.data = data;
          this.resetCell();
          this.onCTAClickCallback = ctaCallback;
          this.titleLabel.string = data.missionInfo.title;
          this.descLabel.string = data.missionInfo.description;
          this.updateStatusActionButton();

          if (this.data.missionInfo.ctaText) {
            let lb = this.actionButton.getComponentInChildren(LabelComponent);

            if (lb) {
              lb.string = data.missionInfo.ctaText;
            }
          }

          this.completeNode.active = data.isCompleted;

          if (data.missionInfo.icon && data.missionInfo.icon.length > 0) {
            this.missionIcon.Fetch(data.missionInfo.icon);
          }

          this.counterLabel.string = '';
          if (data.missionInfo.progressData) this.counterLabel.string = data.missionInfo.progressData;
          let rewardInfo = this.parseRewardInfo(data);
          this.giftDescription.string = rewardInfo.name;

          if (rewardInfo.icon && rewardInfo.icon.length > 0) {
            this.giftIcon.Fetch(rewardInfo.icon);
          }

          this.descLabel.updateRenderData(true);
          this.getComponent(UITransform).height = this.containerDesAndTitle.getComponent(UITransform).height + 50;
          this.actionButton.node.getComponent(Widget).updateAlignment();
          this.giftIcon.node.getComponent(Widget).updateAlignment();
        }

        parseRewardInfo(mission) {
          var _mission$succeededCou, _mission$succeededCou2;

          let rewards = ((_mission$succeededCou = mission.succeededCounter[0]) === null || _mission$succeededCou === void 0 ? void 0 : (_mission$succeededCou2 = _mission$succeededCou.rewardConditions[0]) === null || _mission$succeededCou2 === void 0 ? void 0 : _mission$succeededCou2.rewards) || [];
          if (rewards && rewards.length > 0) return {
            name: rewards[0].actionInfo.name || '',
            icon: rewards[0].actionInfo.icon || '',
            amount: rewards[0].actionInfo.amount || 0
          };
          return {
            name: "",
            icon: "",
            amount: 0
          };
        }

        onTouchCopyCode(ev) {
          MaxApiUtils.copyToClipboard("MOMO" + this.data.missionInfo.code, Text.Copied);
        }

        updateStatusActionButton() {
          this.actionButton.node.active = !this.data.isCompleted;
        }

        onCTAClick() {
          TrackingMgr.Instance.ClickCTAMission();

          if (this.onCTAClickCallback) {
            this.onCTAClickCallback(this.data);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "missionIcon", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "titleLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "descLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "counterLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "actionButton", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "completeNode", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "giftIcon", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "giftDescription", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "containerDesAndTitle", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/HistoryScrollView.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './GiftHistoryCell.ts'], function (exports) {
  'use strict';

  var cclegacy, Prefab, Node, _decorator, ScrollView, NodePool, instantiate, Label, Layout, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, HistoryCellType, GameDefine, Utils, GiftHistoryCell;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      Node = module.Node;
      _decorator = module._decorator;
      ScrollView = module.ScrollView;
      NodePool = module.NodePool;
      instantiate = module.instantiate;
      Label = module.Label;
      Layout = module.Layout;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      HistoryCellType = module.HistoryCellType;
      GameDefine = module.GameDefine;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      GiftHistoryCell = module.GiftHistoryCell;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "82ebfdH/PNGVpHuQX2EH3lD", "HistoryScrollView", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let HistoryScrollView = exports('HistoryScrollView', (_dec = ccclass('HistoryScrollView'), _dec2 = property(Prefab), _dec3 = property(Prefab), _dec4 = property(Prefab), _dec5 = property(Node), _dec(_class = (_class2 = (_temp = class HistoryScrollView extends ScrollView {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "cellTemplate", _descriptor, this);

          _initializerDefineProperty(this, "categoryTemplate", _descriptor2, this);

          _initializerDefineProperty(this, "line", _descriptor3, this);

          _initializerDefineProperty(this, "emptyNode", _descriptor4, this);

          _defineProperty(this, "pools", new Map([[HistoryCellType.CATEGORY, new NodePool()], [HistoryCellType.ITEM, new NodePool()]]));
        }

        onLoad() {
          for (let i = 0; i < GameDefine.HISTORY_LIMIT; i++) {
            this.pools.get(HistoryCellType.ITEM).put(instantiate(this.cellTemplate));

            if (i < 4) {
              this.pools.get(HistoryCellType.CATEGORY).put(instantiate(this.categoryTemplate));
            }
          }
        }

        loadView(items) {
          if (items.length === 0) {
            this.setVisibleEmpty(true);
            return;
          }

          let mapItem = new Map();
          let list = items.sort((cur, prev) => parseInt(prev.timestamp) - parseInt(cur.timestamp));
          list = list.slice(0, GameDefine.HISTORY_LIMIT);
          list.map(it => {
            if (it.timestamp) {
              let d = Utils.getDate(parseInt(it.timestamp));

              if (mapItem.has(d) === false) {
                mapItem.set(d, [it]);
              } else {
                mapItem.get(d).push(it);
              }
            }
          });
          const self = this;
          mapItem.forEach((acc, key, map) => {
            let category = self.getOrCreate(HistoryCellType.CATEGORY);
            let lb = category.getComponentInChildren(Label);

            if (lb) {
              lb.string = "Ngày " + key;
            }

            self.content.addChild(category);
            acc.forEach(it => {
              let cellNode = self.getOrCreate(HistoryCellType.ITEM).getComponent(GiftHistoryCell);
              cellNode.node.parent = self.content;
              cellNode.loadView(it);
            });
            let line = instantiate(self.line);
            self.content.addChild(line);
          });
          this.content.getComponent(Layout).updateLayout();
          this.setVisibleEmpty(false);
        }

        getOrCreate(type) {
          let pool = this.pools.get(type) || null;

          if (pool && pool.size() > 0) {
            return pool.get();
          }

          switch (type) {
            case HistoryCellType.CATEGORY:
              return instantiate(this.categoryTemplate);

            case HistoryCellType.ITEM:
            default:
              return instantiate(this.cellTemplate);
          }
        }

        put(node, type) {
          this.pools.get(type).put(node);
        }

        setVisibleEmpty(isVisible) {
          this.emptyNode.active = isVisible;
        }

        clear() {
          for (let i = this.content.children.length - 1; i >= 0; i--) {
            let children = this.content.children[i];

            if (children.name == this.line.data.name) {
              this.content.removeChild(children);
              children.destroy();
              continue;
            }

            let type = children.getComponent(GiftHistoryCell) ? HistoryCellType.ITEM : HistoryCellType.CATEGORY;
            this.put(children, type);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cellTemplate", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "categoryTemplate", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "line", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "emptyNode", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ThinhJumpEffect.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './Profile.ts'], function (exports) {
  'use strict';

  var cclegacy, ParticleSystem, _decorator, Component, sys, gameEvent, _applyDecoratedDescriptor, _initializerDefineProperty, DevicePerformance, EventPlayer, Utils, Profile;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      ParticleSystem = module.ParticleSystem;
      _decorator = module._decorator;
      Component = module.Component;
      sys = module.sys;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      DevicePerformance = module.DevicePerformance;
      EventPlayer = module.EventPlayer;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      Profile = module.Profile;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp;

      cclegacy._RF.push({}, "877d21G6VxJ3LuJaSuwCohs", "ThinhJumpEffect", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ThinhJumpEffect = exports('ThinhJumpEffect', (_dec = ccclass('ThinhJumpEffect'), _dec2 = property(ParticleSystem), _dec3 = property(ParticleSystem), _dec4 = property(ParticleSystem), _dec5 = property(ParticleSystem), _dec6 = property(ParticleSystem), _dec(_class = (_class2 = (_temp = class ThinhJumpEffect extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "powerEffect", _descriptor, this);

          _initializerDefineProperty(this, "landingEffect", _descriptor2, this);

          _initializerDefineProperty(this, "fireworkEffect1", _descriptor3, this);

          _initializerDefineProperty(this, "fireworkEffect2", _descriptor4, this);

          _initializerDefineProperty(this, "deadEffect", _descriptor5, this);
        }

        start() {
          if (!sys.isMobile || Profile.Instance.DevicePerformance == DevicePerformance.HighEnd || Profile.Instance.DevicePerformance == DevicePerformance.MideEnd) {
            gameEvent.on(EventPlayer.OnHold, this.onHold, this);
            gameEvent.on(EventPlayer.OnRelease, this.onRelease, this);
            gameEvent.on(EventPlayer.OnLanding, this.Landing, this);
            gameEvent.on(EventPlayer.OnLose, this.onLose, this);
            gameEvent.on(EventPlayer.OnWinJumping, this.playFirework, this);
            gameEvent.on(EventPlayer.OnDead, this.onDead, this);
          } else {
            this.node.destroy();
          }
        }

        onDestroy() {
          gameEvent.targetOff(this);
        }

        onHold() {
          this.ShowPowerEffect(true);
        }

        onRelease() {
          this.ShowPowerEffect(false);
        }

        onLose() {
          this.ShowPowerEffect(false);
        }

        onDead() {
          this.playDeadAnim();
        }

        ShowPowerEffect(value) {
          this.fireworkEffect1.node.parent.active = false;

          if (value) {
            this.powerEffect.node.active = true;
            Utils.PlayParticle(this.powerEffect);
          } else {
            this.powerEffect.node.active = false;
            Utils.StopParticle(this.powerEffect);
          }
        }

        Landing(comboIndex) {
          if (comboIndex == -1) return;
          this.landingEffect.play();
        }

        playFirework() {
          this.fireworkEffect1.node.parent.active = true;
          this.fireworkEffect1.play();
          this.fireworkEffect2.play();
        }

        playDeadAnim() {
          Utils.PlayParticle(this.deadEffect);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "powerEffect", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "landingEffect", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "fireworkEffect1", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "fireworkEffect2", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "deadEffect", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TrailEffect.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, Vec3, _decorator, Component, tween, randomRange, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Vec3 = module.Vec3;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      randomRange = module.randomRange;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "947fd/NX95IkKpvqzkTau43", "TrailEffect", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let TrailEffect = exports('TrailEffect', (_dec = ccclass('TrailEffect'), _dec2 = property(Vec3), _dec(_class = (_class2 = (_temp = class TrailEffect extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "size", _descriptor, this);

          _defineProperty(this, "pos", new Vec3(0, 300, 0));

          _defineProperty(this, "offset", void 0);
        }

        start() {
          const time = 1.5;
          this.offset = this.node.position.clone();
          tween(this.node).call(this.drop.bind(this)).delay(randomRange(0, 2)).to(time, {
            scale: Vec3.ONE,
            position: this.pos
          }, {
            easing: "linear"
          }).union().repeatForever().start();
        }

        drop() {
          this.node.scale = new Vec3(1, 0.3, 0.3);
          this.pos.x = this.offset.x + randomRange(-this.size.x, this.size.x);
          this.pos.y = this.offset.y + randomRange(this.size.y, this.size.y * 2);
          this.node.position = new Vec3(this.pos.x, this.offset.y, this.offset.z);
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "size", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/History.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MaxApiUtils.ts', './Profile.ts', './Screen.ts', './ScreenMgr.ts', './TextDefine.ts', './MessageBox.ts', './GameApi.ts', './GameMgr.ts', './Rotation.ts', './HistoryScrollView.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, UITransform, Button, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, ScreenName, FeatureCode, MaxApiUtils, Profile, Screen, ScreenMgr, Text, MessageBox, GameApi, GameMgr, Rotation, HistoryScrollView;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      UITransform = module.UITransform;
      Button = module.Button;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      ScreenName = module.ScreenName;
      FeatureCode = module.FeatureCode;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      MessageBox = module.MessageBox;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      GameMgr = module.GameMgr;
    }, function (module) {
      Rotation = module.Rotation;
    }, function (module) {
      HistoryScrollView = module.HistoryScrollView;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _temp;

      cclegacy._RF.push({}, "9ba65KDrqdAJo39p50Tx/d7", "History", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let History = exports('History', (_dec = ccclass('History'), _dec2 = property(Node), _dec3 = property(HistoryScrollView), _dec4 = property(Rotation), _dec5 = property(UITransform), _dec6 = property(Button), _dec7 = property(Button), _dec(_class = (_class2 = (_temp = class History extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnBack", _descriptor, this);

          _initializerDefineProperty(this, "scrollView", _descriptor2, this);

          _initializerDefineProperty(this, "loading", _descriptor3, this);

          _initializerDefineProperty(this, "bg", _descriptor4, this);

          _initializerDefineProperty(this, "btnWatchMode", _descriptor5, this);

          _initializerDefineProperty(this, "btnUseGift", _descriptor6, this);

          _defineProperty(this, "isLoading", false);

          _defineProperty(this, "data", null);
        }

        start() {
          this.btnBack.on("click", this.OnBackClick.bind(this));
          this.btnUseGift.node.on("click", this.OnUseGiftClick.bind(this)); // this.btnWatchMode.node.on('click', this.OnWatchMoreClick.bind(this));
          // this.btnWatchMode.node.active = false;
        }

        Show() {
          super.Show();
          this.LoadInfo();
        }

        LoadInfo() {
          const self = this;

          if (!self.isLoading) {
            if (self.data == null) {
              self.loading.node.active = true;
            }

            self.isLoading = true;
            GameApi.getGiftHistory(100, 0, value => {
              if (value) {
                self.SetInfo(value);
              } else {
                let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
                msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
                  self.LoadInfo();
                });
              }

              self.loading.node.active = false;
              self.isLoading = false;
            });
          }
        }

        Hide() {
          super.Hide();

          if (GameMgr.Instance.IsEndGame) {
            GameMgr.Instance.Retry();
          }
        }

        OnBackClick() {
          ScreenMgr.Instance.Hide(ScreenName.History);
        }

        OnWatchMoreClick() {
          let currentViewSize = this.scrollView.view.contentSize.clone();
          let currentBgSize = this.bg.contentSize.clone();
          const contentMinY = Math.max(50, this.scrollView.content.worldPosition.y - this.scrollView.content.getComponent(UITransform).height);
          const maxView = this.scrollView.view.node.worldPosition.y - contentMinY - 30;
          const maxBgSize = this.bg.node.worldPosition.y - contentMinY;
          const offset = 200;
          currentViewSize.height = Math.min(offset + currentViewSize.height, maxView);
          currentBgSize.height = Math.min(offset + currentBgSize.height, maxBgSize);
          this.scrollView.view.setContentSize(currentViewSize);
          this.bg.setContentSize(currentBgSize);
          this.btnWatchMode.node.setWorldPosition(this.bg.node.worldPosition.x, this.bg.node.worldPosition.y - currentBgSize.height + 10, 0);
        }

        OnUseGiftClick() {
          MaxApiUtils.startFeatureCode(FeatureCode.MY_VOUCHERS, {
            userId: Profile.Instance.UserID,
            source: Profile.Instance.GameID
          }, () => {});
        }

        SetInfo(historyList) {
          if (this.data != historyList) {
            this.data = historyList;
            this.scrollView.clear();
            this.scrollView.loadView(historyList.items);
          }

          this.btnUseGift.node.active = historyList.items.length > 0;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnBack", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scrollView", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "loading", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bg", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "btnWatchMode", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "btnUseGift", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Reward.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts', './Profile.ts', './Gameconfig.ts', './Popup.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Node, _decorator, Quat, tween, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, GameDefine, MySprite, Profile, Gameconfig, Popup;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
      Quat = module.Quat;
      tween = module.tween;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      Popup = module.Popup;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _temp;

      cclegacy._RF.push({}, "9e359o2UYJP0bxu6KzU6hEN", "Reward", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Reward = exports('Reward', (_dec = ccclass('Reward'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(MySprite), _dec5 = property(Label), _dec6 = property(Node), _dec7 = property(Node), _dec8 = property(Node), _dec(_class = (_class2 = (_temp = class Reward extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "rewardName", _descriptor, this);

          _initializerDefineProperty(this, "timer", _descriptor2, this);

          _initializerDefineProperty(this, "rewardImage", _descriptor3, this);

          _initializerDefineProperty(this, "amout", _descriptor4, this);

          _initializerDefineProperty(this, "mask", _descriptor5, this);

          _initializerDefineProperty(this, "border", _descriptor6, this);

          _initializerDefineProperty(this, "light", _descriptor7, this);

          _defineProperty(this, "reward", null);
        }

        Show() {
          let mode = Profile.Instance.Mode;
          this.reward = Gameconfig.Instance.GetInventoryById("tiger_" + mode);
          super.Show();
          this.rewardName.string = this.reward.itemName;
          this.rewardImage.correctSpriteFrameSize(GameDefine.POPUP_REWARD_SIZE);
          this.rewardImage.Fetch(this.reward.image);
          this.amout.string = mode.toString();
          this.effectLight();
          let rotation = new Quat();
          let rotation1 = new Quat();

          if (mode == 2) {
            Quat.fromEuler(rotation, 0, 0, 90);
            Quat.fromEuler(rotation1, 0, 0, -90);
          }

          if (mode == 3) {
            Quat.fromEuler(rotation, 0, 0, 270);
            Quat.fromEuler(rotation1, 0, 0, -270);
          }

          if (mode == 2 || mode == 3) {
            this.mask.setRotation(rotation1);
            this.border.setRotation(rotation1);
            this.rewardImage.node.setRotation(rotation);
            this.amout.node.setRotation(rotation);
          }

          let timeleft = 5;
          this.timer.string = timeleft.toString();
          let downloadTimer = setInterval(() => {
            this.timer.string = timeleft.toString();

            if (timeleft <= 0) {
              this.Hide();
              clearInterval(downloadTimer);
            }

            timeleft -= 1;
          }, 1000);
        }

        Hide() {
          super.Hide();
        }

        effectLight() {
          let angle = this.light.angle;
          tween(this.light).to(20, {
            angle: angle + 360
          }).set({
            angle: 0
          }).union().repeatForever().start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rewardName", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "timer", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "rewardImage", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "amout", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "mask", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "border", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "light", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LeaderboardCell.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './MySprite.ts', './MaxApiUtils.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Sprite, _decorator, Component, Node, UITransform, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, FeatureCode, GameDefine, Utils, MySprite, MaxApiUtils;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Component = module.Component;
      Node = module.Node;
      UITransform = module.UITransform;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      FeatureCode = module.FeatureCode;
      GameDefine = module.GameDefine;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      MaxApiUtils = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _temp;

      cclegacy._RF.push({}, "a06edkV/E1MPIDesTqDdtlH", "LeaderboardCell", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let LeaderboardCell = exports('LeaderboardCell', (_dec = ccclass('LeaderboardCell'), _dec2 = property(MySprite), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Sprite), _dec7 = property(Sprite), _dec(_class = (_class2 = (_temp = class LeaderboardCell extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "avatarComponent", _descriptor, this);

          _initializerDefineProperty(this, "userNameLabel", _descriptor2, this);

          _initializerDefineProperty(this, "scoreLabel", _descriptor3, this);

          _initializerDefineProperty(this, "rankLabel", _descriptor4, this);

          _initializerDefineProperty(this, "bgCell", _descriptor5, this);

          _initializerDefineProperty(this, "bgMine", _descriptor6, this);

          _defineProperty(this, "rect", null);

          _defineProperty(this, "data", Object.create(null));
        }

        onLoad() {
          this.avatarComponent.node.on(Node.EventType.TOUCH_END, this.onTouchSelf, this);
        }

        loadView(data) {
          this.rect = this.node.getComponent(UITransform);
          this.data = Utils.cloneObject(data);

          if (data.name.length === 0) {
            this.userNameLabel.string = data.userId;
          } else {
            this.userNameLabel.string = data.name.toUpperCase();
          }

          this.bgMine.node.active = false;
          this.scoreLabel.string = data.point.toString();
          this.setRankDisplay();
        }

        layoutMineCell() {
          this.bgCell.node.active = false;
          this.bgMine.node.active = true;
        }

        onTouchSelf(ev) {
          MaxApiUtils.startFeatureCode(FeatureCode.PROFILE_INFO, {
            userId: this.data.userId,
            source: 'webgame_momojump'
          }, () => {});
        }

        setRankDisplay() {
          if (this.data.rank > 100 || this.data.rank < 0) {
            this.rankLabel.string = '100+';
          } else {
            this.rankLabel.string = this.data.rank.toString();
          }
        }

        canLoadAvatar() {
          return this.data.avatarUrl && this.data.avatarUrl.length > 0;
        }

        setAvatar(spriteFrame) {
          this.avatarComponent.setSprite(spriteFrame);
        }

        loadAvatar() {
          this.avatarComponent.correctSpriteFrameSize(GameDefine.NORMAL_RANK_AVATAR_SIZE);
          this.avatarComponent.Fetch(this.data.avatarUrl);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "avatarComponent", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "userNameLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "scoreLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "rankLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "bgCell", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "bgMine", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TrimBase64.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, _decorator;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "a07e2DW8LVCBpcxg7AG7wTC", "TrimBase64", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let TrimBase64 = exports('TrimBase64', (_dec = ccclass('TrimBase64'), _dec(_class = class TrimBase64 {
        static trimCanvas(c) {
          var ctx = c.getContext('2d'),
              copy = document.createElement('canvas').getContext('2d'),
              pixels = ctx.getImageData(0, 0, c.width, c.height),
              l = pixels.data.length,
              i,
              bound = {
            top: null,
            left: null,
            right: null,
            bottom: null
          },
              x,
              y;

          for (i = 0; i < l; i += 4) {
            if (pixels.data[i + 3] !== 0) {
              x = i / 4 % c.width;
              y = ~~(i / 4 / c.width);

              if (bound.top === null) {
                bound.top = y;
              }

              if (bound.left === null) {
                bound.left = x;
              } else if (x < bound.left) {
                bound.left = x;
              }

              if (bound.right === null) {
                bound.right = x;
              } else if (bound.right < x) {
                bound.right = x;
              }

              if (bound.bottom === null) {
                bound.bottom = y;
              } else if (bound.bottom < y) {
                bound.bottom = y;
              }
            }
          }

          var trimHeight = bound.bottom - bound.top + 1,
              trimWidth = bound.right - bound.left + 1,
              trimmed = ctx.getImageData(bound.left, bound.top, trimWidth, trimHeight);
          copy.canvas.width = trimWidth;
          copy.canvas.height = trimHeight;
          copy.putImageData(trimmed, 0, 0); // open new window with trimmed image:

          return copy.canvas;
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Loading.ts", ['cc', './Screen.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Screen;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      Screen = module.Screen;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "a0ca4ril05Do6f8vPERy1A4", "Loading", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Loading = exports('Loading', (_dec = ccclass('Loading'), _dec(_class = class Loading extends Screen {}) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MusicEffect.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, Vec3, UIOpacity, CCFloat, _decorator, Component, tween, randomRange, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Vec3 = module.Vec3;
      UIOpacity = module.UIOpacity;
      CCFloat = module.CCFloat;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      randomRange = module.randomRange;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "a1c64VL/5dP2qKI/l5UTGBM", "MusicEffect", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let MusicEffect = exports('MusicEffect', (_dec = ccclass('MusicEffect'), _dec2 = property(Vec3), _dec3 = property(Vec3), _dec4 = property(UIOpacity), _dec5 = property(CCFloat), _dec(_class = (_class2 = (_temp = class MusicEffect extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "size", _descriptor, this);

          _initializerDefineProperty(this, "pos", _descriptor2, this);

          _initializerDefineProperty(this, "opacityComp", _descriptor3, this);

          _defineProperty(this, "offset", void 0);

          _initializerDefineProperty(this, "time", _descriptor4, this);
        }

        start() {
          this.offset = this.node.position.clone();
          tween(this.node).call(this.fly.bind(this)).call(this.fade.bind(this)).to(this.time, {
            position: this.pos
          }, {
            easing: "sineIn"
          }).delay(this.time / 2).union().repeatForever().start();
        }

        fly() {
          this.opacityComp.opacity = 255;
          this.pos.x = this.offset.x + randomRange(-this.size.x, this.size.x);
          this.node.position = new Vec3(this.pos.x, this.offset.y + randomRange(-this.size.y, this.size.y), 0);
        }

        fade() {
          tween({
            opacity: 255
          }).to(this.time, {
            opacity: 0
          }, {
            onUpdate: (target, ratio) => {
              this.opacityComp.opacity = target.opacity;
            },
            easing: "sineIn"
          }).start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "size", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "pos", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3(0, 0, 0);
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "opacityComp", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "time", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 2;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/SoundBtn.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './AudioMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, SpriteFrame, Sprite, _decorator, Component, _applyDecoratedDescriptor, _initializerDefineProperty, AudioMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      SpriteFrame = module.SpriteFrame;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "a7736Zo30pFHa4ObS0l9YZf", "SoundBtn", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let SoundBtn = exports('SoundBtn', (_dec = ccclass('SoundBtn'), _dec2 = property(SpriteFrame), _dec3 = property(SpriteFrame), _dec4 = property(Sprite), _dec(_class = (_class2 = (_temp = class SoundBtn extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "spriteOn", _descriptor, this);

          _initializerDefineProperty(this, "spriteOff", _descriptor2, this);

          _initializerDefineProperty(this, "btnSprite", _descriptor3, this);
        }

        start() {
          this.node.on("click", this.OnClick, this);
        }

        OnClick() {
          this.btnSprite.spriteFrame = AudioMgr.Instance.IsEnable ? this.spriteOn : this.spriteOff;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "spriteOn", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "spriteOff", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnSprite", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/InGame.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './AudioMgr.ts', './MaxApiUtils.ts', './Profile.ts', './Gameconfig.ts', './Screen.ts', './ScreenMgr.ts', './KolController.ts', './ShipController.ts', './MyButton.ts', './TextDefine.ts', './TrackingMgr.ts', './Onboarding.ts', './UserHUD.ts', './MiniProgress.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, Label, _decorator, tween, resources, instantiate, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, ScreenName, ProfileStorageKey, KolName, AudioMgr, MaxApiUtils, Profile, Gameconfig, Screen, ScreenMgr, KolController, ShipController, MyButton, Text, TrackingMgr, Onboarding, UserHUD, MiniProgress, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      Label = module.Label;
      _decorator = module._decorator;
      tween = module.tween;
      resources = module.resources;
      instantiate = module.instantiate;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      ScreenName = module.ScreenName;
      ProfileStorageKey = module.ProfileStorageKey;
      KolName = module.KolName;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      KolController = module.KolController;
    }, function (module) {
      ShipController = module.ShipController;
    }, function (module) {
      MyButton = module.MyButton;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      Onboarding = module.Onboarding;
    }, function (module) {
      UserHUD = module.UserHUD;
    }, function (module) {
      MiniProgress = module.MiniProgress;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _dec16, _dec17, _dec18, _dec19, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _descriptor16, _descriptor17, _descriptor18, _class3, _temp;

      cclegacy._RF.push({}, "a7db0n8ZptOpIqyJnP1Lj7Y", "InGame", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let InGame = exports('InGame', (_dec = ccclass('InGame'), _dec2 = property(MyButton), _dec3 = property(MyButton), _dec4 = property(MyButton), _dec5 = property(MyButton), _dec6 = property(MyButton), _dec7 = property(MyButton), _dec8 = property(MyButton), _dec9 = property(MyButton), _dec10 = property(Node), _dec11 = property(Node), _dec12 = property(Node), _dec13 = property(Label), _dec14 = property(UserHUD), _dec15 = property(Node), _dec16 = property(Onboarding), _dec17 = property(Node), _dec18 = property(Node), _dec19 = property(MiniProgress), _dec(_class = (_class2 = (_temp = _class3 = class InGame extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnleaderBoard", _descriptor, this);

          _initializerDefineProperty(this, "btnHistory", _descriptor2, this);

          _initializerDefineProperty(this, "btnMission", _descriptor3, this);

          _initializerDefineProperty(this, "btnEvent", _descriptor4, this);

          _initializerDefineProperty(this, "btnCollection", _descriptor5, this);

          _initializerDefineProperty(this, "btnSound", _descriptor6, this);

          _initializerDefineProperty(this, "btnTutorial", _descriptor7, this);

          _initializerDefineProperty(this, "btnCloseGame", _descriptor8, this);

          _initializerDefineProperty(this, "tutorial", _descriptor9, this);

          _initializerDefineProperty(this, "hideTutorial", _descriptor10, this);

          _initializerDefineProperty(this, "groupScore", _descriptor11, this);

          _initializerDefineProperty(this, "score", _descriptor12, this);

          _initializerDefineProperty(this, "userHUD", _descriptor13, this);

          _initializerDefineProperty(this, "btnLayout", _descriptor14, this);

          _initializerDefineProperty(this, "onboarding", _descriptor15, this);

          _initializerDefineProperty(this, "shipHoder", _descriptor16, this);

          _initializerDefineProperty(this, "kolHoder", _descriptor17, this);

          _initializerDefineProperty(this, "miniProgress", _descriptor18, this);

          _defineProperty(this, "shipController", null);

          _defineProperty(this, "kolPrefabs", void 0);

          _defineProperty(this, "kolController", null);

          _defineProperty(this, "kolIndex", -1);

          _defineProperty(this, "tweenScore", null);

          _defineProperty(this, "buttonLayoutPositionOriginal", void 0);
        }

        onLoad() {
          InGame.instance = this;
        }

        start() {
          this.node.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
          this.btnHistory.node.on("click", this.OnHistoryClick, this);
          this.btnleaderBoard.node.on("click", this.OnLeaderboardClick, this);
          this.btnEvent.node.on("click", this.OnEventClick, this);
          this.btnSound.node.on("click", this.OnSoundClick, this);
          this.btnMission.node.on("click", this.OnMissionClick, this);
          this.btnCollection.node.on("click", this.OnCollectionClick, this);
          this.btnTutorial.node.on("click", this.OnTutorialClick, this);
          this.btnCloseGame.node.on("click", this.onClickCloseGame, this);
          this.miniProgress.node.on("click", this.onMiniProgressClick, this);
          this.buttonLayoutPositionOriginal = this.btnLayout.position.clone();
        }

        onTouchStart(ev) {
          this.onboarding.node.active = false;
        }

        onClickCloseGame() {
          TrackingMgr.Instance.ClickBackHome();
          GameMgr.Instance.showBack();
        }

        static get Instance() {
          return InGame.instance;
        }

        get IsOk() {
          return Profile.Instance.iSOk;
        }

        get IsPlaying() {
          return GameMgr.Instance.IsPlaying;
        }

        OnHistoryClick(button) {
          TrackingMgr.Instance.ClickGiftHome();

          if (this.IsOk && !ScreenMgr.Instance.IsShow(ScreenName.History)) {
            button.interactable = false;
            ScreenMgr.Instance.Show(ScreenName.History, button);
          } else if (this.IsPlaying) {
            MaxApiUtils.showToast(Text.ToastBusy);
          }
        }

        OnLeaderboardClick(button) {
          TrackingMgr.Instance.ClickLeaderBoardHome();

          if (this.IsOk && !ScreenMgr.Instance.IsShow(ScreenName.Leaderboard)) {
            button.interactable = false;
            ScreenMgr.Instance.Show(ScreenName.Leaderboard, button);
          } else if (this.IsPlaying) {
            MaxApiUtils.showToast(Text.ToastBusy);
          }
        }

        OnCollectionClick(button) {
          TrackingMgr.Instance.ClickGiftHunt();

          if (this.IsOk && Gameconfig.Instance.IsLoaded && !ScreenMgr.Instance.IsShow(ScreenName.Collection)) {
            button.interactable = false;
            ScreenMgr.Instance.Show(ScreenName.Collection, button);
          } else if (this.IsPlaying) {
            MaxApiUtils.showToast(Text.ToastBusy);
          }
        }

        onMiniProgressClick(button) {
          TrackingMgr.Instance.ClickMileStone();

          if (this.IsOk && !ScreenMgr.Instance.IsShow(ScreenName.Progress)) {
            button.interactable = false;
            ScreenMgr.Instance.Show(ScreenName.Progress, button);
          } else if (this.IsPlaying) {
            MaxApiUtils.showToast(Text.ToastBusy);
          }
        }

        OnMissionClick(button) {
          if (this.IsOk && !ScreenMgr.Instance.IsShow(ScreenName.Mission)) {
            button.interactable = false;
            ScreenMgr.Instance.Show(ScreenName.Mission, button);
          } else if (this.IsPlaying) {
            MaxApiUtils.showToast(Text.ToastBusy);
          }
        }

        OnEventClick() {
          TrackingMgr.Instance.ClickEventHome();
          MaxApiUtils.openWeb(Gameconfig.Instance.EventLink);
        }

        OnSoundClick() {
          TrackingMgr.Instance.ClickSoundHome();
          AudioMgr.Instance.NextStatus();
        }

        OnTutorialClick() {
          const isVisible = !this.tutorial.active;
          this.tutorial.active = isVisible;
          this.hideTutorial.active = isVisible;
          this.groupScore.active = !isVisible; // this.handTutorial.active = !isVisible;
        }

        OnHideTutorial() {
          if (this.tutorial.active) {
            this.tutorial.active = false;
            this.hideTutorial.active = false;
          }

          this.groupScore.active = true;
        }

        updateScore(score) {
          if (this.tweenScore) {
            this.tweenScore.stop();
          }

          const speed = 15; //score per seconds

          const time = Math.min(1, score / speed);
          this.tweenScore = tween({
            value: parseInt(this.score.string) || 0
          }).to(time, {
            value: Profile.Instance.Score
          }, {
            onUpdate: (target, ratio) => {
              this.score.string = Math.floor(target.value).toString();
            }
          }).call(() => {
            this.score.string = Profile.Instance.Score.toString();
          });
          this.tweenScore.start();
        }

        showTipOnboarding(isJumpSuccess, textIndex, isGreater) {
          if (isJumpSuccess) {
            this.onboarding.successJump(textIndex);
          } else {
            this.onboarding.failJump(isGreater);
          }

          this.onboarding.node.active = true;
        }

        setVisible(isVisible) {
          // this.btnLayout.active = isVisible;
          this.setVisibleButtonLayout(isVisible);
          this.userHUD.node.active = isVisible; // this.handTutorial.active = isVisible;

          this.miniProgress.node.active = isVisible;
          this.setVisibleScore(!isVisible);

          if (!isVisible) {
            if (this.kolIndex == 3) {
              var _this$shipController;

              (_this$shipController = this.shipController) === null || _this$shipController === void 0 ? void 0 : _this$shipController.flyUp();
            } else {
              var _this$kolController;

              (_this$kolController = this.kolController) === null || _this$kolController === void 0 ? void 0 : _this$kolController.showIn();
            }
          }
        }

        setVisibleButtonLayout(isVisible) {
          if (isVisible) {
            this.btnLayout.setPosition(this.buttonLayoutPositionOriginal);
          } else {
            this.btnLayout.setPosition(this.buttonLayoutPositionOriginal.clone().add3f(0, -140, 0));
          }

          this.btnCollection.node.active = isVisible;
          this.btnEvent.node.active = isVisible;
          this.btnHistory.node.active = isVisible;
          this.btnMission.node.active = isVisible;
          this.btnleaderBoard.node.active = isVisible;
        }

        setVisibleScore(isVisible) {
          setTimeout(() => {
            this.groupScore.active = isVisible;
          }, isVisible ? 2000 : 0);
        }

        Reset() {
          this.updateScore(0);
        }

        loadKol(callback) {
          this.kolPrefabs = [];
          let count = 0;
          let array = Object.keys(KolName);
          array.forEach((element, index) => {
            resources.load("prefabs/ui/kols/" + element, (err, prefab) => {
              if (prefab) {
                this.kolPrefabs[index] = prefab;
                count++;
                console.log("Kol prefab loaded: " + element);

                if (count >= array.length) {
                  Profile.Instance.getItem(ProfileStorageKey.Mode, value => {
                    let mode = null;

                    if (value != null && value != '') {
                      console.log("MODE IN STORAGE: " + value);
                      mode = value;
                    } else {
                      mode = 0;
                    }

                    this.initKol(mode);
                    callback();
                    if (mode != 3) GameMgr.Instance.changeBackground(mode);
                  });
                }
              } else {
                console.error("Kol prefab notfound: " + element);
              }
            });
          });
        }

        initShip(isFirst = false) {
          if (this.shipController) {
            if (!isFirst) {
              this.shipController.reset();
              this.shipController.flyDown();
            }
          } else {
            if (isFirst) {
              this.hideKol();
            }

            setTimeout(() => {
              this.shipHoder.children.forEach(child => {
                child.active = false;
              });
              this.shipHoder.removeAllChildren();
              let ship = instantiate(this.kolPrefabs[3]);
              this.shipController = ship.getComponent(ShipController);
              this.shipHoder.addChild(ship);
              this.shipController.flyDown();
            }, isFirst ? 1200 : 0);
          }
        }

        initKol(index, isFirst = false) {
          console.log("[INIT KOL] " + index);

          if (index == 3) {
            this.kolIndex = index;
            this.initShip(isFirst);
            return;
          }

          if (this.kolIndex == index) {
            if (!isFirst) {
              this.kolController.reset();
              this.kolController.showOut();
            }

            this.kolController.setTitle(index);
          } else {
            if (isFirst) {
              this.hideKol();

              if (this.shipController) {
                this.shipController.node.active = false;
                this.shipController = null;
              }
            }

            setTimeout(() => {
              this.kolIndex = index;
              this.kolHoder.children.forEach(child => {
                child.active = false;
              });
              this.kolHoder.removeAllChildren();
              let kol = instantiate(this.kolPrefabs[index]);
              this.kolController = kol.getComponent(KolController);
              this.kolHoder.addChild(kol);
              this.kolController.showOut();
              this.kolController.setTitle(index);
              console.log("[INIT KOL DONE] " + index);
            }, isFirst ? 1200 : 0);
          }
        }

        hideKol() {
          var _this$kolController2;

          (_this$kolController2 = this.kolController) === null || _this$kolController2 === void 0 ? void 0 : _this$kolController2.hide();
        }

        setInfoMiniProgress(data) {
          this.miniProgress.setInfo(data);
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnleaderBoard", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnHistory", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnMission", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btnEvent", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "btnCollection", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "btnSound", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "btnTutorial", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "btnCloseGame", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "tutorial", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "hideTutorial", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "groupScore", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "score", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "userHUD", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "btnLayout", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor15 = _applyDecoratedDescriptor(_class2.prototype, "onboarding", [_dec16], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor16 = _applyDecoratedDescriptor(_class2.prototype, "shipHoder", [_dec17], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor17 = _applyDecoratedDescriptor(_class2.prototype, "kolHoder", [_dec18], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor18 = _applyDecoratedDescriptor(_class2.prototype, "miniProgress", [_dec19], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ProgressGiftItem.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './TextDefine.ts', './GameApi.ts', './ProgressGiftCell.ts', './GiftClaim.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, Button, Prefab, _decorator, Component, instantiate, gameEvent, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, ProgressGiftStatus, EventName, Text, GameApi, ProgressGiftCell, GiftClaim;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      Button = module.Button;
      Prefab = module.Prefab;
      _decorator = module._decorator;
      Component = module.Component;
      instantiate = module.instantiate;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      ProgressGiftStatus = module.ProgressGiftStatus;
      EventName = module.EventName;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      ProgressGiftCell = module.ProgressGiftCell;
    }, function (module) {
      GiftClaim = module.GiftClaim;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "a8c49Dym1ZCmrcKrveCTM/q", "ProgressGiftItem", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ProgressGiftItem = exports('ProgressGiftItem', (_dec = ccclass('ProgressGiftItem'), _dec2 = property(Node), _dec3 = property(Button), _dec4 = property(Prefab), _dec5 = property(Node), _dec(_class = (_class2 = (_temp = class ProgressGiftItem extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "background", _descriptor, this);

          _initializerDefineProperty(this, "btnReceive", _descriptor2, this);

          _initializerDefineProperty(this, "progressCell", _descriptor3, this);

          _initializerDefineProperty(this, "container", _descriptor4, this);

          _defineProperty(this, "isClaiming", false);

          _defineProperty(this, "progressItem", null);
        }

        start() {
          this.setEvent();
        }

        loadView(milestone) {
          this.container.removeAllChildren();
          this.progressItem = milestone;
          const cell = instantiate(this.progressCell);
          this.container.addChild(cell);
          cell.getComponent(ProgressGiftCell).loadView(milestone);

          if (milestone.status != ProgressGiftStatus.AVAILABLE) {
            this.btnReceive.node.active = false;
          } else {
            this.btnReceive.node.active = true;
          }
        }

        setEvent() {
          this.btnReceive.node.on('click', this.onClaimItem, this);
        }

        onClaimItem() {
          let giftClaim = GiftClaim.Show(Text.ClaimGift, Text.ClaimGiftContent, this.progressItem.rewards[0].icon, this.progressItem.rewards[0].title);
          giftClaim.SetTypeYesNo(Text.Confirm, Text.Back, () => {
            this.onReceiveItem();
          }, () => {});
        }

        onReceiveItem() {
          const self = this;

          if (self.progressItem && !self.isClaiming) {
            self.btnReceive.node.active = false;
            self.isClaiming = true;
            GameApi.postClaimProgressReward({
              milestoneId: self.progressItem.milestoneId,
              rewardId: self.progressItem.rewards[0].rewardId
            }, response => {
              if (response && response.result) {
                gameEvent.emit(EventName.OnUpdateProgress);
              } else {
                self.onReceiveError();
                self.btnReceive.node.active = true;
              }

              self.isClaiming = false;
            });
          }
        }

        onReceiveError() {
          let giftClaim = GiftClaim.Show(Text.ClaimGiftLate, Text.OutOfGift, this.progressItem.rewards[0].icon, this.progressItem.rewards[0].title, () => {
            gameEvent.emit(EventName.OnUpdateProgress);
          });
          giftClaim.SetTypeOk(Text.BackAfter, () => {
            gameEvent.emit(EventName.OnUpdateProgress);
          });
        }

        getBackgroundPosition() {
          return this.background.position;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "background", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnReceive", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "progressCell", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MessageBox.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './NetworkMgr.ts', './Popup.ts', './PopupMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Sprite, Button, SpriteFrame, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, PopupName, NetworkMgr, Popup, PopupMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Sprite = module.Sprite;
      Button = module.Button;
      SpriteFrame = module.SpriteFrame;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      PopupName = module.PopupName;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }, function (module) {
      Popup = module.Popup;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _temp;

      cclegacy._RF.push({}, "aa4dbR79mdBM4DbTw+iqAVC", "MessageBox", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var MsgBoxType;

      (function (MsgBoxType) {
        MsgBoxType[MsgBoxType["OK"] = 0] = "OK";
        MsgBoxType[MsgBoxType["YesNo"] = 1] = "YesNo";
      })(MsgBoxType || (MsgBoxType = {}));

      let MessageBox = exports('MessageBox', (_dec = ccclass('MessageBox'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Label), _dec7 = property(Sprite), _dec8 = property(Button), _dec9 = property(Button), _dec10 = property(Button), _dec11 = property(SpriteFrame), _dec(_class = (_class2 = (_temp = class MessageBox extends Popup {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lbTitle", _descriptor, this);

          _initializerDefineProperty(this, "lbDescription", _descriptor2, this);

          _initializerDefineProperty(this, "lbBtnOk", _descriptor3, this);

          _initializerDefineProperty(this, "lbBtnYes", _descriptor4, this);

          _initializerDefineProperty(this, "lbBtnNo", _descriptor5, this);

          _initializerDefineProperty(this, "iconSprite", _descriptor6, this);

          _initializerDefineProperty(this, "btOk", _descriptor7, this);

          _initializerDefineProperty(this, "btYes", _descriptor8, this);

          _initializerDefineProperty(this, "btno", _descriptor9, this);

          _initializerDefineProperty(this, "listSprites", _descriptor10, this);

          _defineProperty(this, "okCallback", null);

          _defineProperty(this, "yesCallback", null);

          _defineProperty(this, "noCallback", null);

          _defineProperty(this, "type", MsgBoxType.OK);
        }

        start() {
          super.start();
          this.btOk.node.on("click", this.OnOkClick.bind(this));
          this.btYes.node.on("click", this.OnYesClick.bind(this));
          this.btno.node.on("click", this.OnNoClick.bind(this));
        }

        OnOkClick() {
          if (this.okCallback) {
            this.okCallback();
          }

          this.Hide();
        }

        OnYesClick() {
          if (this.yesCallback) {
            this.yesCallback();
          }

          this.Hide();
        }

        OnNoClick() {
          if (this.noCallback) {
            this.noCallback();
          }

          this.Hide();
        }

        SetInfo(title, description, image, spriteIndex) {
          this.lbTitle.string = title;
          this.lbDescription.string = description;

          if (spriteIndex > -1) {
            this.iconSprite.spriteFrame = this.listSprites[spriteIndex];
          } else {
            if (this.iconSprite && image && image != "") {
              NetworkMgr.geSpriteFrameAsync(image).then(result => {
                if (result) {
                  this.iconSprite.spriteFrame = result;
                }
              }).catch(e => {
                console.warn(e);
              });
            }
          }
        }

        SetTypeOk(textOk, callback) {
          this.lbBtnOk.string = textOk;
          this.okCallback = callback;
          this.SetType(MsgBoxType.OK);
        }

        SetTypeYesNo(textYes, textNo, yesCallback, noCallback) {
          this.lbBtnNo.string = textNo;
          this.lbBtnYes.string = textYes;
          this.yesCallback = yesCallback;
          this.noCallback = noCallback;
          this.SetType(MsgBoxType.YesNo);
        }

        SetType(type) {
          this.btno.node.active = false;
          this.btYes.node.active = false;
          this.btOk.node.active = false;

          switch (type) {
            case MsgBoxType.OK:
              this.btOk.node.active = true;
              break;

            case MsgBoxType.YesNo:
              this.btno.node.active = true;
              this.btYes.node.active = true;
              break;
          }
        }

        static Show(title, description, image = "", onClose = null, spriteIndex = -1) {
          if (PopupMgr.Instance) {
            let msgBox = PopupMgr.Instance.Show(PopupName.MessageBox, onClose);
            msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetInfo(title, description, image, spriteIndex);
            return msgBox;
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lbTitle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lbDescription", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnOk", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnYes", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "lbBtnNo", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "iconSprite", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "btOk", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "btYes", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "btno", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "listSprites", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AgeGate.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts', './AgeGateMgr.ts', './Screen.ts', './PopupMgr.ts', './MyButton.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, PopupName, MySprite, AgeGateMgr, Screen, PopupMgr, MyButton, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      PopupName = module.PopupName;
    }, function (module) {
      MySprite = module.MySprite;
    }, function (module) {
      AgeGateMgr = module.AgeGateMgr;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      MyButton = module.MyButton;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp;

      cclegacy._RF.push({}, "ad68evm+59COYCtA5CICLOR", "AgeGate", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AgeGate = exports('AgeGate', (_dec = ccclass('AgeGate'), _dec2 = property(MyButton), _dec3 = property(MyButton), _dec4 = property(MyButton), _dec5 = property(MySprite), _dec(_class = (_class2 = (_temp = class AgeGate extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "btnOK", _descriptor, this);

          _initializerDefineProperty(this, "btnNO", _descriptor2, this);

          _initializerDefineProperty(this, "btnClose", _descriptor3, this);

          _initializerDefineProperty(this, "bg", _descriptor4, this);
        }

        start() {
          this.btnOK.node.on("click", this.onOkClick, this);
          this.btnNO.node.on("click", this.onNoClick, this);
          this.btnClose.node.on("click", this.onCloseClick, this);
          this.load();
        }

        load() {
          this.bg.load("agegate/bg");
        }

        onOkClick() {
          GameMgr.Instance.callOnMode();
          AgeGateMgr.Instance.setComplete(true);
          this.Hide();
        }

        onNoClick() {
          PopupMgr.Instance.Show(PopupName.AgeGatePU, () => {});
        }

        onCloseClick() {
          GameMgr.Instance.closeGame();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnOK", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btnNO", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnClose", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bg", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Onboarding.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './TrackingMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Node, _decorator, Component, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, TrackingMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "ae2baDNU/dP9Lc1VadRZ26Y", "Onboarding", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Onboarding = exports('Onboarding', (_dec = ccclass('Onboarding'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Node), _dec(_class = (_class2 = (_temp = class Onboarding extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "title", _descriptor, this);

          _initializerDefineProperty(this, "desc", _descriptor2, this);

          _initializerDefineProperty(this, "container", _descriptor3, this);

          _defineProperty(this, "SUCCESS_JUMPS", [['Giậm nhảy thành công', 'Càng gần tâm điểm sẽ càng cao.'], ['Cú nhảy Tuyệt Vời', 'Tiếp tục phát huy nhé!'], ['Bạn thật xuất sắc!', 'Tiếp tục nhảy bật nhận quà nhé.']]);

          _defineProperty(this, "BadJumpTitle", 'Lực nhảy quá nhẹ');

          _defineProperty(this, "BadJump", 'Chạm và giữ tay lâu hơn để tạo đủ lực nhảy. Nhảy trúng hộp điểm thưởng về tay!');

          _defineProperty(this, "StrongJumpTitle", 'Lực nhảy quá mạnh');

          _defineProperty(this, "StrongJump", 'Hãy giữ tay nhẹ hơn để tạo lực vừa đủ. Nhảy trúng hộp chắc chắn có điểm!');

          _defineProperty(this, "FailJump", 'Chạm và giữ tay trên màn hình để lấy đà, giữ càng lâu để nhảy càng xa. Thả ra để nhảy.');
        }

        loadView(title, desc) {
          this.node.active = true;
          this.title.string = title;
          this.desc.string = desc;
          TrackingMgr.Instance.ShowPopupOnboarding();
        }

        successJump(textIndex) {
          console.log("INDEX" + textIndex);
          this.container.active = true;
          this.loadView(this.SUCCESS_JUMPS[Math.min(2, textIndex - 1)][0], this.SUCCESS_JUMPS[Math.min(2, textIndex - 1)][1]);
        }

        failJump(isGreater) {
          this.container.active = true;

          if (!isGreater) {
            this.loadView(this.BadJumpTitle, this.FailJump);
          } else {
            this.loadView(this.StrongJumpTitle, this.FailJump);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "title", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "desc", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Screen.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, Component, _decorator;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Component = module.Component;
      _decorator = module._decorator;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "b07eezZ8U1OVo66oe0eMDJA", "Screen", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Screen = exports('Screen', (_dec = ccclass('Screen'), _dec(_class = class Screen extends Component {
        Show() {
          this.node.active = true;
        }

        Hide() {
          this.node.active = false;
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/NetworkMgr.ts", ['cc', './axios.min.js', './axios.min.mjs_cjs=&original=.js', './Profile.ts'], function (exports) {
  'use strict';

  var cclegacy, Component, assetManager, SpriteFrame, Texture2D, _decorator, _cjsExports, Profile;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Component = module.Component;
      assetManager = module.assetManager;
      SpriteFrame = module.SpriteFrame;
      Texture2D = module.Texture2D;
      _decorator = module._decorator;
    }, function (module) {
      _cjsExports = module.default;
    }, null, function (module) {
      Profile = module.Profile;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "b72b0V4dQJJTLMgBo4CZ95K", "NetworkMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let NetworkMgr = exports('NetworkMgr', (_dec = ccclass('NetworkMgr'), _dec(_class = class NetworkMgr extends Component {
        start() {}

        static getRequest(url, callback) {
          _cjsExports({
            url,
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${Profile.Instance.UserToken}`
            },
            responseType: 'json',
            timeout: 3000
          }).then(function (response) {
            callback(response.data, response.status);
          }).catch(function (error) {
            callback(null, error.status);

            if (error.response) {
              console.log("Request made and server responded");
              console.log(error.response.data);
              console.log(error.response.status);
            } else if (error.request) {
              console.log("The request was made but no response was received");
              console.log(error.request);
            } else {
              console.log("Something happened in setting up the request that triggered an Error");
              console.error("getRequest ", url, error.message);
            }
          });
        }

        static postRequest(url, data, callback) {
          _cjsExports({
            url,
            method: 'POST',
            data,
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${Profile.Instance.UserToken}`
            },
            responseType: 'json',
            timeout: 3000
          }).then(function (response) {
            if (response.status == 200) {
              callback(response.data);
            } else {
              callback(null);
              console.error("postRequest response.status ", url, response.status);
            }
          }).catch(function (error) {
            callback(null);
            console.error("postRequest ", url, error);
          });
        }

        static geSpriteFrameAsync(imgUrl) {
          // imgUrl = imgUrl.replace("img.mservice.io", "atc-edge03.mservice.com.vn");
          return new Promise((resolve, reject) => {
            assetManager.loadRemote(imgUrl, {
              cacheEnabled: true,
              maxRetryCount: 0
            }, (err, imageAsset) => {
              if (err) {
                resolve(null);
                console.warn(err);
              } else {
                if (imageAsset) {
                  const spriteFrame = new SpriteFrame();
                  const texture = new Texture2D();
                  texture.image = imageAsset;
                  spriteFrame.texture = texture;
                  resolve(spriteFrame);
                } else {
                  resolve(null);
                }
              }
            });
          });
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameApi.ts", ['cc', './Api.ts', './NetworkMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Api, NetworkMgr;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      Api = module.Api;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }],
    execute: function () {
      cclegacy._RF.push({}, "ba4b7JbNotHybnbVqsYJgFq", "GameApi", undefined);

      class GameApi {
        //GIFT HISTORY
        static getGiftHistory(size, page, callback) {
          return NetworkMgr.getRequest(Api.HOST + Api.GiftHistory + `/${page}/${size}`, callback);
        }

        static LBWeekly(limit) {
          return `${Api.GLOBAL_RANKING}&frequency=NORMAL&limit=${limit}`;
        }

        static LBAll(limit) {
          return `${Api.GLOBAL_RANKING}&frequency=MONTH&limit=${limit}`;
        }

        static LBFriendWeekly(limit) {
          return `${Api.FRIEND_RANKING}&frequency=NORMAL&limit=${limit}`;
        }

        static LBFriendAll(limit) {
          return `${Api.FRIEND_RANKING}&frequency=MONTH&limit=${limit}`;
        } //


        static getRankGlobalAll(callback) {
          NetworkMgr.getRequest(Api.LBAll(100), callback);
        }

        static getRankFriendAll(callback) {
          NetworkMgr.getRequest(Api.LBFriendAll(100), callback);
        }

        static getRankFriendWeekly(callback) {
          NetworkMgr.getRequest(Api.LBFriendWeekly(100), callback);
        }

        static getRankGlobleWeekly(callback) {
          NetworkMgr.getRequest(Api.LBWeekly(100), callback);
        }

        static AppVazV2() {
          if (window.realtimeSinceStartup) {
            let loadtime = (Date.now() - window.realtimeSinceStartup) / 1000;
            let body = [{
              eventType: "DUR",
              appVersion: Api.VERSION,
              osPlatform: "web",
              env: Api.IS_DEV ? "dev" : "prod",
              flow: "home",
              step: "load_game_resources",
              api: Api.GAME_ID,
              //vn_momo_web_megaluckywheel_game
              serviceName: Api.SERVICE_NAME,
              //megaday
              value: loadtime
            }];
            console.log(body);
            return NetworkMgr.postRequest(Api.HOST + Api.APPVARZ_V2, body, result => {});
          }
        }

        static getMission(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.Mission, callback);
        }

        static getProgress(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.Progress, callback);
        }

        static postClaimProgressReward(data, callback) {
          NetworkMgr.postRequest(Api.HOST + Api.Progress_Claim, {
            milestoneId: data.milestoneId,
            rewardId: data.rewardId
          }, callback);
        }

        static postClaimIventoryReward(callback) {
          NetworkMgr.postRequest(Api.HOST + Api.Inventory_Claim, {}, callback);
        }

        static getInventory(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.Inventory, callback);
        }

        static postSuccessShareFB(callback) {
          return NetworkMgr.postRequest(Api.HOST + Api.MissionCompleted, {
            "game_id": Api.GAME,
            "mission_id": "share_fb",
            "partner_ids": []
          }, callback);
        }

        static genDeepLink(data, callback) {
          return NetworkMgr.postRequest(Api.HOST + Api.DEEP_LINK, {
            title: data.title,
            description: data.description,
            imageLink: data.imageLink,
            domain: data.domain,
            fallbackLink: data.fallbackLink,
            appParams: data.appParams
          }, callback);
        }

        static getTurn(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.GameTurn, result => {
            callback(result);
          });
        }

      }

      exports('GameApi', GameApi);

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Complete.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Profile.ts', './Screen.ts', './ScreenMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Sprite, _decorator, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, ScreenName, Profile, Screen, ScreenMgr, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Sprite = module.Sprite;
      _decorator = module._decorator;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      ScreenName = module.ScreenName;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "ba4f1Fhr0NDorTmE6rCY0pj", "Complete", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Complete = exports('Complete', (_dec = ccclass('Complete'), _dec2 = property(Label), _dec3 = property(Sprite), _dec4 = property(Label), _dec(_class = (_class2 = (_temp = class Complete extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "content", _descriptor, this);

          _initializerDefineProperty(this, "rewardIcon", _descriptor2, this);

          _initializerDefineProperty(this, "rewardName", _descriptor3, this);

          _defineProperty(this, "contents", ['Bạn đã hoàn thành thử thách Độc Nhất đạt 1000 điểm', 'Bạn đã hoàn thành thử thách Đa Chiều đạt 5 tuyệt vời liên tiếp', 'Bạn đã hoàn thành thử thách Chinh Phục vượt 5 hộp biến hình']);

          _defineProperty(this, "rewardStrings", ['Mảnh hổ số 1', 'Mảnh hổ số 2', 'Mảnh hổ số 3', 'Mảnh hổ số 4']);
        }

        Show() {
          let mode = Profile.Instance.Mode;
          this.content.string = this.contents[mode];
          this.rewardName.string = this.rewardStrings[mode];
          if (Profile.Instance.Mode < 3) Profile.Instance.Mode = mode + 1;
          super.Show();
        }

        showReward() {
          if (!ScreenMgr.Instance.IsShow(ScreenName.EndGame)) {
            ScreenMgr.Instance.HideAll();
            ScreenMgr.Instance.Show(ScreenName.EndGame);
          }
        }

        continue() {
          this.Hide();
          GameMgr.Instance.Retry();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "content", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "rewardIcon", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "rewardName", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/RankItem.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Sprite, SpriteFrame, UITransform, _decorator, Component, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, GameDefine, MySprite;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Sprite = module.Sprite;
      SpriteFrame = module.SpriteFrame;
      UITransform = module.UITransform;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
    }, function (module) {
      MySprite = module.MySprite;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _temp;

      cclegacy._RF.push({}, "bfa60Kgzx1KsoT8Swmu2FoI", "RankItem", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let RankItem = exports('RankItem', (_dec = ccclass('RankItem'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Sprite), _dec6 = property(Sprite), _dec7 = property(Sprite), _dec8 = property([SpriteFrame]), _dec9 = property([SpriteFrame]), _dec10 = property(SpriteFrame), _dec11 = property(SpriteFrame), _dec12 = property(SpriteFrame), _dec13 = property(MySprite), _dec14 = property(SpriteFrame), _dec15 = property(UITransform), _dec(_class = (_class2 = (_temp = class RankItem extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "scoreLabel", _descriptor, this);

          _initializerDefineProperty(this, "nameLabel", _descriptor2, this);

          _initializerDefineProperty(this, "rankingLabel", _descriptor3, this);

          _initializerDefineProperty(this, "bg", _descriptor4, this);

          _initializerDefineProperty(this, "icon", _descriptor5, this);

          _initializerDefineProperty(this, "border", _descriptor6, this);

          _initializerDefineProperty(this, "rankIcons", _descriptor7, this);

          _initializerDefineProperty(this, "rankBorders", _descriptor8, this);

          _initializerDefineProperty(this, "noneIcon", _descriptor9, this);

          _initializerDefineProperty(this, "normalBg", _descriptor10, this);

          _initializerDefineProperty(this, "myBg", _descriptor11, this);

          _initializerDefineProperty(this, "avatar", _descriptor12, this);

          _initializerDefineProperty(this, "defaultAvatar", _descriptor13, this);

          _initializerDefineProperty(this, "rect", _descriptor14, this);

          _defineProperty(this, "item", void 0);
        }

        loadView(item, isMe) {
          if (this.item != item) {
            this.item = item;
            this.scoreLabel.string = item.point.toString();
            this.nameLabel.string = '';

            if (item.name.length == 0) {
              this.nameLabel.string = item.userId;
            } else {
              let names = item.name.toUpperCase().split(' ').slice(-2);

              for (let i = 0; i < names.length; i++) {
                this.nameLabel.string += names[i] + ' ';
              }
            }

            this.bg.spriteFrame = isMe ? this.myBg : this.normalBg; // this.bg.color = isMe ? Color.WHITE : item.rank <= 3 ?
            //     GameDefine.RANK_ITEM_TOP_COLOR :
            //     GameDefine.RANK_ITEM_NONE_COLOR;

            this.SetRank(item.rank);
          }
        }

        SetRank(rank) {
          let isShowIcon = rank > 0 && rank <= this.rankIcons.length;

          if (isShowIcon) {
            this.icon.spriteFrame = this.rankIcons[rank - 1]; // this.icon.color = Color.WHITE;

            this.icon.node.active = true;
            this.rankingLabel.node.active = false;
            this.border.spriteFrame = this.rankBorders[rank - 1];
          } else {
            this.icon.spriteFrame = this.noneIcon; // this.icon.color = GameDefine.RANK_ITEM_NONE_COLOR;

            this.rankingLabel.string = rank.toString();
            this.rankingLabel.node.active = true;
            this.border.node.active = false;
          }

          this.LoadAvatar();
        }

        canLoadAvatar() {
          return this.item.avatarUrl && this.item.avatarUrl.length > 0;
        }

        LoadAvatar() {
          this.avatar.correctSpriteFrameSize(GameDefine.RANK_AVATAR_SIZE);
          this.avatar.Fetch(this.item.avatarUrl);
        }

        loadAvatarDefault() {
          this.avatar.setSprite(this.defaultAvatar);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "scoreLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "nameLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "rankingLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bg", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "icon", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "border", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "rankIcons", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "rankBorders", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "noneIcon", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "normalBg", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "myBg", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "avatar", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "defaultAvatar", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "rect", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PopupMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Popup.ts'], function (exports) {
  'use strict';

  var cclegacy, Prefab, _decorator, Component, instantiate, resources, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, PopupName, Popup;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      _decorator = module._decorator;
      Component = module.Component;
      instantiate = module.instantiate;
      resources = module.resources;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      PopupName = module.PopupName;
    }, function (module) {
      Popup = module.Popup;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "c11c1DECexCEJoTf4nhLRP9", "PopupMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PopupMgr = exports('PopupMgr', (_dec = ccclass('PopupMgr'), _dec2 = property(Prefab), _dec(_class = (_class2 = (_temp = _class3 = class PopupMgr extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "prefabs", _descriptor, this);
        }

        onLoad() {
          PopupMgr.instance = this;
        }

        static get Instance() {
          return PopupMgr.instance;
        }

        Show(name, onClose = null) {
          if (!this.node.getChildByName(name) || name == 'MessageBox') {
            let prefab = this.prefabs.find(prefab => prefab.data.name == name);

            if (prefab) {
              let popup = instantiate(prefab).getComponent(Popup);

              if (onClose != null) {
                popup.onClose = onClose;
                popup.btnClose.node.active = true;
              }

              popup.node.setParent(this.node);
              popup.node.name = name;
              popup.Show();
              return popup;
            }
          }
        }

        Hide(name) {
          this.node.children.forEach(child => {
            if (child.name == name) {
              child.getComponent(Popup).Hide();
            }
          });
        }

        IsContain(name) {
          let result = false;
          this.prefabs.forEach(child => {
            if (child.data.name == name) {
              result = true;
              return;
            }
          });
          return result;
        }

        Load(callback) {
          let array = Object.keys(PopupName);
          let count = 0;
          array.forEach(element => {
            if (!this.IsContain(element)) {
              resources.load("prefabs/popups/" + element, (err, prefab) => {
                if (prefab) {
                  this.prefabs.push(prefab);
                  console.log("Popup loaded: " + element);
                } else {
                  console.error("Popup loade fail: " + element);
                }

                count++;

                if (count >= array.length) {
                  callback();
                }
              });
            } else {
              count++;

              if (count >= array.length) {
                callback();
              }
            }
          });
        }

        IsLoaded(name) {
          let prefab = this.prefabs.find(prefab => prefab.data.name == name);
          return prefab;
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "prefabs", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ProgressBarLabelScore.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, Label, Sprite, _decorator, Component, _applyDecoratedDescriptor, _initializerDefineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "c19a8KSerlGy4A1Qfj7I6u4", "ProgressBarLabelScore", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ProgressBarLabelScore = exports('ProgressBarLabelScore', (_dec = ccclass('ProgressBarLabelScore'), _dec2 = property(Label), _dec3 = property(Sprite), _dec(_class = (_class2 = (_temp = class ProgressBarLabelScore extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "labelScore", _descriptor, this);

          _initializerDefineProperty(this, "sprite", _descriptor2, this);
        }

        loadView(score, isGained) {
          this.labelScore.string = score;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "labelScore", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "sprite", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ClaimButton.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, Node, _decorator, Component, Vec3, tween, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      tween = module.tween;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "c5f3fZmAd1HYoZ/ZX6y7Yex", "ClaimButton", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ClaimButton = exports('ClaimButton', (_dec = ccclass('ClaimButton'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class ClaimButton extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "effect1", _descriptor, this);

          _initializerDefineProperty(this, "effect2", _descriptor2, this);

          _defineProperty(this, "scaleSmall", new Vec3(0.3, 0.3, 1));

          _defineProperty(this, "scaleLarge", new Vec3(0.6, 0.6, 1));
        }

        start() {
          this.startEffectAction(this.effect1);
          this.startEffectAction(this.effect2);
        }

        startEffectAction(effect) {
          let scaleOut = tween(effect).to(0.5, {
            scale: this.scaleSmall
          });
          let scaleIn = tween(effect).to(0.5, {
            scale: this.scaleLarge
          });
          let scale = tween(effect).sequence(scaleOut, scaleIn);
          tween(effect).repeatForever(scale).start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "effect1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "effect2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MyGift.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './MyGiftCell.ts'], function (exports) {
  'use strict';

  var cclegacy, ScrollView, _decorator, Component, Layout, _applyDecoratedDescriptor, _initializerDefineProperty, MyGiftCell;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      ScrollView = module.ScrollView;
      _decorator = module._decorator;
      Component = module.Component;
      Layout = module.Layout;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      MyGiftCell = module.MyGiftCell;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "c621bz3gpVGyYjSV0rOnQIa", "MyGift", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let MyGift = exports('MyGift', (_dec = ccclass('MyGift'), _dec2 = property(ScrollView), _dec(_class = (_class2 = (_temp = class MyGift extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "scrollView", _descriptor, this);
        }

        loadView(itemList) {
          //fix dummy ui 4 item
          for (let i = 0; i < 4; i++) {
            let giftItem = this.scrollView.content.children[i].getComponent(MyGiftCell);

            if (i < itemList.length) {
              giftItem.setInfo(itemList[i]);
              giftItem.node.active = true;
            } else {
              giftItem.node.active = false;
            }
          }

          this.scrollView.content.getComponent(Layout).updateLayout(true);
          let trackingList = [];

          for (let key in itemList) {
            if (itemList[key].giftId) trackingList.push(itemList[key].giftId);
          }
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "scrollView", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ProgressGiftCell.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './MySprite.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, Node, _decorator, Component, UIOpacity, Vec3, _applyDecoratedDescriptor, _initializerDefineProperty, GameDefine, ProgressGiftStatus, MySprite;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      UIOpacity = module.UIOpacity;
      Vec3 = module.Vec3;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
      ProgressGiftStatus = module.ProgressGiftStatus;
    }, function (module) {
      MySprite = module.MySprite;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp;

      cclegacy._RF.push({}, "cd95a5OBk9Fw6Pqb9Az/uIy", "ProgressGiftCell", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ProgressGiftCell = exports('ProgressGiftCell', (_dec = ccclass('ProgressGiftCell'), _dec2 = property(MySprite), _dec3 = property(Label), _dec4 = property(Node), _dec5 = property(Node), _dec6 = property(Label), _dec(_class = (_class2 = (_temp = class ProgressGiftCell extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "giftIcon", _descriptor, this);

          _initializerDefineProperty(this, "giftNameLabel", _descriptor2, this);

          _initializerDefineProperty(this, "claimedLabel", _descriptor3, this);

          _initializerDefineProperty(this, "outOfStockLabel", _descriptor4, this);

          _initializerDefineProperty(this, "giftNumberLabel", _descriptor5, this);
        }

        start() {}

        loadView(milestone) {
          const item = milestone.rewards[0];
          this.giftIcon.correctSpriteFrameSize(GameDefine.PROGRESS_GIFT_SIZE);
          this.giftIcon.Fetch(item.icon);
          this.giftNameLabel.string = item.title;

          switch (milestone.status) {
            case ProgressGiftStatus.CLAIMED:
              this.claimedLabel.active = true;
              this.outOfStockLabel.active = false;
              this.giftNumberLabel.node.active = false;
              break;

            case ProgressGiftStatus.OUT_OF_STOCK:
              this.claimedLabel.active = false;
              this.outOfStockLabel.active = true;
              this.giftNumberLabel.node.active = false;
              this.giftIcon.node.getComponent(UIOpacity).opacity = 155;
              this.giftNameLabel.node.getComponent(UIOpacity).opacity = 155;
              break;

            case ProgressGiftStatus.UNAVAILABLE:
              this.claimedLabel.active = false;
              this.outOfStockLabel.active = false;
              this.giftNumberLabel.node.active = true;
              this.giftIcon.node.getComponent(UIOpacity).opacity = 155;
              this.giftNameLabel.node.getComponent(UIOpacity).opacity = 155;
              break;

            case ProgressGiftStatus.AVAILABLE:
              this.claimedLabel.active = false;
              this.outOfStockLabel.active = false;
              this.giftNumberLabel.node.active = true;
              break;
          }

          if (!milestone.amount || milestone.amount > 1000000) {
            this.giftNumberLabel.node.active = false;
          }

          if (!this.giftNumberLabel.node.active) {
            this.giftNameLabel.node.setPosition(new Vec3(-76, -10, 0));
          } else {
            this.giftNumberLabel.string = "Còn " + milestone.amount + " lượt nhận";
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "giftIcon", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "giftNameLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "claimedLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "outOfStockLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "giftNumberLabel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PhoneUtils.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      exports({
        convertPhoneNumerWithMode: convertPhoneNumerWithMode,
        formatPhoneNumberVN: formatPhoneNumberVN,
        isValidPrefix10Phone: isValidPrefix10Phone,
        isValidPrefix11Phone: isValidPrefix11Phone,
        validatePhoneVN: validatePhoneVN
      });

      cclegacy._RF.push({}, "ceccf0969BGaqcBXFyCnvCd", "PhoneUtils", undefined);

      const PHONE_11_10_TABLE = {
        "0162": "032",
        "0163": "033",
        "0164": "034",
        "0165": "035",
        "0166": "036",
        "0167": "037",
        "0168": "038",
        "0169": "039",
        "0120": "070",
        "0121": "079",
        "0122": "077",
        "0126": "076",
        "0128": "078",
        "0123": "083",
        "0124": "084",
        "0125": "085",
        "0127": "081",
        "0129": "082",
        "0186": "056",
        "0188": "058",
        "0199": "059"
      };
      const PHONE_10_11_TABLE = Object.keys(PHONE_11_10_TABLE).reduce((obj, item) => obj = { ...obj,
        [PHONE_11_10_TABLE[item]]: item
      }, {});
      const PHONE_11_REG = new RegExp('^098|^097|^0162|^0163|^0164|^0165|^0166|^0167|^0168|^0169|^0120|^0121|^0122|^0123|^0124|^0125|^0126|^0127|^0128|^0129|^0186|^0189|^0188|^0199|^090|^091|^092|^093|^094|^095|^096|^097|^098|^0129|^099');
      const PHONE_10_REG = new RegExp('^098|^097|^032|^033|^034|^035|^036|^037|^038|^039|^070|^079|^076|^078|^083|^084|^085|^081|^082|^056|^058|^0188|^0199|^077|^059|^090|^091|^092|^093|^094|^095|^096|^097|^098|^088|^087|^086|^089|^099');

      function convertPhoneNumerWithMode({
        phone
      }) {
        /** Empty if phone null */
        if (typeof phone !== 'string') return phone;
        /** Format it before converting */

        let convertedPhoneNumer = formatPhoneNumberVN(phone);

        if (convertedPhoneNumer.length === 10) {
          /** Must convert from 10 to 11 number */
          const prefixPhone = convertedPhoneNumer.substring(0, 3);
          /** Found prefix phone number */

          if (PHONE_10_11_TABLE[prefixPhone]) {
            convertedPhoneNumer = `${PHONE_10_11_TABLE[prefixPhone]}${convertedPhoneNumer.substring(3, convertedPhoneNumer.length)}`;
          }
        } else if (convertedPhoneNumer.length === 11) {
          /** Must convert from 11 to 10 number */
          const prefixPhone = convertedPhoneNumer.substring(0, 4);
          /** Found prefix phone number */

          if (PHONE_11_10_TABLE[prefixPhone]) {
            convertedPhoneNumer = `${PHONE_11_10_TABLE[prefixPhone]}${convertedPhoneNumer.substring(4, convertedPhoneNumer.length)}`;
          }
        }
        /** Output result of converting */


        return convertedPhoneNumer;
      }

      function formatPhoneNumberVN(phone, prefix = "0") {
        if (phone) {
          let phoneFormatted = "+" + phone.replace(/\D/g, '');
          phoneFormatted = phoneFormatted.replace("+84", "0");
          phoneFormatted = phoneFormatted.replace("(+84)", "0");
          phoneFormatted = phoneFormatted.replace("(084)", "0");
          phoneFormatted = phoneFormatted.replace("(0)", "");
          phoneFormatted = phoneFormatted.replace(/\D/g, '');

          if (phoneFormatted.indexOf("00") == 0) {
            phoneFormatted = phoneFormatted.substr(1);
          }

          if (phoneFormatted.indexOf("84") == 0 && phoneFormatted.length > 3) {
            phoneFormatted = phoneFormatted.substr(2);
          }

          if (phoneFormatted.indexOf("0") != 0) {
            phoneFormatted = "0" + phoneFormatted;
          }

          if (phoneFormatted.indexOf(prefix) == 0) {
            return phoneFormatted;
          } else {
            phoneFormatted = prefix + phoneFormatted.substr(1);
            return phoneFormatted;
          }
        } else {
          return phone;
        }
      }

      function validatePhoneVN(phone) {
        if (phone && phone.length > 7 && phone.length < 17) {
          return true;
        }

        return false;
      }

      function isValidPrefix10Phone(number = '', regex) {
        var _regex10$test;

        let regex10 = regex || PHONE_10_REG;
        return (regex10 === null || regex10 === void 0 ? void 0 : (_regex10$test = regex10.test) === null || _regex10$test === void 0 ? void 0 : _regex10$test.call(regex10, number)) && /^\d+$/.test(number) && (number === null || number === void 0 ? void 0 : number.length) === 10;
      }

      function isValidPrefix11Phone(number = '', regex) {
        var _regex11$test;

        let regex11 = regex || PHONE_11_REG;
        return (regex11 === null || regex11 === void 0 ? void 0 : (_regex11$test = regex11.test) === null || _regex11$test === void 0 ? void 0 : _regex11$test.call(regex11, number)) && /^\d+$/.test(number) && (number === null || number === void 0 ? void 0 : number.length) === 11;
      }

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Mission.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './AudioMgr.ts', './MaxApiUtils.ts', './Profile.ts', './Screen.ts', './ScreenMgr.ts', './TextDefine.ts', './MessageBox.ts', './GameApi.ts', './MissionCell.ts'], function (exports) {
  'use strict';

  var cclegacy, Prefab, Node, _decorator, NodePool, instantiate, gameEvent, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, EventName, ScreenName, QuestType, Utils, AudioMgr, MaxApiUtils, Profile, Screen, ScreenMgr, Text, MessageBox, GameApi, MissionCell;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      Node = module.Node;
      _decorator = module._decorator;
      NodePool = module.NodePool;
      instantiate = module.instantiate;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      EventName = module.EventName;
      ScreenName = module.ScreenName;
      QuestType = module.QuestType;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      ScreenMgr = module.ScreenMgr;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      MessageBox = module.MessageBox;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      MissionCell = module.MissionCell;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _class3, _temp;

      cclegacy._RF.push({}, "d2936+QUpVPQ55gxrcQd23V", "Mission", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Mission = exports('Mission', (_dec = ccclass('Mission'), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(Node), _dec(_class = (_class2 = (_temp = _class3 = class Mission extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "missionCellTemplate", _descriptor, this);

          _initializerDefineProperty(this, "content", _descriptor2, this);

          _initializerDefineProperty(this, "btnBack", _descriptor3, this);

          _initializerDefineProperty(this, "loading", _descriptor4, this);

          _defineProperty(this, "pool", new NodePool());

          _defineProperty(this, "data", []);

          _defineProperty(this, "isLoading", false);

          _defineProperty(this, "deepLink", "");
        }

        onLoad() {
          for (let i = 0; i < 8; i++) {
            let cell = instantiate(this.missionCellTemplate);
            this.pool.put(cell);
          }
        }

        start() {
          Mission._instance = this;
          this.btnBack.on("click", this.backScreen.bind(this));
          gameEvent.on(EventName.MissionUpdate, this.refresh.bind(this));
          gameEvent.on(EventName.OnMissionComplete, this.onMissionComplete.bind(this));
        }

        static get Instance() {
          return Mission._instance;
        }

        backScreen() {
          ScreenMgr.Instance.Hide(ScreenName.Mission);
        }

        Show() {
          Profile.Instance.SetNormalFps();
          super.Show();
          this.LoadInfo();
        }

        LoadInfo() {
          const self = this;

          if (!self.isLoading) {
            self.isLoading = true;
            self.loading.active = true;
            GameApi.getMission(resp => {
              if (!resp || !resp.response_info || resp.response_info.error_code !== 0) {
                let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
                msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
                  self.LoadInfo();
                });
              } else {
                self.loadView(resp);
              }

              self.isLoading = false;
              self.loading.active = false;
            });
          }
        }

        Hide() {
          super.Hide();
          this.clearQuest();
        }

        loadView(missionResp) {
          this.refresh(missionResp);
        }

        getMissionSort(missionList) {
          let finalMissions = missionList.filter(item => !item.isExpired);
          finalMissions = finalMissions.sort((cur, prev) => {
            if (!cur.isCompleted && prev.isCompleted) return -1;
            return 1;
          });
          return finalMissions;
        }

        refresh(missonResp) {
          this.data = this.getMissionSort(missonResp.missions);
          let currentMission = this.content.children.length;

          for (let i = 0; i < this.data.length; i++) {
            let missionBase;

            if (i < currentMission) {
              missionBase = this.content.children[i].getComponent(MissionCell);
            } else {
              missionBase = this.getOrCreate();
              this.content.addChild(missionBase.node);
            }

            missionBase.setInfo(this.data[i], this.onCTAClick.bind(this));
            let remain = this.content.children.length - this.data.length;

            while (remain > 0) {
              this.return(this.content.children.pop());
              remain--;
            }
          }
        }

        getMissionInfo(type) {
          return this.data.find(mission => mission.missionId == type);
        }

        CallGenDeepLink(ShareMissionInfo, callback) {
          let self = this;

          if (ShareMissionInfo != null) {
            let data = {
              title: ShareMissionInfo.shareTitle,
              description: ShareMissionInfo.shareDescription,
              imageLink: ShareMissionInfo.shareImgUrl,
              domain: ShareMissionInfo.domain,
              fallbackLink: ShareMissionInfo.linkShare,
              appParams: {
                refId: "vn.momo.web.momojumptiger",
                featureCode: "jump_tiger_game"
              }
            };
            GameApi.genDeepLink(data, res => {
              if (res && res.item && res.item.shortLink) {
                self.deepLink = res.item.shortLink;
                callback(res.item.shortLink);
              }
            });
          }
        }

        CallShareFB(linkShare) {
          let mission = this.getMissionInfo(QuestType.ShareFB);
          console.log("SHARE FB LINk: " + linkShare);

          if (linkShare && linkShare != '') {
            MaxApiUtils.shareFacebook({
              link: linkShare
            }, ok => {
              if (ok) {
                GameApi.postSuccessShareFB(response => {
                  if (response && response.result) {
                    gameEvent.emit(EventName.OnMissionComplete, mission);
                  } else {
                    MaxApiUtils.showToast("Đã có lỗi xảy ra!");
                  }
                });
              }
            });
          } else {
            MaxApiUtils.showToast("Đã có lỗi xảy ra!");
          }
        }

        ClickShareFB() {
          let mission = this.getMissionInfo(QuestType.ShareFB);
          let missionInfo = mission.missionInfo;
          this.CallGenDeepLink(missionInfo, this.CallShareFB.bind(this));
        }

        getOrCreate() {
          let cell = null;

          if (this.pool.size() > 0) {
            cell = this.pool.get();
          } else {
            cell = instantiate(this.missionCellTemplate);
          }

          return cell.getComponent(MissionCell);
        }

        return(node) {
          this.pool.put(node);
        }

        clearQuest() {
          for (let i = 0, size = this.content.children.length; i < size; i++) {
            this.return(this.content.children[i]);
          }
        }

        onCTAClick(mission) {
          if (mission.missionId) ;

          switch (mission.missionId) {
            case QuestType.ShareFB:
              {
                Mission.Instance.ClickShareFB();
              }
              break;

            default:
              {
                this.openMiniApp(mission.missionInfo);
              }
              break;
          }
        }

        openMiniApp(missionInfo) {
          if (missionInfo.refId && missionInfo.refId.length > 0) {
            if (Utils.isUrl(missionInfo.refId)) {
              MaxApiUtils.openWeb(missionInfo.refId);
              return;
            }

            MaxApiUtils.startFeatureCode(missionInfo.refId, {}, () => {
              console.log(`startFeatureCode ${missionInfo.refId}`);
            });

            if (missionInfo.refId == "momo_story") {
              AudioMgr.Instance.Stop();
            }
          }
        }

        onMissionComplete(mission) {// GameMgr.Instance.Refresh();
        }

      }, _defineProperty(_class3, "_instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "missionCellTemplate", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "content", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnBack", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "loading", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/CameraController.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './PlayerController.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, Vec3, _decorator, Component, tween, random, gameEvent, _applyDecoratedDescriptor, _initializerDefineProperty, EventPlayer, PlayerController;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      Vec3 = module.Vec3;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      random = module.random;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      EventPlayer = module.EventPlayer;
    }, function (module) {
      PlayerController = module.PlayerController;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "d37df9wkkBFFL8FU0kD3P8f", "CameraController", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let CameraController = exports('CameraController', (_dec = ccclass('CameraController'), _dec2 = property(Node), _dec3 = property(Vec3), _dec(_class = (_class2 = (_temp = class CameraController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "cameras", _descriptor, this);

          _initializerDefineProperty(this, "mags", _descriptor2, this);
        }

        start() {
          // this.player = find('player').getComponent(PlayerController)
          gameEvent.on(EventPlayer.OnLanding, this.onLanding, this);
          gameEvent.on(EventPlayer.OnLose, this.onLose, this);
        }

        onDestroy() {
          gameEvent.targetOff(this);
        }

        shake(duration = 0.3) {
          let listPos = [];
          let cameras = this.cameras;
          let mags = this.mags;

          for (let i of cameras) {
            listPos.push(i.position.clone());
          }

          return tween({
            value: 0
          }).to(duration, {
            value: 1
          }, {
            onUpdate: (target, ratio) => {
              if (ratio >= 1) {
                for (let i in cameras) {
                  cameras[i].setPosition(listPos[i]);
                }
              } else {
                let pos = new Vec3(random() - .5, random() - .5, random() - .5);

                for (let i in cameras) {
                  let p = pos.clone().multiply(mags[i]);
                  cameras[i].setPosition(listPos[i].clone().add(p));
                }
              }
            }
          });
        }

        goCenter() {
          let p1 = PlayerController.Instance.platform.position.clone();
          let p2 = PlayerController.Instance.nextPlatform.position.clone();
          tween(this.node).to(.3, {
            position: p1.add(p2).multiplyScalar(.5)
          }).start();
        }

        onLanding() {
          setTimeout(this.goCenter.bind(this), 700);
        }

        onLose() {
          this.node.position = Vec3.ZERO;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cameras", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "mags", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MySprite.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './Utils.ts'], function (exports) {
  'use strict';

  var cclegacy, Sprite, _decorator, Component, UITransform, Size, assetManager, SpriteFrame, Texture2D, resources, Vec3, _defineProperty, Utils;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Component = module.Component;
      UITransform = module.UITransform;
      Size = module.Size;
      assetManager = module.assetManager;
      SpriteFrame = module.SpriteFrame;
      Texture2D = module.Texture2D;
      resources = module.resources;
      Vec3 = module.Vec3;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      Utils = module.Utils;
    }],
    execute: function () {
      var _dec, _dec2, _class, _temp;

      cclegacy._RF.push({}, "d56eeYe8MFLU4l4wOAycQQz", "MySprite", undefined);

      const {
        ccclass,
        property,
        requireComponent
      } = _decorator;
      let MySprite = exports('MySprite', (_dec = ccclass('MySprite'), _dec2 = requireComponent(Sprite), _dec(_class = _dec2(_class = (_temp = class MySprite extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "sprite", null);

          _defineProperty(this, "url", "");

          _defineProperty(this, "size", void 0);
        }

        onLoad() {
          if (!this.sprite) this.sprite = this.getComponent(Sprite);
          let uit = this.sprite.getComponent(UITransform);
          this.size = new Size(uit.width, uit.height);
          this.sprite.sizeMode = Sprite.SizeMode.RAW;
        }

        setFixedSize(fixedSize) {
          this.size = fixedSize.clone();
          this.sprite.sizeMode = Sprite.SizeMode.RAW;
        }

        correctSpriteFrameSize(fixedSize) {
          this.setFixedSize(fixedSize);
          Utils.CorrectSpriteFrameSize(this.sprite, this.size);
        }

        Fetch(url) {
          if (url && this.url != url) {
            url = url.replace("img.mservice.io", "atc-edge03.mservice.com.vn");
            url = url.replace("img.mservice.com.vn", "atc-edge01.mservice.com.vn");
            assetManager.loadRemote(url, {
              cacheEnabled: true,
              maxRetryCount: 0
            }, (err, imageAsset) => {
              if (err) {
                console.warn(err);
              } else {
                if (imageAsset) {
                  let spriteFrame = new SpriteFrame();
                  let texture = new Texture2D();
                  texture.image = imageAsset;
                  spriteFrame.texture = texture;
                  this.setSprite(spriteFrame);
                }
              }
            });
          }
        }

        load(url) {
          resources.load(url, (err, imageAsset) => {
            if (err) {
              console.warn(err);
            } else {
              if (imageAsset) {
                let spriteFrame = new SpriteFrame();
                let texture = new Texture2D();
                texture.image = imageAsset;
                spriteFrame.texture = texture;
                this.setSprite(spriteFrame);
              }
            }
          });
        }

        get Sprite() {
          return this.sprite;
        }

        setSprite(spriteFrame, isResetScal = false) {
          this.sprite.spriteFrame = spriteFrame;

          if (isResetScal) {
            this.node.scale = Vec3.ONE;
          } else {
            Utils.CorrectSpriteFrameSize(this.sprite, this.size);
          }
        }

      }, _temp)) || _class) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/HideTutorial.ts", ['cc', './InGame.ts'], function (exports) {
  'use strict';

  var cclegacy, Component, Node, _decorator, InGame;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Component = module.Component;
      Node = module.Node;
      _decorator = module._decorator;
    }, function (module) {
      InGame = module.InGame;
    }],
    execute: function () {
      var _dec, _class;

      cclegacy._RF.push({}, "de1f7FsyT5Gq5sZnV4wEQ4Y", "HideTutorial", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let HideTutorial = exports('HideTutorial', (_dec = ccclass('HideTutorial'), _dec(_class = class HideTutorial extends Component {
        start() {
          this.node.on(Node.EventType.TOUCH_START, this.OnClick.bind(this));
        }

        OnClick(event) {
          InGame.Instance.OnHideTutorial();
          event.propagationStopped = true;
        }

      }) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/OnboardingMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './Api.ts', './NetworkMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, Node, director, _defineProperty, Api, NetworkMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Node = module.Node;
      director = module.director;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      Api = module.Api;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "dea70eGCnFGdqdWWWL3EPTk", "OnboardingMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let OnboardingMgr = exports('OnboardingMgr', (_dec = ccclass('OnboardingMgr'), _dec(_class = (_temp = _class2 = class OnboardingMgr extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "_isComplete", false);
        }

        static get Instance() {
          if (!OnboardingMgr.instance) {
            let node = new Node('OnboardingMgr');
            director.getScene().addChild(node);
            OnboardingMgr.instance = node.addComponent(OnboardingMgr);
          }

          return OnboardingMgr.instance;
        }

        getOnbardingStatus(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.OnboardingStatus, resp => {
            if (resp && resp.items) {
              OnboardingMgr.instance.setComplete(resp.items.isOnboarding); //true is complete onboarding

              callback(true);
            } else {
              callback(false);
            }
          });
        }

        postOnBoardingSubmit(callback) {
          this.setComplete(true);
          NetworkMgr.postRequest(Api.HOST + Api.OnboardingSubmit, {}, callback);
        }

        isComplete() {
          return this._isComplete;
        }

        setComplete(isComplete) {
          this._isComplete = isComplete;
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ShipController.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './AssetMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, Vec3, find, UIOpacity, ParticleSystem, Quat, tween, _defineProperty, AssetMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      find = module.find;
      UIOpacity = module.UIOpacity;
      ParticleSystem = module.ParticleSystem;
      Quat = module.Quat;
      tween = module.tween;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      AssetMgr = module.AssetMgr;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "e0310rWkCNA04PHYpmuH/n7", "ShipController", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ShipController = exports('ShipController', (_dec = ccclass('ShipController'), _dec(_class = (_temp = class ShipController extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "originalPosition", Vec3.ZERO);

          _defineProperty(this, "kolOpacityComp", null);

          _defineProperty(this, "lightOpacityComp", null);

          _defineProperty(this, "starParticle", null);

          _defineProperty(this, "trailParticle", null);

          _defineProperty(this, "trailHolder", null);

          _defineProperty(this, "tweenPosition", null);

          _defineProperty(this, "tweenHorizontal", null);

          _defineProperty(this, "tweenRotation", null);
        }

        onLoad() {
          this.node.active = false;
          this.kolOpacityComp = find('kol', this.node).getComponent(UIOpacity);
          this.lightOpacityComp = find('light', this.node).getComponent(UIOpacity);
          this.starParticle = find('StarParticle', this.node).getComponent(ParticleSystem);
          this.trailParticle = find('TrailParticle', this.node).getComponent(ParticleSystem);
          this.trailHolder = find('trailHolder', this.node);
        }

        start() {
          this.originalPosition = this.node.position.clone();
        }

        stopIdle() {
          var _this$tweenHorizontal, _this$tweenRotation;

          (_this$tweenHorizontal = this.tweenHorizontal) === null || _this$tweenHorizontal === void 0 ? void 0 : _this$tweenHorizontal.stop();
          (_this$tweenRotation = this.tweenRotation) === null || _this$tweenRotation === void 0 ? void 0 : _this$tweenRotation.stop();
        }

        stopFly() {
          var _this$tweenPosition;

          (_this$tweenPosition = this.tweenPosition) === null || _this$tweenPosition === void 0 ? void 0 : _this$tweenPosition.stop();
          this.stopIdle();
        }

        stop() {
          this.stopFly();
          this.stopParticle();
        }

        startParticle() {
          var _this$starParticle, _this$trailParticle;

          this.starParticle.node.active = true;
          this.trailParticle.node.active = true;
          (_this$starParticle = this.starParticle) === null || _this$starParticle === void 0 ? void 0 : _this$starParticle.play();
          (_this$trailParticle = this.trailParticle) === null || _this$trailParticle === void 0 ? void 0 : _this$trailParticle.play();
        }

        stopParticle() {
          var _this$starParticle2, _this$trailParticle2;

          this.starParticle.node.active = false;
          this.trailParticle.node.active = false;
          (_this$starParticle2 = this.starParticle) === null || _this$starParticle2 === void 0 ? void 0 : _this$starParticle2.stop();
          (_this$trailParticle2 = this.trailParticle) === null || _this$trailParticle2 === void 0 ? void 0 : _this$trailParticle2.stop();
        }

        flyUp() {
          const time = 1;
          this.stopFly();
          this.node.rotation = new Quat(0, 0, 0);
          this.tweenPosition = tween(this.node).delay(1).by(time, {
            position: new Vec3(0, 45, 0)
          }, {
            onUpdate: (target, ratio) => {
              let opacity = 255 - ratio * 255;
              this.kolOpacityComp.opacity = opacity;
              this.lightOpacityComp.opacity = opacity;
            },
            easing: "sineIn"
          }).call(() => {
            this.stopParticle();
            this.trailHolder.active = false;
            this.idle();
          }).start();
        }

        flyDown() {
          this.node.active = true;
          const time = 2;
          this.stopFly();
          this.tweenPosition = tween(this.node).by(time, {
            position: new Vec3(0, -320, 0)
          }, {
            onUpdate: (target, ratio) => {
              let opacity = ratio * 255;
              this.kolOpacityComp.opacity = opacity;
              this.lightOpacityComp.opacity = opacity;
            },
            easing: "sineOut"
          }).call(() => {
            this.startParticle();
            this.trailHolder.active = true;
            this.idle();
            AssetMgr.Instance.Load();
          }).start();
        }

        idle() {
          const time = 2;
          const y = this.node.position.y;
          let quatRight = new Quat();
          Quat.fromEuler(quatRight, 0, 0, -0.7);
          let quatLeft = new Quat();
          Quat.fromEuler(quatLeft, 0, 0, 0.7);
          this.tweenHorizontal = tween(this.node).to(time, {
            position: new Vec3(0, y + 5, 0)
          }, {
            easing: "quadOut"
          }).to(time, {
            position: new Vec3(-0, y - 5, 0)
          }, {
            easing: "quadOut"
          }).union().repeatForever().start();
          this.tweenRotation = tween(this.node).to(time * 1.5, {
            rotation: quatLeft
          }, {
            easing: "linear"
          }).to(time * 1.5, {
            rotation: quatRight
          }, {
            easing: "linear"
          }).union().repeatForever().start();
        }

        reset() {
          this.stop();
          this.node.position = this.originalPosition.clone();
        }

        hide() {
          var _this$tweenPosition2;

          (_this$tweenPosition2 = this.tweenPosition) === null || _this$tweenPosition2 === void 0 ? void 0 : _this$tweenPosition2.stop();
          tween(this.node).by(1, {
            position: new Vec3(0, 500, 0)
          }, {
            easing: "sineOut"
          }).start();
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AutoPlayer.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './PlayerController.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, find, tween, Node, gameEvent, _defineProperty, EventPlayer, PlayerController;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      find = module.find;
      tween = module.tween;
      Node = module.Node;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      EventPlayer = module.EventPlayer;
    }, function (module) {
      PlayerController = module.PlayerController;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "e0e08qGai1EYY1YDftq8YqM", "AutoPlayer", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AutoPlayer = exports('AutoPlayer', (_dec = ccclass('AutoPlayer'), _dec(_class = (_temp = class AutoPlayer extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "player", null);

          _defineProperty(this, "canvas", null);
        }

        start() {
          this.player = this.getComponent(PlayerController);
          this.canvas = find('Canvas');
          gameEvent.on(EventPlayer.OnLanding, this.onLanding, this);
        }

        onDestroy() {
          gameEvent.targetOff(this);
        }

        play(player) {
          let canvas = this.canvas;
          tween(this).call(canvas.emit.bind(canvas, Node.EventType.TOUCH_START, null)).delay(player.timeToCenter()).call(canvas.emit.bind(canvas, Node.EventType.TOUCH_END, null)).start();
        }

        onLanding() {
          setTimeout(this.play.bind(this, this.player), 1000);
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TrackingMgr.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './MaxApiUtils.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, _defineProperty, MaxApiUtils;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      MaxApiUtils = module.default;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "e1179ejeQZJBryGfQ2boJpN", "TrackingMgr", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let TrackingMgr = exports('TrackingMgr', (_dec = ccclass('TrackingMgr'), _dec(_class = (_temp = _class2 = class TrackingMgr {
        //----------------------------------------------------
        static get Instance() {
          if (this._instance == null) this._instance = new TrackingMgr();
          return this._instance;
        } //------------------------------------------------------


        onLoad() {
          TrackingMgr._instance = this;
        }

        start() {
          this.ShowGameSuccess();
        } //PUBLIC FUNCTION

        /**
         * Hiển thị MH game MoMo Jump Tiger thành công
         */


        ShowGameSuccess() {
          MaxApiUtils.trackEvent({
            stage: "scr_home",
            event_name: "gamification_momo_jump"
          });
        }
        /**
         * Nhấp vào nút Back thoát game
         */


        ClickBackHome() {
          MaxApiUtils.trackEvent({
            action: "click_back_scr_home"
          });
        }
        /**
         * Nhấn vào nút xem Quà tặng
         */


        ClickGiftHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_gift_scr_home"
          });
        }
        /**
         * Nhấn vào nút xem Bảng xếp hạng
         */


        ClickLeaderBoardHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_leaderboard_scr_home"
          });
        }
        /**
         * Nhấn vào nút tắt/mở âm thanh
         */


        ClickSoundHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_sound_scr_home"
          });
        }
        /**
         * Nhấn vào xem sự kiện
         */


        ClickEventHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_event_scr_home"
          });
        }
        /**
         * Nhấn vào nút lượt
         */


        ClickTurnHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_turn_scr_home"
          });
        }
        /**
         * Nhấn bắt đầu nhảy
         */


        ClickStartHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_start_scr_home"
          });
        }
        /**
         * Nhấn để nhảy
         */


        ClickPlayHome() {
          MaxApiUtils.trackEvent({
            aciton: "click_play_scr_home"
          });
        }
        /**
         * Hiện onboarding instruction
         */


        ShowPopupOnboarding() {
          MaxApiUtils.trackEvent({
            stage: "pu_onborading"
          });
        }
        /**
         * Nhân vật rớt khỏi bục
         */


        PlayerDie() {
          MaxApiUtils.trackEvent({
            stage: "scr_fail"
          });
        }
        /**
         * Hiển thị MH pop up hết lượt
         */


        ShowPopupNoTurn() {
          MaxApiUtils.trackEvent({
            stage: "pu_noturn"
          });
        }
        /**
         * Bấm nút chơi lại
         */


        ClickPlayAgain() {
          MaxApiUtils.trackEvent({
            aciton: "click_playagain_scr_home"
          });
        }
        /**
         * Nhấn vào CTA Xem nhiệm vụ ở MH hết lượt
         */


        ClickMissionPopupNoTurn() {
          MaxApiUtils.trackEvent({
            aciton: "click_mission_pu_noturn"
          });
        }
        /**
         * Ấn vào CTA của 1 trong các nhiệm vụ
         */


        ClickCTAMission() {
          MaxApiUtils.trackEvent({
            aciton: "click_cta_scr_mission"
          });
        }
        /**
         * Load thành công màn hình kết quả cuối game
         */


        ShowSuccessGameResult() {
          MaxApiUtils.trackEvent({
            stage: "scr_result"
          });
        }
        /**
         * Load thành công BXH Detail
         */


        ShowSucessLeaderBoardDetail() {
          MaxApiUtils.trackEvent({
            stage: "scr_leaderboard"
          });
        }
        /**
         * Nhấn vào nút săn thưởng
         */


        ClickGiftHunt() {
          MaxApiUtils.trackEvent({
            aciton: "click_gift_hunt"
          });
        }
        /**
         * Nhấn vào nút "ghép ngay" màn hình săn thưởng
         */


        ClickGiftAssemble() {
          MaxApiUtils.trackEvent({
            aciton: "click_gift_hunt_assemble"
          });
        }
        /**
         * Nhấn vào nút "nhận vé chia thưởng" màn hình săn thưởng
         */


        ClickCollectTicket() {
          MaxApiUtils.trackEvent({
            aciton: "click_gift_hunt_collect_ticket"
          });
        }
        /**
         * Nhấn vào nút milestone
         */


        ClickMileStone() {
          MaxApiUtils.trackEvent({
            aciton: "click_milestone"
          });
        }

      }, _defineProperty(_class2, "_instance", void 0), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TextDefine.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "e19c0a/LP9JFLwLwIt5pY0V", "TextDefine", undefined);

      const Text = exports('Text', {
        Close: "\u0110\xF3ng",
        Exit: "Tho\xE1t",
        Continues: "Ch\u01A1i ti\u1EBFp",
        Retry: "Th\u1EED l\u1EA1i",
        Error: "L\u1ED7i",
        Back: "Quay l\u1EA1i",
        BackAfter: "Quay l\u1EA1i sau",
        Confirm: "X\xE1c nh\u1EADn",
        GiveUp: "B\u1ECF cu\u1ED9c",
        RewardError: "Kh\xF4ng th\u1EC3 nh\u1EADn qu\xE0 l\xFAc n\xE0y",
        ErrorGeneral: "Th\xF4ng b\xE1o l\u1ED7i t\u1EEB BE",
        ConnectError: "L\u1ED7i k\u1EBFt n\u1ED1i",
        NetworkError: "Vui l\xF2ng ki\u1EC3m tra l\u1EA1i \u0111\u01B0\u1EDDng truy\u1EC1n \u0111\u1EC3 ti\u1EBFp t\u1EE5c tham gia",
        OutOfTurn: "B\u1EA1n \u0111\xE3 h\u1EBFt l\u01B0\u1EE3t ch\u01A1i",
        MoreDetail: "T\xECm hi\u1EC3u th\xEAm",
        ClaimMoreTurn: "T\xECm th\xEAm l\u01B0\u1EE3t",
        Copied: "\u0110\xE3 sao ch\xE9p",
        ToastBusy: "Ch\u1EDD ch\xFAt nh\xE9!",
        OutOfFreeTurn: "B\u1EA1n \u0111\xE3 h\u1EBFt l\u01B0\u1EE3t mi\u1EC5n ph\xED",
        ExitGameTitle: "B\u1EA1n mu\u1ED1n b\u1ECF cu\u1ED9c?",
        ExitGameContent: "B\u1EA1n s\u1EBD b\u1ECF l\u1EE1 nhi\u1EC1u ph\u1EA7n th\u01B0\u1EDFng h\u1EA5p d\u1EABn \u1EDF v\xF2ng ch\u01A1i n\xE0y \u0111\u1EA5y!",
        AddTurnTip: "Sau m\u1ED7i {0} b\u1EA1n s\u1EBD nh\u1EADn \u0111\u01B0\u1EE3c 1 l\u01B0\u1EE3t mi\u1EC5n ph\xED khi s\u1ED1 l\u01B0\u1EE3t \u0111ang c\xF3 nh\u1ECF h\u01A1n {1}",
        LetMisssion: "H\xE3y l\xE0m nhi\u1EC7m v\u1EE5 \u0111\u1EC3 nh\u1EADn th\xEAm nhi\u1EC1u l\u01B0\u1EE3t ch\u01A1i nh\xE9!",
        WatchMission: "Xem nhi\u1EC7m v\u1EE5",
        EndGameTipOB: "H\xE3y kh\xE1m ph\xE1 L\u1EAFc X\xEC 2022 \u0111\u1EC3 \u0111\u1ED5i s\u1ED1 k\u1EB9o ki\u1EBFm \u0111\u01B0\u1EE3c th\xE0nh nh\u1EEFng ph\u1EA7n qu\xE0 gi\xE1 tr\u1ECB",
        EndGameTip: "D\xF9ng k\u1EB9o \u0111\u1ED5i h\u1ED9p qu\xE0 h\u1EA5p d\u1EABn trong \"H\u1ED9i ch\u1EE3 s\u0103n qu\xE0\" c\u1EE7a L\u1EAFc X\xEC 2022",
        ClaimGift: "x\xE1c nh\u1EADn ph\u1EA7n th\u01B0\u1EDFng",
        ClaimGiftContent: "B\u1EA1n \u0111\xE3 ch\u1ECDn ph\u1EA7n th\u01B0\u1EDFng d\u01B0\u1EDBi \u0111\xE2y, h\xE3y x\xE1c nh\u1EADn \u0111\u1EC3 nh\u1EADn ngay nh\xE9.",
        ClaimGiftLate: "B\u1EA1n ch\u1EADm tay r\u1ED3i",
        OutOfGift: "Qu\xE0 \u0111\xE3 h\u1EBFt, h\xE3y quay l\u1EA1i sau nh\xE9."
      });

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Input.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, Node, _defineProperty, TouchState;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      Node = module.Node;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      TouchState = module.TouchState;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "e1c6c5BxUBFlrIibwgDLx5h", "Input", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let Input = exports('Input', (_dec = ccclass('Input'), _dec(_class = (_temp = _class2 = class Input extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "state", TouchState.None);

          _defineProperty(this, "isTouchDown", false);
        }

        static get Instance() {
          return Input.instance;
        }

        onLoad() {
          Input.instance = this;
          this.node.on(Node.EventType.TOUCH_START, this.onTouchBegan, this);
          this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
          this.node.on(Node.EventType.TOUCH_END, this.onTouchEnded, this);
          this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancelled, this);
        }

        lateUpdate() {
          if (this.state == TouchState.Down) {
            this.state = TouchState.Press;
          } else if (this.state == TouchState.Up) {
            this.state = TouchState.None;
          }
        }

        onTouchBegan(event) {
          // let touches = event.getTouches();
          this.isTouchDown = true;
          this.state = TouchState.Down; // this.StopPropagation(event);
        }

        onTouchEnded(event) {
          // let touches = event.getTouches();
          this.isTouchDown = false;
          this.state = TouchState.Up; // this.StopPropagation(event);
        }

        onTouchCancelled(event) {
          this.isTouchDown = false;
          this.state = TouchState.Up; // this.StopPropagation(event);
        }

        onTouchMove(event) {
          // let touches = event.getTouches();
          this.isTouchDown = true;
          this.state = TouchState.Press; // this.StopPropagation(event);
        }

        StopPropagation(event) {//event.propagationImmediateStopped = true;
        } // public static get State(): TouchState {
        //     return Input.instance.state;
        // }
        // public static get IsTouchDown(): boolean {
        //     return Input.instance.state == TouchState.Down;
        // }
        // public static get IsTouchUp(): boolean {
        //     return Input.instance.state == TouchState.Up;
        // }


      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ScoreEffect.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './AudioMgr.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, Label, _decorator, Component, Vec3, tween, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, GameDefine, SoundName, AudioMgr, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      Label = module.Label;
      _decorator = module._decorator;
      Component = module.Component;
      Vec3 = module.Vec3;
      tween = module.tween;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
      SoundName = module.SoundName;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _class3, _temp;

      cclegacy._RF.push({}, "e36b7n5B5ZLdpKAc4glyYxU", "ScoreEffect", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ScoreEffect = exports('ScoreEffect', (_dec = ccclass('ScoreEffect'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(Label), _dec(_class = (_class2 = (_temp = _class3 = class ScoreEffect extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "good", _descriptor, this);

          _initializerDefineProperty(this, "perfect", _descriptor2, this);

          _initializerDefineProperty(this, "cool", _descriptor3, this);

          _initializerDefineProperty(this, "xComboLabel", _descriptor4, this);
        }

        onLoad() {
          ScoreEffect.instance = this;
        }

        static get Instance() {
          return ScoreEffect.instance;
        }

        start() {
          this.node.children.forEach(element => {
            element.active = false;
          });
        }

        Good() {
          this.good.active = true;
          this.good.scale = Vec3.ZERO;
          tween(this.good).to(0.5, {
            scale: Vec3.ONE
          }, {
            easing: "elasticOut"
          }).call(() => {}).start();
          setTimeout(() => {
            this.good.active = false;
          }, 1000);
        }

        Perfect() {
          this.perfect.active = true;
          this.perfect.scale = Vec3.ZERO;
          tween(this.perfect).to(0.5, {
            scale: Vec3.ONE
          }, {
            easing: "elasticOut"
          }).call(() => {}).start();
          setTimeout(() => {
            this.perfect.active = false;
          }, 1000);

          if (GameMgr.Instance.CombPCounter > 1) {
            this.xComboLabel.node.active = true;
            this.xComboLabel.string = GameDefine.MULTIPLY_CHAR + GameMgr.Instance.CombPCounter.toString();
          } else {
            this.xComboLabel.node.active = false;
          }

          let sound = `ComboPerfect_${Math.max(1, Math.min(5, GameMgr.Instance.CombPCounter))}`;
          AudioMgr.Instance.PlaySfx(SoundName[sound], true);
        }

        Cool() {
          this.cool.active = true;
          this.cool.scale = Vec3.ZERO;
          tween(this.cool).to(0.5, {
            scale: Vec3.ONE
          }, {
            easing: "elasticOut"
          }).call(() => {}).start();
          setTimeout(() => {
            this.cool.active = false;
          }, 1000);
        }

      }, _defineProperty(_class3, "instance", null), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "good", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "perfect", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "cool", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "xComboLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/CollectionItem.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './MySprite.ts'], function (exports) {
  'use strict';

  var cclegacy, Node, UIOpacity, _decorator, Component, tween, _applyDecoratedDescriptor, _initializerDefineProperty, MySprite;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Node = module.Node;
      UIOpacity = module.UIOpacity;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      MySprite = module.MySprite;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp;

      cclegacy._RF.push({}, "e37f8YxwC1E0pNW+Qobqrkz", "CollectionItem", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let CollectionItem = exports('CollectionItem', (_dec = ccclass('CollectionItem'), _dec2 = property(MySprite), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(UIOpacity), _dec6 = property(Node), _dec(_class = (_class2 = (_temp = class CollectionItem extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "rootSprite", _descriptor, this);

          _initializerDefineProperty(this, "image", _descriptor2, this);

          _initializerDefineProperty(this, "imageEmpty", _descriptor3, this);

          _initializerDefineProperty(this, "opacityComp", _descriptor4, this);

          _initializerDefineProperty(this, "amoutLabel", _descriptor5, this);
        }

        setImage(imageUrl) {
          this.rootSprite.Fetch(imageUrl);
        }

        setAmout(amount) {
          if (amount == 0) {
            this.imageEmpty.active = true;
            this.image.active = false;
          } else {
            this.amoutLabel.active = true;
            this.imageEmpty.active = false;
            this.image.active = true;
          }
        }

        setCombined() {
          this.imageEmpty.active = false;
          this.image.active = true;
          this.amoutLabel.active = false;
          tween({
            opacity: 255
          }).to(2, {
            opacity: 0
          }, {
            onUpdate: (target, ratio) => {
              this.opacityComp.opacity = target.opacity;
            },
            easing: "sineOut"
          }).start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rootSprite", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "image", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "imageEmpty", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "opacityComp", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "amoutLabel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ProgressScrollView.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './ProgressGiftItem.ts'], function (exports) {
  'use strict';

  var cclegacy, Prefab, Node, _decorator, ScrollView, instantiate, Layout, UITransformComponent, _applyDecoratedDescriptor, _initializerDefineProperty, ProgressGiftItem;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      Node = module.Node;
      _decorator = module._decorator;
      ScrollView = module.ScrollView;
      instantiate = module.instantiate;
      Layout = module.Layout;
      UITransformComponent = module.UITransformComponent;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      ProgressGiftItem = module.ProgressGiftItem;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp;

      cclegacy._RF.push({}, "e7045fsciFDjYtFvve2ZWok", "ProgressScrollView", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ProgressScrollView = exports('ProgressScrollView', (_dec = ccclass('ProgressScrollView'), _dec2 = property(Prefab), _dec3 = property(Node), _dec4 = property(Node), _dec(_class = (_class2 = (_temp = class ProgressScrollView extends ScrollView {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "progressGiftItem", _descriptor, this);

          _initializerDefineProperty(this, "emptyNode", _descriptor2, this);

          _initializerDefineProperty(this, "container", _descriptor3, this);
        }

        start() {}

        loadView(listMilestone, currentPoint, callback) {
          const self = this;
          listMilestone.forEach((item, index) => {
            const cell = instantiate(this.progressGiftItem);
            self.container.addChild(cell);
            cell.getComponent(ProgressGiftItem).loadView(item);
          });
          this.container.getComponent(Layout).updateLayout(true);
          const height = this.container.getComponent(UITransformComponent).height;
          this.content.getComponent(UITransformComponent).height = height;
          let listLabelScorePosition = [];
          this.container.children.forEach(element => {
            let y = element.position.y;
            y = y + element.getComponent(ProgressGiftItem).getBackgroundPosition().y;
            listLabelScorePosition.push(y);
          });
          callback(listLabelScorePosition);
        }

        setVisibleEmpty(isVisible) {
          this.emptyNode.active = isVisible;
        }

        clear() {
          this.container.removeAllChildren();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "progressGiftItem", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "emptyNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MyGiftCell.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './Utils.ts', './MySprite.ts'], function (exports) {
  'use strict';

  var cclegacy, Label, _decorator, Component, _applyDecoratedDescriptor, _initializerDefineProperty, Utils, MySprite;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MySprite = module.MySprite;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "e90d13wy5pB3oSpiXNONaxl", "MyGiftCell", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let MyGiftCell = exports('MyGiftCell', (_dec = ccclass('MyGiftCell'), _dec2 = property(MySprite), _dec3 = property(Label), _dec(_class = (_class2 = (_temp = class MyGiftCell extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "giftIcon", _descriptor, this);

          _initializerDefineProperty(this, "giftNameLabel", _descriptor2, this);
        }

        setInfo(item) {
          //this.giftIcon.Fetch(item.iconUrl);
          this.giftNameLabel.string = Utils.truncate(item.giftName, 10);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "giftIcon", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "giftNameLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/maxApi.js", ['./cjs-loader.mjs'], function (exports, module) {
  'use strict';

  var loader;
  return {
    setters: [function (module) {
      loader = module.default;
    }],
    execute: function () {
      exports('default', void 0);

      let _cjsExports;

      loader.define(module.meta.url, function (exports$1, _require, module, __filename, __dirname) {
        let require = loader.createRequireWithReqMap({}, _require);

        (function () {
          /*! For license information please see bundle.js.LICENSE.txt */
          (() => {
            var t = {
              321: (t, n, r) => {
                var e,
                    i = (e = r(211)) && e.__esModule ? e : {
                  default: e
                };
                Object.defineProperty(n, "__esModule", {
                  value: !0
                }), n.default = void 0;
                var a = i.default;
                n.default = a;
              },
              590: (t, n, r) => {
                var e,
                    i = (e = r(285)) && e.__esModule ? e : {
                  default: e
                };

                function a(t) {
                  return a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t;
                  } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
                  }, a(t);
                }

                function o(t, n) {
                  var r = Object.keys(t);

                  if (Object.getOwnPropertySymbols) {
                    var e = Object.getOwnPropertySymbols(t);
                    n && (e = e.filter(function (n) {
                      return Object.getOwnPropertyDescriptor(t, n).enumerable;
                    })), r.push.apply(r, e);
                  }

                  return r;
                }

                function u(t) {
                  for (var n, r = 1; r < arguments.length; r++) n = null == arguments[r] ? {} : arguments[r], r % 2 ? o(Object(n), !0).forEach(function (r) {
                    s(t, r, n[r]);
                  }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function (r) {
                    Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(n, r));
                  });

                  return t;
                }

                function c(t, n) {
                  for (var r, e = 0; e < n.length; e++) (r = n[e]).enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r);
                }

                function s(t, n, r) {
                  return n in t ? Object.defineProperty(t, n, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                  }) : t[n] = r, t;
                }

                Object.defineProperty(n, "__esModule", {
                  value: !0
                }), n.default = void 0;

                var f = function () {
                  function t() {
                    !function (t, n) {
                      if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function");
                    }(this, t);
                  }

                  return function (t, n, r) {
                    n && c(t.prototype, n), r && c(t, r), Object.defineProperty(t, "prototype", {
                      writable: !1
                    });
                  }(t, [{
                    key: "addHost",
                    value: function (t) {
                      var n,
                          r,
                          e = !1;
                      this.hosts = null === (n = this.hosts) || void 0 === n ? void 0 : n.map(function (n) {
                        return n.hostId == t.hostId && (e = !0, n = u(u({}, n), t)), n;
                      }), e || (this.hosts = null !== (r = this.hosts) && void 0 !== r ? r : [], this.hosts.push(t));
                    }
                  }, {
                    key: "removeHost",
                    value: function (t) {
                      var n;
                      this.hosts = null === (n = this.hosts) || void 0 === n ? void 0 : n.filter(function (n) {
                        return n.hostId != t.hostId;
                      });
                    }
                  }, {
                    key: "currentHost",
                    get: function () {
                      var t;
                      return 0 < (null === (t = this.hosts) || void 0 === t ? void 0 : t.length) ? this.hosts[this.hosts.length - 1] : {};
                    }
                  }, {
                    key: "verifyResponse",
                    value: function (t) {
                      return !!t.miniApp;
                    }
                  }, {
                    key: "response",
                    value: function (t) {
                      try {
                        var n = JSON.parse(t);

                        if (n && this.verifyResponse(n)) {
                          var r = n.uuid,
                              e = n.result,
                              i = n.func,
                              o = n.isListening,
                              u = this.callbacks[r];

                          if (u) {
                            try {
                              if ("object" === a(e)) u(e);else u(JSON.parse(e || "") || e);
                            } catch (t) {
                              u(e);
                            }

                            if (0 === i.indexOf("observerUploadDocuments") || o) return;
                            "removeCallback" == i ? this.callbacks && this.callbacks[r] && delete this.callbacks[r] : this.removeCallback(r);
                          }
                        }
                      } catch (t) {}
                    }
                  }, {
                    key: "removeCallback",
                    value: function (t) {
                      this.dispatchFunction("removeCallback", t), this.callbacks && this.callbacks[t] && delete this.callbacks[t];
                    }
                  }, {
                    key: "dispatch",
                    value: function () {
                      var t = this,
                          n = null,
                          r = Array.from(arguments),
                          e = r[0];

                      if (r.shift(), 0 < r.length) {
                        var a = r[r.length - 1];
                        "function" == typeof a && (n = a, r.pop());
                      }

                      var o = this.getUniqueId();
                      this.callbacks || (this.callbacks = {}), n && (this.callbacks[o] = n);
                      var u = i.default.apiVersion,
                          c = this.currentHost,
                          s = {
                        func: e,
                        args: r,
                        uuid: o,
                        platform: this.platform,
                        apiVersion: u,
                        miniApp: c
                      };
                      return this.request(s, n), {
                        remove: function () {
                          t.removeCallback(o);
                        }
                      };
                    }
                  }, {
                    key: "request",
                    value: function () {}
                  }, {
                    key: "getUniqueId",
                    value: function () {
                      return Math.random().toString(36).substring(2) + Date.now().toString(36);
                    }
                  }, {
                    key: "dispatchFunction",
                    value: function () {
                      return this.dispatch.apply(this, arguments);
                    }
                  }], [{
                    key: "init",
                    value: function (n) {
                      var r,
                          e = (null == n || null === (r = n.client) || void 0 === r ? void 0 : r.web) || n || {},
                          i = e.appId;
                      return t.instances[i] || (t.instances[i] = new this(e)), t.instances[i].addHost(e), t.instances[i];
                    }
                  }]), t;
                }();

                n.default = f, s(f, "instances", {}), s(f, "hosts", []);
              },
              211: (t, n, r) => {
                var e,
                    i = (e = r(590)) && e.__esModule ? e : {
                  default: e
                };

                function a(t) {
                  return a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t;
                  } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
                  }, a(t);
                }

                function o(t, n) {
                  for (var r, e = 0; e < n.length; e++) (r = n[e]).enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r);
                }

                function u(t, n) {
                  return u = Object.setPrototypeOf || function (t, n) {
                    return t.__proto__ = n, t;
                  }, u(t, n);
                }

                function c(t, n) {
                  if (n && ("object" === a(n) || "function" == typeof n)) return n;
                  if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                  return function (t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t;
                  }(t);
                }

                function s(t) {
                  return s = Object.setPrototypeOf ? Object.getPrototypeOf : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                  }, s(t);
                }

                Object.defineProperty(n, "__esModule", {
                  value: !0
                }), n.default = void 0;

                var f = function (t) {
                  function n(t) {
                    var e;
                    return function (t, n) {
                      if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function");
                    }(this, n), (e = r.call(this, t)).props = t, e.platform = "web", window.addEventListener("message", function (t) {
                      e.response(t.data);
                    }), e;
                  }

                  !function (t, n) {
                    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function");
                    Object.defineProperty(t, "prototype", {
                      value: Object.create(n && n.prototype, {
                        constructor: {
                          value: t,
                          writable: !0,
                          configurable: !0
                        }
                      }),
                      writable: !1
                    }), n && u(t, n);
                  }(n, t);

                  var r = function (t) {
                    var n = function () {
                      if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                      if (Reflect.construct.sham) return !1;
                      if ("function" == typeof Proxy) return !0;

                      try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})), !0;
                      } catch (t) {
                        return !1;
                      }
                    }();

                    return function () {
                      var r,
                          e = s(t);

                      if (n) {
                        var i = s(this).constructor;
                        r = Reflect.construct(e, arguments, i);
                      } else r = e.apply(this, arguments);

                      return c(this, r);
                    };
                  }(n);

                  return function (t, n, r) {
                    n && o(t.prototype, n), Object.defineProperty(t, "prototype", {
                      writable: !1
                    });
                  }(n, [{
                    key: "request",
                    value: function (t) {
                      var n = JSON.stringify(t),
                          r = window.ReactNativeWebView;
                      r && r.postMessage(n);
                    }
                  }]), n;
                }(i.default);

                n.default = f;
              },
              103: (t, n, r) => {
                var e,
                    i = (e = r(321)) && e.__esModule ? e : {
                  default: e
                };

                function a(t) {
                  return a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
                    return typeof t;
                  } : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
                  }, a(t);
                }

                function o(t, n) {
                  if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function");
                }

                function u(t, n) {
                  for (var r, e = 0; e < n.length; e++) (r = n[e]).enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r);
                }

                function c(t, n) {
                  return c = Object.setPrototypeOf || function (t, n) {
                    return t.__proto__ = n, t;
                  }, c(t, n);
                }

                function s(t, n) {
                  if (n && ("object" === a(n) || "function" == typeof n)) return n;
                  if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                  return function (t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t;
                  }(t);
                }

                function f(t) {
                  return f = Object.setPrototypeOf ? Object.getPrototypeOf : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                  }, f(t);
                }

                Object.defineProperty(n, "__esModule", {
                  value: !0
                }), n.default = void 0;

                var l = function (t) {
                  function n() {
                    return o(this, n), r.apply(this, arguments);
                  }

                  !function (t, n) {
                    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function");
                    Object.defineProperty(t, "prototype", {
                      value: Object.create(n && n.prototype, {
                        constructor: {
                          value: t,
                          writable: !0,
                          configurable: !0
                        }
                      }),
                      writable: !1
                    }), n && c(t, n);
                  }(n, t);

                  var r = function (t) {
                    var n = function () {
                      if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                      if (Reflect.construct.sham) return !1;
                      if ("function" == typeof Proxy) return !0;

                      try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})), !0;
                      } catch (t) {
                        return !1;
                      }
                    }();

                    return function () {
                      var r,
                          e = f(t);

                      if (n) {
                        var i = f(this).constructor;
                        r = Reflect.construct(e, arguments, i);
                      } else r = e.apply(this, arguments);

                      return s(this, r);
                    };
                  }(n);

                  return function (t, n, r) {
                    n && u(t.prototype, n), Object.defineProperty(t, "prototype", {
                      writable: !1
                    });
                  }(n, [{
                    key: "getBillCount",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getBillCount"].concat(n));
                    }
                  }, {
                    key: "getFolderVoucherCount",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getFolderVoucherCount"].concat(n));
                    }
                  }, {
                    key: "getChatCount",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getChatCount"].concat(n));
                    }
                  }, {
                    key: "getMobileVoucherCount",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getMobileVoucherCount"].concat(n));
                    }
                  }, {
                    key: "getUserBills",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getUserBills"].concat(n));
                    }
                  }, {
                    key: "saveBill",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["saveBill"].concat(n));
                    }
                  }, {
                    key: "chatGRPCConnect",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["chatGRPCConnect"].concat(n));
                    }
                  }, {
                    key: "chatSendMessageGRPC",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["chatSendMessageGRPC"].concat(n));
                    }
                  }, {
                    key: "listenChat",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["listenChat"].concat(n));
                    }
                  }, {
                    key: "copyToClipboard",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["copyToClipboard"].concat(n));
                    }
                  }, {
                    key: "openDialer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["openDialer"].concat(n));
                    }
                  }, {
                    key: "getBase64FromUrl",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getBase64FromUrl"].concat(n));
                    }
                  }, {
                    key: "setBrightnessLevel",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setBrightnessLevel"].concat(n));
                    }
                  }, {
                    key: "getBrightnessLevel",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getBrightnessLevel"].concat(n));
                    }
                  }, {
                    key: "getSystemBrightnessLevel",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getSystemBrightnessLevel"].concat(n));
                    }
                  }, {
                    key: "sendSMS",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendSMS"].concat(n));
                    }
                  }, {
                    key: "getScreenShot",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getScreenShot"].concat(n));
                    }
                  }, {
                    key: "enableScreenshots",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["enableScreenshots"].concat(n));
                    }
                  }, {
                    key: "getIpAddress",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getIpAddress"].concat(n));
                    }
                  }, {
                    key: "getImage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getImage"].concat(n));
                    }
                  }, {
                    key: "saveImage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["saveImage"].concat(n));
                    }
                  }, {
                    key: "getImageSize",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getImageSize"].concat(n));
                    }
                  }, {
                    key: "getImageRotateFromUri",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getImageRotateFromUri"].concat(n));
                    }
                  }, {
                    key: "openURLWithPackageId",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["openURLWithPackageId"].concat(n));
                    }
                  }, {
                    key: "openURL",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["openURL"].concat(n));
                    }
                  }, {
                    key: "playYouTube",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["playYouTube"].concat(n));
                    }
                  }, {
                    key: "requestATTPermision",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestATTPermision"].concat(n));
                    }
                  }, {
                    key: "trackEvent",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["trackEvent"].concat(n));
                    }
                  }, {
                    key: "track",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["track"].concat(n));
                    }
                  }, {
                    key: "trackPurchase",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["trackPurchase"].concat(n));
                    }
                  }, {
                    key: "shareFacebook",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["shareFacebook"].concat(n));
                    }
                  }, {
                    key: "throwJSException",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["throwJSException"].concat(n));
                    }
                  }, {
                    key: "uploadImage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["uploadImage"].concat(n));
                    }
                  }, {
                    key: "share",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["share"].concat(n));
                    }
                  }, {
                    key: "setBadgeFeature",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setBadgeFeature"].concat(n));
                    }
                  }, {
                    key: "getDeviceInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getDeviceInfo"].concat(n));
                    }
                  }, {
                    key: "openDeviceSetting",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["openDeviceSetting"].concat(n));
                    }
                  }, {
                    key: "isHighPerformanceDevice",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["isHighPerformanceDevice"].concat(n));
                    }
                  }, {
                    key: "registerShakeSensitivity",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["registerShakeSensitivity"].concat(n));
                    }
                  }, {
                    key: "unregisterShakeSensitivity",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["unregisterShakeSensitivity"].concat(n));
                    }
                  }, {
                    key: "saveCalendarEvent",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["saveCalendarEvent"].concat(n));
                    }
                  }, {
                    key: "sendExtraMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendExtraMessage"].concat(n));
                    }
                  }, {
                    key: "activeKeepAwake",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["activeKeepAwake"].concat(n));
                    }
                  }, {
                    key: "requestLogout",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestLogout"].concat(n));
                    }
                  }, {
                    key: "setBackgroundTimeout",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setBackgroundTimeout"].concat(n));
                    }
                  }, {
                    key: "setFastLogin",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setFastLogin"].concat(n));
                    }
                  }, {
                    key: "getDynamicLink",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getDynamicLink"].concat(n));
                    }
                  }, {
                    key: "getToolkit",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getToolkit"].concat(n));
                    }
                  }, {
                    key: "showToolkit",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showToolkit"].concat(n));
                    }
                  }, {
                    key: "uploadFiles",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["uploadFiles"].concat(n));
                    }
                  }, {
                    key: "getPrivateLink",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getPrivateLink"].concat(n));
                    }
                  }, {
                    key: "uploadAvatar",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["uploadAvatar"].concat(n));
                    }
                  }, {
                    key: "getConfig",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getConfig"].concat(n));
                    }
                  }, {
                    key: "getContactAvatar",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getContactAvatar"].concat(n));
                    }
                  }, {
                    key: "getContacts",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getContacts"].concat(n));
                    }
                  }, {
                    key: "getAgentContacts",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getAgentContacts"].concat(n));
                    }
                  }, {
                    key: "getContactInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getContactInfo"].concat(n));
                    }
                  }, {
                    key: "getContact",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getContact"].concat(n));
                    }
                  }, {
                    key: "queryContact",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["queryContact"].concat(n));
                    }
                  }, {
                    key: "saveContact",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["saveContact"].concat(n));
                    }
                  }, {
                    key: "mapContacts",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["mapContacts"].concat(n));
                    }
                  }, {
                    key: "syncContacts",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["syncContacts"].concat(n));
                    }
                  }, {
                    key: "syncContactAfter1Day",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["syncContactAfter1Day"].concat(n));
                    }
                  }, {
                    key: "syncContactAfter1Minute",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["syncContactAfter1Minute"].concat(n));
                    }
                  }, {
                    key: "pickSingleDocument",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["pickSingleDocument"].concat(n));
                    }
                  }, {
                    key: "pickMultiDocument",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["pickMultiDocument"].concat(n));
                    }
                  }, {
                    key: "uploadDocuments",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["uploadDocuments"].concat(n));
                    }
                  }, {
                    key: "observerUploadDocuments",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["observerUploadDocuments"].concat(n));
                    }
                  }, {
                    key: "cancelUpload",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["cancelUpload"].concat(n));
                    }
                  }, {
                    key: "startCaptureSideDocument",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startCaptureSideDocument"].concat(n));
                    }
                  }, {
                    key: "startCaptureFace",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startCaptureFace"].concat(n));
                    }
                  }, {
                    key: "faceMatching",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["faceMatching"].concat(n));
                    }
                  }, {
                    key: "addFace",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["addFace"].concat(n));
                    }
                  }, {
                    key: "getKycStatus",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getKycStatus"].concat(n));
                    }
                  }, {
                    key: "getAvatarEndPoint",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getAvatarEndPoint"].concat(n));
                    }
                  }, {
                    key: "getResourceEndpoint",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getResourceEndpoint"].concat(n));
                    }
                  }, {
                    key: "getFirebaseWebAppConfig",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getFirebaseWebAppConfig"].concat(n));
                    }
                  }, {
                    key: "checkABTestFlow",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["checkABTestFlow"].concat(n));
                    }
                  }, {
                    key: "getSteps",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getSteps"].concat(n));
                    }
                  }, {
                    key: "getFullListFriendMoMo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getFullListFriendMoMo"].concat(n));
                    }
                  }, {
                    key: "friendQuery",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["friendQuery"].concat(n));
                    }
                  }, {
                    key: "requestGameAction",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestGameAction"].concat(n));
                    }
                  }, {
                    key: "listenAcademy",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["listenAcademy"].concat(n));
                    }
                  }, {
                    key: "getBadgeTicket",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getBadgeTicket"].concat(n));
                    }
                  }, {
                    key: "listen",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["listen"].concat(n));
                    }
                  }, {
                    key: "requestLoan",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestLoan"].concat(n));
                    }
                  }, {
                    key: "requestLocation",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestLocation"].concat(n));
                    }
                  }, {
                    key: "requestLocationWithOptions",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestLocationWithOptions"].concat(n));
                    }
                  }, {
                    key: "getLocation",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getLocation"].concat(n));
                    }
                  }, {
                    key: "chatCrmGRPCConnect",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["chatCrmGRPCConnect"].concat(n));
                    }
                  }, {
                    key: "chatCrmSendMessageGRPC",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["chatCrmSendMessageGRPC"].concat(n));
                    }
                  }, {
                    key: "chatCrmGetConnectionStatus",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["chatCrmGetConnectionStatus"].concat(n));
                    }
                  }, {
                    key: "chatCrmGRPCDisconnect",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["chatCrmGRPCDisconnect"].concat(n));
                    }
                  }, {
                    key: "listenChatCrm",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["listenChatCrm"].concat(n));
                    }
                  }, {
                    key: "subscribeMqttTopic",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["subscribeMqttTopic"].concat(n));
                    }
                  }, {
                    key: "unSubscribeMqttTopic",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["unSubscribeMqttTopic"].concat(n));
                    }
                  }, {
                    key: "fetchNetworkInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["fetchNetworkInfo"].concat(n));
                    }
                  }, {
                    key: "useNetInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["useNetInfo"].concat(n));
                    }
                  }, {
                    key: "sendMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendMessage"].concat(n));
                    }
                  }, {
                    key: "getMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getMessage"].concat(n));
                    }
                  }, {
                    key: "sendConfirmMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendConfirmMessage"].concat(n));
                    }
                  }, {
                    key: "sendProxyMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendProxyMessage"].concat(n));
                    }
                  }, {
                    key: "sendCloudMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendCloudMessage"].concat(n));
                    }
                  }, {
                    key: "getCloudMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getCloudMessage"].concat(n));
                    }
                  }, {
                    key: "clickNotification",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["clickNotification"].concat(n));
                    }
                  }, {
                    key: "showPopupNotification",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showPopupNotification"].concat(n));
                    }
                  }, {
                    key: "observer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["observer"].concat(n));
                    }
                  }, {
                    key: "getDataObserver",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getDataObserver"].concat(n));
                    }
                  }, {
                    key: "setDataObserver",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setDataObserver"].concat(n));
                    }
                  }, {
                    key: "getPassengerInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getPassengerInfo"].concat(n));
                    }
                  }, {
                    key: "setPassengerInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setPassengerInfo"].concat(n));
                    }
                  }, {
                    key: "requestPayment",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestPayment"].concat(n));
                    }
                  }, {
                    key: "internalRequestPayment",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["internalRequestPayment"].concat(n));
                    }
                  }, {
                    key: "requestPaymentSdk",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestPaymentSdk"].concat(n));
                    }
                  }, {
                    key: "addItemToCart",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["addItemToCart"].concat(n));
                    }
                  }, {
                    key: "gotoCart",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["gotoCart"].concat(n));
                    }
                  }, {
                    key: "clearCart",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["clearCart"].concat(n));
                    }
                  }, {
                    key: "getSources",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getSources"].concat(n));
                    }
                  }, {
                    key: "countTrace",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["countTrace"].concat(n));
                    }
                  }, {
                    key: "errorTrace",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["errorTrace"].concat(n));
                    }
                  }, {
                    key: "startTrace",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startTrace"].concat(n));
                    }
                  }, {
                    key: "stopTrace",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["stopTrace"].concat(n));
                    }
                  }, {
                    key: "traceSuccess",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["traceSuccess"].concat(n));
                    }
                  }, {
                    key: "traceFail",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["traceFail"].concat(n));
                    }
                  }, {
                    key: "startTraceScreenLoad",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startTraceScreenLoad"].concat(n));
                    }
                  }, {
                    key: "startTraceScreenInteraction",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startTraceScreenInteraction"].concat(n));
                    }
                  }, {
                    key: "startTraceScreenGoal",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startTraceScreenGoal"].concat(n));
                    }
                  }, {
                    key: "requestPermission",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestPermission"].concat(n));
                    }
                  }, {
                    key: "checkPermission",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["checkPermission"].concat(n));
                    }
                  }, {
                    key: "scanQRCode",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["scanQRCode"].concat(n));
                    }
                  }, {
                    key: "realmQuery",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["realmQuery"].concat(n));
                    }
                  }, {
                    key: "realmSave",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["realmSave"].concat(n));
                    }
                  }, {
                    key: "realmDelete",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["realmDelete"].concat(n));
                    }
                  }, {
                    key: "navigate",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["navigate"].concat(n));
                    }
                  }, {
                    key: "startApp",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startApp"].concat(n));
                    }
                  }, {
                    key: "startMiniApp",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startMiniApp"].concat(n));
                    }
                  }, {
                    key: "startService",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startService"].concat(n));
                    }
                  }, {
                    key: "startServiceId",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startServiceId"].concat(n));
                    }
                  }, {
                    key: "startFeature",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startFeature"].concat(n));
                    }
                  }, {
                    key: "startFeatureCode",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startFeatureCode"].concat(n));
                    }
                  }, {
                    key: "openWeb",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["openWeb"].concat(n));
                    }
                  }, {
                    key: "dismiss",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["dismiss"].concat(n));
                    }
                  }, {
                    key: "dismissAll",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["dismissAll"].concat(n));
                    }
                  }, {
                    key: "goBack",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["goBack"].concat(n));
                    }
                  }, {
                    key: "goHome",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["goHome"].concat(n));
                    }
                  }, {
                    key: "navigateTab",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["navigateTab"].concat(n));
                    }
                  }, {
                    key: "getListFriendMoMo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getListFriendMoMo"].concat(n));
                    }
                  }, {
                    key: "getRelationShipStatus",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getRelationShipStatus"].concat(n));
                    }
                  }, {
                    key: "acceptFriendRequest",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["acceptFriendRequest"].concat(n));
                    }
                  }, {
                    key: "sendFriendRequest",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendFriendRequest"].concat(n));
                    }
                  }, {
                    key: "blockUser",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["blockUser"].concat(n));
                    }
                  }, {
                    key: "unBlockUser",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["unBlockUser"].concat(n));
                    }
                  }, {
                    key: "getFacebookFriendList",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getFacebookFriendList"].concat(n));
                    }
                  }, {
                    key: "socialShare",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["socialShare"].concat(n));
                    }
                  }, {
                    key: "downloadMediaFile",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["downloadMediaFile"].concat(n));
                    }
                  }, {
                    key: "playSound",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["playSound"].concat(n));
                    }
                  }, {
                    key: "pauseSound",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["pauseSound"].concat(n));
                    }
                  }, {
                    key: "resumeSound",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["resumeSound"].concat(n));
                    }
                  }, {
                    key: "stopSound",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["stopSound"].concat(n));
                    }
                  }, {
                    key: "getItem",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getItem"].concat(n));
                    }
                  }, {
                    key: "setItem",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setItem"].concat(n));
                    }
                  }, {
                    key: "removeItem",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["removeItem"].concat(n));
                    }
                  }, {
                    key: "requestSync",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestSync"].concat(n));
                    }
                  }, {
                    key: "getTransactionWithServiceIds",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getTransactionWithServiceIds"].concat(n));
                    }
                  }, {
                    key: "getTransactionInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getTransactionInfo"].concat(n));
                    }
                  }, {
                    key: "getTransactionStatusCode",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getTransactionStatusCode"].concat(n));
                    }
                  }, {
                    key: "getStatusInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getStatusInfo"].concat(n));
                    }
                  }, {
                    key: "getAllTransactionStatusInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getAllTransactionStatusInfo"].concat(n));
                    }
                  }, {
                    key: "getAllTransactionStatusCode",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getAllTransactionStatusCode"].concat(n));
                    }
                  }, {
                    key: "getMoneySourceName",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getMoneySourceName"].concat(n));
                    }
                  }, {
                    key: "getFeatureById",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getFeatureById"].concat(n));
                    }
                  }, {
                    key: "startTranHisDetail",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startTranHisDetail"].concat(n));
                    }
                  }, {
                    key: "getFilteredTranHisList",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getFilteredTranHisList"].concat(n));
                    }
                  }, {
                    key: "getListTransaction",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getListTransaction"].concat(n));
                    }
                  }, {
                    key: "getListTransaction6M",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getListTransaction6M"].concat(n));
                    }
                  }, {
                    key: "getBrowseTransaction",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getBrowseTransaction"].concat(n));
                    }
                  }, {
                    key: "getDetailTransaction",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getDetailTransaction"].concat(n));
                    }
                  }, {
                    key: "getListTransactionBaseInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getListTransactionBaseInfo"].concat(n));
                    }
                  }, {
                    key: "sendThanksMessage",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["sendThanksMessage"].concat(n));
                    }
                  }, {
                    key: "showToast",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showToast"].concat(n));
                    }
                  }, {
                    key: "hideToast",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["hideToast"].concat(n));
                    }
                  }, {
                    key: "showLoading",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showLoading"].concat(n));
                    }
                  }, {
                    key: "hideLoading",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["hideLoading"].concat(n));
                    }
                  }, {
                    key: "showAlert",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showAlert"].concat(n));
                    }
                  }, {
                    key: "showAction",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showAction"].concat(n));
                    }
                  }, {
                    key: "showPicker",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["showPicker"].concat(n));
                    }
                  }, {
                    key: "getProfile",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getProfile"].concat(n));
                    }
                  }, {
                    key: "requestUserInfo",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestUserInfo"].concat(n));
                    }
                  }, {
                    key: "requestUserConsents",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["requestUserConsents"].concat(n));
                    }
                  }, {
                    key: "getUserConsents",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getUserConsents"].concat(n));
                    }
                  }, {
                    key: "setProfile",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setProfile"].concat(n));
                    }
                  }, {
                    key: "observerProfile",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["observerProfile"].concat(n));
                    }
                  }, {
                    key: "setUserProfileExtraOnServer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["setUserProfileExtraOnServer"].concat(n));
                    }
                  }, {
                    key: "getUserUUID",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getUserUUID"].concat(n));
                    }
                  }, {
                    key: "getUserAuth",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getUserAuth"].concat(n));
                    }
                  }, {
                    key: "getWalletId",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getWalletId"].concat(n));
                    }
                  }, {
                    key: "updateItemServer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["updateItemServer"].concat(n));
                    }
                  }, {
                    key: "updateItemLocal",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["updateItemLocal"].concat(n));
                    }
                  }, {
                    key: "getItemsServer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getItemsServer"].concat(n));
                    }
                  }, {
                    key: "getItemsLocal",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getItemsLocal"].concat(n));
                    }
                  }, {
                    key: "getItemLocal",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getItemLocal"].concat(n));
                    }
                  }, {
                    key: "getVouchersCount",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getVouchersCount"].concat(n));
                    }
                  }, {
                    key: "getVouchers",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getVouchers"].concat(n));
                    }
                  }, {
                    key: "onUseVoucher",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["onUseVoucher"].concat(n));
                    }
                  }, {
                    key: "getVoucherBackend",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["getVoucherBackend"].concat(n));
                    }
                  }, {
                    key: "pushWebNavigationOptions",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["pushWebNavigationOptions"].concat(n));
                    }
                  }, {
                    key: "popWebNavigationOptions",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["popWebNavigationOptions"].concat(n));
                    }
                  }, {
                    key: "popNWebNavigationOptions",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["popNWebNavigationOptions"].concat(n));
                    }
                  }, {
                    key: "replaceWebNavigationOptions",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["replaceWebNavigationOptions"].concat(n));
                    }
                  }, {
                    key: "triggerEventVibration",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["triggerEventVibration"].concat(n));
                    }
                  }, {
                    key: "startStaticServer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["startStaticServer"].concat(n));
                    }
                  }, {
                    key: "stopStaticServer",
                    value: function () {
                      for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];

                      return this.dispatchFunction.apply(this, ["stopStaticServer"].concat(n));
                    }
                  }]), n;
                }(i.default);

                n.default = l;
              },
              802: (t, n, r) => {
                var e,
                    i = (e = r(103)) && e.__esModule ? e : {
                  default: e
                };
                n.Z = void 0;
                var a = {},
                    o = null,
                    u = null,
                    c = {
                  get: function (t, n) {
                    var r = this;
                    return this[n] ? "function" == typeof this[n] ? this[n].bind(this) : this[n] : a[n] ? "function" == typeof a[n] ? a[n].bind(a) : a[n] : function () {
                      for (var t = arguments.length, e = Array(t), i = 0; i < t; i++) e[i] = arguments[i];

                      var o = 0 < Object.keys(a).length;
                      o ? console.warn("undefined is not a function") : r.waitForInit().then(function () {
                        try {
                          if ("function" == typeof a[n]) {
                            var t = a[n];
                            t.call.apply(t, [a].concat(e));
                          } else console.warn("Error when calling function: ".concat(n, ". ApiBase haven't been initialized yet!"));
                        } catch (t) {
                          console.warn("MaxApiError: " + t);
                        }
                      });
                    };
                  },
                  set: function (t, n, r) {
                    return a[n] = r, !0;
                  },
                  init: function (t) {
                    a = i.default.init(t), !o || !u || (u(!0), o = null, u = null);
                  },
                  waitForInit: function () {
                    return o || (o = new Promise(function (t) {
                      u = t;
                    })), o;
                  },
                  registerApp: function (t, n) {
                    var e;
                    t.bridgeMode = null !== (e = r.g) && void 0 !== e && e.__repack__ && "vn.momo.platform" != t.appId ? 1 : 2;
                    var c = i.default.registerApp(t, n, function (t) {
                      a = t, !o || !u || (u(!0), o = null, u = null);
                    });
                    return c;
                  }
                },
                    s = new Proxy({}, c);
                n.Z = s;
              },
              426: (t, n, r) => {
                (n = r(645)(!1)).push([t.id, "body\r\n{\r\n    margin: 0;\r\n    /* background: url('./assets/images/bodyBackground.png'); */\r\n    background-size: 100% 100%;\r\n    background-repeat: no-repeat;\r\n}", ""]), t.exports = n;
              },
              645: t => {
                t.exports = function (t) {
                  var n = [];
                  return n.toString = function () {
                    return this.map(function (n) {
                      var r = function (t, n) {
                        var r,
                            e,
                            i,
                            a = t[1] || "",
                            o = t[3];
                        if (!o) return a;

                        if (n && "function" == typeof btoa) {
                          var u = (r = o, e = btoa(unescape(encodeURIComponent(JSON.stringify(r)))), i = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(e), "/*# ".concat(i, " */")),
                              c = o.sources.map(function (t) {
                            return "/*# sourceURL=".concat(o.sourceRoot || "").concat(t, " */");
                          });
                          return [a].concat(c).concat([u]).join("\n");
                        }

                        return [a].join("\n");
                      }(n, t);

                      return n[2] ? "@media ".concat(n[2], " {").concat(r, "}") : r;
                    }).join("");
                  }, n.i = function (t, r, e) {
                    "string" == typeof t && (t = [[null, t, ""]]);
                    var i = {};
                    if (e) for (var a = 0; a < this.length; a++) {
                      var o = this[a][0];
                      null != o && (i[o] = !0);
                    }

                    for (var u = 0; u < t.length; u++) {
                      var c = [].concat(t[u]);
                      e && i[c[0]] || (r && (c[2] ? c[2] = "".concat(r, " and ").concat(c[2]) : c[2] = r), n.push(c));
                    }
                  }, n;
                };
              },
              486: function (t, n, r) {
                var e;
                t = r.nmd(t), function () {
                  var i,
                      a = "Expected a function",
                      o = "__lodash_hash_undefined__",
                      u = "__lodash_placeholder__",
                      c = 32,
                      s = 128,
                      f = 1 / 0,
                      l = 9007199254740991,
                      h = NaN,
                      p = 4294967295,
                      v = [["ary", s], ["bind", 1], ["bindKey", 2], ["curry", 8], ["curryRight", 16], ["flip", 512], ["partial", c], ["partialRight", 64], ["rearg", 256]],
                      y = "[object Arguments]",
                      g = "[object Array]",
                      d = "[object Boolean]",
                      _ = "[object Date]",
                      b = "[object Error]",
                      k = "[object Function]",
                      m = "[object GeneratorFunction]",
                      A = "[object Map]",
                      w = "[object Number]",
                      F = "[object Object]",
                      S = "[object Promise]",
                      C = "[object RegExp]",
                      O = "[object Set]",
                      x = "[object String]",
                      I = "[object Symbol]",
                      j = "[object WeakMap]",
                      T = "[object ArrayBuffer]",
                      P = "[object DataView]",
                      R = "[object Float32Array]",
                      L = "[object Float64Array]",
                      E = "[object Int8Array]",
                      M = "[object Int16Array]",
                      U = "[object Int32Array]",
                      B = "[object Uint8Array]",
                      D = "[object Uint8ClampedArray]",
                      W = "[object Uint16Array]",
                      q = "[object Uint32Array]",
                      z = /\b__p \+= '';/g,
                      N = /\b(__p \+=) '' \+/g,
                      V = /(__e\(.*?\)|\b__t\)) \+\n'';/g,
                      $ = /&(?:amp|lt|gt|quot|#39);/g,
                      G = /[&<>"']/g,
                      Z = RegExp($.source),
                      H = RegExp(G.source),
                      J = /<%-([\s\S]+?)%>/g,
                      K = /<%([\s\S]+?)%>/g,
                      Q = /<%=([\s\S]+?)%>/g,
                      Y = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
                      X = /^\w*$/,
                      tt = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
                      nt = /[\\^$.*+?()[\]{}|]/g,
                      rt = RegExp(nt.source),
                      et = /^\s+/,
                      it = /\s/,
                      at = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,
                      ot = /\{\n\/\* \[wrapped with (.+)\] \*/,
                      ut = /,? & /,
                      ct = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,
                      st = /[()=,{}\[\]\/\s]/,
                      ft = /\\(\\)?/g,
                      lt = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
                      ht = /\w*$/,
                      pt = /^[-+]0x[0-9a-f]+$/i,
                      vt = /^0b[01]+$/i,
                      yt = /^\[object .+?Constructor\]$/,
                      gt = /^0o[0-7]+$/i,
                      dt = /^(?:0|[1-9]\d*)$/,
                      _t = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,
                      bt = /($^)/,
                      kt = /['\n\r\u2028\u2029\\]/g,
                      mt = "\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff",
                      At = "a-z\\xdf-\\xf6\\xf8-\\xff",
                      wt = "A-Z\\xc0-\\xd6\\xd8-\\xde",
                      Ft = "\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",
                      St = "[" + Ft + "]",
                      Ct = "[" + mt + "]",
                      Ot = "\\d+",
                      xt = "[" + At + "]",
                      It = "[^\\ud800-\\udfff" + Ft + Ot + "\\u2700-\\u27bf" + At + wt + "]",
                      jt = "\\ud83c[\\udffb-\\udfff]",
                      Tt = "[^\\ud800-\\udfff]",
                      Pt = "(?:\\ud83c[\\udde6-\\uddff]){2}",
                      Rt = "[\\ud800-\\udbff][\\udc00-\\udfff]",
                      Lt = "[" + wt + "]",
                      Et = "(?:" + xt + "|" + It + ")",
                      Mt = "(?:" + Lt + "|" + It + ")",
                      Ut = "(?:['’](?:d|ll|m|re|s|t|ve))?",
                      Bt = "(?:['’](?:D|LL|M|RE|S|T|VE))?",
                      Dt = "(?:" + Ct + "|" + jt + ")?",
                      Wt = "[\\ufe0e\\ufe0f]?",
                      qt = Wt + Dt + "(?:\\u200d(?:" + [Tt, Pt, Rt].join("|") + ")" + Wt + Dt + ")*",
                      zt = "(?:" + ["[\\u2700-\\u27bf]", Pt, Rt].join("|") + ")" + qt,
                      Nt = "(?:" + [Tt + Ct + "?", Ct, Pt, Rt, "[\\ud800-\\udfff]"].join("|") + ")",
                      Vt = RegExp("['’]", "g"),
                      $t = RegExp(Ct, "g"),
                      Gt = RegExp(jt + "(?=" + jt + ")|" + Nt + qt, "g"),
                      Zt = RegExp([Lt + "?" + xt + "+" + Ut + "(?=" + [St, Lt, "$"].join("|") + ")", Mt + "+" + Bt + "(?=" + [St, Lt + Et, "$"].join("|") + ")", Lt + "?" + Et + "+" + Ut, Lt + "+" + Bt, "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])", "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])", Ot, zt].join("|"), "g"),
                      Ht = RegExp("[\\u200d\\ud800-\\udfff" + mt + "\\ufe0e\\ufe0f]"),
                      Jt = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,
                      Kt = ["Array", "Buffer", "DataView", "Date", "Error", "Float32Array", "Float64Array", "Function", "Int8Array", "Int16Array", "Int32Array", "Map", "Math", "Object", "Promise", "RegExp", "Set", "String", "Symbol", "TypeError", "Uint8Array", "Uint8ClampedArray", "Uint16Array", "Uint32Array", "WeakMap", "_", "clearTimeout", "isFinite", "parseInt", "setTimeout"],
                      Qt = -1,
                      Yt = {};
                  Yt[R] = Yt[L] = Yt[E] = Yt[M] = Yt[U] = Yt[B] = Yt[D] = Yt[W] = Yt[q] = !0, Yt[y] = Yt[g] = Yt[T] = Yt[d] = Yt[P] = Yt[_] = Yt[b] = Yt[k] = Yt[A] = Yt[w] = Yt[F] = Yt[C] = Yt[O] = Yt[x] = Yt[j] = !1;
                  var Xt = {};
                  Xt[y] = Xt[g] = Xt[T] = Xt[P] = Xt[d] = Xt[_] = Xt[R] = Xt[L] = Xt[E] = Xt[M] = Xt[U] = Xt[A] = Xt[w] = Xt[F] = Xt[C] = Xt[O] = Xt[x] = Xt[I] = Xt[B] = Xt[D] = Xt[W] = Xt[q] = !0, Xt[b] = Xt[k] = Xt[j] = !1;

                  var tn = {
                    "\\": "\\",
                    "'": "'",
                    "\n": "n",
                    "\r": "r",
                    "\u2028": "u2028",
                    "\u2029": "u2029"
                  },
                      nn = parseFloat,
                      rn = parseInt,
                      en = "object" == typeof r.g && r.g && r.g.Object === Object && r.g,
                      an = "object" == typeof self && self && self.Object === Object && self,
                      on = en || an || Function("return this")(),
                      un = n && !n.nodeType && n,
                      cn = un && t && !t.nodeType && t,
                      sn = cn && cn.exports === un,
                      fn = sn && en.process,
                      ln = function () {
                    try {
                      return cn && cn.require && cn.require("util").types || fn && fn.binding && fn.binding("util");
                    } catch (t) {}
                  }(),
                      hn = ln && ln.isArrayBuffer,
                      pn = ln && ln.isDate,
                      vn = ln && ln.isMap,
                      yn = ln && ln.isRegExp,
                      gn = ln && ln.isSet,
                      dn = ln && ln.isTypedArray;

                  function _n(t, n, r) {
                    switch (r.length) {
                      case 0:
                        return t.call(n);

                      case 1:
                        return t.call(n, r[0]);

                      case 2:
                        return t.call(n, r[0], r[1]);

                      case 3:
                        return t.call(n, r[0], r[1], r[2]);
                    }

                    return t.apply(n, r);
                  }

                  function bn(t, n, r, e) {
                    for (var i = -1, a = null == t ? 0 : t.length; ++i < a;) {
                      var o = t[i];
                      n(e, o, r(o), t);
                    }

                    return e;
                  }

                  function kn(t, n) {
                    for (var r = -1, e = null == t ? 0 : t.length; ++r < e && !1 !== n(t[r], r, t););

                    return t;
                  }

                  function mn(t, n) {
                    for (var r = null == t ? 0 : t.length; r-- && !1 !== n(t[r], r, t););

                    return t;
                  }

                  function An(t, n) {
                    for (var r = -1, e = null == t ? 0 : t.length; ++r < e;) if (!n(t[r], r, t)) return !1;

                    return !0;
                  }

                  function wn(t, n) {
                    for (var r = -1, e = null == t ? 0 : t.length, i = 0, a = []; ++r < e;) {
                      var o = t[r];
                      n(o, r, t) && (a[i++] = o);
                    }

                    return a;
                  }

                  function Fn(t, n) {
                    return !(null == t || !t.length) && Ln(t, n, 0) > -1;
                  }

                  function Sn(t, n, r) {
                    for (var e = -1, i = null == t ? 0 : t.length; ++e < i;) if (r(n, t[e])) return !0;

                    return !1;
                  }

                  function Cn(t, n) {
                    for (var r = -1, e = null == t ? 0 : t.length, i = Array(e); ++r < e;) i[r] = n(t[r], r, t);

                    return i;
                  }

                  function On(t, n) {
                    for (var r = -1, e = n.length, i = t.length; ++r < e;) t[i + r] = n[r];

                    return t;
                  }

                  function xn(t, n, r, e) {
                    var i = -1,
                        a = null == t ? 0 : t.length;

                    for (e && a && (r = t[++i]); ++i < a;) r = n(r, t[i], i, t);

                    return r;
                  }

                  function In(t, n, r, e) {
                    var i = null == t ? 0 : t.length;

                    for (e && i && (r = t[--i]); i--;) r = n(r, t[i], i, t);

                    return r;
                  }

                  function jn(t, n) {
                    for (var r = -1, e = null == t ? 0 : t.length; ++r < e;) if (n(t[r], r, t)) return !0;

                    return !1;
                  }

                  var Tn = Bn("length");

                  function Pn(t, n, r) {
                    var e;
                    return r(t, function (t, r, i) {
                      if (n(t, r, i)) return e = r, !1;
                    }), e;
                  }

                  function Rn(t, n, r, e) {
                    for (var i = t.length, a = r + (e ? 1 : -1); e ? a-- : ++a < i;) if (n(t[a], a, t)) return a;

                    return -1;
                  }

                  function Ln(t, n, r) {
                    return n == n ? function (t, n, r) {
                      for (var e = r - 1, i = t.length; ++e < i;) if (t[e] === n) return e;

                      return -1;
                    }(t, n, r) : Rn(t, Mn, r);
                  }

                  function En(t, n, r, e) {
                    for (var i = r - 1, a = t.length; ++i < a;) if (e(t[i], n)) return i;

                    return -1;
                  }

                  function Mn(t) {
                    return t != t;
                  }

                  function Un(t, n) {
                    var r = null == t ? 0 : t.length;
                    return r ? qn(t, n) / r : h;
                  }

                  function Bn(t) {
                    return function (n) {
                      return null == n ? i : n[t];
                    };
                  }

                  function Dn(t) {
                    return function (n) {
                      return null == t ? i : t[n];
                    };
                  }

                  function Wn(t, n, r, e, i) {
                    return i(t, function (t, i, a) {
                      r = e ? (e = !1, t) : n(r, t, i, a);
                    }), r;
                  }

                  function qn(t, n) {
                    for (var r, e = -1, a = t.length; ++e < a;) {
                      var o = n(t[e]);
                      o !== i && (r = r === i ? o : r + o);
                    }

                    return r;
                  }

                  function zn(t, n) {
                    for (var r = -1, e = Array(t); ++r < t;) e[r] = n(r);

                    return e;
                  }

                  function Nn(t) {
                    return t ? t.slice(0, ur(t) + 1).replace(et, "") : t;
                  }

                  function Vn(t) {
                    return function (n) {
                      return t(n);
                    };
                  }

                  function $n(t, n) {
                    return Cn(n, function (n) {
                      return t[n];
                    });
                  }

                  function Gn(t, n) {
                    return t.has(n);
                  }

                  function Zn(t, n) {
                    for (var r = -1, e = t.length; ++r < e && Ln(n, t[r], 0) > -1;);

                    return r;
                  }

                  function Hn(t, n) {
                    for (var r = t.length; r-- && Ln(n, t[r], 0) > -1;);

                    return r;
                  }

                  function Jn(t, n) {
                    for (var r = t.length, e = 0; r--;) t[r] === n && ++e;

                    return e;
                  }

                  var Kn = Dn({
                    À: "A",
                    Á: "A",
                    Â: "A",
                    Ã: "A",
                    Ä: "A",
                    Å: "A",
                    à: "a",
                    á: "a",
                    â: "a",
                    ã: "a",
                    ä: "a",
                    å: "a",
                    Ç: "C",
                    ç: "c",
                    Ð: "D",
                    ð: "d",
                    È: "E",
                    É: "E",
                    Ê: "E",
                    Ë: "E",
                    è: "e",
                    é: "e",
                    ê: "e",
                    ë: "e",
                    Ì: "I",
                    Í: "I",
                    Î: "I",
                    Ï: "I",
                    ì: "i",
                    í: "i",
                    î: "i",
                    ï: "i",
                    Ñ: "N",
                    ñ: "n",
                    Ò: "O",
                    Ó: "O",
                    Ô: "O",
                    Õ: "O",
                    Ö: "O",
                    Ø: "O",
                    ò: "o",
                    ó: "o",
                    ô: "o",
                    õ: "o",
                    ö: "o",
                    ø: "o",
                    Ù: "U",
                    Ú: "U",
                    Û: "U",
                    Ü: "U",
                    ù: "u",
                    ú: "u",
                    û: "u",
                    ü: "u",
                    Ý: "Y",
                    ý: "y",
                    ÿ: "y",
                    Æ: "Ae",
                    æ: "ae",
                    Þ: "Th",
                    þ: "th",
                    ß: "ss",
                    Ā: "A",
                    Ă: "A",
                    Ą: "A",
                    ā: "a",
                    ă: "a",
                    ą: "a",
                    Ć: "C",
                    Ĉ: "C",
                    Ċ: "C",
                    Č: "C",
                    ć: "c",
                    ĉ: "c",
                    ċ: "c",
                    č: "c",
                    Ď: "D",
                    Đ: "D",
                    ď: "d",
                    đ: "d",
                    Ē: "E",
                    Ĕ: "E",
                    Ė: "E",
                    Ę: "E",
                    Ě: "E",
                    ē: "e",
                    ĕ: "e",
                    ė: "e",
                    ę: "e",
                    ě: "e",
                    Ĝ: "G",
                    Ğ: "G",
                    Ġ: "G",
                    Ģ: "G",
                    ĝ: "g",
                    ğ: "g",
                    ġ: "g",
                    ģ: "g",
                    Ĥ: "H",
                    Ħ: "H",
                    ĥ: "h",
                    ħ: "h",
                    Ĩ: "I",
                    Ī: "I",
                    Ĭ: "I",
                    Į: "I",
                    İ: "I",
                    ĩ: "i",
                    ī: "i",
                    ĭ: "i",
                    į: "i",
                    ı: "i",
                    Ĵ: "J",
                    ĵ: "j",
                    Ķ: "K",
                    ķ: "k",
                    ĸ: "k",
                    Ĺ: "L",
                    Ļ: "L",
                    Ľ: "L",
                    Ŀ: "L",
                    Ł: "L",
                    ĺ: "l",
                    ļ: "l",
                    ľ: "l",
                    ŀ: "l",
                    ł: "l",
                    Ń: "N",
                    Ņ: "N",
                    Ň: "N",
                    Ŋ: "N",
                    ń: "n",
                    ņ: "n",
                    ň: "n",
                    ŋ: "n",
                    Ō: "O",
                    Ŏ: "O",
                    Ő: "O",
                    ō: "o",
                    ŏ: "o",
                    ő: "o",
                    Ŕ: "R",
                    Ŗ: "R",
                    Ř: "R",
                    ŕ: "r",
                    ŗ: "r",
                    ř: "r",
                    Ś: "S",
                    Ŝ: "S",
                    Ş: "S",
                    Š: "S",
                    ś: "s",
                    ŝ: "s",
                    ş: "s",
                    š: "s",
                    Ţ: "T",
                    Ť: "T",
                    Ŧ: "T",
                    ţ: "t",
                    ť: "t",
                    ŧ: "t",
                    Ũ: "U",
                    Ū: "U",
                    Ŭ: "U",
                    Ů: "U",
                    Ű: "U",
                    Ų: "U",
                    ũ: "u",
                    ū: "u",
                    ŭ: "u",
                    ů: "u",
                    ű: "u",
                    ų: "u",
                    Ŵ: "W",
                    ŵ: "w",
                    Ŷ: "Y",
                    ŷ: "y",
                    Ÿ: "Y",
                    Ź: "Z",
                    Ż: "Z",
                    Ž: "Z",
                    ź: "z",
                    ż: "z",
                    ž: "z",
                    Ĳ: "IJ",
                    ĳ: "ij",
                    Œ: "Oe",
                    œ: "oe",
                    ŉ: "'n",
                    ſ: "s"
                  }),
                      Qn = Dn({
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#39;"
                  });

                  function Yn(t) {
                    return "\\" + tn[t];
                  }

                  function Xn(t) {
                    return Ht.test(t);
                  }

                  function tr(t) {
                    var n = -1,
                        r = Array(t.size);
                    return t.forEach(function (t, e) {
                      r[++n] = [e, t];
                    }), r;
                  }

                  function nr(t, n) {
                    return function (r) {
                      return t(n(r));
                    };
                  }

                  function rr(t, n) {
                    for (var r = -1, e = t.length, i = 0, a = []; ++r < e;) {
                      var o = t[r];
                      o !== n && o !== u || (t[r] = u, a[i++] = r);
                    }

                    return a;
                  }

                  function er(t) {
                    var n = -1,
                        r = Array(t.size);
                    return t.forEach(function (t) {
                      r[++n] = t;
                    }), r;
                  }

                  function ir(t) {
                    var n = -1,
                        r = Array(t.size);
                    return t.forEach(function (t) {
                      r[++n] = [t, t];
                    }), r;
                  }

                  function ar(t) {
                    return Xn(t) ? function (t) {
                      for (var n = Gt.lastIndex = 0; Gt.test(t);) ++n;

                      return n;
                    }(t) : Tn(t);
                  }

                  function or(t) {
                    return Xn(t) ? function (t) {
                      return t.match(Gt) || [];
                    }(t) : function (t) {
                      return t.split("");
                    }(t);
                  }

                  function ur(t) {
                    for (var n = t.length; n-- && it.test(t.charAt(n)););

                    return n;
                  }

                  var cr = Dn({
                    "&amp;": "&",
                    "&lt;": "<",
                    "&gt;": ">",
                    "&quot;": '"',
                    "&#39;": "'"
                  }),
                      sr = function t(n) {
                    var r,
                        e = (n = null == n ? on : sr.defaults(on.Object(), n, sr.pick(on, Kt))).Array,
                        it = n.Date,
                        mt = n.Error,
                        At = n.Function,
                        wt = n.Math,
                        Ft = n.Object,
                        St = n.RegExp,
                        Ct = n.String,
                        Ot = n.TypeError,
                        xt = e.prototype,
                        It = At.prototype,
                        jt = Ft.prototype,
                        Tt = n["__core-js_shared__"],
                        Pt = It.toString,
                        Rt = jt.hasOwnProperty,
                        Lt = 0,
                        Et = (r = /[^.]+$/.exec(Tt && Tt.keys && Tt.keys.IE_PROTO || "")) ? "Symbol(src)_1." + r : "",
                        Mt = jt.toString,
                        Ut = Pt.call(Ft),
                        Bt = on._,
                        Dt = St("^" + Pt.call(Rt).replace(nt, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                        Wt = sn ? n.Buffer : i,
                        qt = n.Symbol,
                        zt = n.Uint8Array,
                        Nt = Wt ? Wt.allocUnsafe : i,
                        Gt = nr(Ft.getPrototypeOf, Ft),
                        Ht = Ft.create,
                        tn = jt.propertyIsEnumerable,
                        en = xt.splice,
                        an = qt ? qt.isConcatSpreadable : i,
                        un = qt ? qt.iterator : i,
                        cn = qt ? qt.toStringTag : i,
                        fn = function () {
                      try {
                        var t = sa(Ft, "defineProperty");
                        return t({}, "", {}), t;
                      } catch (t) {}
                    }(),
                        ln = n.clearTimeout !== on.clearTimeout && n.clearTimeout,
                        Tn = it && it.now !== on.Date.now && it.now,
                        Dn = n.setTimeout !== on.setTimeout && n.setTimeout,
                        fr = wt.ceil,
                        lr = wt.floor,
                        hr = Ft.getOwnPropertySymbols,
                        pr = Wt ? Wt.isBuffer : i,
                        vr = n.isFinite,
                        yr = xt.join,
                        gr = nr(Ft.keys, Ft),
                        dr = wt.max,
                        _r = wt.min,
                        br = it.now,
                        kr = n.parseInt,
                        mr = wt.random,
                        Ar = xt.reverse,
                        wr = sa(n, "DataView"),
                        Fr = sa(n, "Map"),
                        Sr = sa(n, "Promise"),
                        Cr = sa(n, "Set"),
                        Or = sa(n, "WeakMap"),
                        xr = sa(Ft, "create"),
                        Ir = Or && new Or(),
                        jr = {},
                        Tr = Ba(wr),
                        Pr = Ba(Fr),
                        Rr = Ba(Sr),
                        Lr = Ba(Cr),
                        Er = Ba(Or),
                        Mr = qt ? qt.prototype : i,
                        Ur = Mr ? Mr.valueOf : i,
                        Br = Mr ? Mr.toString : i;

                    function Dr(t) {
                      if (ru(t) && !$o(t) && !(t instanceof Nr)) {
                        if (t instanceof zr) return t;
                        if (Rt.call(t, "__wrapped__")) return Da(t);
                      }

                      return new zr(t);
                    }

                    var Wr = function () {
                      function t() {}

                      return function (n) {
                        if (!nu(n)) return {};
                        if (Ht) return Ht(n);
                        t.prototype = n;
                        var r = new t();
                        return t.prototype = i, r;
                      };
                    }();

                    function qr() {}

                    function zr(t, n) {
                      this.__wrapped__ = t, this.__actions__ = [], this.__chain__ = !!n, this.__index__ = 0, this.__values__ = i;
                    }

                    function Nr(t) {
                      this.__wrapped__ = t, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = p, this.__views__ = [];
                    }

                    function Vr(t) {
                      var n = -1,
                          r = null == t ? 0 : t.length;

                      for (this.clear(); ++n < r;) {
                        var e = t[n];
                        this.set(e[0], e[1]);
                      }
                    }

                    function $r(t) {
                      var n = -1,
                          r = null == t ? 0 : t.length;

                      for (this.clear(); ++n < r;) {
                        var e = t[n];
                        this.set(e[0], e[1]);
                      }
                    }

                    function Gr(t) {
                      var n = -1,
                          r = null == t ? 0 : t.length;

                      for (this.clear(); ++n < r;) {
                        var e = t[n];
                        this.set(e[0], e[1]);
                      }
                    }

                    function Zr(t) {
                      var n = -1,
                          r = null == t ? 0 : t.length;

                      for (this.__data__ = new Gr(); ++n < r;) this.add(t[n]);
                    }

                    function Hr(t) {
                      var n = this.__data__ = new $r(t);
                      this.size = n.size;
                    }

                    function Jr(t, n) {
                      var r = $o(t),
                          e = !r && Vo(t),
                          i = !r && !e && Jo(t),
                          a = !r && !e && !i && fu(t),
                          o = r || e || i || a,
                          u = o ? zn(t.length, Ct) : [],
                          c = u.length;

                      for (var s in t) !n && !Rt.call(t, s) || o && ("length" == s || i && ("offset" == s || "parent" == s) || a && ("buffer" == s || "byteLength" == s || "byteOffset" == s) || ga(s, c)) || u.push(s);

                      return u;
                    }

                    function Kr(t) {
                      var n = t.length;
                      return n ? t[Ge(0, n - 1)] : i;
                    }

                    function Qr(t, n) {
                      return Ra(Oi(t), oe(n, 0, t.length));
                    }

                    function Yr(t) {
                      return Ra(Oi(t));
                    }

                    function Xr(t, n, r) {
                      (r !== i && !qo(t[n], r) || r === i && !(n in t)) && ie(t, n, r);
                    }

                    function te(t, n, r) {
                      var e = t[n];
                      Rt.call(t, n) && qo(e, r) && (r !== i || n in t) || ie(t, n, r);
                    }

                    function ne(t, n) {
                      for (var r = t.length; r--;) if (qo(t[r][0], n)) return r;

                      return -1;
                    }

                    function re(t, n, r, e) {
                      return le(t, function (t, i, a) {
                        n(e, t, r(t), a);
                      }), e;
                    }

                    function ee(t, n) {
                      return t && xi(n, Pu(n), t);
                    }

                    function ie(t, n, r) {
                      "__proto__" == n && fn ? fn(t, n, {
                        configurable: !0,
                        enumerable: !0,
                        value: r,
                        writable: !0
                      }) : t[n] = r;
                    }

                    function ae(t, n) {
                      for (var r = -1, a = n.length, o = e(a), u = null == t; ++r < a;) o[r] = u ? i : Ou(t, n[r]);

                      return o;
                    }

                    function oe(t, n, r) {
                      return t == t && (r !== i && (t = t <= r ? t : r), n !== i && (t = t >= n ? t : n)), t;
                    }

                    function ue(t, n, r, e, a, o) {
                      var u,
                          c = 1 & n,
                          s = 2 & n,
                          f = 4 & n;
                      if (r && (u = a ? r(t, e, a, o) : r(t)), u !== i) return u;
                      if (!nu(t)) return t;
                      var l = $o(t);

                      if (l) {
                        if (u = function (t) {
                          var n = t.length,
                              r = new t.constructor(n);
                          return n && "string" == typeof t[0] && Rt.call(t, "index") && (r.index = t.index, r.input = t.input), r;
                        }(t), !c) return Oi(t, u);
                      } else {
                        var h = ha(t),
                            p = h == k || h == m;
                        if (Jo(t)) return mi(t, c);

                        if (h == F || h == y || p && !a) {
                          if (u = s || p ? {} : va(t), !c) return s ? function (t, n) {
                            return xi(t, la(t), n);
                          }(t, function (t, n) {
                            return t && xi(n, Ru(n), t);
                          }(u, t)) : function (t, n) {
                            return xi(t, fa(t), n);
                          }(t, ee(u, t));
                        } else {
                          if (!Xt[h]) return a ? t : {};

                          u = function (t, n, r) {
                            var e,
                                i = t.constructor;

                            switch (n) {
                              case T:
                                return Ai(t);

                              case d:
                              case _:
                                return new i(+t);

                              case P:
                                return function (t, n) {
                                  var r = n ? Ai(t.buffer) : t.buffer;
                                  return new t.constructor(r, t.byteOffset, t.byteLength);
                                }(t, r);

                              case R:
                              case L:
                              case E:
                              case M:
                              case U:
                              case B:
                              case D:
                              case W:
                              case q:
                                return wi(t, r);

                              case A:
                                return new i();

                              case w:
                              case x:
                                return new i(t);

                              case C:
                                return function (t) {
                                  var n = new t.constructor(t.source, ht.exec(t));
                                  return n.lastIndex = t.lastIndex, n;
                                }(t);

                              case O:
                                return new i();

                              case I:
                                return e = t, Ur ? Ft(Ur.call(e)) : {};
                            }
                          }(t, h, c);
                        }
                      }

                      o || (o = new Hr());
                      var v = o.get(t);
                      if (v) return v;
                      o.set(t, u), uu(t) ? t.forEach(function (e) {
                        u.add(ue(e, n, r, e, t, o));
                      }) : eu(t) && t.forEach(function (e, i) {
                        u.set(i, ue(e, n, r, i, t, o));
                      });
                      var g = l ? i : (f ? s ? ra : na : s ? Ru : Pu)(t);
                      return kn(g || t, function (e, i) {
                        g && (e = t[i = e]), te(u, i, ue(e, n, r, i, t, o));
                      }), u;
                    }

                    function ce(t, n, r) {
                      var e = r.length;
                      if (null == t) return !e;

                      for (t = Ft(t); e--;) {
                        var a = r[e],
                            o = n[a],
                            u = t[a];
                        if (u === i && !(a in t) || !o(u)) return !1;
                      }

                      return !0;
                    }

                    function se(t, n, r) {
                      if ("function" != typeof t) throw new Ot(a);
                      return Ia(function () {
                        t.apply(i, r);
                      }, n);
                    }

                    function fe(t, n, r, e) {
                      var i = -1,
                          a = Fn,
                          o = !0,
                          u = t.length,
                          c = [],
                          s = n.length;
                      if (!u) return c;
                      r && (n = Cn(n, Vn(r))), e ? (a = Sn, o = !1) : n.length >= 200 && (a = Gn, o = !1, n = new Zr(n));

                      t: for (; ++i < u;) {
                        var f = t[i],
                            l = null == r ? f : r(f);

                        if (f = e || 0 !== f ? f : 0, o && l == l) {
                          for (var h = s; h--;) if (n[h] === l) continue t;

                          c.push(f);
                        } else a(n, l, e) || c.push(f);
                      }

                      return c;
                    }

                    Dr.templateSettings = {
                      escape: J,
                      evaluate: K,
                      interpolate: Q,
                      variable: "",
                      imports: {
                        _: Dr
                      }
                    }, Dr.prototype = qr.prototype, Dr.prototype.constructor = Dr, zr.prototype = Wr(qr.prototype), zr.prototype.constructor = zr, Nr.prototype = Wr(qr.prototype), Nr.prototype.constructor = Nr, Vr.prototype.clear = function () {
                      this.__data__ = xr ? xr(null) : {}, this.size = 0;
                    }, Vr.prototype.delete = function (t) {
                      var n = this.has(t) && delete this.__data__[t];
                      return this.size -= n ? 1 : 0, n;
                    }, Vr.prototype.get = function (t) {
                      var n = this.__data__;

                      if (xr) {
                        var r = n[t];
                        return r === o ? i : r;
                      }

                      return Rt.call(n, t) ? n[t] : i;
                    }, Vr.prototype.has = function (t) {
                      var n = this.__data__;
                      return xr ? n[t] !== i : Rt.call(n, t);
                    }, Vr.prototype.set = function (t, n) {
                      var r = this.__data__;
                      return this.size += this.has(t) ? 0 : 1, r[t] = xr && n === i ? o : n, this;
                    }, $r.prototype.clear = function () {
                      this.__data__ = [], this.size = 0;
                    }, $r.prototype.delete = function (t) {
                      var n = this.__data__,
                          r = ne(n, t);
                      return !(r < 0 || (r == n.length - 1 ? n.pop() : en.call(n, r, 1), --this.size, 0));
                    }, $r.prototype.get = function (t) {
                      var n = this.__data__,
                          r = ne(n, t);
                      return r < 0 ? i : n[r][1];
                    }, $r.prototype.has = function (t) {
                      return ne(this.__data__, t) > -1;
                    }, $r.prototype.set = function (t, n) {
                      var r = this.__data__,
                          e = ne(r, t);
                      return e < 0 ? (++this.size, r.push([t, n])) : r[e][1] = n, this;
                    }, Gr.prototype.clear = function () {
                      this.size = 0, this.__data__ = {
                        hash: new Vr(),
                        map: new (Fr || $r)(),
                        string: new Vr()
                      };
                    }, Gr.prototype.delete = function (t) {
                      var n = ua(this, t).delete(t);
                      return this.size -= n ? 1 : 0, n;
                    }, Gr.prototype.get = function (t) {
                      return ua(this, t).get(t);
                    }, Gr.prototype.has = function (t) {
                      return ua(this, t).has(t);
                    }, Gr.prototype.set = function (t, n) {
                      var r = ua(this, t),
                          e = r.size;
                      return r.set(t, n), this.size += r.size == e ? 0 : 1, this;
                    }, Zr.prototype.add = Zr.prototype.push = function (t) {
                      return this.__data__.set(t, o), this;
                    }, Zr.prototype.has = function (t) {
                      return this.__data__.has(t);
                    }, Hr.prototype.clear = function () {
                      this.__data__ = new $r(), this.size = 0;
                    }, Hr.prototype.delete = function (t) {
                      var n = this.__data__,
                          r = n.delete(t);
                      return this.size = n.size, r;
                    }, Hr.prototype.get = function (t) {
                      return this.__data__.get(t);
                    }, Hr.prototype.has = function (t) {
                      return this.__data__.has(t);
                    }, Hr.prototype.set = function (t, n) {
                      var r = this.__data__;

                      if (r instanceof $r) {
                        var e = r.__data__;
                        if (!Fr || e.length < 199) return e.push([t, n]), this.size = ++r.size, this;
                        r = this.__data__ = new Gr(e);
                      }

                      return r.set(t, n), this.size = r.size, this;
                    };
                    var le = Ti(be),
                        he = Ti(ke, !0);

                    function pe(t, n) {
                      var r = !0;
                      return le(t, function (t, e, i) {
                        return r = !!n(t, e, i);
                      }), r;
                    }

                    function ve(t, n, r) {
                      for (var e = -1, a = t.length; ++e < a;) {
                        var o = t[e],
                            u = n(o);
                        if (null != u && (c === i ? u == u && !su(u) : r(u, c))) var c = u,
                            s = o;
                      }

                      return s;
                    }

                    function ye(t, n) {
                      var r = [];
                      return le(t, function (t, e, i) {
                        n(t, e, i) && r.push(t);
                      }), r;
                    }

                    function ge(t, n, r, e, i) {
                      var a = -1,
                          o = t.length;

                      for (r || (r = ya), i || (i = []); ++a < o;) {
                        var u = t[a];
                        n > 0 && r(u) ? n > 1 ? ge(u, n - 1, r, e, i) : On(i, u) : e || (i[i.length] = u);
                      }

                      return i;
                    }

                    var de = Pi(),
                        _e = Pi(!0);

                    function be(t, n) {
                      return t && de(t, n, Pu);
                    }

                    function ke(t, n) {
                      return t && _e(t, n, Pu);
                    }

                    function me(t, n) {
                      return wn(n, function (n) {
                        return Yo(t[n]);
                      });
                    }

                    function Ae(t, n) {
                      for (var r = 0, e = (n = di(n, t)).length; null != t && r < e;) t = t[Ua(n[r++])];

                      return r && r == e ? t : i;
                    }

                    function we(t, n, r) {
                      var e = n(t);
                      return $o(t) ? e : On(e, r(t));
                    }

                    function Fe(t) {
                      return null == t ? t === i ? "[object Undefined]" : "[object Null]" : cn && cn in Ft(t) ? function (t) {
                        var n = Rt.call(t, cn),
                            r = t[cn];

                        try {
                          t[cn] = i;
                          var e = !0;
                        } catch (t) {}

                        var a = Mt.call(t);
                        return e && (n ? t[cn] = r : delete t[cn]), a;
                      }(t) : function (t) {
                        return Mt.call(t);
                      }(t);
                    }

                    function Se(t, n) {
                      return t > n;
                    }

                    function Ce(t, n) {
                      return null != t && Rt.call(t, n);
                    }

                    function Oe(t, n) {
                      return null != t && n in Ft(t);
                    }

                    function xe(t, n, r) {
                      for (var a = r ? Sn : Fn, o = t[0].length, u = t.length, c = u, s = e(u), f = 1 / 0, l = []; c--;) {
                        var h = t[c];
                        c && n && (h = Cn(h, Vn(n))), f = _r(h.length, f), s[c] = !r && (n || o >= 120 && h.length >= 120) ? new Zr(c && h) : i;
                      }

                      h = t[0];
                      var p = -1,
                          v = s[0];

                      t: for (; ++p < o && l.length < f;) {
                        var y = h[p],
                            g = n ? n(y) : y;

                        if (y = r || 0 !== y ? y : 0, !(v ? Gn(v, g) : a(l, g, r))) {
                          for (c = u; --c;) {
                            var d = s[c];
                            if (!(d ? Gn(d, g) : a(t[c], g, r))) continue t;
                          }

                          v && v.push(g), l.push(y);
                        }
                      }

                      return l;
                    }

                    function Ie(t, n, r) {
                      var e = null == (t = Sa(t, n = di(n, t))) ? t : t[Ua(Ka(n))];
                      return null == e ? i : _n(e, t, r);
                    }

                    function je(t) {
                      return ru(t) && Fe(t) == y;
                    }

                    function Te(t, n, r, e, a) {
                      return t === n || (null == t || null == n || !ru(t) && !ru(n) ? t != t && n != n : function (t, n, r, e, a, o) {
                        var u = $o(t),
                            c = $o(n),
                            s = u ? g : ha(t),
                            f = c ? g : ha(n),
                            l = (s = s == y ? F : s) == F,
                            h = (f = f == y ? F : f) == F,
                            p = s == f;

                        if (p && Jo(t)) {
                          if (!Jo(n)) return !1;
                          u = !0, l = !1;
                        }

                        if (p && !l) return o || (o = new Hr()), u || fu(t) ? Xi(t, n, r, e, a, o) : function (t, n, r, e, i, a, o) {
                          switch (r) {
                            case P:
                              if (t.byteLength != n.byteLength || t.byteOffset != n.byteOffset) return !1;
                              t = t.buffer, n = n.buffer;

                            case T:
                              return !(t.byteLength != n.byteLength || !a(new zt(t), new zt(n)));

                            case d:
                            case _:
                            case w:
                              return qo(+t, +n);

                            case b:
                              return t.name == n.name && t.message == n.message;

                            case C:
                            case x:
                              return t == n + "";

                            case A:
                              var u = tr;

                            case O:
                              var c = 1 & e;
                              if (u || (u = er), t.size != n.size && !c) return !1;
                              var s = o.get(t);
                              if (s) return s == n;
                              e |= 2, o.set(t, n);
                              var f = Xi(u(t), u(n), e, i, a, o);
                              return o.delete(t), f;

                            case I:
                              if (Ur) return Ur.call(t) == Ur.call(n);
                          }

                          return !1;
                        }(t, n, s, r, e, a, o);

                        if (!(1 & r)) {
                          var v = l && Rt.call(t, "__wrapped__"),
                              k = h && Rt.call(n, "__wrapped__");

                          if (v || k) {
                            var m = v ? t.value() : t,
                                S = k ? n.value() : n;
                            return o || (o = new Hr()), a(m, S, r, e, o);
                          }
                        }

                        return !!p && (o || (o = new Hr()), function (t, n, r, e, a, o) {
                          var u = 1 & r,
                              c = na(t),
                              s = c.length;
                          if (s != na(n).length && !u) return !1;

                          for (var f = s; f--;) {
                            var l = c[f];
                            if (!(u ? l in n : Rt.call(n, l))) return !1;
                          }

                          var h = o.get(t),
                              p = o.get(n);
                          if (h && p) return h == n && p == t;
                          var v = !0;
                          o.set(t, n), o.set(n, t);

                          for (var y = u; ++f < s;) {
                            var g = t[l = c[f]],
                                d = n[l];
                            if (e) var _ = u ? e(d, g, l, n, t, o) : e(g, d, l, t, n, o);

                            if (!(_ === i ? g === d || a(g, d, r, e, o) : _)) {
                              v = !1;
                              break;
                            }

                            y || (y = "constructor" == l);
                          }

                          if (v && !y) {
                            var b = t.constructor,
                                k = n.constructor;
                            b == k || !("constructor" in t) || !("constructor" in n) || "function" == typeof b && b instanceof b && "function" == typeof k && k instanceof k || (v = !1);
                          }

                          return o.delete(t), o.delete(n), v;
                        }(t, n, r, e, a, o));
                      }(t, n, r, e, Te, a));
                    }

                    function Pe(t, n, r, e) {
                      var a = r.length,
                          o = a,
                          u = !e;
                      if (null == t) return !o;

                      for (t = Ft(t); a--;) {
                        var c = r[a];
                        if (u && c[2] ? c[1] !== t[c[0]] : !(c[0] in t)) return !1;
                      }

                      for (; ++a < o;) {
                        var s = (c = r[a])[0],
                            f = t[s],
                            l = c[1];

                        if (u && c[2]) {
                          if (f === i && !(s in t)) return !1;
                        } else {
                          var h = new Hr();
                          if (e) var p = e(f, l, s, t, n, h);
                          if (!(p === i ? Te(l, f, 3, e, h) : p)) return !1;
                        }
                      }

                      return !0;
                    }

                    function Re(t) {
                      return !(!nu(t) || (n = t, Et && Et in n)) && (Yo(t) ? Dt : yt).test(Ba(t));
                      var n;
                    }

                    function Le(t) {
                      return "function" == typeof t ? t : null == t ? ic : "object" == typeof t ? $o(t) ? De(t[0], t[1]) : Be(t) : pc(t);
                    }

                    function Ee(t) {
                      if (!ma(t)) return gr(t);
                      var n = [];

                      for (var r in Ft(t)) Rt.call(t, r) && "constructor" != r && n.push(r);

                      return n;
                    }

                    function Me(t, n) {
                      return t < n;
                    }

                    function Ue(t, n) {
                      var r = -1,
                          i = Zo(t) ? e(t.length) : [];
                      return le(t, function (t, e, a) {
                        i[++r] = n(t, e, a);
                      }), i;
                    }

                    function Be(t) {
                      var n = ca(t);
                      return 1 == n.length && n[0][2] ? wa(n[0][0], n[0][1]) : function (r) {
                        return r === t || Pe(r, t, n);
                      };
                    }

                    function De(t, n) {
                      return _a(t) && Aa(n) ? wa(Ua(t), n) : function (r) {
                        var e = Ou(r, t);
                        return e === i && e === n ? xu(r, t) : Te(n, e, 3);
                      };
                    }

                    function We(t, n, r, e, a) {
                      t !== n && de(n, function (o, u) {
                        if (a || (a = new Hr()), nu(o)) !function (t, n, r, e, a, o, u) {
                          var c = Oa(t, r),
                              s = Oa(n, r),
                              f = u.get(s);
                          if (f) Xr(t, r, f);else {
                            var l = o ? o(c, s, r + "", t, n, u) : i,
                                h = l === i;

                            if (h) {
                              var p = $o(s),
                                  v = !p && Jo(s),
                                  y = !p && !v && fu(s);
                              l = s, p || v || y ? $o(c) ? l = c : Ho(c) ? l = Oi(c) : v ? (h = !1, l = mi(s, !0)) : y ? (h = !1, l = wi(s, !0)) : l = [] : au(s) || Vo(s) ? (l = c, Vo(c) ? l = _u(c) : nu(c) && !Yo(c) || (l = va(s))) : h = !1;
                            }

                            h && (u.set(s, l), a(l, s, e, o, u), u.delete(s)), Xr(t, r, l);
                          }
                        }(t, n, u, r, We, e, a);else {
                          var c = e ? e(Oa(t, u), o, u + "", t, n, a) : i;
                          c === i && (c = o), Xr(t, u, c);
                        }
                      }, Ru);
                    }

                    function qe(t, n) {
                      var r = t.length;
                      if (r) return ga(n += n < 0 ? r : 0, r) ? t[n] : i;
                    }

                    function ze(t, n, r) {
                      n = n.length ? Cn(n, function (t) {
                        return $o(t) ? function (n) {
                          return Ae(n, 1 === t.length ? t[0] : t);
                        } : t;
                      }) : [ic];
                      var e = -1;
                      n = Cn(n, Vn(oa()));
                      var i = Ue(t, function (t, r, i) {
                        var a = Cn(n, function (n) {
                          return n(t);
                        });
                        return {
                          criteria: a,
                          index: ++e,
                          value: t
                        };
                      });
                      return function (t, n) {
                        var e = t.length;

                        for (t.sort(function (t, n) {
                          return function (t, n, r) {
                            for (var e = -1, i = t.criteria, a = n.criteria, o = i.length, u = r.length; ++e < o;) {
                              var c = Fi(i[e], a[e]);
                              if (c) return e >= u ? c : c * ("desc" == r[e] ? -1 : 1);
                            }

                            return t.index - n.index;
                          }(t, n, r);
                        }); e--;) t[e] = t[e].value;

                        return t;
                      }(i);
                    }

                    function Ne(t, n, r) {
                      for (var e = -1, i = n.length, a = {}; ++e < i;) {
                        var o = n[e],
                            u = Ae(t, o);
                        r(u, o) && Qe(a, di(o, t), u);
                      }

                      return a;
                    }

                    function Ve(t, n, r, e) {
                      var i = e ? En : Ln,
                          a = -1,
                          o = n.length,
                          u = t;

                      for (t === n && (n = Oi(n)), r && (u = Cn(t, Vn(r))); ++a < o;) for (var c = 0, s = n[a], f = r ? r(s) : s; (c = i(u, f, c, e)) > -1;) u !== t && en.call(u, c, 1), en.call(t, c, 1);

                      return t;
                    }

                    function $e(t, n) {
                      for (var r = t ? n.length : 0, e = r - 1; r--;) {
                        var i = n[r];

                        if (r == e || i !== a) {
                          var a = i;
                          ga(i) ? en.call(t, i, 1) : si(t, i);
                        }
                      }

                      return t;
                    }

                    function Ge(t, n) {
                      return t + lr(mr() * (n - t + 1));
                    }

                    function Ze(t, n) {
                      var r = "";
                      if (!t || n < 1 || n > l) return r;

                      do {
                        n % 2 && (r += t), (n = lr(n / 2)) && (t += t);
                      } while (n);

                      return r;
                    }

                    function He(t, n) {
                      return ja(Fa(t, n, ic), t + "");
                    }

                    function Je(t) {
                      return Kr(qu(t));
                    }

                    function Ke(t, n) {
                      var r = qu(t);
                      return Ra(r, oe(n, 0, r.length));
                    }

                    function Qe(t, n, r, e) {
                      if (!nu(t)) return t;

                      for (var a = -1, o = (n = di(n, t)).length, u = o - 1, c = t; null != c && ++a < o;) {
                        var s = Ua(n[a]),
                            f = r;
                        if ("__proto__" === s || "constructor" === s || "prototype" === s) return t;

                        if (a != u) {
                          var l = c[s];
                          (f = e ? e(l, s, c) : i) === i && (f = nu(l) ? l : ga(n[a + 1]) ? [] : {});
                        }

                        te(c, s, f), c = c[s];
                      }

                      return t;
                    }

                    var Ye = Ir ? function (t, n) {
                      return Ir.set(t, n), t;
                    } : ic,
                        Xe = fn ? function (t, n) {
                      return fn(t, "toString", {
                        configurable: !0,
                        enumerable: !1,
                        value: nc(n),
                        writable: !0
                      });
                    } : ic;

                    function ti(t) {
                      return Ra(qu(t));
                    }

                    function ni(t, n, r) {
                      var i = -1,
                          a = t.length;
                      n < 0 && (n = -n > a ? 0 : a + n), (r = r > a ? a : r) < 0 && (r += a), a = n > r ? 0 : r - n >>> 0, n >>>= 0;

                      for (var o = e(a); ++i < a;) o[i] = t[i + n];

                      return o;
                    }

                    function ri(t, n) {
                      var r;
                      return le(t, function (t, e, i) {
                        return !(r = n(t, e, i));
                      }), !!r;
                    }

                    function ei(t, n, r) {
                      var e = 0,
                          i = null == t ? e : t.length;

                      if ("number" == typeof n && n == n && i <= 2147483647) {
                        for (; e < i;) {
                          var a = e + i >>> 1,
                              o = t[a];
                          null !== o && !su(o) && (r ? o <= n : o < n) ? e = a + 1 : i = a;
                        }

                        return i;
                      }

                      return ii(t, n, ic, r);
                    }

                    function ii(t, n, r, e) {
                      var a = 0,
                          o = null == t ? 0 : t.length;
                      if (0 === o) return 0;

                      for (var u = (n = r(n)) != n, c = null === n, s = su(n), f = n === i; a < o;) {
                        var l = lr((a + o) / 2),
                            h = r(t[l]),
                            p = h !== i,
                            v = null === h,
                            y = h == h,
                            g = su(h);
                        if (u) var d = e || y;else d = f ? y && (e || p) : c ? y && p && (e || !v) : s ? y && p && !v && (e || !g) : !v && !g && (e ? h <= n : h < n);
                        d ? a = l + 1 : o = l;
                      }

                      return _r(o, 4294967294);
                    }

                    function ai(t, n) {
                      for (var r = -1, e = t.length, i = 0, a = []; ++r < e;) {
                        var o = t[r],
                            u = n ? n(o) : o;

                        if (!r || !qo(u, c)) {
                          var c = u;
                          a[i++] = 0 === o ? 0 : o;
                        }
                      }

                      return a;
                    }

                    function oi(t) {
                      return "number" == typeof t ? t : su(t) ? h : +t;
                    }

                    function ui(t) {
                      if ("string" == typeof t) return t;
                      if ($o(t)) return Cn(t, ui) + "";
                      if (su(t)) return Br ? Br.call(t) : "";
                      var n = t + "";
                      return "0" == n && 1 / t == -1 / 0 ? "-0" : n;
                    }

                    function ci(t, n, r) {
                      var e = -1,
                          i = Fn,
                          a = t.length,
                          o = !0,
                          u = [],
                          c = u;
                      if (r) o = !1, i = Sn;else if (a >= 200) {
                        var s = n ? null : Zi(t);
                        if (s) return er(s);
                        o = !1, i = Gn, c = new Zr();
                      } else c = n ? [] : u;

                      t: for (; ++e < a;) {
                        var f = t[e],
                            l = n ? n(f) : f;

                        if (f = r || 0 !== f ? f : 0, o && l == l) {
                          for (var h = c.length; h--;) if (c[h] === l) continue t;

                          n && c.push(l), u.push(f);
                        } else i(c, l, r) || (c !== u && c.push(l), u.push(f));
                      }

                      return u;
                    }

                    function si(t, n) {
                      return null == (t = Sa(t, n = di(n, t))) || delete t[Ua(Ka(n))];
                    }

                    function fi(t, n, r, e) {
                      return Qe(t, n, r(Ae(t, n)), e);
                    }

                    function li(t, n, r, e) {
                      for (var i = t.length, a = e ? i : -1; (e ? a-- : ++a < i) && n(t[a], a, t););

                      return r ? ni(t, e ? 0 : a, e ? a + 1 : i) : ni(t, e ? a + 1 : 0, e ? i : a);
                    }

                    function hi(t, n) {
                      var r = t;
                      return r instanceof Nr && (r = r.value()), xn(n, function (t, n) {
                        return n.func.apply(n.thisArg, On([t], n.args));
                      }, r);
                    }

                    function pi(t, n, r) {
                      var i = t.length;
                      if (i < 2) return i ? ci(t[0]) : [];

                      for (var a = -1, o = e(i); ++a < i;) for (var u = t[a], c = -1; ++c < i;) c != a && (o[a] = fe(o[a] || u, t[c], n, r));

                      return ci(ge(o, 1), n, r);
                    }

                    function vi(t, n, r) {
                      for (var e = -1, a = t.length, o = n.length, u = {}; ++e < a;) {
                        var c = e < o ? n[e] : i;
                        r(u, t[e], c);
                      }

                      return u;
                    }

                    function yi(t) {
                      return Ho(t) ? t : [];
                    }

                    function gi(t) {
                      return "function" == typeof t ? t : ic;
                    }

                    function di(t, n) {
                      return $o(t) ? t : _a(t, n) ? [t] : Ma(bu(t));
                    }

                    var _i = He;

                    function bi(t, n, r) {
                      var e = t.length;
                      return r = r === i ? e : r, !n && r >= e ? t : ni(t, n, r);
                    }

                    var ki = ln || function (t) {
                      return on.clearTimeout(t);
                    };

                    function mi(t, n) {
                      if (n) return t.slice();
                      var r = t.length,
                          e = Nt ? Nt(r) : new t.constructor(r);
                      return t.copy(e), e;
                    }

                    function Ai(t) {
                      var n = new t.constructor(t.byteLength);
                      return new zt(n).set(new zt(t)), n;
                    }

                    function wi(t, n) {
                      var r = n ? Ai(t.buffer) : t.buffer;
                      return new t.constructor(r, t.byteOffset, t.length);
                    }

                    function Fi(t, n) {
                      if (t !== n) {
                        var r = t !== i,
                            e = null === t,
                            a = t == t,
                            o = su(t),
                            u = n !== i,
                            c = null === n,
                            s = n == n,
                            f = su(n);
                        if (!c && !f && !o && t > n || o && u && s && !c && !f || e && u && s || !r && s || !a) return 1;
                        if (!e && !o && !f && t < n || f && r && a && !e && !o || c && r && a || !u && a || !s) return -1;
                      }

                      return 0;
                    }

                    function Si(t, n, r, i) {
                      for (var a = -1, o = t.length, u = r.length, c = -1, s = n.length, f = dr(o - u, 0), l = e(s + f), h = !i; ++c < s;) l[c] = n[c];

                      for (; ++a < u;) (h || a < o) && (l[r[a]] = t[a]);

                      for (; f--;) l[c++] = t[a++];

                      return l;
                    }

                    function Ci(t, n, r, i) {
                      for (var a = -1, o = t.length, u = -1, c = r.length, s = -1, f = n.length, l = dr(o - c, 0), h = e(l + f), p = !i; ++a < l;) h[a] = t[a];

                      for (var v = a; ++s < f;) h[v + s] = n[s];

                      for (; ++u < c;) (p || a < o) && (h[v + r[u]] = t[a++]);

                      return h;
                    }

                    function Oi(t, n) {
                      var r = -1,
                          i = t.length;

                      for (n || (n = e(i)); ++r < i;) n[r] = t[r];

                      return n;
                    }

                    function xi(t, n, r, e) {
                      var a = !r;
                      r || (r = {});

                      for (var o = -1, u = n.length; ++o < u;) {
                        var c = n[o],
                            s = e ? e(r[c], t[c], c, r, t) : i;
                        s === i && (s = t[c]), a ? ie(r, c, s) : te(r, c, s);
                      }

                      return r;
                    }

                    function Ii(t, n) {
                      return function (r, e) {
                        var i = $o(r) ? bn : re,
                            a = n ? n() : {};
                        return i(r, t, oa(e, 2), a);
                      };
                    }

                    function ji(t) {
                      return He(function (n, r) {
                        var e = -1,
                            a = r.length,
                            o = a > 1 ? r[a - 1] : i,
                            u = a > 2 ? r[2] : i;

                        for (o = t.length > 3 && "function" == typeof o ? (a--, o) : i, u && da(r[0], r[1], u) && (o = a < 3 ? i : o, a = 1), n = Ft(n); ++e < a;) {
                          var c = r[e];
                          c && t(n, c, e, o);
                        }

                        return n;
                      });
                    }

                    function Ti(t, n) {
                      return function (r, e) {
                        if (null == r) return r;
                        if (!Zo(r)) return t(r, e);

                        for (var i = r.length, a = n ? i : -1, o = Ft(r); (n ? a-- : ++a < i) && !1 !== e(o[a], a, o););

                        return r;
                      };
                    }

                    function Pi(t) {
                      return function (n, r, e) {
                        for (var i = -1, a = Ft(n), o = e(n), u = o.length; u--;) {
                          var c = o[t ? u : ++i];
                          if (!1 === r(a[c], c, a)) break;
                        }

                        return n;
                      };
                    }

                    function Ri(t) {
                      return function (n) {
                        var r = Xn(n = bu(n)) ? or(n) : i,
                            e = r ? r[0] : n.charAt(0),
                            a = r ? bi(r, 1).join("") : n.slice(1);
                        return e[t]() + a;
                      };
                    }

                    function Li(t) {
                      return function (n) {
                        return xn(Yu(Vu(n).replace(Vt, "")), t, "");
                      };
                    }

                    function Ei(t) {
                      return function () {
                        var n = arguments;

                        switch (n.length) {
                          case 0:
                            return new t();

                          case 1:
                            return new t(n[0]);

                          case 2:
                            return new t(n[0], n[1]);

                          case 3:
                            return new t(n[0], n[1], n[2]);

                          case 4:
                            return new t(n[0], n[1], n[2], n[3]);

                          case 5:
                            return new t(n[0], n[1], n[2], n[3], n[4]);

                          case 6:
                            return new t(n[0], n[1], n[2], n[3], n[4], n[5]);

                          case 7:
                            return new t(n[0], n[1], n[2], n[3], n[4], n[5], n[6]);
                        }

                        var r = Wr(t.prototype),
                            e = t.apply(r, n);
                        return nu(e) ? e : r;
                      };
                    }

                    function Mi(t) {
                      return function (n, r, e) {
                        var a = Ft(n);

                        if (!Zo(n)) {
                          var o = oa(r, 3);
                          n = Pu(n), r = function (t) {
                            return o(a[t], t, a);
                          };
                        }

                        var u = t(n, r, e);
                        return u > -1 ? a[o ? n[u] : u] : i;
                      };
                    }

                    function Ui(t) {
                      return ta(function (n) {
                        var r = n.length,
                            e = r,
                            o = zr.prototype.thru;

                        for (t && n.reverse(); e--;) {
                          var u = n[e];
                          if ("function" != typeof u) throw new Ot(a);
                          if (o && !c && "wrapper" == ia(u)) var c = new zr([], !0);
                        }

                        for (e = c ? e : r; ++e < r;) {
                          var s = ia(u = n[e]),
                              f = "wrapper" == s ? ea(u) : i;
                          c = f && ba(f[0]) && 424 == f[1] && !f[4].length && 1 == f[9] ? c[ia(f[0])].apply(c, f[3]) : 1 == u.length && ba(u) ? c[s]() : c.thru(u);
                        }

                        return function () {
                          var t = arguments,
                              e = t[0];
                          if (c && 1 == t.length && $o(e)) return c.plant(e).value();

                          for (var i = 0, a = r ? n[i].apply(this, t) : e; ++i < r;) a = n[i].call(this, a);

                          return a;
                        };
                      });
                    }

                    function Bi(t, n, r, a, o, u, c, f, l, h) {
                      var p = n & s,
                          v = 1 & n,
                          y = 2 & n,
                          g = 24 & n,
                          d = 512 & n,
                          _ = y ? i : Ei(t);

                      return function i() {
                        for (var s = arguments.length, b = e(s), k = s; k--;) b[k] = arguments[k];

                        if (g) var m = aa(i),
                            A = Jn(b, m);

                        if (a && (b = Si(b, a, o, g)), u && (b = Ci(b, u, c, g)), s -= A, g && s < h) {
                          var w = rr(b, m);
                          return $i(t, n, Bi, i.placeholder, r, b, w, f, l, h - s);
                        }

                        var F = v ? r : this,
                            S = y ? F[t] : t;
                        return s = b.length, f ? b = Ca(b, f) : d && s > 1 && b.reverse(), p && l < s && (b.length = l), this && this !== on && this instanceof i && (S = _ || Ei(S)), S.apply(F, b);
                      };
                    }

                    function Di(t, n) {
                      return function (r, e) {
                        return function (t, n, r, e) {
                          return be(t, function (t, i, a) {
                            n(e, r(t), i, a);
                          }), e;
                        }(r, t, n(e), {});
                      };
                    }

                    function Wi(t, n) {
                      return function (r, e) {
                        var a;
                        if (r === i && e === i) return n;

                        if (r !== i && (a = r), e !== i) {
                          if (a === i) return e;
                          "string" == typeof r || "string" == typeof e ? (r = ui(r), e = ui(e)) : (r = oi(r), e = oi(e)), a = t(r, e);
                        }

                        return a;
                      };
                    }

                    function qi(t) {
                      return ta(function (n) {
                        return n = Cn(n, Vn(oa())), He(function (r) {
                          var e = this;
                          return t(n, function (t) {
                            return _n(t, e, r);
                          });
                        });
                      });
                    }

                    function zi(t, n) {
                      var r = (n = n === i ? " " : ui(n)).length;
                      if (r < 2) return r ? Ze(n, t) : n;
                      var e = Ze(n, fr(t / ar(n)));
                      return Xn(n) ? bi(or(e), 0, t).join("") : e.slice(0, t);
                    }

                    function Ni(t) {
                      return function (n, r, a) {
                        return a && "number" != typeof a && da(n, r, a) && (r = a = i), n = vu(n), r === i ? (r = n, n = 0) : r = vu(r), function (t, n, r, i) {
                          for (var a = -1, o = dr(fr((n - t) / (r || 1)), 0), u = e(o); o--;) u[i ? o : ++a] = t, t += r;

                          return u;
                        }(n, r, a = a === i ? n < r ? 1 : -1 : vu(a), t);
                      };
                    }

                    function Vi(t) {
                      return function (n, r) {
                        return "string" == typeof n && "string" == typeof r || (n = du(n), r = du(r)), t(n, r);
                      };
                    }

                    function $i(t, n, r, e, a, o, u, s, f, l) {
                      var h = 8 & n;
                      n |= h ? c : 64, 4 & (n &= ~(h ? 64 : c)) || (n &= -4);
                      var p = [t, n, a, h ? o : i, h ? u : i, h ? i : o, h ? i : u, s, f, l],
                          v = r.apply(i, p);
                      return ba(t) && xa(v, p), v.placeholder = e, Ta(v, t, n);
                    }

                    function Gi(t) {
                      var n = wt[t];
                      return function (t, r) {
                        if (t = du(t), (r = null == r ? 0 : _r(yu(r), 292)) && vr(t)) {
                          var e = (bu(t) + "e").split("e");
                          return +((e = (bu(n(e[0] + "e" + (+e[1] + r))) + "e").split("e"))[0] + "e" + (+e[1] - r));
                        }

                        return n(t);
                      };
                    }

                    var Zi = Cr && 1 / er(new Cr([, -0]))[1] == f ? function (t) {
                      return new Cr(t);
                    } : sc;

                    function Hi(t) {
                      return function (n) {
                        var r = ha(n);
                        return r == A ? tr(n) : r == O ? ir(n) : function (t, n) {
                          return Cn(n, function (n) {
                            return [n, t[n]];
                          });
                        }(n, t(n));
                      };
                    }

                    function Ji(t, n, r, o, f, l, h, p) {
                      var v = 2 & n;
                      if (!v && "function" != typeof t) throw new Ot(a);
                      var y = o ? o.length : 0;

                      if (y || (n &= -97, o = f = i), h = h === i ? h : dr(yu(h), 0), p = p === i ? p : yu(p), y -= f ? f.length : 0, 64 & n) {
                        var g = o,
                            d = f;
                        o = f = i;
                      }

                      var _ = v ? i : ea(t),
                          b = [t, n, r, o, f, g, d, l, h, p];

                      if (_ && function (t, n) {
                        var r = t[1],
                            e = n[1],
                            i = r | e,
                            a = i < 131,
                            o = e == s && 8 == r || e == s && 256 == r && t[7].length <= n[8] || 384 == e && n[7].length <= n[8] && 8 == r;
                        if (!a && !o) return t;
                        1 & e && (t[2] = n[2], i |= 1 & r ? 0 : 4);
                        var c = n[3];

                        if (c) {
                          var f = t[3];
                          t[3] = f ? Si(f, c, n[4]) : c, t[4] = f ? rr(t[3], u) : n[4];
                        }

                        (c = n[5]) && (f = t[5], t[5] = f ? Ci(f, c, n[6]) : c, t[6] = f ? rr(t[5], u) : n[6]), (c = n[7]) && (t[7] = c), e & s && (t[8] = null == t[8] ? n[8] : _r(t[8], n[8])), null == t[9] && (t[9] = n[9]), t[0] = n[0], t[1] = i;
                      }(b, _), t = b[0], n = b[1], r = b[2], o = b[3], f = b[4], !(p = b[9] = b[9] === i ? v ? 0 : t.length : dr(b[9] - y, 0)) && 24 & n && (n &= -25), n && 1 != n) k = 8 == n || 16 == n ? function (t, n, r) {
                        var a = Ei(t);
                        return function o() {
                          for (var u = arguments.length, c = e(u), s = u, f = aa(o); s--;) c[s] = arguments[s];

                          var l = u < 3 && c[0] !== f && c[u - 1] !== f ? [] : rr(c, f);
                          return (u -= l.length) < r ? $i(t, n, Bi, o.placeholder, i, c, l, i, i, r - u) : _n(this && this !== on && this instanceof o ? a : t, this, c);
                        };
                      }(t, n, p) : n != c && 33 != n || f.length ? Bi.apply(i, b) : function (t, n, r, i) {
                        var a = 1 & n,
                            o = Ei(t);
                        return function n() {
                          for (var u = -1, c = arguments.length, s = -1, f = i.length, l = e(f + c), h = this && this !== on && this instanceof n ? o : t; ++s < f;) l[s] = i[s];

                          for (; c--;) l[s++] = arguments[++u];

                          return _n(h, a ? r : this, l);
                        };
                      }(t, n, r, o);else var k = function (t, n, r) {
                        var e = 1 & n,
                            i = Ei(t);
                        return function n() {
                          return (this && this !== on && this instanceof n ? i : t).apply(e ? r : this, arguments);
                        };
                      }(t, n, r);
                      return Ta((_ ? Ye : xa)(k, b), t, n);
                    }

                    function Ki(t, n, r, e) {
                      return t === i || qo(t, jt[r]) && !Rt.call(e, r) ? n : t;
                    }

                    function Qi(t, n, r, e, a, o) {
                      return nu(t) && nu(n) && (o.set(n, t), We(t, n, i, Qi, o), o.delete(n)), t;
                    }

                    function Yi(t) {
                      return au(t) ? i : t;
                    }

                    function Xi(t, n, r, e, a, o) {
                      var u = 1 & r,
                          c = t.length,
                          s = n.length;
                      if (c != s && !(u && s > c)) return !1;
                      var f = o.get(t),
                          l = o.get(n);
                      if (f && l) return f == n && l == t;
                      var h = -1,
                          p = !0,
                          v = 2 & r ? new Zr() : i;

                      for (o.set(t, n), o.set(n, t); ++h < c;) {
                        var y = t[h],
                            g = n[h];
                        if (e) var d = u ? e(g, y, h, n, t, o) : e(y, g, h, t, n, o);

                        if (d !== i) {
                          if (d) continue;
                          p = !1;
                          break;
                        }

                        if (v) {
                          if (!jn(n, function (t, n) {
                            if (!Gn(v, n) && (y === t || a(y, t, r, e, o))) return v.push(n);
                          })) {
                            p = !1;
                            break;
                          }
                        } else if (y !== g && !a(y, g, r, e, o)) {
                          p = !1;
                          break;
                        }
                      }

                      return o.delete(t), o.delete(n), p;
                    }

                    function ta(t) {
                      return ja(Fa(t, i, $a), t + "");
                    }

                    function na(t) {
                      return we(t, Pu, fa);
                    }

                    function ra(t) {
                      return we(t, Ru, la);
                    }

                    var ea = Ir ? function (t) {
                      return Ir.get(t);
                    } : sc;

                    function ia(t) {
                      for (var n = t.name + "", r = jr[n], e = Rt.call(jr, n) ? r.length : 0; e--;) {
                        var i = r[e],
                            a = i.func;
                        if (null == a || a == t) return i.name;
                      }

                      return n;
                    }

                    function aa(t) {
                      return (Rt.call(Dr, "placeholder") ? Dr : t).placeholder;
                    }

                    function oa() {
                      var t = Dr.iteratee || ac;
                      return t = t === ac ? Le : t, arguments.length ? t(arguments[0], arguments[1]) : t;
                    }

                    function ua(t, n) {
                      var r,
                          e,
                          i = t.__data__;
                      return ("string" == (e = typeof (r = n)) || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== r : null === r) ? i["string" == typeof n ? "string" : "hash"] : i.map;
                    }

                    function ca(t) {
                      for (var n = Pu(t), r = n.length; r--;) {
                        var e = n[r],
                            i = t[e];
                        n[r] = [e, i, Aa(i)];
                      }

                      return n;
                    }

                    function sa(t, n) {
                      var r = function (t, n) {
                        return null == t ? i : t[n];
                      }(t, n);

                      return Re(r) ? r : i;
                    }

                    var fa = hr ? function (t) {
                      return null == t ? [] : (t = Ft(t), wn(hr(t), function (n) {
                        return tn.call(t, n);
                      }));
                    } : gc,
                        la = hr ? function (t) {
                      for (var n = []; t;) On(n, fa(t)), t = Gt(t);

                      return n;
                    } : gc,
                        ha = Fe;

                    function pa(t, n, r) {
                      for (var e = -1, i = (n = di(n, t)).length, a = !1; ++e < i;) {
                        var o = Ua(n[e]);
                        if (!(a = null != t && r(t, o))) break;
                        t = t[o];
                      }

                      return a || ++e != i ? a : !!(i = null == t ? 0 : t.length) && tu(i) && ga(o, i) && ($o(t) || Vo(t));
                    }

                    function va(t) {
                      return "function" != typeof t.constructor || ma(t) ? {} : Wr(Gt(t));
                    }

                    function ya(t) {
                      return $o(t) || Vo(t) || !!(an && t && t[an]);
                    }

                    function ga(t, n) {
                      var r = typeof t;
                      return !!(n = null == n ? l : n) && ("number" == r || "symbol" != r && dt.test(t)) && t > -1 && t % 1 == 0 && t < n;
                    }

                    function da(t, n, r) {
                      if (!nu(r)) return !1;
                      var e = typeof n;
                      return !!("number" == e ? Zo(r) && ga(n, r.length) : "string" == e && n in r) && qo(r[n], t);
                    }

                    function _a(t, n) {
                      if ($o(t)) return !1;
                      var r = typeof t;
                      return !("number" != r && "symbol" != r && "boolean" != r && null != t && !su(t)) || X.test(t) || !Y.test(t) || null != n && t in Ft(n);
                    }

                    function ba(t) {
                      var n = ia(t),
                          r = Dr[n];
                      if ("function" != typeof r || !(n in Nr.prototype)) return !1;
                      if (t === r) return !0;
                      var e = ea(r);
                      return !!e && t === e[0];
                    }

                    (wr && ha(new wr(new ArrayBuffer(1))) != P || Fr && ha(new Fr()) != A || Sr && ha(Sr.resolve()) != S || Cr && ha(new Cr()) != O || Or && ha(new Or()) != j) && (ha = function (t) {
                      var n = Fe(t),
                          r = n == F ? t.constructor : i,
                          e = r ? Ba(r) : "";
                      if (e) switch (e) {
                        case Tr:
                          return P;

                        case Pr:
                          return A;

                        case Rr:
                          return S;

                        case Lr:
                          return O;

                        case Er:
                          return j;
                      }
                      return n;
                    });
                    var ka = Tt ? Yo : dc;

                    function ma(t) {
                      var n = t && t.constructor;
                      return t === ("function" == typeof n && n.prototype || jt);
                    }

                    function Aa(t) {
                      return t == t && !nu(t);
                    }

                    function wa(t, n) {
                      return function (r) {
                        return null != r && r[t] === n && (n !== i || t in Ft(r));
                      };
                    }

                    function Fa(t, n, r) {
                      return n = dr(n === i ? t.length - 1 : n, 0), function () {
                        for (var i = arguments, a = -1, o = dr(i.length - n, 0), u = e(o); ++a < o;) u[a] = i[n + a];

                        a = -1;

                        for (var c = e(n + 1); ++a < n;) c[a] = i[a];

                        return c[n] = r(u), _n(t, this, c);
                      };
                    }

                    function Sa(t, n) {
                      return n.length < 2 ? t : Ae(t, ni(n, 0, -1));
                    }

                    function Ca(t, n) {
                      for (var r = t.length, e = _r(n.length, r), a = Oi(t); e--;) {
                        var o = n[e];
                        t[e] = ga(o, r) ? a[o] : i;
                      }

                      return t;
                    }

                    function Oa(t, n) {
                      if (("constructor" !== n || "function" != typeof t[n]) && "__proto__" != n) return t[n];
                    }

                    var xa = Pa(Ye),
                        Ia = Dn || function (t, n) {
                      return on.setTimeout(t, n);
                    },
                        ja = Pa(Xe);

                    function Ta(t, n, r) {
                      var e = n + "";
                      return ja(t, function (t, n) {
                        var r = n.length;
                        if (!r) return t;
                        var e = r - 1;
                        return n[e] = (r > 1 ? "& " : "") + n[e], n = n.join(r > 2 ? ", " : " "), t.replace(at, "{\n/* [wrapped with " + n + "] */\n");
                      }(e, function (t, n) {
                        return kn(v, function (r) {
                          var e = "_." + r[0];
                          n & r[1] && !Fn(t, e) && t.push(e);
                        }), t.sort();
                      }(function (t) {
                        var n = t.match(ot);
                        return n ? n[1].split(ut) : [];
                      }(e), r)));
                    }

                    function Pa(t) {
                      var n = 0,
                          r = 0;
                      return function () {
                        var e = br(),
                            a = 16 - (e - r);

                        if (r = e, a > 0) {
                          if (++n >= 800) return arguments[0];
                        } else n = 0;

                        return t.apply(i, arguments);
                      };
                    }

                    function Ra(t, n) {
                      var r = -1,
                          e = t.length,
                          a = e - 1;

                      for (n = n === i ? e : n; ++r < n;) {
                        var o = Ge(r, a),
                            u = t[o];
                        t[o] = t[r], t[r] = u;
                      }

                      return t.length = n, t;
                    }

                    var La,
                        Ea,
                        Ma = (La = Eo(function (t) {
                      var n = [];
                      return 46 === t.charCodeAt(0) && n.push(""), t.replace(tt, function (t, r, e, i) {
                        n.push(e ? i.replace(ft, "$1") : r || t);
                      }), n;
                    }, function (t) {
                      return 500 === Ea.size && Ea.clear(), t;
                    }), Ea = La.cache, La);

                    function Ua(t) {
                      if ("string" == typeof t || su(t)) return t;
                      var n = t + "";
                      return "0" == n && 1 / t == -1 / 0 ? "-0" : n;
                    }

                    function Ba(t) {
                      if (null != t) {
                        try {
                          return Pt.call(t);
                        } catch (t) {}

                        try {
                          return t + "";
                        } catch (t) {}
                      }

                      return "";
                    }

                    function Da(t) {
                      if (t instanceof Nr) return t.clone();
                      var n = new zr(t.__wrapped__, t.__chain__);
                      return n.__actions__ = Oi(t.__actions__), n.__index__ = t.__index__, n.__values__ = t.__values__, n;
                    }

                    var Wa = He(function (t, n) {
                      return Ho(t) ? fe(t, ge(n, 1, Ho, !0)) : [];
                    }),
                        qa = He(function (t, n) {
                      var r = Ka(n);
                      return Ho(r) && (r = i), Ho(t) ? fe(t, ge(n, 1, Ho, !0), oa(r, 2)) : [];
                    }),
                        za = He(function (t, n) {
                      var r = Ka(n);
                      return Ho(r) && (r = i), Ho(t) ? fe(t, ge(n, 1, Ho, !0), i, r) : [];
                    });

                    function Na(t, n, r) {
                      var e = null == t ? 0 : t.length;
                      if (!e) return -1;
                      var i = null == r ? 0 : yu(r);
                      return i < 0 && (i = dr(e + i, 0)), Rn(t, oa(n, 3), i);
                    }

                    function Va(t, n, r) {
                      var e = null == t ? 0 : t.length;
                      if (!e) return -1;
                      var a = e - 1;
                      return r !== i && (a = yu(r), a = r < 0 ? dr(e + a, 0) : _r(a, e - 1)), Rn(t, oa(n, 3), a, !0);
                    }

                    function $a(t) {
                      return null != t && t.length ? ge(t, 1) : [];
                    }

                    function Ga(t) {
                      return t && t.length ? t[0] : i;
                    }

                    var Za = He(function (t) {
                      var n = Cn(t, yi);
                      return n.length && n[0] === t[0] ? xe(n) : [];
                    }),
                        Ha = He(function (t) {
                      var n = Ka(t),
                          r = Cn(t, yi);
                      return n === Ka(r) ? n = i : r.pop(), r.length && r[0] === t[0] ? xe(r, oa(n, 2)) : [];
                    }),
                        Ja = He(function (t) {
                      var n = Ka(t),
                          r = Cn(t, yi);
                      return (n = "function" == typeof n ? n : i) && r.pop(), r.length && r[0] === t[0] ? xe(r, i, n) : [];
                    });

                    function Ka(t) {
                      var n = null == t ? 0 : t.length;
                      return n ? t[n - 1] : i;
                    }

                    var Qa = He(Ya);

                    function Ya(t, n) {
                      return t && t.length && n && n.length ? Ve(t, n) : t;
                    }

                    var Xa = ta(function (t, n) {
                      var r = null == t ? 0 : t.length,
                          e = ae(t, n);
                      return $e(t, Cn(n, function (t) {
                        return ga(t, r) ? +t : t;
                      }).sort(Fi)), e;
                    });

                    function to(t) {
                      return null == t ? t : Ar.call(t);
                    }

                    var no = He(function (t) {
                      return ci(ge(t, 1, Ho, !0));
                    }),
                        ro = He(function (t) {
                      var n = Ka(t);
                      return Ho(n) && (n = i), ci(ge(t, 1, Ho, !0), oa(n, 2));
                    }),
                        eo = He(function (t) {
                      var n = Ka(t);
                      return n = "function" == typeof n ? n : i, ci(ge(t, 1, Ho, !0), i, n);
                    });

                    function io(t) {
                      if (!t || !t.length) return [];
                      var n = 0;
                      return t = wn(t, function (t) {
                        if (Ho(t)) return n = dr(t.length, n), !0;
                      }), zn(n, function (n) {
                        return Cn(t, Bn(n));
                      });
                    }

                    function ao(t, n) {
                      if (!t || !t.length) return [];
                      var r = io(t);
                      return null == n ? r : Cn(r, function (t) {
                        return _n(n, i, t);
                      });
                    }

                    var oo = He(function (t, n) {
                      return Ho(t) ? fe(t, n) : [];
                    }),
                        uo = He(function (t) {
                      return pi(wn(t, Ho));
                    }),
                        co = He(function (t) {
                      var n = Ka(t);
                      return Ho(n) && (n = i), pi(wn(t, Ho), oa(n, 2));
                    }),
                        so = He(function (t) {
                      var n = Ka(t);
                      return n = "function" == typeof n ? n : i, pi(wn(t, Ho), i, n);
                    }),
                        fo = He(io),
                        lo = He(function (t) {
                      var n = t.length,
                          r = n > 1 ? t[n - 1] : i;
                      return r = "function" == typeof r ? (t.pop(), r) : i, ao(t, r);
                    });

                    function ho(t) {
                      var n = Dr(t);
                      return n.__chain__ = !0, n;
                    }

                    function po(t, n) {
                      return n(t);
                    }

                    var vo = ta(function (t) {
                      var n = t.length,
                          r = n ? t[0] : 0,
                          e = this.__wrapped__,
                          a = function (n) {
                        return ae(n, t);
                      };

                      return !(n > 1 || this.__actions__.length) && e instanceof Nr && ga(r) ? ((e = e.slice(r, +r + (n ? 1 : 0))).__actions__.push({
                        func: po,
                        args: [a],
                        thisArg: i
                      }), new zr(e, this.__chain__).thru(function (t) {
                        return n && !t.length && t.push(i), t;
                      })) : this.thru(a);
                    }),
                        yo = Ii(function (t, n, r) {
                      Rt.call(t, r) ? ++t[r] : ie(t, r, 1);
                    }),
                        go = Mi(Na),
                        _o = Mi(Va);

                    function bo(t, n) {
                      return ($o(t) ? kn : le)(t, oa(n, 3));
                    }

                    function ko(t, n) {
                      return ($o(t) ? mn : he)(t, oa(n, 3));
                    }

                    var mo = Ii(function (t, n, r) {
                      Rt.call(t, r) ? t[r].push(n) : ie(t, r, [n]);
                    }),
                        Ao = He(function (t, n, r) {
                      var i = -1,
                          a = "function" == typeof n,
                          o = Zo(t) ? e(t.length) : [];
                      return le(t, function (t) {
                        o[++i] = a ? _n(n, t, r) : Ie(t, n, r);
                      }), o;
                    }),
                        wo = Ii(function (t, n, r) {
                      ie(t, r, n);
                    });

                    function Fo(t, n) {
                      return ($o(t) ? Cn : Ue)(t, oa(n, 3));
                    }

                    var So = Ii(function (t, n, r) {
                      t[r ? 0 : 1].push(n);
                    }, function () {
                      return [[], []];
                    }),
                        Co = He(function (t, n) {
                      if (null == t) return [];
                      var r = n.length;
                      return r > 1 && da(t, n[0], n[1]) ? n = [] : r > 2 && da(n[0], n[1], n[2]) && (n = [n[0]]), ze(t, ge(n, 1), []);
                    }),
                        Oo = Tn || function () {
                      return on.Date.now();
                    };

                    function xo(t, n, r) {
                      return n = r ? i : n, n = t && null == n ? t.length : n, Ji(t, s, i, i, i, i, n);
                    }

                    function Io(t, n) {
                      var r;
                      if ("function" != typeof n) throw new Ot(a);
                      return t = yu(t), function () {
                        return --t > 0 && (r = n.apply(this, arguments)), t <= 1 && (n = i), r;
                      };
                    }

                    var jo = He(function (t, n, r) {
                      var e = 1;

                      if (r.length) {
                        var i = rr(r, aa(jo));
                        e |= c;
                      }

                      return Ji(t, e, n, r, i);
                    }),
                        To = He(function (t, n, r) {
                      var e = 3;

                      if (r.length) {
                        var i = rr(r, aa(To));
                        e |= c;
                      }

                      return Ji(n, e, t, r, i);
                    });

                    function Po(t, n, r) {
                      var e,
                          o,
                          u,
                          c,
                          s,
                          f,
                          l = 0,
                          h = !1,
                          p = !1,
                          v = !0;
                      if ("function" != typeof t) throw new Ot(a);

                      function y(n) {
                        var r = e,
                            a = o;
                        return e = o = i, l = n, c = t.apply(a, r);
                      }

                      function g(t) {
                        return l = t, s = Ia(_, n), h ? y(t) : c;
                      }

                      function d(t) {
                        var r = t - f;
                        return f === i || r >= n || r < 0 || p && t - l >= u;
                      }

                      function _() {
                        var t = Oo();
                        if (d(t)) return b(t);
                        s = Ia(_, function (t) {
                          var r = n - (t - f);
                          return p ? _r(r, u - (t - l)) : r;
                        }(t));
                      }

                      function b(t) {
                        return s = i, v && e ? y(t) : (e = o = i, c);
                      }

                      function k() {
                        var t = Oo(),
                            r = d(t);

                        if (e = arguments, o = this, f = t, r) {
                          if (s === i) return g(f);
                          if (p) return ki(s), s = Ia(_, n), y(f);
                        }

                        return s === i && (s = Ia(_, n)), c;
                      }

                      return n = du(n) || 0, nu(r) && (h = !!r.leading, u = (p = "maxWait" in r) ? dr(du(r.maxWait) || 0, n) : u, v = "trailing" in r ? !!r.trailing : v), k.cancel = function () {
                        s !== i && ki(s), l = 0, e = f = o = s = i;
                      }, k.flush = function () {
                        return s === i ? c : b(Oo());
                      }, k;
                    }

                    var Ro = He(function (t, n) {
                      return se(t, 1, n);
                    }),
                        Lo = He(function (t, n, r) {
                      return se(t, du(n) || 0, r);
                    });

                    function Eo(t, n) {
                      if ("function" != typeof t || null != n && "function" != typeof n) throw new Ot(a);

                      var r = function () {
                        var e = arguments,
                            i = n ? n.apply(this, e) : e[0],
                            a = r.cache;
                        if (a.has(i)) return a.get(i);
                        var o = t.apply(this, e);
                        return r.cache = a.set(i, o) || a, o;
                      };

                      return r.cache = new (Eo.Cache || Gr)(), r;
                    }

                    function Mo(t) {
                      if ("function" != typeof t) throw new Ot(a);
                      return function () {
                        var n = arguments;

                        switch (n.length) {
                          case 0:
                            return !t.call(this);

                          case 1:
                            return !t.call(this, n[0]);

                          case 2:
                            return !t.call(this, n[0], n[1]);

                          case 3:
                            return !t.call(this, n[0], n[1], n[2]);
                        }

                        return !t.apply(this, n);
                      };
                    }

                    Eo.Cache = Gr;

                    var Uo = _i(function (t, n) {
                      var r = (n = 1 == n.length && $o(n[0]) ? Cn(n[0], Vn(oa())) : Cn(ge(n, 1), Vn(oa()))).length;
                      return He(function (e) {
                        for (var i = -1, a = _r(e.length, r); ++i < a;) e[i] = n[i].call(this, e[i]);

                        return _n(t, this, e);
                      });
                    }),
                        Bo = He(function (t, n) {
                      var r = rr(n, aa(Bo));
                      return Ji(t, c, i, n, r);
                    }),
                        Do = He(function (t, n) {
                      var r = rr(n, aa(Do));
                      return Ji(t, 64, i, n, r);
                    }),
                        Wo = ta(function (t, n) {
                      return Ji(t, 256, i, i, i, n);
                    });

                    function qo(t, n) {
                      return t === n || t != t && n != n;
                    }

                    var zo = Vi(Se),
                        No = Vi(function (t, n) {
                      return t >= n;
                    }),
                        Vo = je(function () {
                      return arguments;
                    }()) ? je : function (t) {
                      return ru(t) && Rt.call(t, "callee") && !tn.call(t, "callee");
                    },
                        $o = e.isArray,
                        Go = hn ? Vn(hn) : function (t) {
                      return ru(t) && Fe(t) == T;
                    };

                    function Zo(t) {
                      return null != t && tu(t.length) && !Yo(t);
                    }

                    function Ho(t) {
                      return ru(t) && Zo(t);
                    }

                    var Jo = pr || dc,
                        Ko = pn ? Vn(pn) : function (t) {
                      return ru(t) && Fe(t) == _;
                    };

                    function Qo(t) {
                      if (!ru(t)) return !1;
                      var n = Fe(t);
                      return n == b || "[object DOMException]" == n || "string" == typeof t.message && "string" == typeof t.name && !au(t);
                    }

                    function Yo(t) {
                      if (!nu(t)) return !1;
                      var n = Fe(t);
                      return n == k || n == m || "[object AsyncFunction]" == n || "[object Proxy]" == n;
                    }

                    function Xo(t) {
                      return "number" == typeof t && t == yu(t);
                    }

                    function tu(t) {
                      return "number" == typeof t && t > -1 && t % 1 == 0 && t <= l;
                    }

                    function nu(t) {
                      var n = typeof t;
                      return null != t && ("object" == n || "function" == n);
                    }

                    function ru(t) {
                      return null != t && "object" == typeof t;
                    }

                    var eu = vn ? Vn(vn) : function (t) {
                      return ru(t) && ha(t) == A;
                    };

                    function iu(t) {
                      return "number" == typeof t || ru(t) && Fe(t) == w;
                    }

                    function au(t) {
                      if (!ru(t) || Fe(t) != F) return !1;
                      var n = Gt(t);
                      if (null === n) return !0;
                      var r = Rt.call(n, "constructor") && n.constructor;
                      return "function" == typeof r && r instanceof r && Pt.call(r) == Ut;
                    }

                    var ou = yn ? Vn(yn) : function (t) {
                      return ru(t) && Fe(t) == C;
                    },
                        uu = gn ? Vn(gn) : function (t) {
                      return ru(t) && ha(t) == O;
                    };

                    function cu(t) {
                      return "string" == typeof t || !$o(t) && ru(t) && Fe(t) == x;
                    }

                    function su(t) {
                      return "symbol" == typeof t || ru(t) && Fe(t) == I;
                    }

                    var fu = dn ? Vn(dn) : function (t) {
                      return ru(t) && tu(t.length) && !!Yt[Fe(t)];
                    },
                        lu = Vi(Me),
                        hu = Vi(function (t, n) {
                      return t <= n;
                    });

                    function pu(t) {
                      if (!t) return [];
                      if (Zo(t)) return cu(t) ? or(t) : Oi(t);
                      if (un && t[un]) return function (t) {
                        for (var n, r = []; !(n = t.next()).done;) r.push(n.value);

                        return r;
                      }(t[un]());
                      var n = ha(t);
                      return (n == A ? tr : n == O ? er : qu)(t);
                    }

                    function vu(t) {
                      return t ? (t = du(t)) === f || t === -1 / 0 ? 17976931348623157e292 * (t < 0 ? -1 : 1) : t == t ? t : 0 : 0 === t ? t : 0;
                    }

                    function yu(t) {
                      var n = vu(t),
                          r = n % 1;
                      return n == n ? r ? n - r : n : 0;
                    }

                    function gu(t) {
                      return t ? oe(yu(t), 0, p) : 0;
                    }

                    function du(t) {
                      if ("number" == typeof t) return t;
                      if (su(t)) return h;

                      if (nu(t)) {
                        var n = "function" == typeof t.valueOf ? t.valueOf() : t;
                        t = nu(n) ? n + "" : n;
                      }

                      if ("string" != typeof t) return 0 === t ? t : +t;
                      t = Nn(t);
                      var r = vt.test(t);
                      return r || gt.test(t) ? rn(t.slice(2), r ? 2 : 8) : pt.test(t) ? h : +t;
                    }

                    function _u(t) {
                      return xi(t, Ru(t));
                    }

                    function bu(t) {
                      return null == t ? "" : ui(t);
                    }

                    var ku = ji(function (t, n) {
                      if (ma(n) || Zo(n)) xi(n, Pu(n), t);else for (var r in n) Rt.call(n, r) && te(t, r, n[r]);
                    }),
                        mu = ji(function (t, n) {
                      xi(n, Ru(n), t);
                    }),
                        Au = ji(function (t, n, r, e) {
                      xi(n, Ru(n), t, e);
                    }),
                        wu = ji(function (t, n, r, e) {
                      xi(n, Pu(n), t, e);
                    }),
                        Fu = ta(ae),
                        Su = He(function (t, n) {
                      t = Ft(t);
                      var r = -1,
                          e = n.length,
                          a = e > 2 ? n[2] : i;

                      for (a && da(n[0], n[1], a) && (e = 1); ++r < e;) for (var o = n[r], u = Ru(o), c = -1, s = u.length; ++c < s;) {
                        var f = u[c],
                            l = t[f];
                        (l === i || qo(l, jt[f]) && !Rt.call(t, f)) && (t[f] = o[f]);
                      }

                      return t;
                    }),
                        Cu = He(function (t) {
                      return t.push(i, Qi), _n(Eu, i, t);
                    });

                    function Ou(t, n, r) {
                      var e = null == t ? i : Ae(t, n);
                      return e === i ? r : e;
                    }

                    function xu(t, n) {
                      return null != t && pa(t, n, Oe);
                    }

                    var Iu = Di(function (t, n, r) {
                      null != n && "function" != typeof n.toString && (n = Mt.call(n)), t[n] = r;
                    }, nc(ic)),
                        ju = Di(function (t, n, r) {
                      null != n && "function" != typeof n.toString && (n = Mt.call(n)), Rt.call(t, n) ? t[n].push(r) : t[n] = [r];
                    }, oa),
                        Tu = He(Ie);

                    function Pu(t) {
                      return Zo(t) ? Jr(t) : Ee(t);
                    }

                    function Ru(t) {
                      return Zo(t) ? Jr(t, !0) : function (t) {
                        if (!nu(t)) return function (t) {
                          var n = [];
                          if (null != t) for (var r in Ft(t)) n.push(r);
                          return n;
                        }(t);
                        var n = ma(t),
                            r = [];

                        for (var e in t) ("constructor" != e || !n && Rt.call(t, e)) && r.push(e);

                        return r;
                      }(t);
                    }

                    var Lu = ji(function (t, n, r) {
                      We(t, n, r);
                    }),
                        Eu = ji(function (t, n, r, e) {
                      We(t, n, r, e);
                    }),
                        Mu = ta(function (t, n) {
                      var r = {};
                      if (null == t) return r;
                      var e = !1;
                      n = Cn(n, function (n) {
                        return n = di(n, t), e || (e = n.length > 1), n;
                      }), xi(t, ra(t), r), e && (r = ue(r, 7, Yi));

                      for (var i = n.length; i--;) si(r, n[i]);

                      return r;
                    }),
                        Uu = ta(function (t, n) {
                      return null == t ? {} : function (t, n) {
                        return Ne(t, n, function (n, r) {
                          return xu(t, r);
                        });
                      }(t, n);
                    });

                    function Bu(t, n) {
                      if (null == t) return {};
                      var r = Cn(ra(t), function (t) {
                        return [t];
                      });
                      return n = oa(n), Ne(t, r, function (t, r) {
                        return n(t, r[0]);
                      });
                    }

                    var Du = Hi(Pu),
                        Wu = Hi(Ru);

                    function qu(t) {
                      return null == t ? [] : $n(t, Pu(t));
                    }

                    var zu = Li(function (t, n, r) {
                      return n = n.toLowerCase(), t + (r ? Nu(n) : n);
                    });

                    function Nu(t) {
                      return Qu(bu(t).toLowerCase());
                    }

                    function Vu(t) {
                      return (t = bu(t)) && t.replace(_t, Kn).replace($t, "");
                    }

                    var $u = Li(function (t, n, r) {
                      return t + (r ? "-" : "") + n.toLowerCase();
                    }),
                        Gu = Li(function (t, n, r) {
                      return t + (r ? " " : "") + n.toLowerCase();
                    }),
                        Zu = Ri("toLowerCase"),
                        Hu = Li(function (t, n, r) {
                      return t + (r ? "_" : "") + n.toLowerCase();
                    }),
                        Ju = Li(function (t, n, r) {
                      return t + (r ? " " : "") + Qu(n);
                    }),
                        Ku = Li(function (t, n, r) {
                      return t + (r ? " " : "") + n.toUpperCase();
                    }),
                        Qu = Ri("toUpperCase");

                    function Yu(t, n, r) {
                      return t = bu(t), (n = r ? i : n) === i ? function (t) {
                        return Jt.test(t);
                      }(t) ? function (t) {
                        return t.match(Zt) || [];
                      }(t) : function (t) {
                        return t.match(ct) || [];
                      }(t) : t.match(n) || [];
                    }

                    var Xu = He(function (t, n) {
                      try {
                        return _n(t, i, n);
                      } catch (t) {
                        return Qo(t) ? t : new mt(t);
                      }
                    }),
                        tc = ta(function (t, n) {
                      return kn(n, function (n) {
                        n = Ua(n), ie(t, n, jo(t[n], t));
                      }), t;
                    });

                    function nc(t) {
                      return function () {
                        return t;
                      };
                    }

                    var rc = Ui(),
                        ec = Ui(!0);

                    function ic(t) {
                      return t;
                    }

                    function ac(t) {
                      return Le("function" == typeof t ? t : ue(t, 1));
                    }

                    var oc = He(function (t, n) {
                      return function (r) {
                        return Ie(r, t, n);
                      };
                    }),
                        uc = He(function (t, n) {
                      return function (r) {
                        return Ie(t, r, n);
                      };
                    });

                    function cc(t, n, r) {
                      var e = Pu(n),
                          i = me(n, e);
                      null != r || nu(n) && (i.length || !e.length) || (r = n, n = t, t = this, i = me(n, Pu(n)));
                      var a = !(nu(r) && "chain" in r && !r.chain),
                          o = Yo(t);
                      return kn(i, function (r) {
                        var e = n[r];
                        t[r] = e, o && (t.prototype[r] = function () {
                          var n = this.__chain__;

                          if (a || n) {
                            var r = t(this.__wrapped__),
                                i = r.__actions__ = Oi(this.__actions__);
                            return i.push({
                              func: e,
                              args: arguments,
                              thisArg: t
                            }), r.__chain__ = n, r;
                          }

                          return e.apply(t, On([this.value()], arguments));
                        });
                      }), t;
                    }

                    function sc() {}

                    var fc = qi(Cn),
                        lc = qi(An),
                        hc = qi(jn);

                    function pc(t) {
                      return _a(t) ? Bn(Ua(t)) : function (t) {
                        return function (n) {
                          return Ae(n, t);
                        };
                      }(t);
                    }

                    var vc = Ni(),
                        yc = Ni(!0);

                    function gc() {
                      return [];
                    }

                    function dc() {
                      return !1;
                    }

                    var _c,
                        bc = Wi(function (t, n) {
                      return t + n;
                    }, 0),
                        kc = Gi("ceil"),
                        mc = Wi(function (t, n) {
                      return t / n;
                    }, 1),
                        Ac = Gi("floor"),
                        wc = Wi(function (t, n) {
                      return t * n;
                    }, 1),
                        Fc = Gi("round"),
                        Sc = Wi(function (t, n) {
                      return t - n;
                    }, 0);

                    return Dr.after = function (t, n) {
                      if ("function" != typeof n) throw new Ot(a);
                      return t = yu(t), function () {
                        if (--t < 1) return n.apply(this, arguments);
                      };
                    }, Dr.ary = xo, Dr.assign = ku, Dr.assignIn = mu, Dr.assignInWith = Au, Dr.assignWith = wu, Dr.at = Fu, Dr.before = Io, Dr.bind = jo, Dr.bindAll = tc, Dr.bindKey = To, Dr.castArray = function () {
                      if (!arguments.length) return [];
                      var t = arguments[0];
                      return $o(t) ? t : [t];
                    }, Dr.chain = ho, Dr.chunk = function (t, n, r) {
                      n = (r ? da(t, n, r) : n === i) ? 1 : dr(yu(n), 0);
                      var a = null == t ? 0 : t.length;
                      if (!a || n < 1) return [];

                      for (var o = 0, u = 0, c = e(fr(a / n)); o < a;) c[u++] = ni(t, o, o += n);

                      return c;
                    }, Dr.compact = function (t) {
                      for (var n = -1, r = null == t ? 0 : t.length, e = 0, i = []; ++n < r;) {
                        var a = t[n];
                        a && (i[e++] = a);
                      }

                      return i;
                    }, Dr.concat = function () {
                      var t = arguments.length;
                      if (!t) return [];

                      for (var n = e(t - 1), r = arguments[0], i = t; i--;) n[i - 1] = arguments[i];

                      return On($o(r) ? Oi(r) : [r], ge(n, 1));
                    }, Dr.cond = function (t) {
                      var n = null == t ? 0 : t.length,
                          r = oa();
                      return t = n ? Cn(t, function (t) {
                        if ("function" != typeof t[1]) throw new Ot(a);
                        return [r(t[0]), t[1]];
                      }) : [], He(function (r) {
                        for (var e = -1; ++e < n;) {
                          var i = t[e];
                          if (_n(i[0], this, r)) return _n(i[1], this, r);
                        }
                      });
                    }, Dr.conforms = function (t) {
                      return function (t) {
                        var n = Pu(t);
                        return function (r) {
                          return ce(r, t, n);
                        };
                      }(ue(t, 1));
                    }, Dr.constant = nc, Dr.countBy = yo, Dr.create = function (t, n) {
                      var r = Wr(t);
                      return null == n ? r : ee(r, n);
                    }, Dr.curry = function t(n, r, e) {
                      var a = Ji(n, 8, i, i, i, i, i, r = e ? i : r);
                      return a.placeholder = t.placeholder, a;
                    }, Dr.curryRight = function t(n, r, e) {
                      var a = Ji(n, 16, i, i, i, i, i, r = e ? i : r);
                      return a.placeholder = t.placeholder, a;
                    }, Dr.debounce = Po, Dr.defaults = Su, Dr.defaultsDeep = Cu, Dr.defer = Ro, Dr.delay = Lo, Dr.difference = Wa, Dr.differenceBy = qa, Dr.differenceWith = za, Dr.drop = function (t, n, r) {
                      var e = null == t ? 0 : t.length;
                      return e ? ni(t, (n = r || n === i ? 1 : yu(n)) < 0 ? 0 : n, e) : [];
                    }, Dr.dropRight = function (t, n, r) {
                      var e = null == t ? 0 : t.length;
                      return e ? ni(t, 0, (n = e - (n = r || n === i ? 1 : yu(n))) < 0 ? 0 : n) : [];
                    }, Dr.dropRightWhile = function (t, n) {
                      return t && t.length ? li(t, oa(n, 3), !0, !0) : [];
                    }, Dr.dropWhile = function (t, n) {
                      return t && t.length ? li(t, oa(n, 3), !0) : [];
                    }, Dr.fill = function (t, n, r, e) {
                      var a = null == t ? 0 : t.length;
                      return a ? (r && "number" != typeof r && da(t, n, r) && (r = 0, e = a), function (t, n, r, e) {
                        var a = t.length;

                        for ((r = yu(r)) < 0 && (r = -r > a ? 0 : a + r), (e = e === i || e > a ? a : yu(e)) < 0 && (e += a), e = r > e ? 0 : gu(e); r < e;) t[r++] = n;

                        return t;
                      }(t, n, r, e)) : [];
                    }, Dr.filter = function (t, n) {
                      return ($o(t) ? wn : ye)(t, oa(n, 3));
                    }, Dr.flatMap = function (t, n) {
                      return ge(Fo(t, n), 1);
                    }, Dr.flatMapDeep = function (t, n) {
                      return ge(Fo(t, n), f);
                    }, Dr.flatMapDepth = function (t, n, r) {
                      return r = r === i ? 1 : yu(r), ge(Fo(t, n), r);
                    }, Dr.flatten = $a, Dr.flattenDeep = function (t) {
                      return null != t && t.length ? ge(t, f) : [];
                    }, Dr.flattenDepth = function (t, n) {
                      return null != t && t.length ? ge(t, n = n === i ? 1 : yu(n)) : [];
                    }, Dr.flip = function (t) {
                      return Ji(t, 512);
                    }, Dr.flow = rc, Dr.flowRight = ec, Dr.fromPairs = function (t) {
                      for (var n = -1, r = null == t ? 0 : t.length, e = {}; ++n < r;) {
                        var i = t[n];
                        e[i[0]] = i[1];
                      }

                      return e;
                    }, Dr.functions = function (t) {
                      return null == t ? [] : me(t, Pu(t));
                    }, Dr.functionsIn = function (t) {
                      return null == t ? [] : me(t, Ru(t));
                    }, Dr.groupBy = mo, Dr.initial = function (t) {
                      return null != t && t.length ? ni(t, 0, -1) : [];
                    }, Dr.intersection = Za, Dr.intersectionBy = Ha, Dr.intersectionWith = Ja, Dr.invert = Iu, Dr.invertBy = ju, Dr.invokeMap = Ao, Dr.iteratee = ac, Dr.keyBy = wo, Dr.keys = Pu, Dr.keysIn = Ru, Dr.map = Fo, Dr.mapKeys = function (t, n) {
                      var r = {};
                      return n = oa(n, 3), be(t, function (t, e, i) {
                        ie(r, n(t, e, i), t);
                      }), r;
                    }, Dr.mapValues = function (t, n) {
                      var r = {};
                      return n = oa(n, 3), be(t, function (t, e, i) {
                        ie(r, e, n(t, e, i));
                      }), r;
                    }, Dr.matches = function (t) {
                      return Be(ue(t, 1));
                    }, Dr.matchesProperty = function (t, n) {
                      return De(t, ue(n, 1));
                    }, Dr.memoize = Eo, Dr.merge = Lu, Dr.mergeWith = Eu, Dr.method = oc, Dr.methodOf = uc, Dr.mixin = cc, Dr.negate = Mo, Dr.nthArg = function (t) {
                      return t = yu(t), He(function (n) {
                        return qe(n, t);
                      });
                    }, Dr.omit = Mu, Dr.omitBy = function (t, n) {
                      return Bu(t, Mo(oa(n)));
                    }, Dr.once = function (t) {
                      return Io(2, t);
                    }, Dr.orderBy = function (t, n, r, e) {
                      return null == t ? [] : ($o(n) || (n = null == n ? [] : [n]), $o(r = e ? i : r) || (r = null == r ? [] : [r]), ze(t, n, r));
                    }, Dr.over = fc, Dr.overArgs = Uo, Dr.overEvery = lc, Dr.overSome = hc, Dr.partial = Bo, Dr.partialRight = Do, Dr.partition = So, Dr.pick = Uu, Dr.pickBy = Bu, Dr.property = pc, Dr.propertyOf = function (t) {
                      return function (n) {
                        return null == t ? i : Ae(t, n);
                      };
                    }, Dr.pull = Qa, Dr.pullAll = Ya, Dr.pullAllBy = function (t, n, r) {
                      return t && t.length && n && n.length ? Ve(t, n, oa(r, 2)) : t;
                    }, Dr.pullAllWith = function (t, n, r) {
                      return t && t.length && n && n.length ? Ve(t, n, i, r) : t;
                    }, Dr.pullAt = Xa, Dr.range = vc, Dr.rangeRight = yc, Dr.rearg = Wo, Dr.reject = function (t, n) {
                      return ($o(t) ? wn : ye)(t, Mo(oa(n, 3)));
                    }, Dr.remove = function (t, n) {
                      var r = [];
                      if (!t || !t.length) return r;
                      var e = -1,
                          i = [],
                          a = t.length;

                      for (n = oa(n, 3); ++e < a;) {
                        var o = t[e];
                        n(o, e, t) && (r.push(o), i.push(e));
                      }

                      return $e(t, i), r;
                    }, Dr.rest = function (t, n) {
                      if ("function" != typeof t) throw new Ot(a);
                      return He(t, n = n === i ? n : yu(n));
                    }, Dr.reverse = to, Dr.sampleSize = function (t, n, r) {
                      return n = (r ? da(t, n, r) : n === i) ? 1 : yu(n), ($o(t) ? Qr : Ke)(t, n);
                    }, Dr.set = function (t, n, r) {
                      return null == t ? t : Qe(t, n, r);
                    }, Dr.setWith = function (t, n, r, e) {
                      return e = "function" == typeof e ? e : i, null == t ? t : Qe(t, n, r, e);
                    }, Dr.shuffle = function (t) {
                      return ($o(t) ? Yr : ti)(t);
                    }, Dr.slice = function (t, n, r) {
                      var e = null == t ? 0 : t.length;
                      return e ? (r && "number" != typeof r && da(t, n, r) ? (n = 0, r = e) : (n = null == n ? 0 : yu(n), r = r === i ? e : yu(r)), ni(t, n, r)) : [];
                    }, Dr.sortBy = Co, Dr.sortedUniq = function (t) {
                      return t && t.length ? ai(t) : [];
                    }, Dr.sortedUniqBy = function (t, n) {
                      return t && t.length ? ai(t, oa(n, 2)) : [];
                    }, Dr.split = function (t, n, r) {
                      return r && "number" != typeof r && da(t, n, r) && (n = r = i), (r = r === i ? p : r >>> 0) ? (t = bu(t)) && ("string" == typeof n || null != n && !ou(n)) && !(n = ui(n)) && Xn(t) ? bi(or(t), 0, r) : t.split(n, r) : [];
                    }, Dr.spread = function (t, n) {
                      if ("function" != typeof t) throw new Ot(a);
                      return n = null == n ? 0 : dr(yu(n), 0), He(function (r) {
                        var e = r[n],
                            i = bi(r, 0, n);
                        return e && On(i, e), _n(t, this, i);
                      });
                    }, Dr.tail = function (t) {
                      var n = null == t ? 0 : t.length;
                      return n ? ni(t, 1, n) : [];
                    }, Dr.take = function (t, n, r) {
                      return t && t.length ? ni(t, 0, (n = r || n === i ? 1 : yu(n)) < 0 ? 0 : n) : [];
                    }, Dr.takeRight = function (t, n, r) {
                      var e = null == t ? 0 : t.length;
                      return e ? ni(t, (n = e - (n = r || n === i ? 1 : yu(n))) < 0 ? 0 : n, e) : [];
                    }, Dr.takeRightWhile = function (t, n) {
                      return t && t.length ? li(t, oa(n, 3), !1, !0) : [];
                    }, Dr.takeWhile = function (t, n) {
                      return t && t.length ? li(t, oa(n, 3)) : [];
                    }, Dr.tap = function (t, n) {
                      return n(t), t;
                    }, Dr.throttle = function (t, n, r) {
                      var e = !0,
                          i = !0;
                      if ("function" != typeof t) throw new Ot(a);
                      return nu(r) && (e = "leading" in r ? !!r.leading : e, i = "trailing" in r ? !!r.trailing : i), Po(t, n, {
                        leading: e,
                        maxWait: n,
                        trailing: i
                      });
                    }, Dr.thru = po, Dr.toArray = pu, Dr.toPairs = Du, Dr.toPairsIn = Wu, Dr.toPath = function (t) {
                      return $o(t) ? Cn(t, Ua) : su(t) ? [t] : Oi(Ma(bu(t)));
                    }, Dr.toPlainObject = _u, Dr.transform = function (t, n, r) {
                      var e = $o(t),
                          i = e || Jo(t) || fu(t);

                      if (n = oa(n, 4), null == r) {
                        var a = t && t.constructor;
                        r = i ? e ? new a() : [] : nu(t) && Yo(a) ? Wr(Gt(t)) : {};
                      }

                      return (i ? kn : be)(t, function (t, e, i) {
                        return n(r, t, e, i);
                      }), r;
                    }, Dr.unary = function (t) {
                      return xo(t, 1);
                    }, Dr.union = no, Dr.unionBy = ro, Dr.unionWith = eo, Dr.uniq = function (t) {
                      return t && t.length ? ci(t) : [];
                    }, Dr.uniqBy = function (t, n) {
                      return t && t.length ? ci(t, oa(n, 2)) : [];
                    }, Dr.uniqWith = function (t, n) {
                      return n = "function" == typeof n ? n : i, t && t.length ? ci(t, i, n) : [];
                    }, Dr.unset = function (t, n) {
                      return null == t || si(t, n);
                    }, Dr.unzip = io, Dr.unzipWith = ao, Dr.update = function (t, n, r) {
                      return null == t ? t : fi(t, n, gi(r));
                    }, Dr.updateWith = function (t, n, r, e) {
                      return e = "function" == typeof e ? e : i, null == t ? t : fi(t, n, gi(r), e);
                    }, Dr.values = qu, Dr.valuesIn = function (t) {
                      return null == t ? [] : $n(t, Ru(t));
                    }, Dr.without = oo, Dr.words = Yu, Dr.wrap = function (t, n) {
                      return Bo(gi(n), t);
                    }, Dr.xor = uo, Dr.xorBy = co, Dr.xorWith = so, Dr.zip = fo, Dr.zipObject = function (t, n) {
                      return vi(t || [], n || [], te);
                    }, Dr.zipObjectDeep = function (t, n) {
                      return vi(t || [], n || [], Qe);
                    }, Dr.zipWith = lo, Dr.entries = Du, Dr.entriesIn = Wu, Dr.extend = mu, Dr.extendWith = Au, cc(Dr, Dr), Dr.add = bc, Dr.attempt = Xu, Dr.camelCase = zu, Dr.capitalize = Nu, Dr.ceil = kc, Dr.clamp = function (t, n, r) {
                      return r === i && (r = n, n = i), r !== i && (r = (r = du(r)) == r ? r : 0), n !== i && (n = (n = du(n)) == n ? n : 0), oe(du(t), n, r);
                    }, Dr.clone = function (t) {
                      return ue(t, 4);
                    }, Dr.cloneDeep = function (t) {
                      return ue(t, 5);
                    }, Dr.cloneDeepWith = function (t, n) {
                      return ue(t, 5, n = "function" == typeof n ? n : i);
                    }, Dr.cloneWith = function (t, n) {
                      return ue(t, 4, n = "function" == typeof n ? n : i);
                    }, Dr.conformsTo = function (t, n) {
                      return null == n || ce(t, n, Pu(n));
                    }, Dr.deburr = Vu, Dr.defaultTo = function (t, n) {
                      return null == t || t != t ? n : t;
                    }, Dr.divide = mc, Dr.endsWith = function (t, n, r) {
                      t = bu(t), n = ui(n);
                      var e = t.length,
                          a = r = r === i ? e : oe(yu(r), 0, e);
                      return (r -= n.length) >= 0 && t.slice(r, a) == n;
                    }, Dr.eq = qo, Dr.escape = function (t) {
                      return (t = bu(t)) && H.test(t) ? t.replace(G, Qn) : t;
                    }, Dr.escapeRegExp = function (t) {
                      return (t = bu(t)) && rt.test(t) ? t.replace(nt, "\\$&") : t;
                    }, Dr.every = function (t, n, r) {
                      var e = $o(t) ? An : pe;
                      return r && da(t, n, r) && (n = i), e(t, oa(n, 3));
                    }, Dr.find = go, Dr.findIndex = Na, Dr.findKey = function (t, n) {
                      return Pn(t, oa(n, 3), be);
                    }, Dr.findLast = _o, Dr.findLastIndex = Va, Dr.findLastKey = function (t, n) {
                      return Pn(t, oa(n, 3), ke);
                    }, Dr.floor = Ac, Dr.forEach = bo, Dr.forEachRight = ko, Dr.forIn = function (t, n) {
                      return null == t ? t : de(t, oa(n, 3), Ru);
                    }, Dr.forInRight = function (t, n) {
                      return null == t ? t : _e(t, oa(n, 3), Ru);
                    }, Dr.forOwn = function (t, n) {
                      return t && be(t, oa(n, 3));
                    }, Dr.forOwnRight = function (t, n) {
                      return t && ke(t, oa(n, 3));
                    }, Dr.get = Ou, Dr.gt = zo, Dr.gte = No, Dr.has = function (t, n) {
                      return null != t && pa(t, n, Ce);
                    }, Dr.hasIn = xu, Dr.head = Ga, Dr.identity = ic, Dr.includes = function (t, n, r, e) {
                      t = Zo(t) ? t : qu(t), r = r && !e ? yu(r) : 0;
                      var i = t.length;
                      return r < 0 && (r = dr(i + r, 0)), cu(t) ? r <= i && t.indexOf(n, r) > -1 : !!i && Ln(t, n, r) > -1;
                    }, Dr.indexOf = function (t, n, r) {
                      var e = null == t ? 0 : t.length;
                      if (!e) return -1;
                      var i = null == r ? 0 : yu(r);
                      return i < 0 && (i = dr(e + i, 0)), Ln(t, n, i);
                    }, Dr.inRange = function (t, n, r) {
                      return n = vu(n), r === i ? (r = n, n = 0) : r = vu(r), function (t, n, r) {
                        return t >= _r(n, r) && t < dr(n, r);
                      }(t = du(t), n, r);
                    }, Dr.invoke = Tu, Dr.isArguments = Vo, Dr.isArray = $o, Dr.isArrayBuffer = Go, Dr.isArrayLike = Zo, Dr.isArrayLikeObject = Ho, Dr.isBoolean = function (t) {
                      return !0 === t || !1 === t || ru(t) && Fe(t) == d;
                    }, Dr.isBuffer = Jo, Dr.isDate = Ko, Dr.isElement = function (t) {
                      return ru(t) && 1 === t.nodeType && !au(t);
                    }, Dr.isEmpty = function (t) {
                      if (null == t) return !0;
                      if (Zo(t) && ($o(t) || "string" == typeof t || "function" == typeof t.splice || Jo(t) || fu(t) || Vo(t))) return !t.length;
                      var n = ha(t);
                      if (n == A || n == O) return !t.size;
                      if (ma(t)) return !Ee(t).length;

                      for (var r in t) if (Rt.call(t, r)) return !1;

                      return !0;
                    }, Dr.isEqual = function (t, n) {
                      return Te(t, n);
                    }, Dr.isEqualWith = function (t, n, r) {
                      var e = (r = "function" == typeof r ? r : i) ? r(t, n) : i;
                      return e === i ? Te(t, n, i, r) : !!e;
                    }, Dr.isError = Qo, Dr.isFinite = function (t) {
                      return "number" == typeof t && vr(t);
                    }, Dr.isFunction = Yo, Dr.isInteger = Xo, Dr.isLength = tu, Dr.isMap = eu, Dr.isMatch = function (t, n) {
                      return t === n || Pe(t, n, ca(n));
                    }, Dr.isMatchWith = function (t, n, r) {
                      return r = "function" == typeof r ? r : i, Pe(t, n, ca(n), r);
                    }, Dr.isNaN = function (t) {
                      return iu(t) && t != +t;
                    }, Dr.isNative = function (t) {
                      if (ka(t)) throw new mt("Unsupported core-js use. Try https://npms.io/search?q=ponyfill.");
                      return Re(t);
                    }, Dr.isNil = function (t) {
                      return null == t;
                    }, Dr.isNull = function (t) {
                      return null === t;
                    }, Dr.isNumber = iu, Dr.isObject = nu, Dr.isObjectLike = ru, Dr.isPlainObject = au, Dr.isRegExp = ou, Dr.isSafeInteger = function (t) {
                      return Xo(t) && t >= -9007199254740991 && t <= l;
                    }, Dr.isSet = uu, Dr.isString = cu, Dr.isSymbol = su, Dr.isTypedArray = fu, Dr.isUndefined = function (t) {
                      return t === i;
                    }, Dr.isWeakMap = function (t) {
                      return ru(t) && ha(t) == j;
                    }, Dr.isWeakSet = function (t) {
                      return ru(t) && "[object WeakSet]" == Fe(t);
                    }, Dr.join = function (t, n) {
                      return null == t ? "" : yr.call(t, n);
                    }, Dr.kebabCase = $u, Dr.last = Ka, Dr.lastIndexOf = function (t, n, r) {
                      var e = null == t ? 0 : t.length;
                      if (!e) return -1;
                      var a = e;
                      return r !== i && (a = (a = yu(r)) < 0 ? dr(e + a, 0) : _r(a, e - 1)), n == n ? function (t, n, r) {
                        for (var e = r + 1; e--;) if (t[e] === n) return e;

                        return e;
                      }(t, n, a) : Rn(t, Mn, a, !0);
                    }, Dr.lowerCase = Gu, Dr.lowerFirst = Zu, Dr.lt = lu, Dr.lte = hu, Dr.max = function (t) {
                      return t && t.length ? ve(t, ic, Se) : i;
                    }, Dr.maxBy = function (t, n) {
                      return t && t.length ? ve(t, oa(n, 2), Se) : i;
                    }, Dr.mean = function (t) {
                      return Un(t, ic);
                    }, Dr.meanBy = function (t, n) {
                      return Un(t, oa(n, 2));
                    }, Dr.min = function (t) {
                      return t && t.length ? ve(t, ic, Me) : i;
                    }, Dr.minBy = function (t, n) {
                      return t && t.length ? ve(t, oa(n, 2), Me) : i;
                    }, Dr.stubArray = gc, Dr.stubFalse = dc, Dr.stubObject = function () {
                      return {};
                    }, Dr.stubString = function () {
                      return "";
                    }, Dr.stubTrue = function () {
                      return !0;
                    }, Dr.multiply = wc, Dr.nth = function (t, n) {
                      return t && t.length ? qe(t, yu(n)) : i;
                    }, Dr.noConflict = function () {
                      return on._ === this && (on._ = Bt), this;
                    }, Dr.noop = sc, Dr.now = Oo, Dr.pad = function (t, n, r) {
                      t = bu(t);
                      var e = (n = yu(n)) ? ar(t) : 0;
                      if (!n || e >= n) return t;
                      var i = (n - e) / 2;
                      return zi(lr(i), r) + t + zi(fr(i), r);
                    }, Dr.padEnd = function (t, n, r) {
                      t = bu(t);
                      var e = (n = yu(n)) ? ar(t) : 0;
                      return n && e < n ? t + zi(n - e, r) : t;
                    }, Dr.padStart = function (t, n, r) {
                      t = bu(t);
                      var e = (n = yu(n)) ? ar(t) : 0;
                      return n && e < n ? zi(n - e, r) + t : t;
                    }, Dr.parseInt = function (t, n, r) {
                      return r || null == n ? n = 0 : n && (n = +n), kr(bu(t).replace(et, ""), n || 0);
                    }, Dr.random = function (t, n, r) {
                      if (r && "boolean" != typeof r && da(t, n, r) && (n = r = i), r === i && ("boolean" == typeof n ? (r = n, n = i) : "boolean" == typeof t && (r = t, t = i)), t === i && n === i ? (t = 0, n = 1) : (t = vu(t), n === i ? (n = t, t = 0) : n = vu(n)), t > n) {
                        var e = t;
                        t = n, n = e;
                      }

                      if (r || t % 1 || n % 1) {
                        var a = mr();
                        return _r(t + a * (n - t + nn("1e-" + ((a + "").length - 1))), n);
                      }

                      return Ge(t, n);
                    }, Dr.reduce = function (t, n, r) {
                      var e = $o(t) ? xn : Wn,
                          i = arguments.length < 3;
                      return e(t, oa(n, 4), r, i, le);
                    }, Dr.reduceRight = function (t, n, r) {
                      var e = $o(t) ? In : Wn,
                          i = arguments.length < 3;
                      return e(t, oa(n, 4), r, i, he);
                    }, Dr.repeat = function (t, n, r) {
                      return n = (r ? da(t, n, r) : n === i) ? 1 : yu(n), Ze(bu(t), n);
                    }, Dr.replace = function () {
                      var t = arguments,
                          n = bu(t[0]);
                      return t.length < 3 ? n : n.replace(t[1], t[2]);
                    }, Dr.result = function (t, n, r) {
                      var e = -1,
                          a = (n = di(n, t)).length;

                      for (a || (a = 1, t = i); ++e < a;) {
                        var o = null == t ? i : t[Ua(n[e])];
                        o === i && (e = a, o = r), t = Yo(o) ? o.call(t) : o;
                      }

                      return t;
                    }, Dr.round = Fc, Dr.runInContext = t, Dr.sample = function (t) {
                      return ($o(t) ? Kr : Je)(t);
                    }, Dr.size = function (t) {
                      if (null == t) return 0;
                      if (Zo(t)) return cu(t) ? ar(t) : t.length;
                      var n = ha(t);
                      return n == A || n == O ? t.size : Ee(t).length;
                    }, Dr.snakeCase = Hu, Dr.some = function (t, n, r) {
                      var e = $o(t) ? jn : ri;
                      return r && da(t, n, r) && (n = i), e(t, oa(n, 3));
                    }, Dr.sortedIndex = function (t, n) {
                      return ei(t, n);
                    }, Dr.sortedIndexBy = function (t, n, r) {
                      return ii(t, n, oa(r, 2));
                    }, Dr.sortedIndexOf = function (t, n) {
                      var r = null == t ? 0 : t.length;

                      if (r) {
                        var e = ei(t, n);
                        if (e < r && qo(t[e], n)) return e;
                      }

                      return -1;
                    }, Dr.sortedLastIndex = function (t, n) {
                      return ei(t, n, !0);
                    }, Dr.sortedLastIndexBy = function (t, n, r) {
                      return ii(t, n, oa(r, 2), !0);
                    }, Dr.sortedLastIndexOf = function (t, n) {
                      if (null != t && t.length) {
                        var r = ei(t, n, !0) - 1;
                        if (qo(t[r], n)) return r;
                      }

                      return -1;
                    }, Dr.startCase = Ju, Dr.startsWith = function (t, n, r) {
                      return t = bu(t), r = null == r ? 0 : oe(yu(r), 0, t.length), n = ui(n), t.slice(r, r + n.length) == n;
                    }, Dr.subtract = Sc, Dr.sum = function (t) {
                      return t && t.length ? qn(t, ic) : 0;
                    }, Dr.sumBy = function (t, n) {
                      return t && t.length ? qn(t, oa(n, 2)) : 0;
                    }, Dr.template = function (t, n, r) {
                      var e = Dr.templateSettings;
                      r && da(t, n, r) && (n = i), t = bu(t), n = Au({}, n, e, Ki);
                      var a,
                          o,
                          u = Au({}, n.imports, e.imports, Ki),
                          c = Pu(u),
                          s = $n(u, c),
                          f = 0,
                          l = n.interpolate || bt,
                          h = "__p += '",
                          p = St((n.escape || bt).source + "|" + l.source + "|" + (l === Q ? lt : bt).source + "|" + (n.evaluate || bt).source + "|$", "g"),
                          v = "//# sourceURL=" + (Rt.call(n, "sourceURL") ? (n.sourceURL + "").replace(/\s/g, " ") : "lodash.templateSources[" + ++Qt + "]") + "\n";
                      t.replace(p, function (n, r, e, i, u, c) {
                        return e || (e = i), h += t.slice(f, c).replace(kt, Yn), r && (a = !0, h += "' +\n__e(" + r + ") +\n'"), u && (o = !0, h += "';\n" + u + ";\n__p += '"), e && (h += "' +\n((__t = (" + e + ")) == null ? '' : __t) +\n'"), f = c + n.length, n;
                      }), h += "';\n";
                      var y = Rt.call(n, "variable") && n.variable;

                      if (y) {
                        if (st.test(y)) throw new mt("Invalid `variable` option passed into `_.template`");
                      } else h = "with (obj) {\n" + h + "\n}\n";

                      h = (o ? h.replace(z, "") : h).replace(N, "$1").replace(V, "$1;"), h = "function(" + (y || "obj") + ") {\n" + (y ? "" : "obj || (obj = {});\n") + "var __t, __p = ''" + (a ? ", __e = _.escape" : "") + (o ? ", __j = Array.prototype.join;\nfunction print() { __p += __j.call(arguments, '') }\n" : ";\n") + h + "return __p\n}";
                      var g = Xu(function () {
                        return At(c, v + "return " + h).apply(i, s);
                      });
                      if (g.source = h, Qo(g)) throw g;
                      return g;
                    }, Dr.times = function (t, n) {
                      if ((t = yu(t)) < 1 || t > l) return [];

                      var r = p,
                          e = _r(t, p);

                      n = oa(n), t -= p;

                      for (var i = zn(e, n); ++r < t;) n(r);

                      return i;
                    }, Dr.toFinite = vu, Dr.toInteger = yu, Dr.toLength = gu, Dr.toLower = function (t) {
                      return bu(t).toLowerCase();
                    }, Dr.toNumber = du, Dr.toSafeInteger = function (t) {
                      return t ? oe(yu(t), -9007199254740991, l) : 0 === t ? t : 0;
                    }, Dr.toString = bu, Dr.toUpper = function (t) {
                      return bu(t).toUpperCase();
                    }, Dr.trim = function (t, n, r) {
                      if ((t = bu(t)) && (r || n === i)) return Nn(t);
                      if (!t || !(n = ui(n))) return t;
                      var e = or(t),
                          a = or(n);
                      return bi(e, Zn(e, a), Hn(e, a) + 1).join("");
                    }, Dr.trimEnd = function (t, n, r) {
                      if ((t = bu(t)) && (r || n === i)) return t.slice(0, ur(t) + 1);
                      if (!t || !(n = ui(n))) return t;
                      var e = or(t);
                      return bi(e, 0, Hn(e, or(n)) + 1).join("");
                    }, Dr.trimStart = function (t, n, r) {
                      if ((t = bu(t)) && (r || n === i)) return t.replace(et, "");
                      if (!t || !(n = ui(n))) return t;
                      var e = or(t);
                      return bi(e, Zn(e, or(n))).join("");
                    }, Dr.truncate = function (t, n) {
                      var r = 30,
                          e = "...";

                      if (nu(n)) {
                        var a = "separator" in n ? n.separator : a;
                        r = "length" in n ? yu(n.length) : r, e = "omission" in n ? ui(n.omission) : e;
                      }

                      var o = (t = bu(t)).length;

                      if (Xn(t)) {
                        var u = or(t);
                        o = u.length;
                      }

                      if (r >= o) return t;
                      var c = r - ar(e);
                      if (c < 1) return e;
                      var s = u ? bi(u, 0, c).join("") : t.slice(0, c);
                      if (a === i) return s + e;

                      if (u && (c += s.length - c), ou(a)) {
                        if (t.slice(c).search(a)) {
                          var f,
                              l = s;

                          for (a.global || (a = St(a.source, bu(ht.exec(a)) + "g")), a.lastIndex = 0; f = a.exec(l);) var h = f.index;

                          s = s.slice(0, h === i ? c : h);
                        }
                      } else if (t.indexOf(ui(a), c) != c) {
                        var p = s.lastIndexOf(a);
                        p > -1 && (s = s.slice(0, p));
                      }

                      return s + e;
                    }, Dr.unescape = function (t) {
                      return (t = bu(t)) && Z.test(t) ? t.replace($, cr) : t;
                    }, Dr.uniqueId = function (t) {
                      var n = ++Lt;
                      return bu(t) + n;
                    }, Dr.upperCase = Ku, Dr.upperFirst = Qu, Dr.each = bo, Dr.eachRight = ko, Dr.first = Ga, cc(Dr, (_c = {}, be(Dr, function (t, n) {
                      Rt.call(Dr.prototype, n) || (_c[n] = t);
                    }), _c), {
                      chain: !1
                    }), Dr.VERSION = "4.17.21", kn(["bind", "bindKey", "curry", "curryRight", "partial", "partialRight"], function (t) {
                      Dr[t].placeholder = Dr;
                    }), kn(["drop", "take"], function (t, n) {
                      Nr.prototype[t] = function (r) {
                        r = r === i ? 1 : dr(yu(r), 0);
                        var e = this.__filtered__ && !n ? new Nr(this) : this.clone();
                        return e.__filtered__ ? e.__takeCount__ = _r(r, e.__takeCount__) : e.__views__.push({
                          size: _r(r, p),
                          type: t + (e.__dir__ < 0 ? "Right" : "")
                        }), e;
                      }, Nr.prototype[t + "Right"] = function (n) {
                        return this.reverse()[t](n).reverse();
                      };
                    }), kn(["filter", "map", "takeWhile"], function (t, n) {
                      var r = n + 1,
                          e = 1 == r || 3 == r;

                      Nr.prototype[t] = function (t) {
                        var n = this.clone();
                        return n.__iteratees__.push({
                          iteratee: oa(t, 3),
                          type: r
                        }), n.__filtered__ = n.__filtered__ || e, n;
                      };
                    }), kn(["head", "last"], function (t, n) {
                      var r = "take" + (n ? "Right" : "");

                      Nr.prototype[t] = function () {
                        return this[r](1).value()[0];
                      };
                    }), kn(["initial", "tail"], function (t, n) {
                      var r = "drop" + (n ? "" : "Right");

                      Nr.prototype[t] = function () {
                        return this.__filtered__ ? new Nr(this) : this[r](1);
                      };
                    }), Nr.prototype.compact = function () {
                      return this.filter(ic);
                    }, Nr.prototype.find = function (t) {
                      return this.filter(t).head();
                    }, Nr.prototype.findLast = function (t) {
                      return this.reverse().find(t);
                    }, Nr.prototype.invokeMap = He(function (t, n) {
                      return "function" == typeof t ? new Nr(this) : this.map(function (r) {
                        return Ie(r, t, n);
                      });
                    }), Nr.prototype.reject = function (t) {
                      return this.filter(Mo(oa(t)));
                    }, Nr.prototype.slice = function (t, n) {
                      t = yu(t);
                      var r = this;
                      return r.__filtered__ && (t > 0 || n < 0) ? new Nr(r) : (t < 0 ? r = r.takeRight(-t) : t && (r = r.drop(t)), n !== i && (r = (n = yu(n)) < 0 ? r.dropRight(-n) : r.take(n - t)), r);
                    }, Nr.prototype.takeRightWhile = function (t) {
                      return this.reverse().takeWhile(t).reverse();
                    }, Nr.prototype.toArray = function () {
                      return this.take(p);
                    }, be(Nr.prototype, function (t, n) {
                      var r = /^(?:filter|find|map|reject)|While$/.test(n),
                          e = /^(?:head|last)$/.test(n),
                          a = Dr[e ? "take" + ("last" == n ? "Right" : "") : n],
                          o = e || /^find/.test(n);
                      a && (Dr.prototype[n] = function () {
                        var n = this.__wrapped__,
                            u = e ? [1] : arguments,
                            c = n instanceof Nr,
                            s = u[0],
                            f = c || $o(n),
                            l = function (t) {
                          var n = a.apply(Dr, On([t], u));
                          return e && h ? n[0] : n;
                        };

                        f && r && "function" == typeof s && 1 != s.length && (c = f = !1);
                        var h = this.__chain__,
                            p = !!this.__actions__.length,
                            v = o && !h,
                            y = c && !p;

                        if (!o && f) {
                          n = y ? n : new Nr(this);
                          var g = t.apply(n, u);
                          return g.__actions__.push({
                            func: po,
                            args: [l],
                            thisArg: i
                          }), new zr(g, h);
                        }

                        return v && y ? t.apply(this, u) : (g = this.thru(l), v ? e ? g.value()[0] : g.value() : g);
                      });
                    }), kn(["pop", "push", "shift", "sort", "splice", "unshift"], function (t) {
                      var n = xt[t],
                          r = /^(?:push|sort|unshift)$/.test(t) ? "tap" : "thru",
                          e = /^(?:pop|shift)$/.test(t);

                      Dr.prototype[t] = function () {
                        var t = arguments;

                        if (e && !this.__chain__) {
                          var i = this.value();
                          return n.apply($o(i) ? i : [], t);
                        }

                        return this[r](function (r) {
                          return n.apply($o(r) ? r : [], t);
                        });
                      };
                    }), be(Nr.prototype, function (t, n) {
                      var r = Dr[n];

                      if (r) {
                        var e = r.name + "";
                        Rt.call(jr, e) || (jr[e] = []), jr[e].push({
                          name: n,
                          func: r
                        });
                      }
                    }), jr[Bi(i, 2).name] = [{
                      name: "wrapper",
                      func: i
                    }], Nr.prototype.clone = function () {
                      var t = new Nr(this.__wrapped__);
                      return t.__actions__ = Oi(this.__actions__), t.__dir__ = this.__dir__, t.__filtered__ = this.__filtered__, t.__iteratees__ = Oi(this.__iteratees__), t.__takeCount__ = this.__takeCount__, t.__views__ = Oi(this.__views__), t;
                    }, Nr.prototype.reverse = function () {
                      if (this.__filtered__) {
                        var t = new Nr(this);
                        t.__dir__ = -1, t.__filtered__ = !0;
                      } else (t = this.clone()).__dir__ *= -1;

                      return t;
                    }, Nr.prototype.value = function () {
                      var t = this.__wrapped__.value(),
                          n = this.__dir__,
                          r = $o(t),
                          e = n < 0,
                          i = r ? t.length : 0,
                          a = function (t, n, r) {
                        for (var e = -1, i = r.length; ++e < i;) {
                          var a = r[e],
                              o = a.size;

                          switch (a.type) {
                            case "drop":
                              t += o;
                              break;

                            case "dropRight":
                              n -= o;
                              break;

                            case "take":
                              n = _r(n, t + o);
                              break;

                            case "takeRight":
                              t = dr(t, n - o);
                          }
                        }

                        return {
                          start: t,
                          end: n
                        };
                      }(0, i, this.__views__),
                          o = a.start,
                          u = a.end,
                          c = u - o,
                          s = e ? u : o - 1,
                          f = this.__iteratees__,
                          l = f.length,
                          h = 0,
                          p = _r(c, this.__takeCount__);

                      if (!r || !e && i == c && p == c) return hi(t, this.__actions__);
                      var v = [];

                      t: for (; c-- && h < p;) {
                        for (var y = -1, g = t[s += n]; ++y < l;) {
                          var d = f[y],
                              _ = d.iteratee,
                              b = d.type,
                              k = _(g);

                          if (2 == b) g = k;else if (!k) {
                            if (1 == b) continue t;
                            break t;
                          }
                        }

                        v[h++] = g;
                      }

                      return v;
                    }, Dr.prototype.at = vo, Dr.prototype.chain = function () {
                      return ho(this);
                    }, Dr.prototype.commit = function () {
                      return new zr(this.value(), this.__chain__);
                    }, Dr.prototype.next = function () {
                      this.__values__ === i && (this.__values__ = pu(this.value()));
                      var t = this.__index__ >= this.__values__.length;
                      return {
                        done: t,
                        value: t ? i : this.__values__[this.__index__++]
                      };
                    }, Dr.prototype.plant = function (t) {
                      for (var n, r = this; r instanceof qr;) {
                        var e = Da(r);
                        e.__index__ = 0, e.__values__ = i, n ? a.__wrapped__ = e : n = e;
                        var a = e;
                        r = r.__wrapped__;
                      }

                      return a.__wrapped__ = t, n;
                    }, Dr.prototype.reverse = function () {
                      var t = this.__wrapped__;

                      if (t instanceof Nr) {
                        var n = t;
                        return this.__actions__.length && (n = new Nr(this)), (n = n.reverse()).__actions__.push({
                          func: po,
                          args: [to],
                          thisArg: i
                        }), new zr(n, this.__chain__);
                      }

                      return this.thru(to);
                    }, Dr.prototype.toJSON = Dr.prototype.valueOf = Dr.prototype.value = function () {
                      return hi(this.__wrapped__, this.__actions__);
                    }, Dr.prototype.first = Dr.prototype.head, un && (Dr.prototype[un] = function () {
                      return this;
                    }), Dr;
                  }();

                  on._ = sr, (e = function () {
                    return sr;
                  }.call(n, r, n, t)) === i || (t.exports = e);
                }.call(this);
              },
              654: (t, n, r) => {
                var e = r(379),
                    i = r(426);
                "string" == typeof (i = i.__esModule ? i.default : i) && (i = [[t.id, i, ""]]);
                e(i, {
                  insert: "head",
                  singleton: !1
                }), t.exports = i.locals || {};
              },
              379: (t, n, r) => {
                var e,
                    i = function () {
                  var t = {};
                  return function (n) {
                    if (void 0 === t[n]) {
                      var r = document.querySelector(n);
                      if (window.HTMLIFrameElement && r instanceof window.HTMLIFrameElement) try {
                        r = r.contentDocument.head;
                      } catch (t) {
                        r = null;
                      }
                      t[n] = r;
                    }

                    return t[n];
                  };
                }(),
                    a = [];

                function o(t) {
                  for (var n = -1, r = 0; r < a.length; r++) if (a[r].identifier === t) {
                    n = r;
                    break;
                  }

                  return n;
                }

                function u(t, n) {
                  for (var r = {}, e = [], i = 0; i < t.length; i++) {
                    var u = t[i],
                        c = n.base ? u[0] + n.base : u[0],
                        s = r[c] || 0,
                        f = "".concat(c, " ").concat(s);
                    r[c] = s + 1;
                    var l = o(f),
                        h = {
                      css: u[1],
                      media: u[2],
                      sourceMap: u[3]
                    };
                    -1 !== l ? (a[l].references++, a[l].updater(h)) : a.push({
                      identifier: f,
                      updater: y(h, n),
                      references: 1
                    }), e.push(f);
                  }

                  return e;
                }

                function c(t) {
                  var n = document.createElement("style"),
                      e = t.attributes || {};

                  if (void 0 === e.nonce) {
                    var a = r.nc;
                    a && (e.nonce = a);
                  }

                  if (Object.keys(e).forEach(function (t) {
                    n.setAttribute(t, e[t]);
                  }), "function" == typeof t.insert) t.insert(n);else {
                    var o = i(t.insert || "head");
                    if (!o) throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
                    o.appendChild(n);
                  }
                  return n;
                }

                var s,
                    f = (s = [], function (t, n) {
                  return s[t] = n, s.filter(Boolean).join("\n");
                });

                function l(t, n, r, e) {
                  var i = r ? "" : e.media ? "@media ".concat(e.media, " {").concat(e.css, "}") : e.css;
                  if (t.styleSheet) t.styleSheet.cssText = f(n, i);else {
                    var a = document.createTextNode(i),
                        o = t.childNodes;
                    o[n] && t.removeChild(o[n]), o.length ? t.insertBefore(a, o[n]) : t.appendChild(a);
                  }
                }

                function h(t, n, r) {
                  var e = r.css,
                      i = r.media,
                      a = r.sourceMap;
                  if (i ? t.setAttribute("media", i) : t.removeAttribute("media"), a && "undefined" != typeof btoa && (e += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(a)))), " */")), t.styleSheet) t.styleSheet.cssText = e;else {
                    for (; t.firstChild;) t.removeChild(t.firstChild);

                    t.appendChild(document.createTextNode(e));
                  }
                }

                var p = null,
                    v = 0;

                function y(t, n) {
                  var r, e, i;

                  if (n.singleton) {
                    var a = v++;
                    r = p || (p = c(n)), e = l.bind(null, r, a, !1), i = l.bind(null, r, a, !0);
                  } else r = c(n), e = h.bind(null, r, n), i = function () {
                    !function (t) {
                      if (null === t.parentNode) return !1;
                      t.parentNode.removeChild(t);
                    }(r);
                  };

                  return e(t), function (n) {
                    if (n) {
                      if (n.css === t.css && n.media === t.media && n.sourceMap === t.sourceMap) return;
                      e(t = n);
                    } else i();
                  };
                }

                t.exports = function (t, n) {
                  (n = n || {}).singleton || "boolean" == typeof n.singleton || (n.singleton = (void 0 === e && (e = Boolean(window && document && document.all && !window.atob)), e));
                  var r = u(t = t || [], n);
                  return function (t) {
                    if (t = t || [], "[object Array]" === Object.prototype.toString.call(t)) {
                      for (var e = 0; e < r.length; e++) {
                        var i = o(r[e]);
                        a[i].references--;
                      }

                      for (var c = u(t, n), s = 0; s < r.length; s++) {
                        var f = o(r[s]);
                        0 === a[f].references && (a[f].updater(), a.splice(f, 1));
                      }

                      r = c;
                    }
                  };
                };
              },
              138: (t, n, r) => {
                r.d(n, {
                  Z: () => a
                }), r(486), r(654);
                var e = r(802);
                console.warn("Production mode, console cleared");

                class i {
                  constructor() {}

                  MainGameClosure() {
                    e.Z.init({
                      appId: "vn.momo.lixi2022",
                      name: "vn.momo.lixi2022",
                      displayName: "Lì xì 2022",
                      client: {
                        ios: {
                          installMode: "NORMAL",
                          deploymentTarget: 1
                        },
                        android: {
                          installMode: "NORMAL",
                          deploymentTarget: 1
                        }
                      },
                      uploadToken: "U2FsdGVkX1/+gROElA3KuMeC1dgqo+9NwI5bVORXII41cu1ZCtsLzUmMBJ30fuP5bJp+wW/hSyDhjHpOvElOzTUfDLAOtDFnmnFLkNgjw0Y=",
                      configuration_version: 1
                    }), window.addEventListener("getUserProfile", function () {
                      e.Z.getProfile(t => {
                        const n = new CustomEvent("userProfileRes", {
                          detail: t
                        });
                        window.dispatchEvent(n);
                      });
                    }), window.addEventListener("getAvatarEndPoint", function (t) {
                      const n = t.detail;
                      e.Z.getContactAvatar(n, t => {
                        const n = new CustomEvent("AvatarEndPointRes", {
                          detail: t
                        });
                        window.dispatchEvent(n);
                      });
                    }), window.addEventListener("ExitGame", function () {
                      console.log("exit game"), e.Z.dismiss();
                    }), window.addEventListener("message", function (t) {
                      if (console.log(">>>" + t), t && t.data && "backPress" == t.data) {
                        const t = new CustomEvent("BackKeyPressed", {});
                        window.dispatchEvent(t);
                      }
                    });
                  }

                  OnReady() {
                    this.MainGameClosure();
                  }

                }

                window.Index = i, window.MaxApi = e.Z;
                const a = i;
              },
              285: t => {
                t.exports = JSON.parse('{"name":"@momo-api","apiVersion":64}');
              }
            },
                n = {};

            function r(e) {
              var i = n[e];
              if (void 0 !== i) return i.exports;
              var a = n[e] = {
                id: e,
                loaded: !1,
                exports: {}
              };
              return t[e].call(a.exports, a, a.exports, r), a.loaded = !0, a.exports;
            }

            r.n = t => {
              var n = t && t.__esModule ? () => t.default : () => t;
              return r.d(n, {
                a: n
              }), n;
            }, r.d = (t, n) => {
              for (var e in n) r.o(n, e) && !r.o(t, e) && Object.defineProperty(t, e, {
                enumerable: !0,
                get: n[e]
              });
            }, r.g = function () {
              if ("object" == typeof globalThis) return globalThis;

              try {
                return this || new Function("return this")();
              } catch (t) {
                if ("object" == typeof window) return window;
              }
            }(), r.o = (t, n) => Object.prototype.hasOwnProperty.call(t, n), r.nmd = t => (t.paths = [], t.children || (t.children = []), t), new (r(138).Z)().OnReady(), window.addEventListener("resize", t => {
              document.getElementById("canvasContainer");
            }, !1);
          })();
        })();

        _cjsExports = exports('default', module.exports);
      });

      const __cjsMetaURL = exports('__cjsMetaURL', module.meta.url);
    }
  };
});

System.register("chunks:///_virtual/Rotation.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, CCFloat, Vec3, _decorator, Component, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      CCFloat = module.CCFloat;
      Vec3 = module.Vec3;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "eddd4lxbtdOHrEJO75AcVdI", "Rotation", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      /**
       * Author = vhung.it
       *
       */

      let Rotation = exports('Rotation', (_dec = ccclass('Rotation'), _dec2 = property(CCFloat), _dec3 = property(Vec3), _dec(_class = (_class2 = (_temp = class Rotation extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "speed", _descriptor, this);

          _initializerDefineProperty(this, "direction", _descriptor2, this);

          _defineProperty(this, "eulerAngle", new Vec3());
        }

        start() {}

        update(dt) {
          this.eulerAngle.add(this.direction.normalize().multiplyScalar(this.speed * dt));
          this.node.eulerAngles = this.eulerAngle;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 100;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "direction", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3(0, 0, 1);
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Leaderboard.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './MaxApiUtils.ts', './Profile.ts', './Screen.ts', './TextDefine.ts', './TrackingMgr.ts', './MessageBox.ts', './GameApi.ts', './GameMgr.ts', './LeaderboardTopCell.ts', './LeaderboardCell.ts'], function (exports) {
  'use strict';

  var cclegacy, UITransform, Prefab, Node, ScrollView, SpriteFrame, Toggle, _decorator, instantiate, Layout, Vec3, _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, GameDefine, RankingType, Utils, MaxApiUtils, Profile, Screen, Text, TrackingMgr, MessageBox, GameApi, GameMgr, LeaderboardTopCell, LeaderboardCell;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      UITransform = module.UITransform;
      Prefab = module.Prefab;
      Node = module.Node;
      ScrollView = module.ScrollView;
      SpriteFrame = module.SpriteFrame;
      Toggle = module.Toggle;
      _decorator = module._decorator;
      instantiate = module.instantiate;
      Layout = module.Layout;
      Vec3 = module.Vec3;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      GameDefine = module.GameDefine;
      RankingType = module.RankingType;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      Screen = module.Screen;
    }, function (module) {
      Text = module.Text;
    }, function (module) {
      TrackingMgr = module.TrackingMgr;
    }, function (module) {
      MessageBox = module.MessageBox;
    }, function (module) {
      GameApi = module.GameApi;
    }, function (module) {
      GameMgr = module.GameMgr;
    }, function (module) {
      LeaderboardTopCell = module.LeaderboardTopCell;
    }, function (module) {
      LeaderboardCell = module.LeaderboardCell;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _temp;

      cclegacy._RF.push({}, "ef8cbAOdyFA9YwE1EkvW7ky", "Leaderboard", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      var ScrollViewEvent;

      (function (ScrollViewEvent) {
        ScrollViewEvent[ScrollViewEvent["scrolling"] = 4] = "scrolling";
        ScrollViewEvent[ScrollViewEvent["ScrollEnded"] = 9] = "ScrollEnded";
      })(ScrollViewEvent || (ScrollViewEvent = {}));

      let Leaderboard = exports('Leaderboard', (_dec = ccclass('Leaderboard'), _dec2 = property(UITransform), _dec3 = property(Prefab), _dec4 = property(Prefab), _dec5 = property(Node), _dec6 = property(Node), _dec7 = property(Node), _dec8 = property(ScrollView), _dec9 = property(SpriteFrame), _dec10 = property(Toggle), _dec11 = property(Node), _dec12 = property(Node), _dec13 = property(Node), _dec(_class = (_class2 = (_temp = class Leaderboard extends Screen {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "content", _descriptor, this);

          _initializerDefineProperty(this, "cellTemplate", _descriptor2, this);

          _initializerDefineProperty(this, "topCellTemplate", _descriptor3, this);

          _initializerDefineProperty(this, "topRankContainer", _descriptor4, this);

          _initializerDefineProperty(this, "backBtn", _descriptor5, this);

          _initializerDefineProperty(this, "loadingIcon", _descriptor6, this);

          _initializerDefineProperty(this, "scrollView", _descriptor7, this);

          _initializerDefineProperty(this, "defaultAvatar", _descriptor8, this);

          _initializerDefineProperty(this, "friendToogle", _descriptor9, this);

          _initializerDefineProperty(this, "mineLeaderboardCell", _descriptor10, this);

          _initializerDefineProperty(this, "bannerSprite", _descriptor11, this);

          _initializerDefineProperty(this, "banner", _descriptor12, this);

          _defineProperty(this, "mineCellIndex", -1);

          _defineProperty(this, "cellList", []);

          _defineProperty(this, "isLoading", false);

          _defineProperty(this, "items", []);

          _defineProperty(this, "model", Object.create(null));

          _defineProperty(this, "isFriendOnly", false);

          _defineProperty(this, "heightCell", 96);

          _defineProperty(this, "bannerLink", "https://img.mservice.com.vn/momo_app_v2/img/1029x342_ingame1.jpg");

          _defineProperty(this, "eventLink", "https://momo.vn/tin-tuc/khuyen-mai/cung-tiger-platinum-mo-momo-jump-san-ngay-tien-mat-2558");
        }

        onLoad() {
          for (let i = 0; i < GameDefine.RANKING_LIMIT; i++) {
            let nodeItem = instantiate(this.cellTemplate);
            this.items.push(nodeItem);
          }

          this.backBtn.on("click", this.OnBackClick.bind(this));
          this.friendToogle.node.on(Toggle.EventType.TOGGLE, this.onCheckFriend.bind(this));
          this.banner.on("click", this.OnOpenBanner.bind(this));
          this.friendToogle.isChecked = false;
          Utils.setInfoMySprite(this.bannerSprite, this.bannerLink);
        }

        Show() {
          Profile.Instance.SetNormalFps();
          super.Show();
          this.isFriendOnly = this.friendToogle.isChecked;
          this.refreshRanking();
          TrackingMgr.Instance.ShowSucessLeaderBoardDetail();
        }

        refreshRanking() {
          const self = this;

          if (!self.isLoading) {
            self.isLoading = true;
            self.loadingIcon.active = true;
            self.friendToogle.interactable = false;
            self.fetch(resp => {
              if (!resp || !resp.response_info || resp.response_info.error_code !== 0) {
                let msgBox = MessageBox.Show(Text.ConnectError, Text.NetworkError, "", () => {}, 1);
                msgBox === null || msgBox === void 0 ? void 0 : msgBox.SetTypeOk(Text.Retry, () => {
                  self.refreshRanking();
                });
              } else {
                self.loadModel(resp);
              }

              self.isLoading = false;
              self.friendToogle.interactable = true;
              self.loadingIcon.active = false;
            });
          }
        }

        OnBackClick() {
          this.Hide();

          if (GameMgr.Instance.IsEndGame) {
            GameMgr.Instance.Retry();
          }
        }

        OnOpenBanner() {
          MaxApiUtils.openWeb(this.eventLink);
        }

        onCheckFriend(event) {
          if (this.isFriendOnly == this.friendToogle.isChecked) return;
          this.isFriendOnly = this.friendToogle.isChecked;
          this.refreshRanking();
        }

        fetch(callback) {
          const self = this;
          let type = self.isFriendOnly ? RankingType.FriendWeekly : RankingType.GlobleWeekly;

          switch (type) {
            case RankingType.FriendWeekly:
              GameApi.getRankFriendWeekly(callback);
              break;

            case RankingType.GlobleWeekly:
            default:
              GameApi.getRankGlobleWeekly(callback);
              break;
          }
        }

        loadModel(data) {
          if (this.model != data) {
            this.model = data;
            this.cellList = [];
            this.mineCellIndex = -1;
            this.topRankContainer.removeAllChildren();
            this.mineLeaderboardCell.removeAllChildren();
            this.content.node.removeAllChildren();
            this.content.getComponent(Layout).enabled = true;
            this.content.getComponent(Layout).updateLayout();
            const topRank = 3;

            for (let i = 0, size = data.items.length; i < size; i++) {
              if (i < topRank && data.items[i].rank <= topRank) {
                this.loadViewTopRank(data.items[i], i + 1);
              } else {
                let nodeItem = this.items[i];
                nodeItem.active = true;
                this.content.node.addChild(nodeItem);
                let item = nodeItem.getComponent(LeaderboardCell);
                this.cellList.push(item);
                item.loadView(data.items[i]); //layout pin minecell if it in top 100

                if (this.mineCellIndex < 0 && Profile.Instance.isMine(data.items[i].userId)) {
                  this.mineCellIndex = i - topRank;
                  item.layoutMineCell();
                  this.loadViewMineLeaderCell(data.items[i]);
                }
              }
            }

            this.content.getComponent(Layout).updateLayout();
            this.content.getComponent(Layout).enabled = false; //layout pin minecell if it out of top 100

            if (this.mineCellIndex < 0 && data.meta.rank < 0) {
              this.loadViewMineLeaderCell(data.meta);
            }

            if (this.cellList.length > 0) {
              this.heightCell = this.cellList[0].rect.contentSize.y;
            }

            this.onScroll(this.scrollView, ScrollViewEvent.scrolling);
            this.onScroll(this.scrollView, ScrollViewEvent.ScrollEnded);
          }
        }

        loadViewMineLeaderCell(data) {
          const nodeItem = instantiate(this.cellTemplate);
          this.mineLeaderboardCell.addChild(nodeItem);
          nodeItem.setPosition(new Vec3(0, 0, 0));
          const item = nodeItem.getComponent(LeaderboardCell);
          item.loadView(data);
          item.loadAvatar();
          item.layoutMineCell();
        }

        loadViewTopRank(data, rank) {
          const topCell = instantiate(this.topCellTemplate);
          this.topRankContainer.addChild(topCell);
          const leaderboardTopCellComp = topCell.getComponent(LeaderboardTopCell);
          leaderboardTopCellComp.loadView(data, rank);
        }

        onScroll(scrollView = null, event = null) {
          if (scrollView) {
            switch (event) {
              case ScrollViewEvent.ScrollEnded:
                this.onScrollEnded(scrollView);
                break;

              case ScrollViewEvent.scrolling:
                this.onScrolling(scrollView);
                break;
            }
          }
        }

        onScrolling(scrollView) {
          let scrollViewHeight = scrollView.view.height;
          let itemHeight = this.heightCell + this.content.getComponent(Layout).spacingY;
          let topPos = scrollView.getScrollOffset().y;
          let topIndex = Math.max(0, Math.floor(topPos / itemHeight));
          let numberItemShow = Math.ceil(scrollViewHeight / itemHeight);

          if (this.mineCellIndex >= topIndex && this.mineCellIndex < topIndex + numberItemShow) {
            this.mineLeaderboardCell.active = false;
          } else {
            this.mineLeaderboardCell.active = true;
          }

          this.content.node.children.forEach((element, index) => {
            if (index < topIndex || index >= topIndex + numberItemShow) {
              element.active = false;
            } else {
              element.active = true;
            }
          });
        }

        onScrollEnded(scrollView) {
          this.content.node.children.forEach((element, index) => {
            const cell = this.cellList[index];

            if (cell.node.active && cell.canLoadAvatar()) {
              cell.loadAvatar();
            } else {
              cell.setAvatar(this.defaultAvatar);
            }
          });
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "content", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "cellTemplate", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "topCellTemplate", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "topRankContainer", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "backBtn", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "loadingIcon", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "scrollView", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "defaultAvatar", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "friendToogle", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "mineLeaderboardCell", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "bannerSprite", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "banner", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PlayerController.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './AudioMgr.ts', './MaxApiUtils.ts', './Profile.ts', './CameraController.ts', './PlatformCtrl.ts', './GameMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, Vec3, _decorator, Component, SkeletalAnimation, find, Node, game, Game, tween, MeshRenderer, instantiate, director, Quat, randomRangeInt, gameEvent, _defineProperty, _applyDecoratedDescriptor, _initializerDefineProperty, SoundName, EventPlayer, AudioMgr, MaxApiUtils, Profile, CameraController, PlatformCtrl, GameMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Vec3 = module.Vec3;
      _decorator = module._decorator;
      Component = module.Component;
      SkeletalAnimation = module.SkeletalAnimation;
      find = module.find;
      Node = module.Node;
      game = module.game;
      Game = module.Game;
      tween = module.tween;
      MeshRenderer = module.MeshRenderer;
      instantiate = module.instantiate;
      director = module.director;
      Quat = module.Quat;
      randomRangeInt = module.randomRangeInt;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _defineProperty = module.defineProperty;
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      SoundName = module.SoundName;
      EventPlayer = module.EventPlayer;
    }, function (module) {
      AudioMgr = module.AudioMgr;
    }, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      Profile = module.Profile;
    }, function (module) {
      CameraController = module.CameraController;
    }, function (module) {
      PlatformCtrl = module.PlatformCtrl;
    }, function (module) {
      GameMgr = module.GameMgr;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _class3, _temp;

      cclegacy._RF.push({}, "f35884Rm79NaYGI7oi4bmyj", "PlayerController", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let PlayerController = exports('PlayerController', (_dec = ccclass('PlayerController'), _dec2 = property(Vec3), _dec(_class = (_class2 = (_temp = _class3 = class PlayerController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "config", _descriptor, this);

          _defineProperty(this, "nextPlatform", null);

          _defineProperty(this, "isReadyToPlay", false);

          _defineProperty(this, "camera", null);

          _defineProperty(this, "isHolding", false);

          _defineProperty(this, "force", 0);

          _defineProperty(this, "momoOffset", void 0);

          _defineProperty(this, "momo", null);

          _defineProperty(this, "animation", null);

          _defineProperty(this, "platform", null);

          _defineProperty(this, "drop", void 0);

          _defineProperty(this, "EPSILON", .1);

          _defineProperty(this, "Idles", ['Silly Dancing', 'Excited', 'Rumba Dancing']);
        }

        static get Instance() {
          return PlayerController.instance;
        }

        onLoad() {// this.nextPlatform.active = false
          // this.enabled = false
        }

        start() {
          this.nextPlatform = PlatformCtrl.instance.node;
          this.enabled = false;
          this.momo = this.node.children[0];
          this.animation = this.momo.getComponent(SkeletalAnimation);
          let canvas = find('Canvas');
          canvas.on(Node.EventType.TOUCH_END, this.ontouchend, this);
          canvas.on(Node.EventType.TOUCH_START, this.ontouchstart, this);
          this.momoOffset = this.momo.position.clone();
          this.momo.position = new Vec3(this.momoOffset.x, 50, this.momoOffset.z);
          PlayerController.instance = this;
          console.log("MOMO loaded");
          this.camera = find('CameraHolder').getComponent(CameraController);
          game.on(Game.EVENT_SHOW, () => {
            this.resetHolding();
          }); // resources.load<Prefab>("prefabs/Tiger", (err, prefab) => {
          //     if (prefab) {
          //         this.momo = instantiate(prefab);
          //         this.momo.active = true;
          //         this.momo.setParent(this.node);
          //         t
          //     }
          //     else {
          //         console.error("FAIL TO LOAD MOMO!!!");
          //     }
          // });
        }

        play() {
          {
            // momo start up
            this.isReadyToPlay = false;
            this.momo.forward = Vec3.FORWARD;
            this.momo.active = true;
            this.node.position = new Vec3(0, 1, 0);
            this.nextPlatform.position = new Vec3(0, 50, 0); // this.nextPlatform.active = false;

            this.platform = this.nextPlatform;
            this.enabled = true;
            let offset = this.momoOffset;
            this.momo.position = new Vec3(offset.x, 2, offset.z);
            this.animation.play('Falling');
            tween(this.momo).to(2, {
              position: offset
            }, {
              easing: 'sineOut'
            }).start();
            AudioMgr.Instance.PlaySfx(SoundName.Spawn);
            let configCheck = tween(this).delay(.3).call(() => {
              if (GameMgr.Instance.IsStartGame && this.momo.position.y <= 0) {
                this.nextPlatform.position = Vec3.ZERO; // this.nextPlatform.active = true

                let platformComp = this.nextPlatform.getComponent(PlatformCtrl);
                platformComp.changeColor(Profile.Instance.Mode);
                platformComp.play(1).call(this.init.bind(this)).start();
                configCheck.stop();
              }
            }).union().repeatForever().start();
          }
        }

        playDissolve() {
          let renderer = this.momo.getComponentInChildren(MeshRenderer);
          let effect = renderer.getMaterial(0);
          return tween({
            value: 0
          }).to(1, {
            value: 1
          }, {
            easing: 'sineOut',
            'onUpdate': (target, ratio) => {
              if (ratio >= 1) {
                this.momo.active = false;
                effect.setProperty('alphaThreshold', 0);
              } else {
                effect.setProperty('alphaThreshold', target.value);
              }
            }
          });
        }

        init() {
          this.isReadyToPlay = true;
          this.playIdle();
          AudioMgr.Instance.PlaySfx(SoundName.Landing);
          gameEvent.emit(EventPlayer.OnLanding, -1);
          this.next(true);
        }

        next(alive) {
          if (!alive) {
            // this.animation.crossFade('Die', .5)
            this.force = 0;
            this.isHolding = false;
            this.isReadyToPlay = false;
            this.animation.pause();
            AudioMgr.Instance.PlaySfx(SoundName.Dead);
            this.nextPlatform.getComponent(PlatformCtrl).stop(false);
            gameEvent.emit(EventPlayer.OnDead);
            this.playDissolve().call(gameEvent.emit.bind(gameEvent, EventPlayer.OnLose)).start();
            return;
          } // create new platform


          let node = instantiate(this.nextPlatform);
          director.getScene().addChild(node);
          node.getComponent(PlatformCtrl).init();
          this.nextPlatform = node;
          {
            // momo face to new platform
            this.playIdle();
            let forward = new Vec3(this.node.position);
            forward.y = 0; // this.momo.forward = forward.subtract(node.position)

            tween(this.momo.forward.clone()).to(.5, forward.subtract(node.position), {
              'onUpdate': (target, ratio) => {
                this.momo.forward = target;
              }
            }).start();
          }
        }

        postJump(alive, almost) {
          let momo = this.momo;
          let offset = this.momoOffset;
          let platform = this.nextPlatform.getComponent(PlatformCtrl);
          alive && (alive = !platform.isTransparent);
          tween(momo).to(.1, {
            position: new Vec3(offset.x, alive ? offset.y : -1, offset.z)
          }, {
            easing: 'sineIn'
          }).delay(.5).call(this.next.bind(this, alive)).start();
          platform.stop(alive);

          if (alive) {
            gameEvent.emit(EventPlayer.OnLanding, this.calculateCombo(), platform.effectTween != null);
            AudioMgr.Instance.PlaySfx(SoundName.Landing);
            {
              // landing animation
              let scale = this.nextPlatform.scale;
              tween(this.nextPlatform).by(.1, {
                scale: new Vec3(0, -.15, 0)
              }, {
                easing: 'sineIn'
              }).to(.1, {
                scale: new Vec3(scale.x, 1, scale.z)
              }, {
                easing: 'sineIn'
              }).start();
            }
          }

          if (alive && almost) {
            let dir = platform.node.worldPosition.clone().subtract(momo.worldPosition);
            dir.y = 0;
            dir.normalize();
            let x = dir.dot(momo.forward) * 50;
            let y = momo.rotation.y * 50;
            let data = new Quat();
            Quat.fromEuler(data, x, y, 0);
            this.drop = tween(momo).to(2, {
              rotation: data,
              position: new Vec3(offset.x, -1, -offset.z)
            }).call(() => {
              let scale = this.platform.scale;
              platform.getComponent(PlatformCtrl).end(scale, false).start();
              this.next(false);
            }).start();
          }
        }

        check(dir) {
          let pos = this.nextPlatform.position;
          let scale = this.nextPlatform.scale.clone().multiplyScalar(.5);
          dir = dir.clone().add(this.node.position);
          let res = new Vec3(scale.x - Math.abs(dir.x - pos.x), 0, scale.z - Math.abs(dir.z - pos.z));
          return res;
        }

        ontouchstart(event) {
          if (this.platform == this.nextPlatform || GameMgr.Instance.IsPause || !this.isReadyToPlay) return;
          this.isHolding = true;
          this.animation.crossFade('PreJump', .3);
          gameEvent.emit(EventPlayer.OnHold);
          AudioMgr.Instance.PlaySfx(SoundName.PreJump);
        }

        ontouchend(event) {
          if (this.isHolding) {
            this.isHolding = false;
            gameEvent.emit(EventPlayer.OnRelease);
          }
        }

        update(deltaTime) {
          let f = this.force;
          let config = this.config;
          let scale = this.platform.scale;
          let offset = this.momoOffset;

          if (this.isHolding) {
            f += deltaTime * config.x;
            f = Math.min(f, 1.5);
            this.platform.setScale(scale.x, 1 / (1 + f), scale.z);
            this.momo.setPosition(offset.x, offset.y + 1 / (1 + f) - 1, offset.z);
          } else if (f > 0) {
            f = Math.max(0.25, f);
            let checkOB = this.checkForOnBoarding(f);

            if (checkOB.result) {
              f = checkOB.force;
              AudioMgr.Instance.StopSfx(SoundName.PreJump);
              AudioMgr.Instance.PlaySfx(SoundName.Jump);
              let scalar = f * config.y;
              let forward = this.node.position.clone();
              forward.y = 0;
              forward.subtract(this.nextPlatform.position).normalize().multiplyScalar(-scalar);
              let delta = this.check(forward);
              let alive = Math.min(delta.x, delta.z) > -this.EPSILON;
              let almost = Math.min(delta.x, delta.z) < 0;
              let time = .4 + scalar * .1;

              if (this.drop) {
                this.drop.stop();
              }

              {
                // play model animation
                this.animation.crossFade('Jump', .3);
                tween(this.animation).delay(time).call(this.animation.play.bind(this.animation, "Landing")).start();
              }
              {
                // movement animation
                tween(this.node) // X-axis
                .by(time, {
                  position: forward
                }).call(this.postJump.bind(this, alive, almost)).start();
                tween(this.momo) // Y-axis
                .to(time * .5, {
                  position: new Vec3(offset.x, f * config.z, offset.z)
                }, {
                  easing: 'sineOut'
                }).to(time * .5, {
                  position: new Vec3(offset.x, -.23, offset.z)
                }, {
                  easing: 'sineIn'
                }).start();
              }
              {
                // old platform disappearance
                this.platform.getComponent(PlatformCtrl).end(scale, alive).start();
              }
              this.platform = this.nextPlatform;
            } else {
              // this.animation.crossFade('Idle' + randomRangeInt(1, 5), .5)
              // this.platform.setScale(scale.x, 1, scale.z)
              // this.momo.setPosition(offset.x, offset.y, offset.z)
              this.resetHolding(scale, offset, true);
            }

            f = 0;
          }

          this.force = f;
        }

        calculateCombo() {
          let dis = this.node.position.clone().subtract(this.platform.position);
          dis.y = 0;
          let distance = dis.length();
          let distancePerCombo = this.platform.scale.x / 2 / 10;
          if (distance < distancePerCombo * 3) return 0;
          if (distance < distancePerCombo * 6.5) return 1;
          return 2;
        }

        checkForOnBoarding(f) {
          let force = f;

          if (GameMgr.Instance.IsOnboarding) {
            let forceToCenter = this.timeToCenter() * this.config.x;
            let minForce = forceToCenter;
            minForce -= .23;
            let maxForce = minForce + .46;

            if (f >= minForce && f <= maxForce) {
              GameMgr.Instance.OBJumpResult(true, f > maxForce);
              return {
                result: true,
                force: forceToCenter + .5 * (f - forceToCenter)
              };
            } else {
              GameMgr.Instance.OBJumpResult(false, f > maxForce);
              return {
                result: false,
                force
              };
            }
          }

          return {
            result: true,
            force
          };
        }

        timeToCenter() {
          let d = new Vec3(this.node.position).subtract(this.nextPlatform.position).length();
          let time = (d - .2) / this.config.y;
          return time;
        }

        resetHolding(scale = null, offset = null, force = false) {
          if (this.isHolding || force) {
            var _this$momo;

            if (!scale) scale = this.platform.scale;
            console.log(scale);
            if (!offset) offset = this.momoOffset;
            console.log(offset);
            this.isHolding = false;
            this.force = 0;
            console.log(this.animation);
            this.playIdle();
            this.platform.setScale(scale.x, 1, scale.z);
            (_this$momo = this.momo) === null || _this$momo === void 0 ? void 0 : _this$momo.setPosition(offset.x, offset.y, offset.z);
            gameEvent.emit(EventPlayer.OnRelease);
          }
        }

        playWinJumping() {
          let offset = this.momoOffset;
          this.animation.crossFade('WinJumping');
          gameEvent.emit(EventPlayer.OnWinJumping);
          let secondPerFrame = 2 / 30;
          let preJumpFrame = 20;
          let jumpFrame = 5;
          tween(this.momo).delay(preJumpFrame * secondPerFrame).to(jumpFrame * secondPerFrame, {
            position: new Vec3(offset.x, 1, offset.z)
          }, {
            easing: 'sineOut'
          }).to(jumpFrame * secondPerFrame, {
            position: new Vec3(offset.x, 0, offset.z)
          }, {
            easing: 'sineIn'
          }).call(() => {
            this.camera.shake().start();
            MaxApiUtils.triggerEventVibration();
          }).start();
        }

        playIdle() {
          this.animation.crossFade(this.Idles[randomRangeInt(0, this.Idles.length)], 0.5);
        }

      }, _defineProperty(_class3, "instance", null), _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "config", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3();
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ProgressBarScore.ts", ['cc', './_rollupPluginModLoBabelHelpers.js', './ProgressBarLabelScore.ts'], function (exports) {
  'use strict';

  var cclegacy, Prefab, Node, _decorator, Component, instantiate, Vec3, _applyDecoratedDescriptor, _initializerDefineProperty, ProgressBarLabelScore;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Prefab = module.Prefab;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      instantiate = module.instantiate;
      Vec3 = module.Vec3;
    }, function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      ProgressBarLabelScore = module.ProgressBarLabelScore;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "f3974RwdbRHAYF6fR5ttUnc", "ProgressBarScore", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ProgressBarScore = exports('ProgressBarScore', (_dec = ccclass('ProgressBarScore'), _dec2 = property(Prefab), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class ProgressBarScore extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "progressBarScore", _descriptor, this);

          _initializerDefineProperty(this, "container", _descriptor2, this);
        }

        loadView(currentPoint, listTargetPoint, listLabelScorePosition) {
          if (this.container.children[0]) {
            return;
          } else {
            listTargetPoint.forEach((element, index) => {
              let labelScore = instantiate(this.progressBarScore);
              const y = listLabelScorePosition[index];
              this.container.addChild(labelScore);
              labelScore.setPosition(new Vec3(labelScore.position.x, y, 0));
              labelScore.getComponent(ProgressBarLabelScore).loadView(element, currentPoint >= element);
            });
          }
        }

        clear() {
          this.container.removeAllChildren();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "progressBarScore", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ApiMock.ts", ['cc', './_rollupPluginModLoBabelHelpers.js'], function (exports) {
  'use strict';

  var cclegacy, _defineProperty;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }],
    execute: function () {
      cclegacy._RF.push({}, "f6032IoNbNDmaE5dpKfBrwy", "ApiMock", undefined);

      class ApiMock {}

      exports('ApiMock', ApiMock);

      _defineProperty(ApiMock, "getConfig", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_get_config"
        },
        "item": {
          "size": [{
            "step": "1",
            "min": 1.0,
            "max": 1.0
          }, {
            "step": "5",
            "min": 0.6,
            "max": 1.0
          }, {
            "step": "6",
            "min": 0.9,
            "max": 1.0
          }, {
            "step": "8",
            "min": 0.9,
            "max": 1.0
          }, {
            "step": "11",
            "min": 0.7,
            "max": 0.9
          }, {
            "step": "16",
            "min": 0.8,
            "max": 1.0
          }, {
            "step": "21",
            "min": 0.6,
            "max": 0.9
          }, {
            "step": "26",
            "min": 0.7,
            "max": 1.0
          }, {
            "step": "31",
            "min": 0.4,
            "max": 1.0
          }],
          "reward": [{
            "from": 2,
            "to": 3,
            "type": "gift"
          }, {
            "from": 6,
            "to": 7,
            "type": "gift"
          }, {
            "from": 11,
            "to": 15,
            "type": "gift"
          }],
          "point": [10, 6, 2],
          "checkpoint": [100, 200, 300],
          "power": [3.0, 3.0],
          "distances": [{
            "step": "2",
            "min": 1.9,
            "max": 2.1
          }, {
            "step": "5",
            "min": 2.8,
            "max": 3.2
          }, {
            "step": "8",
            "min": 1.9,
            "max": 2.3
          }, {
            "step": "11",
            "min": 1.5,
            "max": 3.2
          }, {
            "step": "15",
            "min": 2.4,
            "max": 3.0
          }, {
            "step": "21",
            "min": 2.0,
            "max": 3.5
          }, {
            "step": "31",
            "min": 1.5,
            "max": 4.0
          }],
          "eventLink": "https://momo.vn/tin-tuc/tin-tuc-su-kien/choi-momo-jump-sieu-hoi-nhay-bat-san-tien-mat-va-qua-khung-2046",
          "turnTimer": "60000",
          "turnTimerLimit": 10,
          "goldHour": {
            "start": "1647795600000",
            "end": "1647795600000",
            "stepBonus": 10
          },
          "bonusLimit": "1000000",
          "starterLimit": "200",
          "goldDay": {
            "start": "1640082732241",
            "end": "1640537999000",
            "stepBonus": 5
          },
          "info": "Huy Thái đã trúng IPhone rồi còn cái nịt nào đâu mà trúng",
          "goldDayLimit": 5,
          "stages": {
            "0": {
              "name": "stage 1",
              "hasBonus": true,
              "hasGift": true,
              "rewardItemId": "tiger_1",
              "target": "50",
              "type": "POINT",
              "hasReward": true
            },
            "1": {
              "name": "stage 2",
              "hasGift": true,
              "rewardItemId": "tiger_2",
              "target": "3",
              "type": "PERFECT",
              "hasReward": true
            },
            "2": {
              "name": "stage 3",
              "hasGift": true,
              "rewardItemId": "tiger_3",
              "target": "3",
              "type": "SPECIAL",
              "hasReward": true
            },
            "3": {
              "name": "stage 4",
              "hasBonus": true,
              "hasGift": true,
              "rewardItemId": "none",
              "target": "-1",
              "type": "ENDLESS"
            }
          }
        },
        "inventory": [{
          "itemId": "tiger_2",
          "itemName": "Mảnh 2",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger_3",
          "itemName": "Mảnh 3",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger_1",
          "itemName": "Mảnh 1",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger",
          "itemName": "TIGER",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger_combine",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger_4",
          "itemName": "Mảnh 4",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }]
      });

      _defineProperty(ApiMock, "postSuccessMission", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "send_succeeded_event"
        },
        "result": true
      });

      _defineProperty(ApiMock, "getGiftHistory", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_get_gift_history"
        },
        "meta": {
          "hasNext": false
        },
        "items": [{
          "giftName": "Nhận 132đ vào ví MoMo",
          "gameId": "ac21a5b1-3042-44c9-9902-e466cf21d6b7",
          "step": "-1",
          "userId": "01663285001",
          "type": "money",
          "timestamp": "1636889835110"
        }]
      });

      _defineProperty(ApiMock, "getProgress", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "get_reward_progress"
        },
        "data": {
          "userId": "0915968549",
          "progressId": "pigjump_normal_20211203",
          "currentPoint": 20000,
          "milestones": [{
            "milestoneId": "milestone_level_1",
            "targetPoint": 50,
            "rewards": [{
              "rewardId": "reward_1_2021120",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/RUcvQ_1.jpg",
              "title": "Tiền thưởng 55đ",
              "description": "Tiền thưởng 55đ",
              "status": "UNAVAILABLE"
            }],
            "status": "AVAILABLE",
            "amount": 1000000000
          }, {
            "milestoneId": "milestone_level_2",
            "targetPoint": 200,
            "rewards": [{
              "rewardId": "reward_2_20211203",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/RUcvQ_1.jpg",
              "title": "Tiền thưởng 299đ",
              "description": "Tiền thưởng 299đ",
              "status": "UNAVAILABLE"
            }],
            "status": "AVAILABLE",
            "amount": 1000000000
          }, {
            "milestoneId": "milestone_level_3",
            "targetPoint": 1000,
            "rewards": [{
              "rewardId": "reward_3_20211203",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/RUcvQ_1.jpg",
              "title": "Tiền thưởng 1.999đ",
              "description": "Tiền thưởng 1.999đ",
              "status": "UNAVAILABLE"
            }],
            "status": "CLAIMED",
            "amount": 1000000000
          }, {
            "milestoneId": "milestone_level_4",
            "targetPoint": 10000,
            "rewards": [{
              "rewardId": "reward_4_20211203",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/ZUycq_2.jpg",
              "title": "Tiền thưởng 9.999đ",
              "description": "Tiền thưởng 9.999đ",
              "status": "UNAVAILABLE"
            }],
            "status": "OUT_OF_STOCK",
            "amount": 1000000000
          }, {
            "milestoneId": "milestone_level_5",
            "targetPoint": 25000,
            "rewards": [{
              "rewardId": "reward_5_20211203",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/pxTZG_3.jpg",
              "title": "Tiền thưởng 19.999đ",
              "description": "Tiền thưởng 19.999đ",
              "status": "UNAVAILABLE"
            }],
            "status": "UNAVAILABLE",
            "amount": 15000
          }, {
            "milestoneId": "milestone_level_6",
            "targetPoint": 60000,
            "rewards": [{
              "rewardId": "reward_6_20211203",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/HQOar_4.jpg",
              "title": "Tiền thưởng 99.999đ",
              "description": "Tiền thưởng 99.999đ",
              "status": "UNAVAILABLE"
            }],
            "status": "UNAVAILABLE",
            "amount": 1500
          }, {
            "milestoneId": "milestone_level_7",
            "targetPoint": 200000,
            "rewards": [{
              "rewardId": "reward_6_20211203",
              "icon": "https://atc-edge03.mservice.com.vn/momo_app_v2/img/xIcdw_5.jpg",
              "title": "Tiền thưởng 1.000.000đ",
              "description": "Tiền thưởng 1.000.000đ",
              "status": "UNAVAILABLE"
            }],
            "status": "CLAIMED",
            "amount": 100
          }]
        }
      });

      _defineProperty(ApiMock, "getGift", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_get_gift"
        },
        "items": [{
          "giftName": "Nhận 379đ vào ví MoMo"
        }, {
          "value": "2",
          "timestamp": "1633405939030",
          "hasGift": true,
          "giftName": "1119_cashback_momo_200k",
          "name": "200k tiền về ví!!!"
        }]
      });

      _defineProperty(ApiMock, "getMission", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "mission_status"
        },
        "missions": [{
          "missionId": "open_vts",
          "missionInfo": {
            "title": "Mở ví trả sau",
            "description": "Mở ví trả sau đê nhận lượt quay",
            "icon": "https://img.mservice.com.vn/momo_app_v2/new_version/img/Marketing/icon-transfer-menu-update-v-mo-mo-2@2x.png",
            "ctaText": "Mở ngay",
            "refId": "",
            "videoUrl": "",
            "progressData": "0/1",
            "code": "0FXUPJ9",
            "linkShare": "https://momo.vn/tin-tuc/khuyen-mai/tich-du-8-tim-nhan-ngay-combo-4-the-qua-cuc-hot-2450?utm_source=in_app&utm_campaign=retail",
            "shareImgUrl": "",
            "shareTitle": "Nhảy Tung Chiêu, Trúng Tiền Triệu",
            "shareDescription": "Nhảy MoMo Jump cùng Tiger Platinum săn tiền mặt tới 1 triệu",
            "domain": "momoapp.vn"
          },
          "startMission": 1633345200000,
          "endMission": 5631466000000,
          "group": "",
          "sort": 10,
          "succeededCounter": [{
            "counterId": "counter_open_vts_20211006",
            "limitType": "END_TIME",
            "limitUnit": 1,
            "startTime": 1629824400000,
            "endTime": 1636638400000,
            "upperBound": 1,
            "numSucceeded": 0,
            "isMainCounter": true,
            "rewardConditions": [{
              "rewardId": "",
              "conditionType": "AT_POINT",
              "conditionValue": 1,
              "description": "",
              "numAvailableReward": 0,
              "numReceivedReward": 0,
              "canGetReward": false,
              "isAutoClaimReward": true,
              "rewards": [{
                "actionInfo": {
                  "name": "+1 lượt",
                  "icon": "",
                  "amount": 1
                },
                "extra": ""
              }]
            }]
          }],
          "isCompleted": false,
          "canGetReward": false,
          "isComingSoon": false,
          "isExpired": false
        }]
      });

      _defineProperty(ApiMock, "postStartGame", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_start_game"
        },
        "item": {
          "gameId": "3adfab00-50c6-40f4-8e93-4631cfdb8f77",
          "hasGift": true
        }
      });

      _defineProperty(ApiMock, "getScore", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_get_score"
        },
        "item": {
          "userId": "01663285001",
          "agentId": "363285001",
          "gameId": "f6d395bb-1f1e-4175-9fa4-9043edde4ab9",
          "scores": [{
            "value": "20",
            "timestamp": "1633158555758"
          }, {
            "value": "10",
            "timestamp": "1633158558218"
          }, {
            "value": "20",
            "timestamp": "1633158560920"
          }, {
            "value": "6",
            "timestamp": "1633158562639"
          }, {
            "value": "20",
            "timestamp": "1633158564939"
          }, {
            "value": "20",
            "timestamp": "1633158566919"
          }, {
            "value": "6",
            "timestamp": "1633158569579"
          }, {
            "value": "6",
            "timestamp": "1633158572082"
          }, {
            "value": "6",
            "timestamp": "1633158574560"
          }, {
            "value": "6",
            "timestamp": "1633158574560"
          }, {
            "value": "6",
            "timestamp": "1633158574560"
          }, {
            "value": "6",
            "timestamp": "1633158574560"
          }],
          "isEnd": true,
          "eventTime": "1633970443612",
          "requestId": "eff38d13-befb-4e9c-9707-1e4dd3a1f31e"
        }
      });

      _defineProperty(ApiMock, "gameGift", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_get_gift"
        },
        "items": [{
          "giftName": "450đ vào Ví Momo"
        }, {
          "value": "10",
          "giftName": "Quà Giảm 5K Khi Mua Data 3G/4G Từ 15K",
          "timestamp": "1636889834057",
          "giftId": "210512_data_10k_20k",
          "hasGift": "true"
        }]
      });

      _defineProperty(ApiMock, "getTurn", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_check_turn"
        },
        "item": {
          "balance": 811,
          "timestamp": 10000,
          "isTiming": true
        }
      });

      _defineProperty(ApiMock, "getRankPoints", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "v1_frequency_ranking_global"
        },
        "meta": {
          "userId": "0938314514",
          "rank": 8,
          "name": "PHAM VIET HUNG",
          "title": "",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/ef0e/8e76f459cc76543af546244a65173a3b0f4d733f4ecd50e353338ffaf4ad.png",
          "point": 370
        },
        "items": [{
          "userId": "0938314557",
          "rank": 1,
          "name": "Nguyen Van D",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/d008/3c1333f8109d5369d7ba24ccd51a9ba8119d87e6bde3764d2b8116a3d184.png",
          "point": 1438
        }, {
          "userId": "0368485025",
          "rank": 2,
          "name": "HOANG ANH",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/d008/3c1333f8109d5369d7ba24ccd51a9ba8119d87e6bde3764d2b8116a3d184.png",
          "point": 1142
        }, {
          "userId": "0907007739",
          "rank": 3,
          "name": "Tran Thi Mui",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/d008/3c1333f8109d5369d7ba24ccd51a9ba8119d87e6bde3764d2b8116a3d184.png",
          "point": 638
        }, {
          "userId": "0972365207",
          "rank": 4,
          "name": "VŨ THỊ LỆ",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/ef0e/8e76f459cc76543af546244a65173a3b0f4d733f4ecd50e353338ffaf4ad.png",
          "point": 550
        }, {
          "userId": "0937432551",
          "rank": 5,
          "name": "Luan Ho",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/2966/6db1f0b0374b9b79f95f44e9a7f37e43225fb72c19f75fc255bfff2de518.png",
          "point": 448
        }, {
          "userId": "0583130828",
          "rank": 6,
          "name": "NGUYỄN NGỌC TRƯỜNG",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 426
        }, {
          "userId": "0363285001",
          "rank": 7,
          "name": "ĐOÀN TẤN VIỆT KHÔI",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 393
        }, {
          "userId": "0938314514",
          "rank": 8,
          "name": "PHAM VIET HUNG",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 370
        }, {
          "userId": "0777076857",
          "rank": 9,
          "name": "VI MỸ NGỌC",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 340
        }, {
          "userId": "0963852741",
          "rank": 10,
          "name": "PHUC HUY",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 310
        }, {
          "userId": "0909872331",
          "rank": 11,
          "name": "DDRDRFH ESSGFSSE",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/c4af/eee1e3bdcf7543de4df6f3618f5d425083f921c5214919bfffced5d8dd96.png",
          "point": 286
        }, {
          "userId": "0363285008",
          "rank": 12,
          "name": "KHOI KK",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 262
        }, {
          "userId": "0912646599",
          "rank": 13,
          "name": "NAM HAI HO",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/939d/910f43e37fb4a488b32d10fcf0e34faabb229859563affc7c060fd0296fc.png",
          "point": 231
        }, {
          "userId": "0909872116",
          "rank": 14,
          "name": "TEST ABC",
          "title": "",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "",
          "point": 173
        }, {
          "userId": "0909872363",
          "rank": 15,
          "name": "Name Test",
          "title": "Tân binh trà đá",
          "friendStatus": "UNKNOWN",
          "avatarUrl": "https://cdn-test.momoapp.vn/avatars/avatar_test/ff70/2e69a470d9e01bc125355df4a0ad3fd3cc478d176c167162b98d73dd3b1d.png",
          "point": 148
        }]
      });

      _defineProperty(ApiMock, "getInventory", {
        "response_info": {
          "error_message": "success",
          "error_code": 0,
          "event_tracking": "get_profile"
        },
        "inventory": {
          "isSuccess": true,
          "items": [{
            "id": "tiger_1@0bf1b275-0ded-4d6e-856b-46aefab323e6",
            "itemId": "tiger_1",
            "itemName": "Mảnh 1",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_1@237765b1-56bd-41f8-8aa0-9cc5e8091b5c",
            "itemId": "tiger_1",
            "itemName": "Mảnh 1",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_1@53b4dd1a-106c-48e1-a703-983317a4d712",
            "itemId": "tiger_1",
            "itemName": "Mảnh 1",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_1@6ca0b5a0-e793-41a4-b819-d770843b3d17",
            "itemId": "tiger_1",
            "itemName": "Mảnh 1",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_1@75a73e43-7973-4339-926c-7250825171f3",
            "itemId": "tiger_1",
            "itemName": "Mảnh 1",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_1@d1b80948-31d3-4406-ac76-3a8813312836",
            "itemId": "tiger_1",
            "itemName": "Mảnh 1",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_2@4ab0d81e-0080-4426-9100-9679f73aebb8",
            "itemId": "tiger_2",
            "itemName": "Mảnh 2",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_2@977b6295-42cb-479d-93e6-b6364ad581db",
            "itemId": "tiger_2",
            "itemName": "Mảnh 2",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_2@9d59ad68-caa8-4e43-95ef-6d964785e3ae",
            "itemId": "tiger_2",
            "itemName": "Mảnh 2",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_2@b8b905f9-29a3-4ecc-b5c0-f1f87a152601",
            "itemId": "tiger_2",
            "itemName": "Mảnh 2",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_2@c444dd9a-593b-4655-8e32-b5b407cfda41",
            "itemId": "tiger_2",
            "itemName": "Mảnh 2",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_3@175f06b6-4261-4f50-85fa-128cdef1d85c",
            "itemId": "tiger_3",
            "itemName": "Mảnh 3",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_3@321cdf6f-59a3-4c15-a8cd-a889faf8620f",
            "itemId": "tiger_3",
            "itemName": "Mảnh 3",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }, {
            "id": "tiger_3@3f3b09c1-a49d-4f94-975a-09d03e8a8145",
            "itemId": "tiger_3",
            "itemName": "Mảnh 3",
            "collection": {
              "collectionId": "tiger",
              "collectionName": "Bia Tiger",
              "image": "https://bitly.com.vn/50v4f3",
              "icon": "https://bitly.com.vn/50v4f3",
              "iconEmpty": "https://bitly.com.vn/50v4f3"
            },
            "status": "AVAILABLE",
            "image": "https://bitly.com.vn/50v4f3",
            "icon": "https://bitly.com.vn/50v4f3"
          }],
          "message": "Done"
        },
        "config": [{
          "itemId": "tiger_2",
          "itemName": "Mảnh 2",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger_3",
          "itemName": "Mảnh 3",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger_1",
          "itemName": "Mảnh 1",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger",
          "itemName": "TIGER",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger_combine",
          "icon": "https://bitly.com.vn/50v4f3"
        }, {
          "itemId": "tiger_4",
          "itemName": "Mảnh 4",
          "image": "https://bitly.com.vn/50v4f3",
          "imageEmpty": "https://bitly.com.vn/50v4f3",
          "collectionId": "tiger",
          "icon": "https://bitly.com.vn/50v4f3"
        }]
      });

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Profile.ts", ['cc', './GameEvent.ts', './_rollupPluginModLoBabelHelpers.js', './GameDefine.ts', './Utils.ts', './Api.ts', './enc-base64.js', './index.js', './index.mjs_cjs=&original=.js', './enc-base64.mjs_cjs=&original=.js', './enc-utf8.js', './enc-utf8.mjs_cjs=&original=.js', './MaxApiUtils.ts', './NetworkMgr.ts', './Gameconfig.ts', './BoxMgr.ts'], function (exports) {
  'use strict';

  var cclegacy, _decorator, Component, sys, game, director, gameEvent, _defineProperty, EventName, ProfileStorageKey, DevicePerformance, Utils, Api, _cjsExports$1, _cjsExports, _cjsExports$2, MaxApiUtils, NetworkMgr, Gameconfig, BoxMgr;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      sys = module.sys;
      game = module.game;
      director = module.director;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      EventName = module.EventName;
      ProfileStorageKey = module.ProfileStorageKey;
      DevicePerformance = module.DevicePerformance;
    }, function (module) {
      Utils = module.Utils;
    }, function (module) {
      Api = module.Api;
    }, function (module) {
      _cjsExports$1 = module.default;
    }, function (module) {
      _cjsExports = module.default;
    }, null, null, function (module) {
      _cjsExports$2 = module.default;
    }, null, function (module) {
      MaxApiUtils = module.default;
    }, function (module) {
      NetworkMgr = module.NetworkMgr;
    }, function (module) {
      Gameconfig = module.Gameconfig;
    }, function (module) {
      BoxMgr = module.BoxMgr;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "fb70chVwDpNe5DpzETj+HsT", "Profile", undefined);

      const {
        ccclass,
        property
      } = _decorator;

      class PlayerProgress {
        constructor() {
          _defineProperty(this, "value", void 0);

          _defineProperty(this, "timestamp", void 0);

          _defineProperty(this, "hasGift", void 0);

          _defineProperty(this, "is_special", void 0);
        }

      }

      class ProfileData {
        constructor() {
          _defineProperty(this, "progress", []);

          _defineProperty(this, "score", 0);

          _defineProperty(this, "turn", 0);

          _defineProperty(this, "id", "01234567890");

          _defineProperty(this, "token", "");

          _defineProperty(this, "name", "");

          _defineProperty(this, "avatar", "");
        }

      }

      let Profile = exports('Profile', (_dec = ccclass('Profile'), _dec(_class = (_temp = _class2 = class Profile extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "data", new ProfileData());

          _defineProperty(this, "DevicePerformance", void 0);

          _defineProperty(this, "iSOk", false);

          _defineProperty(this, "hasGift", false);

          _defineProperty(this, "gameID", "");

          _defineProperty(this, "mode", -1);
        }

        get Mode() {
          return this.mode;
        }

        set Mode(value) {
          this.mode = value;
        }

        get Score() {
          return this.data.score;
        }

        set Score(value) {
          this.data.score = value;
        }

        get GameID() {
          return this.gameID;
        }

        set GameID(value) {
          this.gameID = value;
        }

        get Turn() {
          return this.data.turn;
        }

        set Turn(value) {
          this.data.turn = value;
        }

        get UserID() {
          return this.data.id;
        }

        set UserID(value) {
          this.data.id = value;
        }

        get UserName() {
          return this.data.name;
        }

        set UserName(value) {
          this.data.name = value;
        }

        get UserAvatar() {
          return this.data.avatar;
        }

        set UserAvatar(value) {
          this.data.avatar = value;
        }

        get UserToken() {
          return this.data.token;
        }

        set UserToken(value) {
          this.data.token = value;
        }

        get Progress() {
          return this.data.progress;
        }

        get HasGift() {
          return this.hasGift;
        }

        set HasGift(value) {
          this.hasGift = value;
        }

        isMine(userId) {
          return this.data.id === userId;
        }

        onLoad() {
          Profile.instance = this;
          !sys.isMobile && this.SetMaxFps();
          MaxApiUtils.GetProfile().then(res => {
            this.OnUpdateUserInfo(res);
            MaxApiUtils.GetDeviceInfo().then(res => {
              if (res) {
                Profile.Instance.DevicePerformance = res.devicePerformance;
                this.SetMaxFps();
              }
            }).catch(e => {});
          });
        }

        static get Instance() {
          return Profile.instance;
        }

        OnUpdateUserInfo(data) {
          if (!data) {
            data = {
              userId: Api.DEBUG_TOKEN,
              token: Api.DEBUG_TOKEN,
              name: "",
              avatar: ""
            };
          }

          this.UserID = data.userId;
          this.UserToken = data.token;
          this.UserName = data.name;
          this.UserAvatar = data.avatar;
          this.iSOk = true;
          gameEvent.emit(EventName.OnUpdateUserInfo, data);
        }

        Reset() {
          this.data.score = 0;
          this.data.progress = [];
          this.gameID = "";
          Gameconfig.Instance.Reset();
          console.log("Reset Profile");
        }

        AddScore(step, value, hasGift, is_special, isComplete) {
          let progress = new PlayerProgress();
          progress.timestamp = Date.now();
          progress.value = value;
          progress.hasGift = hasGift;
          progress.is_special = is_special;
          this.data.progress.push(progress);
          let bonus = Gameconfig.Instance.CheckBonus(step);
          BoxMgr.Instance.prepick();

          if (progress.hasGift) {
            this.SubmitScore(Profile.Instance.Score, false, (result, reward) => {
              // if (isComplete) {
              //     if (result && result.reward) {
              //         let item = Gameconfig.Instance.GetInventoryById(result.reward)
              //         if (item) {
              //             BoxMgr.Instance.initFlyPopup(item.itemName, PlayerController.Instance.platform.position.clone(), item.image);
              //         }
              //     }
              // }
              if (progress.hasGift) {
                if (result && result.gifts.length > 0) {
                  result.gifts.forEach(item => {
                    if (item.step == step) {
                      console.log("[PICKED GIFT]: " + JSON.stringify(item));
                      BoxMgr.Instance.pickedUp(item.giftName);
                    }
                  });
                } else {
                  BoxMgr.Instance.pickedUp("U là trời, bá đạo thế!");
                }
              }

              console.log("Submit score done");
            });
          } else {
            if (bonus > 0) {
              this.SubmitScore(Profile.Instance.Score, false, () => {
                BoxMgr.Instance.pickedUp();
              });
            } else if (step % 5 == 0 || isComplete) {
              this.SubmitScore(Profile.Instance.Score, false, () => {});
            }
          }
        }

        FetchGameTurn(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.GameTurn, result => {
            if (result && result.item) {
              this.Turn = result.item.balance;
            } else {
              this.Turn = -1;
            }

            callback(this.Turn);
            gameEvent.emit(EventName.OnUpdateTurn, result);
          });
        }

        FetchGameMode(callback) {
          NetworkMgr.getRequest(Api.HOST + Api.Profile, result => {
            if (result && result.profile) {
              if (result.profile.stage != null) {
                this.Mode = result.profile.stage;
              } else {
                this.Mode = 0;
              }

              this.setItem(ProfileStorageKey.Mode, this.Mode);
            }

            callback(this.Mode);
            gameEvent.emit(EventName.OnUpdateTurn, result);
          });
        }

        FetchGameID(callback) {
          NetworkMgr.postRequest(Api.HOST + Api.StartGame, {
            requestId: Utils.uuid,
            size: Gameconfig.Instance.Size,
            distance: Gameconfig.Instance.Distance,
            scores: Gameconfig.Instance.ScoreRange
          }, result => {
            if (result && result.item) {
              console.log("[BONUS]: " + JSON.stringify(result.item.bonus));
              Gameconfig.Instance.SetBonus(result.item.bonus);
              this.gameID = result.item.gameId;
              this.hasGift = true;
              callback(true);
              console.log("GameID: " + this.gameID);
              console.log("Has Gift: " + this.hasGift);
            } else {
              callback(false);
            }
          });
        }

        SubmitScore(score, isEnd, callback) {
          if (Profile.Instance.GameID != null) {
            let agentId = _cjsExports.MD5(_cjsExports$1.stringify(_cjsExports$2.parse(_cjsExports.MD5(`${Profile.Instance.GameID}#${score}`).toString()))).toString();

            let data = {
              scores: this.Progress,
              gameId: this.gameID,
              isEnd,
              agentId
            };
            NetworkMgr.postRequest(Api.HOST + Api.SubmitScore, data, result => {
              if (result && result.item) {
                callback(result.item, result.Reward);
              } else {
                callback(null, 0);
              }
            });
          } else {
            callback(null, 0);
          }
        }

        GetGameGift(callback) {
          if (Profile.Instance.GameID != null) {
            NetworkMgr.getRequest(Api.HOST + Api.GameGift + Profile.Instance.GameID, result => {
              if (result && result.items) {
                callback(result.items);
              } else {
                callback(null);
              }
            });
          } else {
            callback(null);
          }
        }

        SetMaxFps() {
          if (this.DevicePerformance == DevicePerformance.LowEnd) {
            game.frameRate = 30;
          } else if (this.DevicePerformance == DevicePerformance.MideEnd) {
            game.frameRate = 45;
            director.getScene().globals.shadows.enabled = true;
          } else {
            game.frameRate = 60;
            director.getScene().globals.shadows.enabled = true;
          }

          console.log("[FPS]: " + game.frameRate);
        }

        SetNormalFps() {// if (this.DevicePerformance == DevicePerformance.LowEnd) {
          //     game.frameRate = 30;
          // }
          // else if (this.DevicePerformance == DevicePerformance.MideEnd) {
          //     game.frameRate = 30;
          // }
          // else {
          //     game.frameRate = 45;
          // }
        }

        setItem(key, value) {
          let keyStorage = Api.GAME_ID + key;
          MaxApiUtils.setItem(keyStorage, value);
        }

        getItem(key, callback = null) {
          if (sys.isMobile) {
            let keyStorage = Api.GAME_ID + key;
            MaxApiUtils.getItem(keyStorage, callback);
          } else {
            callback(null);
          }
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/main", ['./GameEvent.ts', './GameDefine.ts', './Utils.ts', './AudioMgr.ts', './MySprite.ts', './FlyScore.ts', './Api.ts', './MaxApiUtils.ts', './Profile.ts', './NetworkMgr.ts', './Gameconfig.ts', './BoxMgr.ts', './TrimBase64.ts', './ThemeController.ts', './AgeGateMgr.ts', './Input.ts', './ScoreEffect.ts', './Screen.ts', './ScreenMgr.ts', './Popup.ts', './PopupMgr.ts', './AssetMgr.ts', './KolController.ts', './ShipController.ts', './MyButton.ts', './TextDefine.ts', './TrackingMgr.ts', './Onboarding.ts', './PhoneUtils.ts', './UserHUD.ts', './MiniProgress.ts', './InGame.ts', './OnboardingMgr.ts', './MessageBox.ts', './CameraController.ts', './PlatformCtrl.ts', './PlayerController.ts', './GameApi.ts', './GameMgr.ts', './MyGiftCell.ts', './MyGift.ts', './RankItem.ts', './RankView.ts', './EndGame.ts', './CollectionItem.ts', './Rotation.ts', './Collection.ts', './ProgressGiftCell.ts', './GiftClaim.ts', './ProgressGiftItem.ts', './ProgressScrollView.ts', './ProgressBarLabelScore.ts', './ProgressBarScore.ts', './Progress.ts', './GiftHistoryCell.ts', './AgeGatePU.ts', './AddTurn.ts', './LeaderboardTopCell.ts', './MissionCell.ts', './HistoryScrollView.ts', './ThinhJumpEffect.ts', './TrailEffect.ts', './History.ts', './Reward.ts', './LeaderboardCell.ts', './Loading.ts', './MusicEffect.ts', './SoundBtn.ts', './AgeGate.ts', './Complete.ts', './ClaimButton.ts', './Mission.ts', './HideTutorial.ts', './AutoPlayer.ts', './Leaderboard.ts', './ApiMock.ts', './maxApi.mjs_cjs=&original=.js'], function () {
  'use strict';

  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});