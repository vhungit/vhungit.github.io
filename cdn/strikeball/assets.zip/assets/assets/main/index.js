System.register("chunks:///_virtual/GameDefine.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      exports({
        EventName: void 0,
        MapName: void 0,
        SoundName: void 0
      });

      cclegacy._RF.push({}, "2206evorXFC47acoQuucOAQ", "GameDefine", undefined);

      class Layer {}

      exports('Layer', Layer);

      _defineProperty(Layer, "Ball", 1 << 0);

      _defineProperty(Layer, "Wall", 1 << 1);

      let MapName;

      (function (MapName) {
        MapName["map_001"] = "map_001";
        MapName["map_002"] = "map_002";
        MapName["map_003"] = "map_003";
        MapName["map_004"] = "map_004";
        MapName["map_005"] = "map_005";
        MapName["map_006"] = "map_006";
        MapName["map_007"] = "map_007";
        MapName["map_008"] = "map_008";
        MapName["map_009"] = "map_009";
        MapName["map_010"] = "map_010";
        MapName["map_011"] = "map_011";
        MapName["map_012"] = "map_012";
        MapName["map_013"] = "map_013";
        MapName["map_014"] = "map_014";
        MapName["map_015"] = "map_015";
        MapName["map_016"] = "map_016";
        MapName["map_017"] = "map_017";
        MapName["map_018"] = "map_018";
        MapName["map_019"] = "map_019";
        MapName["map_020"] = "map_020";
      })(MapName || (MapName = exports('MapName', {})));

      let SoundName;

      (function (SoundName) {
        SoundName["Break1"] = "break1";
        SoundName["Break2"] = "break2";
        SoundName["Break3"] = "break3";
        SoundName["Clear"] = "clear";
        SoundName["Tap01"] = "TAP-01";
        SoundName["Tap02"] = "TAP-02";
        SoundName["Wall"] = "wall";
      })(SoundName || (SoundName = exports('SoundName', {})));

      let EventName;

      (function (EventName) {
        EventName["OnUpdatePitBreakCounter"] = "on-update-pit-break-counter";
        EventName["BallStart"] = "on-ball-start";
        EventName["BallStop"] = "on-ball-stop";
      })(EventName || (EventName = exports('EventName', {})));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/MapManager.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './GameDefine.ts', './GameEvent.ts', './PitController.ts', './BallController.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Material, Prefab, Node, _decorator, Component, Vec4, director, find, randomRangeInt, Camera, Color, resources, instantiate, EventName, MapName, gameEvent, PitController, BallController;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Material = module.Material;
      Prefab = module.Prefab;
      Node = module.Node;
      _decorator = module._decorator;
      Component = module.Component;
      Vec4 = module.Vec4;
      director = module.director;
      find = module.find;
      randomRangeInt = module.randomRangeInt;
      Camera = module.Camera;
      Color = module.Color;
      resources = module.resources;
      instantiate = module.instantiate;
    }, function (module) {
      EventName = module.EventName;
      MapName = module.MapName;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      PitController = module.PitController;
    }, function (module) {
      BallController = module.BallController;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _temp;

      cclegacy._RF.push({}, "51a73DZNadP1IVpqC8pKXAx", "MapManager", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let MapManager = exports('MapManager', (_dec = ccclass('MapManager'), _dec2 = property(Material), _dec3 = property(Material), _dec4 = property(Material), _dec5 = property(Prefab), _dec6 = property(Material), _dec7 = property(Material), _dec8 = property(Node), _dec(_class = (_class2 = (_temp = class MapManager extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "groundMaterial", _descriptor, this);

          _initializerDefineProperty(this, "discMaterial", _descriptor2, this);

          _initializerDefineProperty(this, "boderMaterial", _descriptor3, this);

          _initializerDefineProperty(this, "pitPrefabs", _descriptor4, this);

          _initializerDefineProperty(this, "pitMaterial", _descriptor5, this);

          _initializerDefineProperty(this, "pitBreakMaterial", _descriptor6, this);

          _initializerDefineProperty(this, "stageClear", _descriptor7, this);

          _defineProperty(this, "pits", []);

          _defineProperty(this, "currentMapIndex", 0);

          _defineProperty(this, "mapPrefabs", []);

          _defineProperty(this, "mapCurrent", null);

          _defineProperty(this, "pitHolder", null);

          _defineProperty(this, "ball", null);

          _defineProperty(this, "scene", null);

          _defineProperty(this, "discNumber", 0);

          _defineProperty(this, "pitBreakCounter", 0);

          _defineProperty(this, "colors_background", [[new Vec4(1., 1., 1., 1.), new Vec4(.96, .32, .65, 1.), new Vec4(.4, .4, .4, 1.)], [new Vec4(.96, .91, .26, 1.), new Vec4(.96, .32, .32, 1.), new Vec4(.49, .24, 1., 1.)], [new Vec4(1., .55, .06, 1.), new Vec4(.46, .32, 1., 1.), new Vec4(1., .2, .42, 1.)], [new Vec4(.95, .6, .89, 1.), new Vec4(.87, .22, .24, 1.), new Vec4(0., .73, .86, 1.)], [new Vec4(.82, .8, .99, 1.), new Vec4(.95, .25, .61, 1.), new Vec4(.16, .8, .38, 1.)], [new Vec4(.61, .92, .6, 1.), new Vec4(.08, .71, .55, 1.), new Vec4(.99, .64, 0., 1.)]]);

          _defineProperty(this, "colors_pit", [new Vec4(1., 1., .5, 1.), new Vec4(.5, 1., 1., 1.), new Vec4(1., .5, 1., 1.), new Vec4(.5, 1., .5, 1.), new Vec4(1., .5, .5, 1.), new Vec4(.5, .5, 1., 1.)]);
        }

        onLoad() {
          this.setColors();
          this.loadMap(this.currentMapIndex);
          this.scene = director.getScene();
          this.pitHolder = find('pitHolder');
          gameEvent.on(EventName.OnUpdatePitBreakCounter, this.updatePitBreakCounter, this);
        }

        setColors() {
          let colors = this.colors_background[randomRangeInt(0, this.colors_background.length)];
          let groundColor = colors[0].clone().multiplyScalar(255);
          this.setMaterialColor(this.groundMaterial, groundColor);
          let boderColor = colors[1].clone().multiplyScalar(255);
          this.setMaterialColor(this.boderMaterial, boderColor);
          let discColor = new Vec4(.71, .91, .23, 1.).multiplyScalar(255);
          this.setMaterialColor(this.discMaterial, discColor);
          let backgroundCamera = find('Background/Camera').getComponent(Camera);
          let color = colors[2].clone().multiplyScalar(255);
          backgroundCamera.clearColor = new Color(color.x, color.y, color.z, color.w);
        }

        setMaterialColor(material, colorVec) {
          let color = new Color(colorVec.x, colorVec.y, colorVec.z, colorVec.w);
          material.setProperty('mainColor', color);
        }

        loadMap(index) {
          this.currentMapIndex = index;
          let mapNames = Object.keys(MapName);
          let mapName = mapNames[index];
          resources.load("prefabs/maps/" + mapName, (err, mapPrefab) => {
            if (mapPrefab) {
              this.mapPrefabs[index] = mapPrefab;
              this.initMap(index);
            } else {
              console.warn("Load map: " + mapName + " failed!!!");
            }
          });
        }

        initMap(index) {
          var _this$mapCurrent;

          (_this$mapCurrent = this.mapCurrent) === null || _this$mapCurrent === void 0 ? void 0 : _this$mapCurrent.destroy();
          let mapPrefab = this.mapPrefabs[index];
          let map = instantiate(mapPrefab);
          map.active = true;
          this.mapCurrent = map;
          this.scene.addChild(map);
          this.initBall();
          this.initPit();
          this.setCamera();
        }

        initBall() {
          let char = this.mapCurrent.getChildByName("char");

          if (!this.ball) {
            resources.load("prefabs/ball", (err, ballPrefab) => {
              if (ballPrefab) {
                this.ball = instantiate(ballPrefab);
                this.ball.active = true;
                this.scene.addChild(this.ball);
                this.ball.getComponent(BallController).init(char.position);
              } else {
                console.warn("Load ball failed!!!");
              }
            });
          } else {
            this.ball.getComponent(BallController).init(char.position);
          }
        }

        initPit() {
          this.mapCurrent.children.forEach(child => {
            if (child.name.includes("disc")) {
              this.discNumber++;
              let pitPrefab;

              if (child.name.includes("hard")) {
                pitPrefab = this.pitPrefabs[0];
              } else {
                if (child.name.includes("move")) {
                  pitPrefab = this.pitPrefabs[2];
                } else {
                  pitPrefab = this.pitPrefabs[1];
                }
              }

              let pit = instantiate(pitPrefab);
              pit.position = child.position;
              pit.active = true;
              this.pitHolder.addChild(pit);
              let pitController = pit.getComponent(PitController);
              this.pits.push(pitController);
            }
          });
          this.setPitsColor();
        }

        setPitsColor() {
          this.pits.forEach(pit => {
            let index = randomRangeInt(0, this.colors_pit.length);
            let color = this.colors_pit[index].clone().multiplyScalar(255.);
            pit.setColor(this.pitMaterial, this.pitBreakMaterial, new Color(color.x, color.y, color.z, 255));
          });
        }

        setCamera() {
          let mainCamera = find('Main Camera');
          let mapCamera = this.mapCurrent.getChildByName('Camera');
          mainCamera.setPosition(mapCamera.position);
        }

        resetMap() {
          this.discNumber = 0;
          this.pitBreakCounter = 0;
          this.stageClear.active = false;
          this.mapCurrent.destroy();
          this.pitHolder.removeAllChildren();
        }

        updatePitBreakCounter() {
          this.pits = [];
          this.pitBreakCounter++;

          if (this.pitBreakCounter == this.discNumber) {
            this.endGame();
          }
        }

        endGame() {
          this.stageClear.active = true;
          let ballController = this.ball.getComponent(BallController);
          ballController.offEvent();
          ballController.setEnd();
          setTimeout(() => {
            this.resetMap();
            this.loadMap(++this.currentMapIndex);
          }, 5000);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "groundMaterial", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "discMaterial", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "boderMaterial", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "pitPrefabs", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "pitMaterial", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "pitBreakMaterial", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "stageClear", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PitBreakController.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, cclegacy, Material, _decorator, Component, MeshCollider, MeshRenderer, RigidBody;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Material = module.Material;
      _decorator = module._decorator;
      Component = module.Component;
      MeshCollider = module.MeshCollider;
      MeshRenderer = module.MeshRenderer;
      RigidBody = module.RigidBody;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "5ccd3f1hOlGuaeIddkBpyho", "PitBreakController", undefined);

      const {
        ccclass,
        property,
        executeInEditMode
      } = _decorator;
      let PitBreakController = exports('PitBreakController', (_dec = ccclass('PitBreakController'), _dec2 = executeInEditMode(true), _dec3 = property(Material), _dec4 = property(Material), _dec(_class = _dec2(_class = (_class2 = (_temp = class PitBreakController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "groundMaterial", _descriptor, this);

          _initializerDefineProperty(this, "borderMaterial", _descriptor2, this);
        } // @property(PhysicMaterial) border: PhysicMaterial = null
        // @property(PhysicMaterial) ground: PhysicMaterial = null


        onEnable() {
          // this.node.children.forEach((child) => {
          //     if (!child.getComponent(MeshCollider)) {
          //         let collider = child.addComponent(MeshCollider)
          //         let meshRenderer = child.getComponent(MeshRenderer)
          //         collider.mesh = meshRenderer.mesh
          //         collider.convex = true
          //         child.addComponent(RigidBody)
          //         meshRenderer.setMaterial(this.mat, 0)
          //     }
          //     let meshRenderer = child.getComponent(MeshRenderer)
          //     meshRenderer.setMaterial(this.mat, 0)
          // })
          console.log("Start");
          this.node.children.forEach(child => {
            if (child.name.includes('Cube') || child.name.includes('ground') || child.name.includes('Cylinder')) {
              if (!child.getComponent(MeshCollider)) {
                let collider = child.addComponent(MeshCollider);
                let meshRenderer = child.getComponent(MeshRenderer);
                collider.mesh = meshRenderer.mesh;
                let rigidBody = child.addComponent(RigidBody);
                rigidBody.isStatic = true;
              }
            }

            let meshRenderer = child.getComponent(MeshRenderer);

            if (child.name.includes('ground')) {
              meshRenderer.setMaterial(this.groundMaterial, 0);
            }

            if (child.name.includes('Cube') || child.name.includes('Cylinder')) {
              meshRenderer.setMaterial(this.borderMaterial, 0);
            }
          });
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "groundMaterial", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "borderMaterial", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BallController.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './GameDefine.ts', './AudioManager.ts', './GameEvent.ts', './PitController.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, find, RigidBody, Vec3, Collider, Node, EventName, SoundName, Layer, AudioManager, gameEvent, PitController;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      find = module.find;
      RigidBody = module.RigidBody;
      Vec3 = module.Vec3;
      Collider = module.Collider;
      Node = module.Node;
    }, function (module) {
      EventName = module.EventName;
      SoundName = module.SoundName;
      Layer = module.Layer;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      gameEvent = module.default;
    }, function (module) {
      PitController = module.PitController;
    }],
    execute: function () {
      var _dec, _class, _temp;

      cclegacy._RF.push({}, "5ce348UlY5BOLwdEQVxwgqg", "BallController", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let BallController = exports('BallController', (_dec = ccclass('BallController'), _dec(_class = (_temp = class BallController extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "rb", null);

          _defineProperty(this, "collider", null);

          _defineProperty(this, "scaler", 3);

          _defineProperty(this, "maxLength", 300);

          _defineProperty(this, "arrow", null);

          _defineProperty(this, "canvas", null);

          _defineProperty(this, "isEnd", false);
        }

        onLoad() {
          this.canvas = find('Canvas');
          this.rb = this.node.getComponent(RigidBody);
          this.rb.linearFactor = new Vec3(1, 0, 1);
          this.collider = this.node.getComponent(Collider);
          this.collider.on("onTriggerEnter", this.onTriggerEnter, this);
          this.collider.on("onCollisionEnter", this.onCollisionEnter, this);
          this.arrow = find('arrow');
          this.arrow.active = false;
        }

        update(dt) {
          this.arrow.position = this.node.position;
          let outVec = new Vec3();
          this.rb.getLinearVelocity(outVec);

          if (outVec.length() < 0.6) {
            gameEvent.emit(EventName.BallStop);
            this.rb.clearVelocity();
            this.onEvent();
          }
        }

        init(pos) {
          this.isEnd = false;
          this.node.setPosition(pos);
          this.onEvent();
        }

        setEnd() {
          this.isEnd = true;
        }

        onEvent() {
          if (this.isEnd) return;
          this.canvas.on(Node.EventType.TOUCH_START, this.ontouchstart, this);
          this.canvas.on(Node.EventType.TOUCH_END, this.ontouchend, this);
          this.canvas.on(Node.EventType.TOUCH_MOVE, this.ontouchmove, this);
          this.canvas.on(Node.EventType.TOUCH_CANCEL, this.ontouchend, this);
        }

        offEvent() {
          this.canvas.off(Node.EventType.TOUCH_START, this.ontouchstart, this);
          this.canvas.off(Node.EventType.TOUCH_END, this.ontouchend, this);
          this.canvas.off(Node.EventType.TOUCH_MOVE, this.ontouchmove, this);
          this.canvas.off(Node.EventType.TOUCH_CANCEL, this.ontouchend, this);
        }

        ontouchstart(event) {
          this.arrow.active = true;
          this.arrow.position = this.node.position;
          this.arrow.setScale(1, 1, 0);
        }

        ontouchend(event) {
          this.offEvent();
          this.arrow.active = false;
          let direction = event.getStartLocation().subtract(event.getLocation());
          let force = new Vec3(direction.y, 0, direction.x);
          let length = direction.length();
          force = force.normalize().multiplyScalar(Math.min(length, this.maxLength) * this.scaler);
          this.rb.applyImpulse(force);
        }

        ontouchmove(event) {
          let direction = event.getStartLocation().subtract(event.getLocation());
          this.arrow.setScale(1, 1, Math.min(direction.length(), this.maxLength) / this.maxLength);
          this.arrow.forward = new Vec3(direction.y, 0, direction.x);
        }

        onTriggerEnter(event) {
          let pitController = event.otherCollider.node.getComponent(PitController);
          pitController === null || pitController === void 0 ? void 0 : pitController.spawnPitBreak();
          AudioManager.Instance.playSfx(SoundName.Break1);
        }

        onCollisionEnter(event) {
          if (event.otherCollider.node.layer == Layer.Wall) {
            AudioManager.Instance.playSfx(SoundName.Wall);
          }
        }

      }, _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ComboManager.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './GameDefine.ts', './GameEvent.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, SpriteFrame, Sprite, _decorator, Component, tween, Vec3, EventName, gameEvent;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      SpriteFrame = module.SpriteFrame;
      Sprite = module.Sprite;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      Vec3 = module.Vec3;
    }, function (module) {
      EventName = module.EventName;
    }, function (module) {
      gameEvent = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp;

      cclegacy._RF.push({}, "678f6cxLytHbpFlTLqjlisP", "ComboManager", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let ComboManager = exports('ComboManager', (_dec = ccclass('ComboManager'), _dec2 = property(SpriteFrame), _dec3 = property(Sprite), _dec(_class = (_class2 = (_temp = class ComboManager extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "comboSprites", _descriptor, this);

          _initializerDefineProperty(this, "combo", _descriptor2, this);

          _defineProperty(this, "comboCounter", 0);

          _defineProperty(this, "comboNumer", 0);

          _defineProperty(this, "tweenScale", null);
        }

        start() {
          this.comboNumer = this.comboSprites.length;
          gameEvent.on(EventName.OnUpdatePitBreakCounter, this.onUpdateCombo, this);
          gameEvent.on(EventName.BallStop, this.onResetCombo, this);
        }

        onUpdateCombo() {
          var _this$tweenScale;

          this.comboCounter++;
          if (this.comboCounter > this.comboNumer) this.comboCounter = this.comboNumer;
          this.combo.spriteFrame = this.comboSprites[this.comboCounter - 1];
          (_this$tweenScale = this.tweenScale) === null || _this$tweenScale === void 0 ? void 0 : _this$tweenScale.stop();
          this.tweenScale = tween(this.node).to(0.1, {
            scale: new Vec3(.9, .9, .9)
          }).to(0.1, {
            scale: Vec3.ONE
          }).start();
        }

        onResetCombo() {
          this.comboCounter = 0;
          this.combo.spriteFrame = null;
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "comboSprites", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "combo", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AudioManager.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './GameDefine.ts'], function (exports) {
  'use strict';

  var _defineProperty, cclegacy, _decorator, Component, AudioSource, resources, SoundName;

  return {
    setters: [function (module) {
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
      AudioSource = module.AudioSource;
      resources = module.resources;
    }, function (module) {
      SoundName = module.SoundName;
    }],
    execute: function () {
      var _dec, _class, _class2, _temp;

      cclegacy._RF.push({}, "c17d6fGIyZJhaj7VmodzVIa", "AudioManager", undefined);

      const {
        ccclass,
        property
      } = _decorator;
      let AudioManager = exports('AudioManager', (_dec = ccclass('AudioManager'), _dec(_class = (_temp = _class2 = class AudioManager extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "audioClips", []);

          _defineProperty(this, "bgVolume", 0.4);

          _defineProperty(this, "sfxVolume", 0.7);

          _defineProperty(this, "audioSourceSFX", null);

          _defineProperty(this, "audioSourceMusic", null);

          _defineProperty(this, "IsEnable", true);
        }

        static get Instance() {
          return this.instance;
        }

        onLoad() {
          AudioManager.instance = this;
          this.audioSourceSFX = this.addComponent(AudioSource);
          this.audioSourceSFX.loop = false;
          this.audioSourceSFX.volume = this.sfxVolume;
          this.audioSourceSFX.playOnAwake = false;
          this.audioSourceMusic = this.addComponent(AudioSource);
          this.audioSourceMusic.playOnAwake = false;
          this.audioSourceMusic.play();
          this.loadSound();
        }

        playMusic(clip, loop) {
          if (clip && this.IsEnable) {
            if (this.audioSourceMusic.clip != clip || !this.audioSourceMusic.playing) {
              this.stop();
              this.audioSourceMusic.clip = clip;
              this.audioSourceMusic.loop = loop;
              this.on();
              this.audioSourceMusic.volume = this.bgVolume;
              this.audioSourceMusic.play();
            }
          }
        }

        stop() {
          this.audioSourceMusic.stop();
          this.audioSourceSFX.stop();
        }

        Ssart() {
          if (this.IsEnable) this.audioSourceMusic.play();
        }

        playSfx(name) {
          if (!this.IsEnable) return;
          let clip = this.audioClips.find(clip => clip.name == name);

          if (clip) {
            this.audioSourceSFX.playOneShot(clip);
          }
        }

        StopSfx(name) {
          this.audioClips.forEach(clip => {
            if (clip.name == name && this.audioSourceSFX.clip == clip) {
              if (this.audioSourceSFX.playing) {
                this.audioSourceSFX.stop();
              }
            }

            return;
          });
        }

        playMusicWithName(name, loop) {
          if (!this.IsEnable) return;
          this.audioClips.forEach(clip => {
            if (clip.name == name) {
              this.playMusic(clip, loop);
            }

            return;
          });
        }

        on() {
          this.IsEnable = true;
          this.start();
        }

        off() {
          this.IsEnable = false;
          this.stop();
        }

        nextStatus() {
          this.IsEnable = !this.IsEnable;

          if (this.IsEnable) {
            this.on();
          } else {
            this.off();
          }
        }

        loadSound() {
          let array = Object.keys(SoundName);
          array.forEach(element => {
            let name = SoundName[element];
            resources.load("sounds/" + name, (err, audioClip) => {
              if (audioClip) {
                audioClip.name = name;
                this.audioClips.push(audioClip);
                console.log("Sound loaded: " + name);
              } else {
                console.error("Sound notfound: " + name);
              }
            });
          });
        }

      }, _defineProperty(_class2, "instance", null), _temp)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PitController.ts", ['./_rollupPluginModLoBabelHelpers.js', 'cc', './GameDefine.ts', './GameEvent.ts'], function (exports) {
  'use strict';

  var _applyDecoratedDescriptor, _initializerDefineProperty, _defineProperty, cclegacy, Enum, _decorator, Component, tween, randomRange, Vec3, Material, MeshRenderer, resources, instantiate, director, RigidBody, ParticleSystem, EventName, gameEvent;

  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _defineProperty = module.defineProperty;
    }, function (module) {
      cclegacy = module.cclegacy;
      Enum = module.Enum;
      _decorator = module._decorator;
      Component = module.Component;
      tween = module.tween;
      randomRange = module.randomRange;
      Vec3 = module.Vec3;
      Material = module.Material;
      MeshRenderer = module.MeshRenderer;
      resources = module.resources;
      instantiate = module.instantiate;
      director = module.director;
      RigidBody = module.RigidBody;
      ParticleSystem = module.ParticleSystem;
    }, function (module) {
      EventName = module.EventName;
    }, function (module) {
      gameEvent = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _temp;

      cclegacy._RF.push({}, "cb937Hy7iRG4Lmi4bEDP0Xo", "PitController", undefined);

      const {
        ccclass,
        property,
        type
      } = _decorator;
      var PitType;

      (function (PitType) {
        PitType[PitType["TYPE1"] = 0] = "TYPE1";
        PitType[PitType["TYPE2"] = 1] = "TYPE2";
        PitType[PitType["TYPE3"] = 2] = "TYPE3";
      })(PitType || (PitType = {}));

      Enum(PitType);
      let PitController = exports('PitController', (_dec = ccclass('PitController'), _dec2 = property({
        type: PitType
      }), _dec(_class = (_class2 = (_temp = class PitController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "type", _descriptor, this);

          _defineProperty(this, "pitBreak", null);

          _defineProperty(this, "starPartical", null);

          _defineProperty(this, "isHaftBreak", false);

          _defineProperty(this, "mat", null);

          _defineProperty(this, "breakMat", null);
        }

        start() {
          if (this.type == PitType.TYPE3) {
            tween(this.node).delay(randomRange(2, 4)).by(.3, {
              position: new Vec3(0, -2, 0)
            }, {
              easing: "sineIn"
            }).delay(randomRange(2, 4)).by(.3, {
              position: new Vec3(0, 2, 0)
            }, {
              easing: "sineOut"
            }).union().repeatForever().start();
          }
        }

        setColor(material, pitBreakMaterial, color) {
          this.mat = new Material();
          this.mat.copy(material);
          this.getComponentInChildren(MeshRenderer).setMaterial(this.mat, 0);
          this.mat.setProperty('mainColor', color);
          this.breakMat = new Material();
          this.breakMat.copy(pitBreakMaterial);
          this.breakMat.setProperty('mainColor', color);
          this.initPitBreak();
        }

        initPitBreak() {
          resources.load("prefabs/pit_break", (err, pitBreakPrefab) => {
            if (pitBreakPrefab) {
              this.pitBreak = instantiate(pitBreakPrefab);
              director.getScene().addChild(this.pitBreak);
              this.pitBreak.setPosition(new Vec3(0, 100, 0));
              this.pitBreak.children.forEach(child => {
                child.getComponent(MeshRenderer).setMaterial(this.breakMat, 0);
                let rigidbody = child.getComponent(RigidBody);
                rigidbody.isStatic = true;
              });
              console.log("Load pit break success!");
            } else {
              console.warn("Load pit break fail, can't spawn !!!");
            }
          });
          resources.load("prefabs/star_particle", (err, starParticalPrefab) => {
            if (starParticalPrefab) {
              this.starPartical = instantiate(starParticalPrefab);
              this.starPartical.active = false;
              this.starPartical.setParent(this.node.parent);
              this.starPartical.setPosition(this.node.position);
              console.log("Load star particle success!");
            } else {
              console.warn("Load star particle fail, can't spawn !!!");
            }
          });
        }

        spawnPitBreak() {
          if (this.starPartical) {
            var _this$starPartical$ge;

            this.starPartical.active = true;
            (_this$starPartical$ge = this.starPartical.getComponent(ParticleSystem)) === null || _this$starPartical$ge === void 0 ? void 0 : _this$starPartical$ge.play();
          }

          if (this.type == PitType.TYPE1) {
            this.node.children[0].active = false;

            if (this.pitBreak) {
              this.pitBreak.children.forEach((child, index) => {
                if (this.isHaftBreak) {
                  child.getComponent(RigidBody).isStatic = false;
                }

                if (index >= 6 && !this.isHaftBreak) {
                  child.getComponent(RigidBody).isStatic = false;
                }
              });
              this.pitBreak.setPosition(this.node.position);
            }

            if (this.isHaftBreak) {
              this.updatePitBreakCounter();
              this.fade();
            } else {
              this.isHaftBreak = true;
            }
          } else {
            if (this.pitBreak) {
              this.pitBreak.children.forEach(child => {
                child.getComponent(RigidBody).isStatic = false;
              });
              this.pitBreak.setPosition(this.node.position);
            }

            this.node.active = false;
            this.updatePitBreakCounter();
            this.fade();
          }
        }

        destroyPit() {
          var _this$node, _this$pitBreak;

          (_this$node = this.node) === null || _this$node === void 0 ? void 0 : _this$node.destroy();
          (_this$pitBreak = this.pitBreak) === null || _this$pitBreak === void 0 ? void 0 : _this$pitBreak.destroy();
        }

        updatePitBreakCounter() {
          gameEvent.emit(EventName.OnUpdatePitBreakCounter);
        }

        fade() {
          let color;
          color = this.breakMat.getProperty('mainColor');
          tween({
            alpha: 255
          }).delay(1).to(2, {
            alpha: 100
          }, {
            onUpdate: (target, ratio) => {
              var _this$breakMat;

              color.a = target.alpha;
              (_this$breakMat = this.breakMat) === null || _this$breakMat === void 0 ? void 0 : _this$breakMat.setProperty('mainColor', color);
            },
            easing: "sineIn"
          }).call(() => {
            this.destroyPit();
          }).start();
        }

      }, _temp), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "type", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return PitType.TYPE1;
        }
      }), _class2)) || _class));

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameEvent.ts", ['cc'], function (exports) {
  'use strict';

  var cclegacy, EventTarget;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      EventTarget = module.EventTarget;
    }],
    execute: function () {
      cclegacy._RF.push({}, "cf9d40nuDZHO4TL11ffdiT4", "GameEvent", undefined);

      let gameEvent = exports('default', new EventTarget());

      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/main", ['./GameDefine.ts', './AudioManager.ts', './GameEvent.ts', './PitController.ts', './BallController.ts', './MapManager.ts', './PitBreakController.ts', './ComboManager.ts'], function () {
  'use strict';

  return {
    setters: [null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});