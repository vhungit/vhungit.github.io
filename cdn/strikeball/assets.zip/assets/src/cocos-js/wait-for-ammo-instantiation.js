System.register(['./instantiated-abfb7b3d.js'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('default', module.hj);
		}],
		execute: function () {



		}
	};
});
